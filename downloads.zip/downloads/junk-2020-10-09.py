import pandas as pd

f1=open('test.csv','w')
f=open('test.txt','r')
l=f.readlines()
t=[]
for lii in l:
    li=str(lii)
    if 'arcgis.com' in li.lower() and 'https' in li.lower() and 'query' in li.lower():
        li=li.replace('Invoke-WebRequest -Uri "','').replace('" -Headers @{','')
        # if li.replace('Invoke-WebRequest -Uri "','').replace('" -Headers @{','') not in t:
        if True:
            print(li.split('?')[0])
            found=0
            for ti in t:
                if (li.split('?')[0]) in str(ti):
                    found=1
                    break
            print(found)
            if found==0:
                print(li.replace('Invoke-WebRequest -Uri "','').replace('" -Headers @{',''))
                t.append(li.replace('Invoke-WebRequest -Uri "','').replace('" -Headers @{',''))
                f1.write(li.replace('Invoke-WebRequest -Uri "','').replace('" -Headers @{','')+"")
print(len(l))
t=list(set(l))
print(len(t))
# df=pd.DataFrame()
# df['test']=t
# df.to_csv('test.csv')
f1.close()
f.close()

# import json
# import pandas 
# print(pandas.read_json('experience.arcgis.com.har'))
# obj = json.loads('experience.arcgis.com.har')
# urls = [ entry['request']['url'] for entry in obj['log']['entries'] ]

# from selenium import webdriver
# from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
# from selenium.webdriver.chrome.options import Options

# def get_perf_log_on_load(url, headless = True, filter = None):

#     # init Chrome driver (Selenium)
#     options = Options()
#     options.headless = headless
#     cap = DesiredCapabilities.CHROME
#     cap['loggingPrefs'] = {'performance': 'ALL'}
#     driverpath = "C:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
#     driver = webdriver.Chrome(desired_capabilities = cap, options = options,executable_path=driverpath)
#     driver.get(url)
#     if filter: log = [item for item in driver.get_log('performance')
#                       if filter in str(item)]
#     else: log = driver.get_log('performance')
#     driver.close()

#     return log

# get_perf_log_on_load('https://experience.arcgis.com/experience/ed2def13f9b045eda9f7d22dbc9b500e')