import csv
import time
import params
import datetime
import requests
import zipfile, io
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.ie.options import Options
from selenium.webdriver.support.ui import WebDriverWait

"""
Resources detail:
https://dph.georgia.gov/covid-19-daily-status-report
Data scrapped can be download from the web site directly
"""
# -----------------------------edit end for state----------------------------
fileout_county_name = 'GA_county_test'
fileout_state_name = 'GA_ICU_Case'

file_county_out = (params.file_url + fileout_county_name + params.csvfile)
file_state_out = (params.file_url + fileout_state_name + params.csvfile)

class my_dictionary(dict):
    # __init__ function 
    def __init__(self):
        self = dict()    
    # Function to add key:value
    def add(self, key, value):
        self[key] = value

def scrap_function():
    url = 'https://ga-covid19.ondemand.sas.com/'
    
    options = webdriver.ChromeOptions()
    # options.add_argument('--headless')
    driver = webdriver.Chrome(chrome_options=options, executable_path="C:\ProgramData\ChromeDriver_83\chromedriver.exe")

    """
    ie_options = Options()
    ie_options.ignore_protected_mode_settings = True
    driver = webdriver.Ie(options=ie_options, executable_path="C:\\Program Files\\IEDriverServer\\3.150.0\\IEDriverServer.exe")
    """

    driver.get(url)
    driver.implicitly_wait(10)
    time.sleep(10)
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    #print(soup.prettify())

    """
    Get latest updated date
    """
    updated_time_text = soup.find_all("p", class_="MuiTypography-root MuiTypography-body1 MuiTypography-colorTextSecondary")[0].text
    updated_time_text = updated_time_text[updated_time_text.index('as of') + 6: updated_time_text.index('as of') + 15].strip()
    updated_time_text = updated_time_text.replace(",", "")

    """
    Get State metric 
    """
    header = []
    data = []
    header.append("Date")
    data.append(updated_time_text)
    header.append("Total Tests")

    table = soup.find('table', class_="MuiTable-root")
    data_rows = table.select('tbody > tr')
    data_row  = data_rows[0]
    data.append((data_row.find_all('td')[-1]).text.replace(",", "").strip())

    divs = soup.find_all('div', class_="MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-3 MuiGrid-grid-lg-3")
    count = 0
    for div in divs:
        if (count == 0):
            #header.append(div.find("div").find("h2").text.replace("*", "").strip())
            #data.append(div.find("div").find("p").text.replace(",", "").strip())
            header.append(div.find("h2").text.replace("*", "").strip())
            data.append(div.find("p").text.replace(",", "").strip())
        else:
            header.append(div.find("h2").text.replace("*", "").strip())
            data.append(div.find("p").text.replace(",", "").strip())
        count = count + 1

    with open(file_state_out, 'w', newline='\n') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(header)
        writer.writerow(data)
    """
    Get County metric
    """
    table = soup.find('table', class_="MuiTable-root MuiTable-stickyHeader")
    header_rows = table.select('thead > tr')
    header = []
    header.append("Date")
    for th in header_rows[0].find_all('th'):
        header.append(th.find('span').text)

    with open(file_county_out, 'w', newline='\n') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(header)
        data_rows = table.select('tbody > tr')
        for data_row in data_rows:
            data = [updated_time_text]
            for td in data_row.find_all('td'):
                data.append(td.text.replace(",", "").strip())
            writer.writerow(data)

    driver.close()
    driver.quit()

def GA_file():
    web_url = 'https://ga-covid19.ondemand.sas.com/docs/ga_covid_data.zip'
    r = requests.get(web_url)
    z = zipfile.ZipFile(io.BytesIO(r.content))
    z.extractall(params.file_url)
    print('GA raw files extracted')

if __name__ == "__main__":
    print("Georgia Working")
    try:
        GA_file()
        #scrap_function()
    except Exception as identifier:
        raise(identifier)
    finally:
        print("Georgia Completed")