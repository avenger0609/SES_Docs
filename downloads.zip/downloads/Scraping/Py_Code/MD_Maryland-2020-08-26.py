import csv
import params
import requests

"""Resources detail: Update dashboard link """        

# ----------------------------Assign source URLs----------------------------
source_url = ['https://services.arcgis.com/njFNhDsUCentVYJW/ArcGIS/rest/services/MASTERCaseTracker/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json',
'https://services.arcgis.com/njFNhDsUCentVYJW/arcgis/rest/services/MDH_COVID_19_Dashboard_Feature_Layer_Counties_MEMA/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]
# ----------------------------Assign output file name----------------------------
fileout_name = ['MD_state_master', 'MD_county_test']
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x] + ": Complete")
#----------------------Call Function--------------------------
if __name__ == "__main__":
    print("Maryland In Progress")
# -----------------------------loop through all sources----------------------------
    for x in range(len(fileout_name)):
        file_out = (params.file_url + fileout_name[x] + params.csvfile)
        url = source_url[x]
        
        scrap_function(url, file_out)
    print("Maryland Complete")