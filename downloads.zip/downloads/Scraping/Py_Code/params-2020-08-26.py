file_url = 'C:\\Users\\rsing45\\Documents\\PRJ_Covid\\Scraping\\Data\\Raw\\'
csvfile = '.csv'
xlfile = '.xlsx'