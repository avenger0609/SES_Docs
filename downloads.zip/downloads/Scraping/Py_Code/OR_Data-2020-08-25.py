import pandas as pd
import params
import csv

'''Resource details - Update dashboard link'''

file_path = params.file_url

inputfile1 = 'OR_state_coviddetails.csv'
inputfile2 = 'OR_state_hosp.csv'
inputfile3 = 'OR_state_test.csv'

outfile = 'OR_State_Final.csv'

#--------------------------------------OR_state_coviddetails.csv-------------------------------------------------------------------
file = file_path + inputfile1
df1 = pd.read_csv(file)
df1_1 = df1.filter(["COVID-19 details5", "Patients with suspected or confirmed COVID-19"])

df1_2 = df1.filter(["COVID-19 details5", "Only patients with confirmed COVID-19"])

df1_2_T = df1_2.T.reset_index().rename(columns={'index':'COVID-19 details5'})
df1_2_T.columns = df1_2_T.iloc[0]
df1_2_T = df1_2_T.reindex(df1_2_T.index.drop(0)).reset_index(drop=True)
df1_2_T.columns.name = None

#---------------------------------------------OR_state_hosp.csv---------------------------------------------------------------------
file = file_path + inputfile2
df2 = pd.read_csv(file)
df2_1 = df2.filter(["Hospital capacity and usage5", "Available"])

df2_1_T = df2_1.T.reset_index().rename(columns={'index':'Hospital capacity and usage5'})
df2_1_T.columns = df2_1_T.iloc[0]
df2_1_T = df2_1_T.reindex(df2_1_T.index.drop(0)).reset_index(drop=True)
df2_1_T.columns.name = None

#------------------------------------------------OR_state_test.csv--------------------------------------------------------------------
file = file_path + inputfile3
df3 = pd.read_csv(file)
df3_T = df3.T.reset_index().rename(columns={'index':'Key'})
df3_T.columns = df3_T.iloc[0]
df3_T = df3_T.reindex(df3_T.index.drop(0)).reset_index(drop=True)
df3_T.columns.name = None

result = pd.concat([df3_T, df1_2_T, df2_1_T], axis=1, sort=False)

print(result)
result.to_csv(file_path + outfile, index = False)