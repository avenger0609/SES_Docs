import csv
import params
import requests
from pathlib import Path
from bs4 import BeautifulSoup

"""
Resources detail: url = 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173---,00.html'
"""
url = 'https://www.michigan.gov/coronavirus/0,9753,7-406-98163_98173---,00.html'
folder_location = params.file_url + 'MI_'
preurl = 'https://www.michigan.gov'
filetype = ".xlsx"
# -----------------------------function declaration----------------------------
def scrap_function(url, folder_location, preurl, filetype):   
    try:
        page = requests.get(url)
        soup = BeautifulSoup(page.content, 'html.parser')
        links = soup.find_all('a')
        for i, tag in enumerate(links[0:]):
            link = tag.get('href',None)
            if link is not None:
                result1 = link.find('/documents/coronavirus/')
                if result1 != -1:
                    # print("index: " + str(i))
                    result = link[23:]
                    filename = result[:result.find("_2020")]
                    fileout = folder_location + filename + filetype
                    url1 = preurl + link
                    # print(link)
                    print(filename)
                    # print(url1)
                    response = requests.get(url1)
                    output = open(fileout, 'wb')
                    output.write(response.content)
                    output.close()  
    except Exception as identifier:
        raise(identifier)
    finally:
        print(filename + ": Complete")

if __name__ == "__main__":
    print("Michigan In Progress")
    scrap_function(url, folder_location, preurl, filetype)