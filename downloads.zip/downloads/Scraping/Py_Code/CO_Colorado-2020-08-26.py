import csv
import params
import requests

"""
Resources detail:
OpenDataRepo: https://data-cdphe.opendata.arcgis.com/search?tags=covid19
"""
# ----------------------------------------------------Assign source URLs----------------------------
source_url = ['https://services.arcgis.com/seTexOicoRXDvRsJ/ArcGIS/rest/services/DouglasCounty_COVID19_View/FeatureServer/1/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services3.arcgis.com/66aUo8zsujfVXRIT/arcgis/rest/services/colorado_covid19_county_statistics_cumulative/FeatureServer/0/query?where=1%3D1&outFields=*&outSR=4326&f=json'
, 'https://services3.arcgis.com/66aUo8zsujfVXRIT/arcgis/rest/services/colorado_covid19_daily_state_statistics_cumulative/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services.arcgis.com/seTexOicoRXDvRsJ/arcgis/rest/services/DouglasCounty_COVID19_View/FeatureServer/2/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services.arcgis.com/seTexOicoRXDvRsJ/arcgis/rest/services/DouglasCounty_COVID19_View/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services3.arcgis.com/66aUo8zsujfVXRIT/arcgis/rest/services/Colorado_COVID19_Positive_Cases/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]
#--------------------------------------------------Assign output file names--------------------------------
fileout_name = ['CO_State_test','CO_CountyLevelData', 'CO_state_case_hosp', 'CO_age_hosp_death', 'CO_county_death', 'CO_county_population']
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False      
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
        

    except Exception as identifier:
        raise(identifier)
    finally:
        print("Colorado Complete")
#----------------------------Call function----------------------------------------
if __name__ == "__main__":
    print("Colorado In Progress")
# -----------------------------loop through all sources----------------------------
for x in range(len(fileout_name)):
    file_out = (params.file_url + fileout_name[x] + params.csvfile)
    url = source_url[x]
    
    scrap_function(url, file_out)
