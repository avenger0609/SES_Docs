import csv
import params
import requests

"""Resources detail: https://www.nj.gov/health/cd/topics/covid2019_dashboard.shtml """
# ----------------------------Assign source URLs----------------------------
source_url = ['https://services7.arcgis.com/Z0rixLlManVefxqY/arcgis/rest/services/DailyCaseCounts/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services7.arcgis.com/Z0rixLlManVefxqY/ArcGIS/rest/services/DailyCasesLong/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services7.arcgis.com/Z0rixLlManVefxqY/ArcGIS/rest/services/survey123_cb9a6e9a53ae45f6b9509a23ecdf7bcf/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services7.arcgis.com/Z0rixLlManVefxqY/ArcGIS/rest/services/COVID_Zip_Code_Data/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services7.arcgis.com/Z0rixLlManVefxqY/ArcGIS/rest/services/Data_By_Zip_Code/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services7.arcgis.com/Z0rixLlManVefxqY/ArcGIS/rest/services/PPE_Capacity/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services7.arcgis.com/Z0rixLlManVefxqY/ArcGIS/rest/services/NJ_State_Psychiatric_Hospital_Survey/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]
#-----------------------------Assign output file name------------------------
fileout_name = ['NJ_county', 'NJ_state', 'NJ_survey', 'NJ_zip', 'NJ_zip_data', 'NJ_PPE', 'NJ_hosp']
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x]+": Complete")
#-----------------------Call function-------------------------------
if __name__ == "__main__":
    print("New Jersey In Progress")
# -----------------------------loop through all sources-------------
    for x in range(len(fileout_name)):
        file_out = (params.file_url + fileout_name[x] + params.csvfile)
        url = source_url[x]
        
        scrap_function(url, file_out)
    print("New Jersey Complete")