import csv
import urllib
import params
import requests
import pandas as pd

"""Update sourece location: """
#---------------------------------------------Source URL----------------------------------------------------
source_url = ['https://www.cdc.gov/nhsn/pdfs/covid19/covid19-NatEst.csv']
#-----------------------------------Destination file name and path -----------------------------------------
fileout = ['NHSN_COVID19']
#------------------------------------------------Function declaration -----------------------------------------
def scrap_function(url, file_out):
    try:
        req = requests.get(url, verify=False)
        url_content = req.content
        csv_file = open(file_out, 'wb')
        csv_file.write(url_content)
        csv_file.close()
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": complete")

#---------------------------Call Function and loop through all sources----------------------------------------
if __name__ == "__main__":
    print("NHSN In Progress")

    for x in range(len(fileout)):
        file_out = (params.file_url + fileout[x] + params.csvfile)
        url = source_url[x]
        
        scrap_function(url, file_out)
    print("NHSN complete")