import pandas as pd
import csv
import params
import urllib
import requests

url = "https://coronavirus.ohio.gov/static/COVIDSummaryData.csv"
outfile = 'OH_summary'

rawfile = params.file_url + outfile + params.csvfile

#-----------------Download csv file ------------------------

urllib.request.urlretrieve(url, rawfile)
print(outfile + ": Download Complete")
