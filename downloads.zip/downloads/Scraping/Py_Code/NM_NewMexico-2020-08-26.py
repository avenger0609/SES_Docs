import csv
import params
import requests

"""
Resources detail: Update dashboard link """
# ----------------------------Assign source URLs----------------------------
source_url = ['https://e7p503ngy5.execute-api.us-west-2.amazonaws.com/prod/GetPublicStatewideData'
, 'https://e7p503ngy5.execute-api.us-west-2.amazonaws.com/prod/GetCounties']
#-----------------------------Assign output file name-----------------------
fileout = ['NM_State', 'NM_County']
#----------------------------Function declaration---------------------------
def scrap_function_state(url, file_out):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["data"]

        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow((data_feature).keys())
            writer.writerow((data_feature).values())         
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": Complete")
# -----------------------------function declaration----------------------------
def scrap_function_county(url, file_out):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["data"]

        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data_feature:
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": Complete")
#-------------------Call function and loop through all sources-----------------
if __name__ == "__main__":
    myFunc = [scrap_function_state, scrap_function_county]
    print("New Mexico In Progress")
    try:
        for x in range(len(fileout)):
            file_out = (params.file_url + fileout[x] + params.csvfile)
            url = source_url[x]
            myFunc[x](url, file_out)
    except Exception as identifier:
        raise(identifier)
    finally:
        print("New Mexico complete")
