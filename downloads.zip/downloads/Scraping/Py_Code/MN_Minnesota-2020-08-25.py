import csv
import params
import requests
import pandas as pd 
import datetime

'''Resource details - https://mn.gov/covid19/data/covid-dashboard/index.jsp'''
# -----------------------------Assign source URLs----------------------------
source_url = ['https://services2.arcgis.com/V12PKGiMAH7dktkU/arcgis/rest/services/MyMapService/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services2.arcgis.com/V12PKGiMAH7dktkU/ArcGIS/rest/services/PositiveCountyCount/FeatureServer/0/query?where=1%3D1&outFields=*&outSR=4326&f=json'
]
#-----------------------------Assign output file name---------------------------
fileout_name = ['MN_state_output', 'MN_county_count']
#-----------------------------Function declaration------------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x]+": Complete")
#----------------------Call function---------------------------------------
if __name__ == "__main__":
    print("Minnesota in progress")
#----------------------Loop through all sources----------------------------
    for x in range(len(fileout_name)):
        file_out = (params.file_url + fileout_name[x] + params.csvfile)
        url = source_url[x]
        scrap_function(url, file_out)
    print("Minnesota complete")
