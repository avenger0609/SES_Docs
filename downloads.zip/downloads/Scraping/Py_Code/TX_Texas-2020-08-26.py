import csv
import requests
import params

"""Resources Detail: update dashboard link"""
#-----------------------Assign source URLs--------------------
source_url = ['https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_TestData_Service/FeatureServer/3/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/0/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_TestData_Service/FeatureServer/0/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_TestData_Service/FeatureServer/1/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID_Hospital_Data/FeatureServer/0/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID_Hospital_Data/FeatureServer/1/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/1/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/2/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/3/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/4/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/5/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/6/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/7/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_Cases_Service/FeatureServer/8/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
,'https://services5.arcgis.com/ACaLB9ifngzawspq/ArcGIS/rest/services/DSHS_COVID19_TestData_Service/FeatureServer/2/query?f=json&outFields=*&where=1%3D1&returnGeometry=false'
]
#-----------------------Assign output file name--------------------
fileout = ['TX_state_testcount', 'TX_county_testresult', 'TX_county_testcount', 'TX_state_hospitalization', 'TX_hosp_data1', 'TX_hosp_data2'
,'TX_CaseAge', 'TX_CaseGender', 'TX_CaseRace', 'TX_FatalityAge', 'TX_FatalityGender', 'TX_FatalityRace', 'TX_RecoveredActive', 'TX_Trend', 'TX_test_type'
]
#-----------------------Function declaration--------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False

        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values())
    
    except Exception as identifier:
        raise(identifier)
    finally:
        print( fileout[x] + ": Completed")

# -----------------------------Call function and loop through all sources----------------------------
if __name__ == "__main__":
    print("Texas In Progress")

    for x in range(len(fileout)):
        file_out = (params.file_url + fileout[x] + params.csvfile)
        url = source_url[x]
        scrap_function(url, file_out)
    print("Texas Completed")