import pandas as pd
import csv
import params
import urllib
import requests

'''Resource details - https://coronavirus.health.ok.gov/ and https://looker-dashboards.ok.gov/embed/dashboards/63 '''
#---------------------------------------------Assign source URLs-------------------------------------------
source_url = ['https://storage.googleapis.com/ok-covid-gcs-public-download/oklahoma_cases_county.csv'
,'https://storage.googleapis.com/ok-covid-gcs-public-download/oklahoma_cases_city.csv'
,'https://storage.googleapis.com/ok-covid-gcs-public-download/oklahoma_cases_zip.csv'
,'https://storage.googleapis.com/ok-covid-gcs-public-download/oklahoma_cases_osdh_district.csv'
,'https://storage.googleapis.com/ok-covid-gcs-public-download/oklahoma_cases_osdh_county.csv'
]
#-----------------------------------Assign output file name----------------------------------------
fileout = ['OK_county', 'OK_city', 'OK_zip', 'OK_OSDH_districts', 'OK_OSDH_counties']
#-----------------------------------Function declaration-----------------------------------------
def scrap_function(url, file_out):
    try:
        urllib.request.urlretrieve(url, file_out)
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": complete")

#----------------------------------------------Call Function-----------------------------------------------
if __name__ == "__main__":
    print("OK In Progress")
# -----------------------------loop through all sources----------------------------
for x in range(len(fileout)):
    file_out = (params.file_url + fileout[x] + params.csvfile)
    url = source_url[x]
    scrap_function(url, file_out)
print("OK Complete")