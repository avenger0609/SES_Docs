import csv
import params
import requests

# ----------------------------Assign source URLs----------------------------
source_url = ['https://raw.githubusercontent.com/nytimes/covid-19-data/master/us.csv'
, 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-states.csv'
, 'https://raw.githubusercontent.com/nytimes/covid-19-data/master/us-counties.csv'
]
#---------------------------Assign output file name-----------------------------
fileout = ['NYT_USA', 'NYT_USA_States', 'NYT_USA_Counties']

# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        req = requests.get(url)
        url_content = req.content
        csv_file = open(file_out, 'wb')
        csv_file.write(url_content)
        csv_file.close()
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": Complete")
#------------------Call function and loop through all sources------------------
if __name__ == "__main__":
    for x in range(len(fileout)):
        file_out = (params.file_url + fileout[x] + params.csvfile)
        url = source_url[x]
        scrap_function(url, file_out)