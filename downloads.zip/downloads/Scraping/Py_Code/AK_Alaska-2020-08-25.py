import csv
import datetime
import requests
import params

"""
Resources detail: https://experience.arcgis.com/experience/6a5932d709ef4ab1b868188a4c757b4f :: https://covid19.alaska.gov/
"""
#----------------------------------------------Assign source URLs-------------------------------------------------
source_url = ['https://services1.arcgis.com/WzFsmainVTuD5KML/ArcGIS/rest/services/COVID_Hospital_Dataset_(prod)/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services1.arcgis.com/WzFsmainVTuD5KML/ArcGIS/rest/services/Daily_Testing_Summary_Occurrence/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services1.arcgis.com/WzFsmainVTuD5KML/ArcGIS/rest/services/Tests_Dataset/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services1.arcgis.com/WzFsmainVTuD5KML/ArcGIS/rest/services/Demographic_Distribution_of_Confirmed_Cases/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services1.arcgis.com/WzFsmainVTuD5KML/ArcGIS/rest/services/Demographics/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]
#----------------------------------------------Assign Output file names-------------------------------------------------
fileout_name = ['AK_region_bed', 'AK_test', 'AK_county_test', 'AK_demographic_distribution', 'AK_demographics']
#---------------------------------------------------function declaration-------------------------------------------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x] + ": Complete")

if __name__ == "__main__":
    print("Alaska In Progress")
# -----------------------------loop through all sources----------------------------
    for x in range(len(fileout_name)):
        file_out = (params.file_url + fileout_name[x] + params.csvfile)
        url = source_url[x]
        scrap_function(url, file_out)
    print("Alaska Complete")