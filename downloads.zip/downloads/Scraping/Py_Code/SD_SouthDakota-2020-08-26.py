import csv
import params
import requests

"""Resources detail: Update dashboard link"""
# ----------------------------Assign source URLs----------------------------
source_url = ['https://services.arcgis.com/YpECgwASS4iMvgsA/arcgis/rest/services/SD_COVID19_Data/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services.arcgis.com/YpECgwASS4iMvgsA/arcgis/rest/services/Cases_public/FeatureServer/1/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]
#----------------------------Assign output file name-----------------------
fileout = ['SD_county_data', 'SD_state_data']

# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": Complete")
# ------------------Call function and loop through all sources---------------------
if __name__ == "__main__":
    print("SD in Progress")

for x in range(len(fileout)):
    file_out = (params.file_url + fileout[x] + params.csvfile)
    url = source_url[x]
    scrap_function(url, file_out)
print("SD complete")