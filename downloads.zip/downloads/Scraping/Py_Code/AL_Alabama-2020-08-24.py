import csv
import datetime
import requests
import params

"""
Resources detail:
County test             url = 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/ArcGIS/rest/services/COV19_Public_Dashboard_ReadOnly2/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
State ICU Vent          url = 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/c19v2_hcw_ltcf_PUBLIC/FeatureServer/1/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
Dashboard               url = 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/ArcGIS/rest/services/COV19_Public_Dashboard_ReadOnly2/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
Demograpic              url = 'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/'
"""        
# ----------------------------edit for each state----------------------------
source_url = ['https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/ArcGIS/rest/services/COV19_Public_Dashboard_ReadOnly2/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/c19v2_hcw_ltcf_PUBLIC/FeatureServer/1/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/1/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/2/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
,'https://services7.arcgis.com/4RQmZZ0yaZkGR1zy/arcgis/rest/services/Statewide_COVID19_CONFIRMED_DEMOG_PUBLIC/FeatureServer/3/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]

fileout_name = ['AL_county_test','AL_state_bed','AL_Statewide_Age_Group','AL_Statewide_Ethnicity','AL_Statewide_Gender','AL_Statewide_Race']
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 

    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x] + ": Complete")

if __name__ == "__main__":
    print("Alabama In Progress")
# -----------------------------loop through all sources----------------------------
    for x in range(len(fileout_name)):
        file_out = (params.file_url + fileout_name[x] + params.csvfile)
        url = source_url[x]
        
        scrap_function(url, file_out)
    print("Alabama Complete")