import csv
import params
import pandas as pd
def main():
    
    try:
        print("CO file processing start")

        inputfile = 'CO_CountyLevelData.csv'
        outfile = 'CO_couny_test.csv'

        rawfile = params.file_url + inputfile

        df = pd.read_csv(rawfile)
        df1 = df.filter(["Date", "FULL_", "Metric", "Value", "Rate", "Desc_"])

        is_cases = df1['Metric'] == "Cases"
        is_totaltest = df1['Metric'] == "Total Tests Performed"
        is_serology = df1['Metric'] == "Percent of tests by Serology"
        is_pcr = df1['Metric'] == "Percent of tests by PCR"

        df_cases = df1[is_cases]
        df_cases.rename(columns={'Value': 'TotalPositive'}, inplace=True)
        df_cases = df_cases.filter(["Date", "FULL_", "TotalPositive"])

        df_totaltest = df1[is_totaltest]
        df_totaltest.rename(columns={'Value': 'TotalTests'}, inplace=True)
        df_totaltest = df_totaltest.filter(["Date", "FULL_", "TotalTests"])

        df_serology = df1[is_serology]
        df_serology.rename(columns={'Rate': 'PercentSerology'}, inplace=True)
        df_serology = df_serology.filter(["Date", "FULL_", "PercentSerology"])

        df_pcr = df1[is_pcr]
        df_pcr.rename(columns={'Rate': 'PercentPCR'}, inplace=True)
        df_pcr = df_pcr.filter(["Date", "FULL_", "PercentPCR"])

        merged_df = pd.merge(df_cases,df_totaltest,how='left',on=['Date','FULL_'])
        merged_df = pd.merge(merged_df,df_serology,how='left',on=['Date','FULL_'])
        merged_df = pd.merge(merged_df,df_pcr,how='left',on=['Date','FULL_'])

        merged_df.to_csv(params.file_url + outfile, index = False)

        print("CO file processing complete")
    
    except Exception as identifier:
        raise(identifier)
    finally:
        print("CO file processing complete")
        print("New file: " + outfile)


if __name__ == "__main__":
    main()