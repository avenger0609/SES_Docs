import os
import csv
import params
import urllib
import requests

'''
Dashboard URL - https://www.coronavirus.in.gov/2393.htm
TestingInfo URL - https://www.coronavirus.in.gov/2524.htm
Dataset URL - https://hub.mph.in.gov/dataset?q=COVID
'https://hub.mph.in.gov/dataset/c2c241cf-cf92-4870-9ac3-a59328f12c33/resource/efdfe6bc-0637-4210-bdc9-06ccdf5b0dab/download/ltc_facility_cases_and_deaths.xlsx'
'IN_LTC'
'''
#----------------------------------------------------Assign source URLs------------------------------------------------------------
f_source_url = ['https://hub.mph.in.gov/dataset/89cfa2e3-3319-4d31-a60d-710f76856588/resource/8b8e6cd7-ede2-4c41-a9bd-4266df783145/download/covid_report_county.xlsx'
, 'https://hub.mph.in.gov/dataset/62ddcb15-bbe8-477b-bb2e-175ee5af8629/resource/2538d7f1-391b-4733-90b3-9e95cd5f3ea6/download/covid_report_demographics.xlsx'
, 'https://hub.mph.in.gov/dataset/6b57a4f2-b754-4f79-a46b-cff93e37d851/resource/46b310b9-2f29-4a51-90dc-3886d9cf4ac1/download/covid_report.xlsx'
, 'https://hub.mph.in.gov/dataset/14a59397-9ebc-4902-a7c7-fd7ca3c08101/resource/3ea01356-42e4-42aa-8935-493709313ca3/download/covid_count_per_zip_all.csv'
, 'https://hub.mph.in.gov/dataset/5a905d51-eb50-4a83-8f79-005239bd108b/resource/882a7426-886f-48cc-bbe0-a8d14e3012e4/download/covid_report_bedvent.xlsx'
, 'https://hub.mph.in.gov/dataset/ab9d97ab-84e3-4c19-97f8-af045ee51882/resource/182b6742-edac-442d-8eeb-62f96b17773e/download/covid_report_date.xlsx'
, 'https://hub.mph.in.gov/dataset/181c677e-d1d0-4493-b673-356532fd7b7f/resource/3466ada6-a174-416d-a1c4-aaa0bf3d68af/download/covid_report_county_region_date.xlsx'
, 'https://hub.mph.in.gov/dataset/4d31808a-85da-4a48-9a76-a273e0beadb3/resource/0c00f7b6-05b0-4ebe-8722-ccf33e1a314f/download/covid_report_bedvent_date.xlsx'
, 'https://hub.mph.in.gov/dataset/bd08cdd3-9ab1-4d70-b933-41f9ef7b809d/resource/afaa225d-ac4e-4e80-9190-f6800c366b58/download/covid_report_county_date.xlsx'
, 'https://hub.mph.in.gov/dataset/07e12c46-eb38-43cf-b9e1-46a9c305beaa/resource/9ae4b185-b81d-40d5-aee2-f0e30405c162/download/covid_report_demographics_county_district.xlsx'
, 'https://hub.mph.in.gov/dataset/6bcfb11c-6b9e-44b2-be7f-a2910d28949a/resource/7661f008-81b5-4ff2-8e46-f59ad5aad456/download/covid_report_death_date_agegrp.xlsx'
]
#----------------------------------------------------Assign output file names------------------------------------------------------------
f_fileout = ['IN_County_report', 'IN_demographics', 'IN_casedata', 'IN_casesbyzip', 'IN_beds_vent'
, 'IN_statewide', 'IN_regionwide', 'IN_beds_vent_daily', 'IN_countywide', 'IN_demographicsbycounty', 'IN_deathbyage'
]
#---------------------------------------------------Function Declaration-----------------------------------------------------------------
def IN_file(url, file_out):
    try:
        urllib.request.urlretrieve(url, file_out)     
    except Exception as identifier:
        raise(identifier)
    finally:
        print(f_fileout[x] + ": download complete")

if __name__ == "__main__":
    print("Indiana in progress")
#--------------------------------------------------Loop through all sources-----------------------------------------------------------------------
    for x in range(len(f_fileout)):        
        f_url = f_source_url[x]
        if f_url[-5:] != '.xlsx':
            file_tp = '.csv'
        else:
            file_tp = '.xlsx'
        f_file_out = (params.file_url + f_fileout[x] + file_tp)
        IN_file(f_url, f_file_out)
