import csv
import params
import requests
import pandas as pd 
import datetime

"""Resources detail: covidtracking.com for following states
state_name = ['AZ','DE','ID','IL','KA','MO','NV','NH','OH','OR','SD','UT','WV']
"""
# ----------------------------Assign source URLs----------------------------
source_url = ['https://covidtracking.com/api/v1/states/current.json', 'https://covidtracking.com/api/v1/states/daily.json']
file_dt = '_' + datetime.date.today().strftime("%Y%m%d")
# ----------------------------Assign output file name----------------------------
fileout = ['CovidTrackingCurrent', 'CovidTrackingHistory']

# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
     
    try:
        response = requests.get(url)
        data = response.json()
        # data_feature = data["features"]

        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data:
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values()) 

    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": Complete")

if __name__ == "__main__":
    print("CovidTrackingStates In Progress")
# -----------------------------loop through all sources----------------------------
    for x in range(len(fileout)):
        file_out = (params.file_url + fileout[x] + file_dt + params.csvfile)
        url = source_url[x]
        scrap_function(url, file_out)
    print("CovidTrackingStates Complete")