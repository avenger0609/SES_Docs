import csv
import urllib
import requests
import pandas as pd
import params
from pathlib import Path
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

#-------------------Assign source URL----------------------------------------------------
url = 'https://coronavirus.dc.gov/page/coronavirus-data'
#------------------Find file download link from HTML-------------------------------------
page = requests.get(url)
soup = BeautifulSoup(page.content, 'html.parser')
links = soup.find_all('a')
for i, tag in enumerate(links[10:]):
    link = tag.get('href',None)
    if link is not None:
        #result1 = link.find('/sites/coronavirus/')
        result1 = link.find('DC-COVID-19-Data-for-')
        if result1 != -1:
            if "https://" not in link:
                srcfilepath = 'https://coronavirus.dc.gov/' + link
                print(srcfilepath)
            else:
                srcfilepath = link
                print(srcfilepath)
            break
dstfile_path = params.file_url
inputfile1 = 'DC-COVID-19-Data.xlsx'
filetype = '.xlsx'

#------------------Use it for manual run only---------------------
#fileurl = 'https://coronavirus.dc.gov/sites/default/files/dc/sites/coronavirus/page_content/attachments/DC-COVID-19-Data-for-June-21-2020.xlsx'
#-----------------------------------Assign destination for raw data download -----------------------------------------
rawfile1 = dstfile_path + inputfile1
#-----------------------------------Get source data-----------------------------------------------------------
resp = requests.get(srcfilepath)
#-----------------------------------Comment this section only if need to run only data processing code. -----------------------------------------
output = open(rawfile1, 'wb')
output.write(resp.content)
output.close()
print('DC raw data downloaded')
#----------------------------------------------Process data----------------------------------------------------------------
outfile = 'DC-COVID-Final.csv'

file = dstfile_path + inputfile1
df = pd.read_excel(file)
df_T = df.T.reset_index().rename(columns={'index':'Date'})

df_T.columns = df_T.iloc[0]
df_T = df_T.reindex(df_T.index.drop(0)).reset_index(drop=True)
df_T.columns.name = None

df_T.columns = df_T.iloc[0]
df_T = df_T.reindex(df_T.index.drop(0)).reset_index(drop=True)
df_T.columns.name = None

dfout = df_T[['Unnamed: 1'
            ,'Total Overall Number of Tests'
            ,'Total Number of DC Residents Tested'
            ,'Total Positives'
            ,'Number of Deaths'
            ,'Cleared From Isolation'
            ,'Total ICU Beds in Hospitals'
            ,'ICU Beds Available'
            ,'Total Reported Ventilators in Hospitals'
            ,'In-Use Ventilators in Hospitals'
            ,'Available Ventilators in Hospitals'
            ,'Total COVID-19 Patients in DC Hospitals'
            ,'Total COVID-19 Patients in ICU'
            ,'Total Patients in DC Hospitals (COVID and non-COVID'
            ,'Percentage of pre-COVID Hospital Bed Capacity']]
dfout.rename(columns={'Unnamed: 1': 'DateReported'}, inplace=True)
print(dfout)
dfout.to_csv(dstfile_path + outfile, index = False)
print('Please validate output above')
print('File location: ' + dstfile_path + outfile)
