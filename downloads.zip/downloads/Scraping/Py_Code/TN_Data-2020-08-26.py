import csv
import params
import urllib
import requests
import pandas as pd

'''Resource details - update dashboard link'''
#---------------------------------------------Assign source URLs----------------------------------------------------
source_url = ['https://www.tn.gov/content/dam/tn/health/documents/cedep/novel-coronavirus/datasets/Public-Dataset-Daily-Case-Info.XLSX'
,'https://www.tn.gov/content/dam/tn/health/documents/cedep/novel-coronavirus/datasets/Public-Dataset-County-New.XLSX'
,'https://www.tn.gov/content/dam/tn/health/documents/cedep/novel-coronavirus/datasets/Public-Dataset-Age.XLSX'
,'https://www.tn.gov/content/dam/tn/health/documents/cedep/novel-coronavirus/datasets/Public-Dataset-Daily-County-Age-Group.XLSX'
,'https://www.tn.gov/content/dam/tn/health/documents/cedep/novel-coronavirus/datasets/Public-Dataset-RaceEthSex.XLSX'
,'https://www.tn.gov/content/dam/tn/health/documents/cedep/novel-coronavirus/datasets/Public-Dataset-Daily-County-Cases-5-18-Years.XLSX'
,'https://www.tn.gov/content/dam/tn/health/documents/cedep/novel-coronavirus/datasets/Public-Dataset-MMWR-Week-Case-Count.XLSX'
]
#-----------------------------------Assign output file name-----------------------------------------
fileout = ['TN-state_data', 'TN-county_data', 'TN_Age', 'TN_AgeByCounty', 'TN_demographics', 'TN_5-18', 'TN_MMWR_Case']
#------------------------------------------------Download raw file -----------------------------------------
def scrap_function(url, file_out):
    try:
        resp = requests.get(url)
        output = open(file_out, 'wb')
        output.write(resp.content)
        output.close()
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": complete")

#---------------Call Function-----------------------------------------------
if __name__ == "__main__":
    print("TN In Progress")
# -----------------------------loop through all sources----------------------------
    for x in range(len(fileout)):
        file_out = (params.file_url + fileout[x] + params.xlfile)
        url = source_url[x]
        scrap_function(url, file_out)
    print("TN Complete")