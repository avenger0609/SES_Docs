import csv
import params
import datetime
import requests

"""
Resources detail: https://protect-public.hhs.gov/datasets/state-representative-estimates-for-hospital-utilization/geoservice?geometry=89.569%2C-16.702%2C-96.408%2C72.161&orderBy=state_name
Resources detail: https://protect-public.hhs.gov/pages/hospital-capacity#download-data
"""
# --------------------------------------------Assign source URLs----------------------------
source_url = ['https://services5.arcgis.com/qWZ7BaZXaP5isnfT/ArcGIS/rest/services/State_Representative_Estimates_for_Hospital_Utilization/FeatureServer/0/query?where=1%3D1&outFields=*&outSR=4326&f=json'
, 'https://services5.arcgis.com/qWZ7BaZXaP5isnfT/ArcGIS/rest/services/Hospitals_Reporting_State_Level/FeatureServer/0/query?where=1%3D1&outFields=*&outSR=4326&f=json'
]
#--------------------------------------------Assign output file names-----------------------
fileout_name = ['HHS_hospital_utilization', 'HHS_Facilities_Reporting']
# -------------------------------------------Function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print("HHS Complete")
#------------------------------Call Function----------------------------
if __name__ == "__main__":
    print("HHS In Progress")
# -----------------------------loop through all sources----------------------------
for x in range(len(fileout_name)):
    file_out = (params.file_url + fileout_name[x] + params.csvfile)
    url = source_url[x]
    scrap_function(url, file_out)