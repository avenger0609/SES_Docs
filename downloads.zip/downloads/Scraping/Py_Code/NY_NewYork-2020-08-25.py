import csv
import params
import requests

"""
Resources detail: https://www1.nyc.gov/site/doh/covid/covid-19-data.page
GitHub - https://github.com/nychealth/coronavirus-data
"""
# ----------------------------Assign source URLs----------------------------
source_url = ['https://health.data.ny.gov/api/views/xdss-u53e/rows.csv?accessType=DOWNLOAD&api_foundry=true'
,'https://github.com/nychealth/coronavirus-data/raw/master/by-age.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/by-boro.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/by-poverty.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/by-race.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/by-sex.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/case-hosp-death.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/data-by-modzcta.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/summary.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/syndromic_data.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/tests-by-zcta.csv'
,'https://github.com/nychealth/coronavirus-data/raw/master/tests.csv'
]
#-------------------------Assign output file name-----------------------------------
fileout = ['NY_county_test', 'NY_age', 'NY_boro', 'NY_poverty', 'NY_race', 'NY_sex'
, 'NY_hosp_death', 'NY_by_modzcta', 'NY_summary', 'NY_syndromic', 'NY_test_zcta', 'NY_test']

# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        req = requests.get(url)
        url_content = req.content
        csv_file = open(file_out, 'wb')
        csv_file.write(url_content)
        csv_file.close()

    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": Complete")

if __name__ == "__main__":
    print("NY In Progress")
# -----------------------------loop through all sources----------------------------
for x in range(len(fileout)):    
    url = source_url[x]
    file_out = (params.file_url + fileout[x] + params.csvfile)
    scrap_function(url, file_out)
print("NY complete")