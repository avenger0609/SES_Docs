import csv
import os
import params
import requests

"""
Resources detail: Update dashboard link

"""
#------------------------------------------------------Assign source URLs-----------------------------------------
source_url = ['https://services6.arcgis.com/l7uujk4hHifqabRB/arcgis/rest/services/ADHS_Count/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services6.arcgis.com/l7uujk4hHifqabRB/ArcGIS/rest/services/Arizona_COVID19_Zip_Code_Data/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services6.arcgis.com/l7uujk4hHifqabRB/ArcGIS/rest/services/AZ_COVID19_Zip_Code/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services6.arcgis.com/l7uujk4hHifqabRB/ArcGIS/rest/services/AZ_COVID19_Zip_Code_Summary/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services6.arcgis.com/l7uujk4hHifqabRB/ArcGIS/rest/services/COVID19_County_Level/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services6.arcgis.com/l7uujk4hHifqabRB/ArcGIS/rest/services/COVID19_County_Level_View_Layer/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]
#------------------------------------------------------Assign File Names-------------------------------------------------------------------
fileout_name = [
'AZ_ADHS_count'
, 'AZ Zip code data'
, 'AZ Zip code'
, 'AZ zip code summery'
, 'AZ covid19 county'
, 'AZ covid19 county1'
]
# -----------------------------Assign folder name and output loction for AZ----------------------------
folder_nme = params.file_url + 'AZ'
file_url = params.file_url + 'AZ\\'
#-----------------------------------Create new folder for AZ-------------------------------------------------
print("Creating AZ folder")
os.mkdir(folder_nme)
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x] + ": complete")

if __name__ == "__main__":
    print("Arizona In Progress")
# -----------------------------loop through all sources----------------------------
for x in range(len(fileout_name)):
    file_out = (file_url + fileout_name[x] + params.csvfile)
    url = source_url[x]
    scrap_function(url, file_out)
print("Arizona complete")