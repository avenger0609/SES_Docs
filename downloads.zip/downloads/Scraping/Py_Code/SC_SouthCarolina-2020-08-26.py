import csv
import params
import requests
from bs4 import BeautifulSoup

"""Resource details - Update dashboard link"""
#-------------------Assign source URLs-----------------------
source_url = ['https://www.scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19'
, 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/COVID19/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
]
#-------------------Assign output file name-----------------------
fileout = ['SC_bed_hosp', 'SC_county_cases']

#-------------------Function declaration-----------------------
def web_scrap(url, file_out):
    # url = 'https://www.scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19'
    page = requests.get(url)
    soup = BeautifulSoup(page.content, 'html.parser')

    header = []
    data_rows = []

    table_rows = soup.find(id="table-block").find("table").find("tbody").find_all("tr")

    for tr in table_rows:
        header_text = tr.find_all('td')[0].text.replace(":", "").strip()
        if ((header_text == "Hospital beds occupied") or (header_text == "Beds available") or (header_text == "Patients hospitalized with COVID-19")):
            header.append(header_text)
            data_rows.append(tr.find_all('td')[1].text.replace(",", ""))

    # url = 'https://www.scdhec.gov/infectious-diseases/viruses/coronavirus-disease-2019-covid-19/sc-testing-data-projections-covid-19'
    # page = requests.get(url)
    # soup = BeautifulSoup(page.content, 'html.parser')

    # table_rows = soup.find(id="dmtable").find("tbody").find_all("tr")
    # for tr in table_rows:
    #     header_text = tr.find_all('td')[0].text.replace(":", "").strip()
    #     if ((header_text == "Total negative tests") or (header_text == "Total positive tests") or (header_text == "Total number of tests performed in South Carolina")):
    #         header.append(header_text)
    #         data_rows.append(tr.find_all('td')[1].text.replace(",", ""))

    with open(file_out, 'w', newline='\n') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(header)
        writer.writerow(data_rows)
    print(fileout[x] + ': Complete')
#-----------------------------County data via API-----------------------------------    
def json_func(url, file_out):
    url = 'https://services2.arcgis.com/XZg2efAbaieYAXmu/arcgis/rest/services/COVID19/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
            else:
                should_Continue = False
        
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": Complete")  
#-----------------Call function and loop through all sources-----------------------
if __name__ == "__main__":
    myFunc = [web_scrap, json_func]
    print("South Carolina in progress")
    try:
        for x in range(len(fileout)):
            file_out = (params.file_url + fileout[x] + params.csvfile)
            url = source_url[x]
            myFunc[x](url, file_out)
    except Exception as identifier:
        raise(identifier)
    finally:
        print("South Carolina complete")