import csv
import params
import requests

"""
Resources detail: Update dashboard/source data link """
# ----------------------------Assign source URLs----------------------------
TestURL = 'http://www.dph.illinois.gov/sitefiles/COVIDTestResults.json'
HospURL = 'http://www.dph.illinois.gov/sitefiles/COVIDHospitalRegions.json'
file_url = params.file_url 
file_type = params.csvfile
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["characteristics_by_county"]
        data_feature = data_feature["values"]

        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_row_index, data_attribute in enumerate(data_feature):
                if (data_row_index >= 1):
                    if count == 0:
                        writer.writerow((data_attribute).keys())
                        count += 1
                    writer.writerow((data_attribute).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#--------------------------------------------------------------------------------
def scrap_function1(url, file_out):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["state_testing_results"]
        data_feature = data_feature["values"]

        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data_feature:
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#--------------------------------------------------------------------------------
def scrap_function2(url, file_out):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["regionValues"]
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data_feature:
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#--------------------------------------------------------------------------------
def scrap_function3(url, file_out):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["statewideValues"]
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow((data_feature).keys())
            writer.writerow((data_feature).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#--------------------------------------------------------------------------------
def scrap_function4(url, file_out):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["HospitalUtilizationResults"]

        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data_feature:
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values()) 
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#-----------------------------------------------------------------------------------
def scrap_function_demographics(url):
    try:
        response = requests.get(url)
        data = response.json()
        data_feature = data["demographics"]
        return data_feature
    except Exception as identifier:
        raise(identifier)
    finally:
        print("Demographics Data Download: Complete")
#------------------------------------------------------------------------------------
def create_age_data_file(data_set, file_to_write):
    try:
        data_feature = data_set["age"]
        count = 0
        with open(file_to_write, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data_feature:
                del data_attribute["demographics"]
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values())

    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#------------------------------------------------------------
def create_race_data_file(data_set, file_to_write):
    try:
        data_feature = data_set["race"]
        count = 0
        with open(file_to_write, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data_feature:
                del data_attribute["color"]
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values())

    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#------------------------------------------------------------
def create_gender_data_file(data_set, file_to_write):
    try:
        data_feature = data_set["gender"]
        count = 0
        with open(file_to_write, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in data_feature:
                del data_attribute["color"]
                if count == 0:
                    writer.writerow((data_attribute).keys())
                    count += 1
                writer.writerow((data_attribute).values())

    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name + ": Complete")
#------------------------------------------------------------
if __name__ == "__main__":
    print("Illinios In Progress")
# -----------------------------loop through all sources----------------------------
    fileout_name = 'IL_county_test'
    file_out = (file_url + fileout_name + file_type)
    url = TestURL
    scrap_function(url, file_out)

    fileout_name = 'IL_state_test'
    file_out = (file_url + fileout_name + file_type)
    scrap_function1(url, file_out)

    demographics_all_data = scrap_function_demographics(url)

    fileout_name = 'IL_age_test'
    file_out = (file_url + fileout_name + file_type)
    create_age_data_file(demographics_all_data, file_out)

    fileout_name = 'IL_race_test'
    file_out = (file_url + fileout_name + file_type)
    create_race_data_file(demographics_all_data, file_out)

    fileout_name = 'IL_gender_test'
    file_out = (file_url + fileout_name + file_type)
    create_gender_data_file(demographics_all_data, file_out)


    fileout_name = 'IL_state_test'
    file_out = (file_url + fileout_name + file_type)
    scrap_function1(url, file_out)
    
    fileout_name = 'IL_region_ICUvent'
    file_out = (file_url + fileout_name + file_type)
    url = HospURL
    scrap_function2(url, file_out)

    fileout_name = 'IL_statewide_hosp'
    file_out = (file_url + fileout_name + file_type)
    scrap_function3(url, file_out)

    fileout_name = 'IL_statewide_hosp_history'
    file_out = (file_url + fileout_name + file_type)
    scrap_function4(url, file_out)

    print("Illinios: Complete")