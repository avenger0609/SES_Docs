import csv
import params
import requests

"""Resources detail: 'https://data.ct.gov/stories/s/COVID-19-data/wa3g-tfvc/' """
# ----------------------------Assign source URLs----------------------------
source_url = ['https://data.ct.gov/api/views/rf3k-f8fg/rows.csv'
, 'https://data.ct.gov/api/views/bfnu-rgqt/rows.csv'
, 'https://data.ct.gov/api/views/qfkt-uahj/rows.csv'
, 'https://data.ct.gov/api/views/ypz6-8qyf/rows.csv'
, 'https://data.ct.gov/api/views/7rne-efic/rows.csv'
, 'https://data.ct.gov/api/views/qa53-fghg/rows.csv'
, 'https://data.ct.gov/api/views/28fr-iqnx/rows.csv'
]
#---------------------------Assign output file names--------------------------
fileout_name = ['CT_state_test', 'CT_county_cases', 'CT_county_test', 'CT_cases_deaths_agegroup'
, 'CT_Cases_deaths_Race_Ethnicity', 'CT_Cases_Deaths_Gender', 'CT_Town_Tests_Cases_Deaths']
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        req = requests.get(url)
        url_content = req.content
        csv_file = open(file_out, 'wb')
        csv_file.write(url_content)
        csv_file.close()

    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x] + ": Complete")

#----------------------------Call Function--------------------------------------
if __name__ == "__main__":
    print("CT In Progress")
# -----------------------------loop through all sources----------------------------
for x in range(len(fileout_name)):
    file_out = (params.file_url + fileout_name[x] + params.csvfile)
    url = source_url[x]
    
    scrap_function(url, file_out)