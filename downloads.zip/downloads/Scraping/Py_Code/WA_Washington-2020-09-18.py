"""
State Level information is being scraped from below URL
url = 'https://www.doh.wa.gov/Emergencies/Coronavirus'
weekly file download: https://www.doh.wa.gov/Portals/1/Documents/1600/coronavirus/data-tables/PUBLIC_CDC_Event_Date_SARS.xlsx
    
    #from selenium.webdriver.ie.options import Options

    # ie_options = Options()
    # ie_options.ignore_protected_mode_settings = True
    # driver = webdriver.Ie(options=ie_options, executable_path="C:\\Program Files\\IEDriverServer\\3.150.0\\IEDriverServer.exe")
"""

import csv
import time
import params
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.ie.options import Options

class my_dictionary(dict):
    # __init__ function 
    def __init__(self):
        self = dict()    
    # Function to add key:value
    def add(self, key, value):
        self[key] = value

fileout = ['WA_state', 'WA_county', 'WA_databyage', 'WA_databysex', 'WA_deathbyrace', 'WA_hospbyrace', 'WA_casebyrace']

url = 'https://www.doh.wa.gov/Emergencies/COVID19/DataDashboard'
fileurl = 'https://www.doh.wa.gov/Portals/1/Documents/1600/coronavirus/data-tables/PUBLIC_CDC_Event_Date_SARS.xlsx'

# options = webdriver.ChromeOptions()
# options.add_argument('--headless')
# driver = webdriver.Chrome(chrome_options=options, executable_path="C:\ProgramData\ChromeDriver_83\chromedriver.exe")

ie_options = Options()
ie_options.ignore_protected_mode_settings = True
driver = webdriver.Ie(options=ie_options, executable_path="C:\\Program Files\\IEDriverServer\\3.150.0\\IEDriverServer.exe")

driver.get(url)
driver.implicitly_wait(1000)
time.sleep(10)
soup = BeautifulSoup(driver.page_source, 'html.parser')
driver.close()
driver.quit()

def scrap_state_data(outfile):

    test_obj = []
    """
    table_rows = soup.find(id="pnlTestingTbl").find('div').find('div').find('table').find("tbody").find_all("tr")

    for tr in table_rows:
        test_obj.append(tr.find_all('td')[1].text.replace(",", "").strip())
    """
    data_rows = []
    """
    Get State Covid Hospitalized data
    """
    table = soup.find(id="pnlHospAndIcuTbl").find('div').find('div').find('table')
    table_data_rows = table.select('tbody > tr')

    for data_row_index, data_row in enumerate(table_data_rows):
        dict_obj = my_dictionary()
        dict_obj.add("Negative Test", 0)
        dict_obj.add("Positive Test", 0)
        dict_obj.add("Date", data_row.find_all("td")[0].text.replace(",", "").strip())

        #dict_obj.add("Hospitals Reporting", 'NR')
        dict_obj.add("Total Patients Hospitalized with COVID-19", data_row.find_all("td")[1].text.replace(",", "").strip())
        dict_obj.add("Total COVID-19 Patients Ventilated", data_row.find_all("td")[2].text.replace(",", "").strip())

        """
        if (data_row_index == len(table_data_rows) - 1):
            dict_obj.add("Negative Test", test_obj[0])
            dict_obj.add("Positive Test", test_obj[1])
            """
        data_rows.append(dict_obj)
    
    with open(outfile, 'w', newline='\n') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=(data_rows[0]).keys())
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)
    print(fileout[x] + ': Complete')
#----------------------------------------------------------------------------------------------------------------------------------------
def scrap_county_data(outfile):
    data_rows = []

    table_rows = soup.find(id="pnlConfirmedCasesDeathsTbl").find('div').find('div').find('table').find("tbody").find_all("tr")

    for data_row in table_rows:
        if ((data_row.find("th")) == None):
            dict_obj = my_dictionary()
            dict_obj.add("County", (data_row.find_all("td")[0].find("a").text.replace(",", "").strip()) if (data_row.find_all("td")[0].find("a") != None) else data_row.find_all("td")[0].text.replace(",", "").strip())
            dict_obj.add("Confirmed Cases", data_row.find_all("td")[1].text.replace(",", "").strip())
            dict_obj.add("Hospitalizations", data_row.find_all("td")[2].text.replace(",", "").strip())
            dict_obj.add("Deaths", data_row.find_all("td")[3].text.replace(",", "").strip())
            data_rows.append(dict_obj)
    

    with open(outfile, 'w', newline='\n') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=(data_rows[0]).keys())
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)
    print(fileout[x] + ': Complete')
#----------------------------------------------------------------------------------------------------------------------------------------
def scrap_race_death(outfile):
    test_obj = []
    data_rows = []

    table_rows = soup.find(id="pnlDeathsByRaceTbl").find('div').find('div').find('table').find("tbody").find_all("tr")

    for data_row in table_rows:
        if ((data_row.find("th")) == None):
            dict_obj = my_dictionary()
            dict_obj.add("Race/Ethnicity", (data_row.find_all("td")[0].find("a").text.replace(",", "").strip()) if (data_row.find_all("td")[0].find("a") != None) else data_row.find_all("td")[0].text.replace(",", "").strip())
            dict_obj.add("Deaths", data_row.find_all("td")[1].text.replace(",", "").strip())
            dict_obj.add("Percent of Deaths *", data_row.find_all("td")[2].text.replace(",", "").strip())
            dict_obj.add("Percent of Total WA Population", data_row.find_all("td")[3].text.replace(",", "").strip())
            data_rows.append(dict_obj)


    with open(outfile, 'w', newline='\n') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=(data_rows[0]).keys())
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)
    print(fileout[x] + ': Complete')
#----------------------------------------------------------------------------------------------------------------------------------------
def scrap_race_hosp(outfile):
    test_obj = []
    data_rows = []

    table_rows = soup.find(id="pnlHospitalizationsByRaceTbl").find('div').find('div').find('table').find("tbody").find_all("tr")

    for data_row in table_rows:
        if ((data_row.find("th")) == None):
            dict_obj = my_dictionary()
            dict_obj.add("Race/Ethnicity", (data_row.find_all("td")[0].find("a").text.replace(",", "").strip()) if (data_row.find_all("td")[0].find("a") != None) else data_row.find_all("td")[0].text.replace(",", "").strip())
            dict_obj.add("Hospitalization", data_row.find_all("td")[1].text.replace(",", "").strip())
            dict_obj.add("Percent of Hospitalizations *", data_row.find_all("td")[2].text.replace(",", "").strip())
            dict_obj.add("Percent of Total WA Population", data_row.find_all("td")[3].text.replace(",", "").strip())
            data_rows.append(dict_obj)


    with open(outfile, 'w', newline='\n') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=(data_rows[0]).keys())
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)
    print(fileout[x] + ': Complete')
#----------------------------------------------------------------------------------------------------------------------------------------
def scrap_race_case(outfile):
    test_obj = []
    data_rows = []

    table_rows = soup.find(id="pnlConfirmedCasesByRaceTbl").find('div').find('div').find('table').find("tbody").find_all("tr")

    for data_row in table_rows:
        if ((data_row.find("th")) == None):
            dict_obj = my_dictionary()
            dict_obj.add("Race/Ethnicity", (data_row.find_all("td")[0].find("a").text.replace(",", "").strip()) if (data_row.find_all("td")[0].find("a") != None) else data_row.find_all("td")[0].text.replace(",", "").strip())
            dict_obj.add("Confirmed Cases", data_row.find_all("td")[1].text.replace(",", "").strip())
            dict_obj.add("Percent of Cases *", data_row.find_all("td")[2].text.replace(",", "").strip())
            dict_obj.add("Percent of Total WA Population", data_row.find_all("td")[3].text.replace(",", "").strip())
            data_rows.append(dict_obj)


    with open(outfile, 'w', newline='\n') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=(data_rows[0]).keys())
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)
    print(fileout[x] + ': Complete')
#----------------------------------------------------------------------------------------------------------------------------------------
def scrap_age_case(outfile):
    test_obj = []
    data_rows = []

    table_rows = soup.find(id="pnlCasesDeathsByAgeTbl").find('div').find('div').find('table').find("tbody").find_all("tr")

    for data_row in table_rows:
        if ((data_row.find("th")) == None):
            dict_obj = my_dictionary()
            dict_obj.add("Age Group", (data_row.find_all("td")[0].find("a").text.replace(",", "").strip()) if (data_row.find_all("td")[0].find("a") != None) else data_row.find_all("td")[0].text.replace(",", "").strip())
            dict_obj.add("Percent of Cases", data_row.find_all("td")[1].text.replace(",", "").strip())
            dict_obj.add("Percent of Hospitalizations", data_row.find_all("td")[2].text.replace(",", "").strip())
            dict_obj.add("Percent of Deaths", data_row.find_all("td")[3].text.replace(",", "").strip())
            data_rows.append(dict_obj)


    with open(outfile, 'w', newline='\n') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=(data_rows[0]).keys())
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)
    print(fileout[x] + ': Complete')
#----------------------------------------------------------------------------------------------------------------------------------------
def scrap_sex_case(outfile):
    test_obj = []
    data_rows = []

    table_rows = soup.find(id="pnlCasesDeathsByGenderTbl").find('div').find('div').find('table').find("tbody").find_all("tr")

    for data_row in table_rows:
        if ((data_row.find("th")) == None):
            dict_obj = my_dictionary()
            dict_obj.add("Sex at Birth", (data_row.find_all("td")[0].find("a").text.replace(",", "").strip()) if (data_row.find_all("td")[0].find("a") != None) else data_row.find_all("td")[0].text.replace(",", "").strip())
            dict_obj.add("Percent of Cases", data_row.find_all("td")[1].text.replace(",", "").strip())
            dict_obj.add("Percent of Hospitalizations", data_row.find_all("td")[2].text.replace(",", "").strip())
            dict_obj.add("Percent of Deaths", data_row.find_all("td")[3].text.replace(",", "").strip())
            data_rows.append(dict_obj)


    with open(outfile, 'w', newline='\n') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=(data_rows[0]).keys())
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)
    print(fileout[x] + ': Complete')
#----------------------------------------------------------------------------------------------------------------------------------------
def file_download(fileurl, outfile):

    resp = requests.get(fileurl)

    output = open(outfile, 'wb')
    output.write(resp.content)
    output.close()
    print(outfile + ': Complete')

#----------------------Call function and loop through sources----------------------------------------    
if __name__ == "__main__":
    myFunc = [scrap_state_data, scrap_county_data, scrap_age_case, scrap_sex_case, scrap_race_death, scrap_race_hosp, scrap_race_case]
    print("WA Working")
    try:
        for x in range(len(fileout)):
            file_out = (params.file_url + fileout[x] + params.csvfile)
            myFunc[x](file_out)

        outfile = params.file_url + 'WA_weekly_data.xlsx'
        file_download(fileurl, outfile)
    except Exception as identifier:
        raise(identifier)
    finally:
        print("WA Completed")