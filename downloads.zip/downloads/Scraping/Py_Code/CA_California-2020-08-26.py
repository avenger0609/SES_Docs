import csv
import params
import urllib
import requests
import pandas as pd

"""Resources detail: https://data.ca.gov/group/covid-19"""
#------------------------------------------------------------------Assign source URLs------------------------------------------------
source_url = ['https://data.ca.gov/dataset/590188d5-8545-4c93-a9a0-e230f0db7290/resource/926fd08f-cc91-4828-af38-bd45de97f8c3/download/statewide_cases.csv'
,'https://data.ca.gov/dataset/590188d5-8545-4c93-a9a0-e230f0db7290/resource/339d1c4d-77ab-44a2-9b40-745e64e335f2/download/case_demographics_age.csv'
,'https://data.ca.gov/dataset/590188d5-8545-4c93-a9a0-e230f0db7290/resource/ee01b266-0a04-4494-973e-93497452e85f/download/case_demographics_sex.csv'
,'https://data.ca.gov/dataset/590188d5-8545-4c93-a9a0-e230f0db7290/resource/7e477adb-d7ab-4d4b-a198-dc4c6dc634c9/download/case_demographics_ethnicity.csv'
,'https://data.ca.gov/dataset/efd6b822-7312-477c-922b-bccb82025fbe/resource/b6648a0d-ff0a-4111-b80b-febda2ac9e09/download/statewide_testing.csv'
,'https://data.ca.gov/dataset/529ac907-6ba1-4cb7-9aae-8966fc96aeef/resource/42d33765-20fd-44b8-a978-b083b7542225/download/hospitals_by_county.csv'
,'https://data.ca.gov/dataset/cbbfb307-ac91-47ec-95c0-f05684e06065/resource/ef6675e7-cd3a-4762-ba75-2ef78d6dc334/download/bed_surge.csv'
,'https://data.ca.gov/dataset/f40b9c5c-ef29-4705-9f12-8325f4fb8fc5/resource/235466b6-0eb9-4ff7-a4b4-8138f474ce83/download/homeless_impact.csv'
,'https://data.ca.gov/dataset/da1978f2-068c-472f-be2d-04cdec48c3d9/resource/7d2f11a4-cc0f-4189-8ba4-8bee05493af1/download/logistics_ppe.csv'
]
#-----------------------------------------------------------Assign output file names------------------------------------------------
fileout_name = ['CA_state_case', 'CA_case_age', 'CA_case_sex', 'CA_case_eth', 'CA_state_test'
,'CA_county_hosp', 'CA_Med_surge_fac', 'CA_homeless_impact', 'CA_PPE']
# # -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        urllib.request.urlretrieve(url, file_out)     
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout_name[x] + ": download complete")
#----------------------------------Call function---------------------------------
if __name__ == "__main__":
    print("California in progress")

# -----------------------------loop through all sources----------------------------
    for x in range(len(fileout_name)):
        file_out = (params.file_url + fileout_name[x] + params.csvfile)
        url = source_url[x]
        
        scrap_function(url, file_out)

print("California Complete")