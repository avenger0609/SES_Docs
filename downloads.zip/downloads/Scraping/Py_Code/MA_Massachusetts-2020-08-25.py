import csv
import urllib
import params
import requests
import zipfile, io
import pandas as pd
from bs4 import BeautifulSoup

'''Source URL - https://www.mass.gov/info-details/covid-19-response-reporting'''
#------------------------------------------Assign file URLs and name----------------------------------------------------
dstfile_path = params.file_url + 'MA'
fileoutpath = params.file_url

outputfile1 = 'MA_State_Test.csv'
outputfile2 = 'MA_State_Hosp.csv'
#------------------------------------------Get source URL-----------------------------------------
url = 'https://www.mass.gov/info-details/covid-19-response-reporting'

page = requests.get(url)
soup = BeautifulSoup(page.content, 'html.parser')

links = soup.find_all('a')

for i, tag in enumerate(links[0:]):
    link = tag.get('href',None)

    if link is not None:
        result1 = link.find('covid-19-raw-data-')
        if result1 != -1:
            if "https://" not in link:
                fileurl = 'https://www.mass.gov' + link
            else:
                fileurl = link
            break
#---------------------------------------------------------IN CASE OF ERROR-------------------------------------------
'''Go to the source link mentioned above and find link to download and update below fileurl uncomment and run the code
remember to comment the below fileurl so that code can run next day'''
#fileurl = 'https://www.mass.gov/doc/covid-19-raw-data-august-22-2020/download'
print(fileurl)
#-----------------------------------Extract raw data-----------------------------------------
r = requests.get(fileurl)
z = zipfile.ZipFile(io.BytesIO(r.content))
z.extractall(dstfile_path)
print('Raw files extracted')
#-----------------------------------Process files to get final output------------------------
print("MA file processing start")

input_file_path = params.file_url + 'MA\\'
inputfile1 = 'Key Metrics.xlsx'
inputfile2 = 'TestingByDate.csv'

rawfile1 = input_file_path + inputfile1
rawfile2 = input_file_path + inputfile2

dfTest = pd.read_csv(rawfile2)
dfHosp = pd.read_excel(rawfile1)
dfHosp = dfHosp.filter(["Date", "COVID patients in hospital"])

dfTest.to_csv(fileoutpath + outputfile1, index = False)
dfHosp.to_csv(fileoutpath + outputfile2, index = False)
print('MA file processing complete')