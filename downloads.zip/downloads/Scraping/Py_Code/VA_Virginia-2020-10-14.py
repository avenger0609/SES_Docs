import pandas as pd
import csv
import params
import urllib
import requests

"""Resource details: Update dashboard link"""

#---------------------------------------------Source URL----------------------------------------------------
source_url = ['https://www.vdh.virginia.gov/content/uploads/sites/182/2020/05/VDH-COVID-19-PublicUseDataset-Cases.csv'
,'https://www.vdh.virginia.gov/content/uploads/sites/182/2020/05/VDH-COVID-19-PublicUseDataset-KeyMeasures-Hospitals.csv'
,'https://www.vdh.virginia.gov/content/uploads/sites/182/2020/05/VDH-COVID-19-PublicUseDataset-Tests_by-LabReportDate.csv'
]
#-----------------------------------Destination file name and path -----------------------------------------
fileout = ['VA_county_case', 'VA_state_hosp', 'VA_state_test']

#------------------------------------------------Download raw file -----------------------------------------
def scrap_function(url, file_out):
    try:
        req = requests.get(url, verify=False)
        url_content = req.content
        csv_file = open(file_out, 'wb')
        csv_file.write(url_content)
        csv_file.close()
        
    except Exception as identifier:
        raise(identifier)
    finally:
        print(fileout[x] + ": complete")

#----------------------------------------------Call Function-----------------------------------------------
if __name__ == "__main__":
    print("Virginia In Progress")
# -----------------------------loop through all sources----------------------------
    for x in range(len(fileout)):
        file_out = ("c:\\users\\asrilekh\\documents\\" + fileout[x] + params.csvfile)
        url = source_url[x]
        scrap_function(url, file_out)
    print("Virginia complete")