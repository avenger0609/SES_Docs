#-------------------------------------------read log file-------------------------------------------------------------
infile = "C:\\Users\\rsing45\\Documents\\PRJ_Covid\\Scraping\\Data\\LogFile.log"
important = []
keep_phrases = ["Log start:",
              "py: failed"
              ]
with open(infile) as f:
    f = f.readlines()
for line in f:
    for phrase in keep_phrases:
        if phrase in line:
            print(line)
            #important.append(line)
            break
#print(important)