import glob
import subprocess
from subprocess import *
import os, sys
from datetime import datetime, timedelta
import time
import csv
import logging
from distutils.dir_util import copy_tree


d = datetime.today() - timedelta(days=1)
folderdt = '_' + d.strftime("%Y%m%d")

logging.basicConfig(filename='C:\\Users\\rsing45\\Documents\\PRJ_Covid\\Scraping\\Data\\LogFile.log',level=logging.DEBUG)

# Declare folder URLs
folderpath = "C:\\Users\\rsing45\\Documents\\PRJ_Covid\\Scraping\\Py_Code"
old = 'C:\\Users\\rsing45\\Documents\\PRJ_Covid\\Scraping\\Data\\Raw'
new = 'C:\\Users\\rsing45\\Documents\\PRJ_Covid\\Scraping\\Data\\Raw'+ folderdt
old_nas = "\\" + '\\nasv0602\\cv19_surgemodel\\Data\\Raw'
new_nas = "\\" + '\\nasv0602\cv19_surgemodel\Data\\Raw'+ folderdt

def createfolder(old, new, old_nas, new_nas):
    i = 1
    #-----------------------comment this section for manual run if code got intrupted----------------------------
    try:
        logging.debug('Log start: ' + (datetime.now().strftime("%d-%b-%Y (%H:%M:%S)")))
        # Renaming local folder
        os.rename(old, new)
        logging.debug('Renaming local folder: success')
        print('Local folder renamed')
        # Creating new local folder
        os.mkdir(old)
        logging.debug('Creating new local folder: success')
        print('New local folder created')
        # Renaming NAS drive folder
        os.rename(old_nas, new_nas)
        logging.debug('Renaming NAS folder: success')
        print('Folder renamed @ NAS drive')
        # Creating new NAS drive folder
        os.mkdir(old_nas)
        logging.debug('Creating new NAS folder: success')
        print('New folder created @ NAS drive')
    except Exception as identifier:
        i = 0
        logging.debug(identifier)
        sys.exit(1)
    finally:
        if i == 0:
            logging.debug('Refer previous row for error')
        else:
            logging.debug('Folder creation: success')
    #---------------------------Declare folder URL for python scripts--------------------------------------------------
def run_all(folderpath):
    os.chdir(folderpath)
    files = glob.glob("*.py")
    for i, file in enumerate(files[0:]):
        timestampStr = datetime.now().strftime("%d-%b-%Y (%H:%M:%S.%f)")
        startmsg = file + "Start: " + timestampStr
        logging.debug(startmsg)
        prog = "python " + folderpath + "\\" + file
        try:
            p = Popen(prog)
            output = p.communicate()
            if p.returncode != 0: 
                logging.debug(file + ": failed %d %s" % (p.returncode, output))
        except Exception as identifier:
            logging.debug(identifier)
            break
        finally:
            timestampStr = datetime.now().strftime("%d-%b-%Y (%H:%M:%S.%f)")
            endmsg = file + "End: " + timestampStr
            logging.debug(endmsg)
#-------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    createfolder(old, new, old_nas, new_nas)
    run_all(folderpath)
    logging.debug('Log end: ' + (datetime.now().strftime("%d-%b-%Y (%H:%M:%S)")))