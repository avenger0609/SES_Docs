#############################################
# Object detection - YOLO - OpenCV
# Author : Arun Ponnusamy   (July 16, 2018)
# Website : http://www.arunponnusamy.com
############################################


import cv2
import argparse
import numpy as np
import imutils
import os
import cv2 

ap = argparse.ArgumentParser()
# ap.add_argument('-i', '--image', required=True,
#                 help = 'path to input image')
# ap.add_argument('-c', '--config', required=True,
#                 help = 'path to yolo config file')
# ap.add_argument('-w', '--weights', required=True,
#                 help = 'path to yolo pre-trained weights')
# ap.add_argument('-cl', '--classes', required=True,
#                 help = 'path to text file containing class names')
# args = ap.parse_args()


def get_output_layers(net):
    
    layer_names = net.getLayerNames()
    
    output_layers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]

    return output_layers


def draw_prediction(img, class_id, confidence, x, y, x_plus_w, y_plus_h):

    label = str(classes[class_id])
    # print(label)

    color = COLORS[class_id]

    cv2.rectangle(img, (x,y), (x_plus_w,y_plus_h), color, 2)

    cv2.putText(img, label, (x-10,y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

cnfg_file_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\yolov3.cfg"
wght_file_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\yolov3.weights"
classes_file_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\yolov3.txt"
classes = None

x_lst=[]
y_lst=[]
x_h_lst=[]
y_h_lst=[]



with open(classes_file_name, 'r') as f:
    classes = [line.strip() for line in f.readlines()]

COLORS = np.random.uniform(0, 255, size=(len(classes), 3))

def image_recog1(image) :
    
    persons_cnt=0
    pets_cnt=0
    # img_abs_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\"+img_name
    # image = cv2.imread(img_abs_name)
    image = imutils.resize(image, width=min(800, image.shape[1]))
    Width = image.shape[1]
    Height = image.shape[0]
    scale = 0.00392
    net = cv2.dnn.readNet(wght_file_name,cnfg_file_name)
    blob = cv2.dnn.blobFromImage(image, scale, (416,416), (0,0,0), True, crop=False)
    net.setInput(blob)
    outs = net.forward(get_output_layers(net))
    class_ids = []
    confidences = []
    boxes = []
    conf_threshold = 0.5
    nms_threshold = 0.4


    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                center_x = int(detection[0] * Width)
                center_y = int(detection[1] * Height)
                w = int(detection[2] * Width)
                h = int(detection[3] * Height)
                x = center_x - w / 2
                y = center_y - h / 2
                class_ids.append(class_id)
                confidences.append(float(confidence))
                boxes.append([x, y, w, h])


    indices = cv2.dnn.NMSBoxes(boxes, confidences, conf_threshold, nms_threshold)

    for i in indices:
        
        i = i[0]
        box = boxes[i]
        x = box[0]
        y = box[1]
        w = box[2]
        h = box[3]
        # print(class_ids[i])
        
        # print("label1"+label1)
        x_found=0
        y_found=0
        xh_found=0
        yh_found=0

        x_temp=round(x)
        for xti in range(x_temp-100,x_temp+101):
            try:
                xi=x_lst.index(round(xti))
                x_found=1
                break
            except:
                junk=1
        
        y_temp=round(y)
        for xti in range(y_temp-100,y_temp+101):
            try:
                xi=y_lst.index(round(xti))
                y_found=1
                break
            except:
                junk=1
        
        xh_temp=round(x+w)
        for xti in range(xh_temp-100,xh_temp+101):
            try:
                xi=x_h_lst.index(round(xti))
                xh_found=1
                break
            except:
                junk=1
        
        yh_temp=round(y+h)
        for xti in range(yh_temp-100,yh_temp+101):
            try:
                xi=y_h_lst.index(round(xti))
                yh_found=1
                break
            except:
                junk=1
        
        
        if x_found==1 and y_found==1 and xh_found==1 and yh_found==1:
            continue
        print(x_found,y_found,xh_found,yh_found)
        print(round(x), round(y), round(x+w), round(y+h))
        print(str(x_lst),str(y_lst),str(x_h_lst),str(y_h_lst))
        label1 = str(classes[class_ids[i]])
        if str(label1).strip(' ').lower()=='person' :
            
            persons_cnt=persons_cnt+1
            # print("entered persons"+str(persons_cnt))
        elif str(label1).strip(' ').lower()=='dog':
            pets_cnt=pets_cnt+1
            # print("entered pets"+str(pets_cnt))
        else:
            continue
        x_lst.append(round(x))
        y_lst.append( round(y))
        x_h_lst.append(round(x+w))
        y_h_lst.append( round(y+h))
        draw_prediction(image, class_ids[i], confidences[i], round(x), round(y), round(x+w), round(y+h))

    # cv2.imshow(img_name.split('.')[0], image)
    # cv2.waitKey()
    # img_res=img_abs_name.split('.')[0]+"_res.jpg"    
    cv2.imwrite("C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\op_img_video_"+str(len(x_lst)), image)
    cv2.destroyAllWindows()
    op_lst=[]
    # op_lst.append(img_res)
    op_lst.append(persons_cnt)
    op_lst.append(pets_cnt)
    print(op_lst)
    return op_lst


def video_object_detection(video_name):
    x_lst=[]
    y_lst=[]
    x_h_lst=[]
    y_h_lst=[]
    persons_v_cnt=0
    pets_v_cnt=0
    video_abs_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\"+video_name
    vidObj = cv2.VideoCapture(video_abs_name) 
    count = 0
    success = 1
    while success: 
        # if count ==10:
        #     break
        print(count)
        # vidObj object calls read 
        # function extract frames 
        success, image = vidObj.read() 
  
        # Saves the frames with frame-count 
        try:
            # print("entered try")
            op=image_recog1(image)
            # print(str(op)+ " output from image recog")
            persons_v_cnt=persons_v_cnt+op[0]
            pets_v_cnt=pets_v_cnt+op[1]
            # persons_v_cnt=2
            # pets_v_cnt=0
        except Exception as e:
            # print(str(e)+" exception ")
            junk=1
        # cv2.imwrite("C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\c\\frame%d.jpg" % count, image) 
  
        count += 1
    
    op_lst1=[]    
    op_lst1.append(persons_v_cnt)
    op_lst1.append(pets_v_cnt)    
    return op_lst1

# print(video_object_detection("180131_A_08.mp4"))
# print(image_recog("pets_flood.jpg"))
# print(image_recog("flood4.jpg"))
# print(image_recog("Fire.jpg"))