from flask import Flask
from flask import render_template,jsonify,request,send_file
import requests
from yolo_opencv import *
from yolo_opencv_video import *
import random
import urllib3
from flask_cors import CORS
import json
import glob
import os

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False
app.secret_key = '12345'
CORS(app)

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route("/parse", methods=['GET', 'POST', 'OPTIONS'])
def parse():

    try:
        ### to read parameters###

        parsed=(urllib3.util.url.parse_url(request.url)) 
        ######## Used in case of any parameters passed ###########       
        s1=str(str(parsed.query).split('&')[0].split('=')[1].replace('+',' ')) # first query        
        while True:
            a=s1.find("%")
            if a > -1:
                ss=s1[a]+s1[a+1]+s1[a+2]
                s1=s1.replace(ss," ")
            else:
                break 
        s1=s1.replace('  ',' ').replace('  ',' ').strip(' ') 
        print(s1)    
        ######## Used in case of any parameters passed ########### 
        print(str(s1.split('.')[1]))
        ouptut_lst=[2,0]        
        if str(s1.split('.')[1]).lower().strip(' ')=="mp4":
            output_lst=video_object_detection(s1)
            return jsonify({"person_count":ouptut_lst[0],"pets_count":ouptut_lst[1]})
        else:
            print("entered if")
            op=image_recog(s1)
            return jsonify({"output_file":op[0],"person_count":op[1],"pets_count":op[2]})
        
        
    except Exception as e:    
        print(e) 
        return jsonify({"response":"Sorry I do not have an answer for that. You may reach out to us through call or email for assistance."})   


app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(host='10.198.55.2',port=5050,debug=True)
    # app.run(host='localhost',port=5050,debug=True)
    # app.run(host='apsrp03693',port=5051,debug=True)