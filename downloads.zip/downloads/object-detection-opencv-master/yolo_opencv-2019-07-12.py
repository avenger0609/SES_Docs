#############################################
# Object detection - YOLO - OpenCV
# Author : Arun Ponnusamy   (July 16, 2018)
# Website : http://www.arunponnusamy.com
############################################


import cv2
import argparse
import numpy as np
import imutils

ap = argparse.ArgumentParser()
# ap.add_argument('-i', '--image', required=True,
#                 help = 'path to input image')
# ap.add_argument('-c', '--config', required=True,
#                 help = 'path to yolo config file')
# ap.add_argument('-w', '--weights', required=True,
#                 help = 'path to yolo pre-trained weights')
# ap.add_argument('-cl', '--classes', required=True,
#                 help = 'path to text file containing class names')
# args = ap.parse_args()


def get_output_layers(net):
    
    layer_names = net.getLayerNames()
    
    output_layers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]

    return output_layers


def draw_prediction(img, class_id, confidence, x, y, x_plus_w, y_plus_h):

    label = str(classes[class_id])
    print(label)

    color = COLORS[class_id]

    cv2.rectangle(img, (x,y), (x_plus_w,y_plus_h), color, 2)

    cv2.putText(img, label, (x-10,y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

cnfg_file_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\yolov3.cfg"
wght_file_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\yolov3.weights"
classes_file_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\yolov3.txt"
classes = None

with open(classes_file_name, 'r') as f:
    classes = [line.strip() for line in f.readlines()]

COLORS = np.random.uniform(0, 255, size=(len(classes), 3))

def image_recog(img_name) :
    
    persons_cnt=0
    pets_cnt=0
    img_abs_name="C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\"+img_name
    image = cv2.imread(img_abs_name)
    image = imutils.resize(image, width=min(800, image.shape[1]))
    Width = image.shape[1]
    Height = image.shape[0]
    scale = 0.00392
    net = cv2.dnn.readNet(wght_file_name,cnfg_file_name)
    blob = cv2.dnn.blobFromImage(image, scale, (416,416), (0,0,0), True, crop=False)
    net.setInput(blob)
    outs = net.forward(get_output_layers(net))
    class_ids = []
    confidences = []
    boxes = []
    conf_threshold = 0.5
    nms_threshold = 0.4

    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                center_x = int(detection[0] * Width)
                center_y = int(detection[1] * Height)
                w = int(detection[2] * Width)
                h = int(detection[3] * Height)
                x = center_x - w / 2
                y = center_y - h / 2
                class_ids.append(class_id)
                confidences.append(float(confidence))
                boxes.append([x, y, w, h])


    indices = cv2.dnn.NMSBoxes(boxes, confidences, conf_threshold, nms_threshold)

    for i in indices:
        
        i = i[0]
        box = boxes[i]
        x = box[0]
        y = box[1]
        w = box[2]
        h = box[3]
        print(class_ids[i])
        label1 = str(classes[class_ids[i]])
        print("label1"+label1)
        if str(label1).strip(' ').lower()=='person' :
            
            persons_cnt=persons_cnt+1
            print("entered persons"+str(persons_cnt))
        elif str(label1).strip(' ').lower()=='dog':
            pets_cnt=pets_cnt+1
            print("entered pets"+str(pets_cnt))
        else:
            continue
        draw_prediction(image, class_ids[i], confidences[i], round(x), round(y), round(x+w), round(y+h))

    # cv2.imshow(img_name.split('.')[0], image)
    # cv2.waitKey()
    img_res=img_abs_name.split('.')[0]+"_res.jpg"
    cv2.imwrite(img_res, image)
    cv2.destroyAllWindows()
    op_lst=[]
    img_res_name=img_name.split('.')[0]+"_res.jpg"
    op_lst.append(img_res_name)
    op_lst.append(persons_cnt)
    op_lst.append(pets_cnt)
    return op_lst

# print(image_recog("pets_flood.jpg"))
# print(image_recog("flood4.jpg"))
# print(image_recog("Fire.jpg"))