import csv
# import params
import requests

"""
Resources detail: 'https://covid19.ncdhhs.gov/dashboard/about-data' """
# ----------------------------Assign source URLs----------------------------
source_url = ['https://services.arcgis.com/iFBq2AW9XO0jYYF7/ArcGIS/rest/services/NCCovid19MapDaybyDay/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=false&f=json'
, 'https://services.arcgis.com/iFBq2AW9XO0jYYF7/arcgis/rest/services/NCCovid19/FeatureServer/0/query?where=1%3D1&outFields=*&outSR=4326&f=json'
, 'https://services1.arcgis.com/ssJTvu2LI9qRE1oE/ArcGIS/rest/services/CovidCases_View/FeatureServer/0/query?where=1%3D1&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&resultType=none&distance=0.0&units=esriSRUnit_Meter&returnGeodetic=false&outFields=*&returnGeometry=false&returnCentroid=false&featureEncoding=esriDefault&multipatchOption=xyFootprint&maxAllowableOffset=&geometryPrecision=&outSR=4326&datumTransformation=&applyVCSProjection=false&returnIdsOnly=false&returnUniqueIdsOnly=false&returnCountOnly=false&returnExtentOnly=false&returnQueryGeometry=false&returnDistinctValues=false&cacheHint=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&having=&resultOffset=&resultRecordCount=&returnZ=false&returnM=false&returnExceededLimitFeatures=false&quantizationParameters=&sqlFormat=none&f=pjson&token='
, 'https://services.arcgis.com/iFBq2AW9XO0jYYF7/ArcGIS/rest/services/Covid19byZIPnew/FeatureServer/0/query?where=1%3D1&outFields=*&outSR=4326&f=json']
#----------------------------Assign output file name------------------------
fileout_name = ['NC_county', 'NC_state', 'NC_county_DG', 'NC_zip_cases']
# -----------------------------function declaration----------------------------
def scrap_function(url, file_out):
    try:
        should_Continue = True
        all_data_feature = []
        while should_Continue:
            url_withOffset = url # + "&resultOffset="+  str(len(all_data_feature))
            print(url_withOffset)
            response = requests.get(url_withOffset)
            data = response.json()
            print(type(data))
            # print(data)
            data_feature = data["features"]
            if len(data_feature) > 0:
                all_data_feature.extend(data_feature)
                should_Continue = False
            else:
                should_Continue = False
        count = 0
        with open(file_out, 'w', newline='\n') as csv_file:
            writer = csv.writer(csv_file)
            for data_attribute in all_data_feature:
                if count == 0:
                    writer.writerow((data_attribute['attributes']).keys())
                    count += 1
                writer.writerow((data_attribute['attributes']).values()) 
    except Exception as identifier:
        print(identifier)
    finally:
        print(fileout_name[x]+": Complete")  
#-------------------------------------Call function-----------------------------
if __name__ == "__main__":
    print("North Carolina In Progress")
#-----------------------------loop through all sources----------------------------
    for x in range(len(fileout_name)):
        if x==2:
            file_out = ('c:\\users\\asrilekh\\documents\\' + fileout_name[x] +'.csv')
            url = source_url[x]
            scrap_function(url, file_out)
    print("North Carolina Complete")