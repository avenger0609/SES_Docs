import os
import pandas as pd
import csv
from datetime import datetime


def sas_to_csv(fname,fullfn):
    
    print("Conversion of "+str(fname)+" Started at "+str(datetime.now()))

    sas_file=fullfn
    text_fname=fname.split('.')[0]+'.txt'
    txt_file=os.path.join(thisdir,text_fname)

    print("sas file full path: "+sas_file)
    print("converted file full path: "+txt_file)

    try:

        reader = pd.read_sas(sas_file, chunksize=10000,encoding='latin-1',convert_dates=bool)
        no_of_lines_written=0

        for df in reader:

            if no_of_lines_written==0:                
                print(df.columns)
                print(df.dtypes)
                print(len(df.columns))
                df.to_csv(txt_file, sep='|', index=False)
                no_of_lines_written=no_of_lines_written+len(df)
                print("Number of lines written to file="+str(no_of_lines_written)+" at "+str(datetime.now()))
            else:                
                df.to_csv(txt_file,mode="a",header=False,sep='|', index=False)
                no_of_lines_written=no_of_lines_written+len(df)
                print("Number of lines written to file="+str(no_of_lines_written)+" at "+str(datetime.now()))

        output_msg="converted text file has "+str(no_of_lines_written)+" rows and "+str(len(df.columns))+" columns"
        print("Conversion of "+str(fname)+" Completed at "+str(datetime.now()))
        logfile.write("Success|"+fname+"|"+fullfn+"|"+txt_file+"|"+str(output_msg)+"\n")
        return ["Success",fname,fullfn,txt_file,output_msg]

    except Exception as e:

        try:
            
            df = pd.read_sas(sas_file,encoding='latin-1',convert_dates=bool)
            print(df.dtypes)
            print(len(df))
            print(df.columns)
            print(len(df.columns))
            df.to_csv(txt_file, sep='|', index=False)
            output_msg="converted text file has "+str(len(df))+" rows and "+str(len(df.columns))+" columns"
            print("Conversion of "+str(fname)+" Completed at "+str(datetime.now()))
            logfile.write("Success|"+fname+"|"+fullfn+"|"+txt_file+"|"+str(output_msg)+"\n")
            return ["Success",fname,fullfn,txt_file,output_msg]

        except Exception as e:
            logfile.write("Failed|"+fname+"|"+fullfn+"|"+txt_file+"|"+str(e)+"\n")
            return ["Failed",fname,fullfn,txt_file,str(e)]

    

thisdir = r'/mapr/datalake/uhc/ei/hcemi/in/restricted/inbound'
logdt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')    
logfile= open(os.path.join(thisdir,"Sas_to_Text_Log_"+logdt+".log"),"w+")

for r, d, f in os.walk(thisdir):
    for file in f:
        if file.lower().endswith(".sas7bdat"):            
            try:   
                res=sas_to_csv(file,os.path.join(r, file))
                os.system("cp "+os.path.join(r, file)+" /mapr/datalake/uhc/ei/hcemi/in/restricted/inbound/Archive")           
                os.system("rm "+os.path.join(r, file))           
                print(res)
            except Exception as e:                
                logfile.write(str(e))
                print(str(e))
logfile.close()