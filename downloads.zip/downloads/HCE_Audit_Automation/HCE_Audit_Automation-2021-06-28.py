# import pandas as pd
# import os
# from pyhive import hive
# from datetime import datetime

# onlyfiles=[f for f in os.listdir('/mapr/datalake/uhc/ei/hcemi/in/permitted/inbound') if '.txt' in f and os.path.isfile(os.path.join('/mapr/datalake/uhc/ei/hcemi/in/permitted/inbound', f))]
# db_name=onlyfiles[0].split()

# conn = hive.Connection(host='apvrp80107', port=10494, database=db_name+'_hce_offshore', username='hcemioff', password='65V7NHzv', auth='CUSTOM')#connect hive
# cur=conn.cursor()
# onlyfiles=[os.path.join('/mapr/datalake/uhc/ei/hcemi/in/permitted/inbound', f) for f in os.listdir('/mapr/datalake/uhc/ei/hcemi/in/permitted/inbound') if '.txt' in f and os.path.isfile(os.path.join('/mapr/datalake/uhc/ei/hcemi/in/permitted/inbound', f))]
# df=pd.read_csv(onlyfiles[0],sep='\t')
# df=df[0:1]
# table_names=list(df['table'])
# row_counts=list(df['NOBS'])
# offshore_count_lst=[]
# status_lst=[]
# for tni in range(0,len(table_names)):
#   sql_stmt="select count(*) from "+db_name+"_hce_offshore_p2."+table_names[tni]+"_vw"
#   print(sql_stmt)
#   cur.execute(sql_stmt)
#   record = cur.fetchone()
#   offshore_count_lst.append(record[0])
#   if int(str(row_counts[tni]).replace(',',''))==record[0]:    
#     status_lst.append(True)    
#   else:
#     status_lst.append(False)
# df['Offshore Count']=offshore_count_lst
# df['status']=status_lst
# df.to_csv('Outputfile'+'_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv',index=False)
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
df=pd.read_csv(r'c:\users\asrilekh\documents\dmp_portal_20210330155408596510.csv')
me="srilekha.anumula@optum.com"
you="srilekha.anumula@optum.com"
msg=MIMEMultipart('alternative')
msg['Subject']="Link"
msg["From"]=me
msg["To"]=you
html="<h1>title</h1>"
html=df.to_html()
part2=MIMEText(html,'html')
msg.attach(part2)
s=smtplib.SMTP('mail25.uhc.com')
s.sendmail(me,you,msg.as_string())
s.quit()