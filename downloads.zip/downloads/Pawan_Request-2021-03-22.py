import pandas as pd

def derive_global_groups(ipfname,opfname,new_column):
    # df=pd.read_excel(r'c:\users\asrilekh\downloads\OT_Roaster_Test.xlsx')
    df=pd.read_excel(ipfname)
    cols=df.columns
    conv = dict(zip(cols ,[str] * len(cols)))
    # df=pd.read_excel(r'c:\users\asrilekh\downloads\OT_Roaster_Test.xlsx', converters=conv)
    df=pd.read_excel(ipfname, converters=conv)
    print(list(df.columns))
    print(len(df))
    df=df[df['wfm_ioi_sr_exec']=='Rollins']
    df=df.reset_index(inplace=False,drop=True)
    print(len(df))
    for dfi in range(0,len(df)):
        if dfi%100==0:
            print(dfi)
        International_Indicator=df.loc[dfi,'International_Indicator']
        Wfm_Ioi_Exec=df.loc[dfi,'wfm_ioi_exec']
        Supervisor_Flag=df.loc[dfi,'supervisor_flag']
        Emp_Contractor=str(df.loc[dfi,'FTE_Type']).lower()
        

        if  International_Indicator=='N' and Wfm_Ioi_Exec=='Weymouth' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_EandI_Contractor_US'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Weymouth' and Supervisor_Flag=='N' and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_EandI_Global'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Weymouth' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_EandI_Global_Contractor'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Weymouth' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_EandI_Global_Mgr'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Weymouth' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_EandI_Mgr_US'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Weymouth' and Supervisor_Flag=='N'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_EandI_US'

        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Abraham' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_GPT_Contractor_US'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Abraham' and Supervisor_Flag=='N' and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_GPT_Global'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Abraham' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_GPT_Global_Contractor'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Abraham' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_GPT_Global_Mgr'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Abraham' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_GPT_Mgr_US'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Abraham' and Supervisor_Flag=='N'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_GPT_US'

        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Dunivant' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Contractor_US'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Dunivant' and Supervisor_Flag=='N' and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Global'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Dunivant' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Global_Contractor'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Dunivant' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Global_Mgr'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Dunivant' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Mgr_US'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Dunivant' and Supervisor_Flag=='N'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_US'


        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Rollins' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Contractor_US'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Rollins' and Supervisor_Flag=='N' and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Global'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Rollins' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Global_Contractor'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Rollins' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Global_Mgr'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Rollins' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_Mgr_US'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Rollins' and Supervisor_Flag=='N'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Ops_US'


        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Neale' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Provider_SS_Contractor_US'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Neale' and Supervisor_Flag=='N' and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Provider_SS_Global'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Neale' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Provider_SS_Global_Contractor'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Neale' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Provider_SS_Global_Mgr'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Neale' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Provider_SS_Mgr_US'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Neale' and Supervisor_Flag=='N'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_Provider_SS_US'

        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Durham' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_CTO_Contractor_US'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Durham' and Supervisor_Flag=='N' and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_CTO_Global'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Durham' and Supervisor_Flag=='N' and 'contractor' in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_CTO_Global_Contractor'
        elif International_Indicator=='Y' and Wfm_Ioi_Exec=='Durham' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_CTO_Global_Mgr'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Durham' and Supervisor_Flag=='Y'  and 'contractor' not in Emp_Contractor :
            df.loc[dfi,new_column]= 'UHC_Technology_CTO_Mgr_US'
        elif International_Indicator=='N' and Wfm_Ioi_Exec=='Durham' and Supervisor_Flag=='N'  and 'contractor' not in Emp_Contractor : 
            df.loc[dfi,new_column]= 'UHC_Technology_CTO_US'
    df.to_excel(opfname,index=False)
    return df

def audit_global_group(ipfname,opfname,new_column,audit_fname,manual_fname,outliersfname):

    ## testing purpose
    # derived_df=pd.read_excel(opfname)
    # cols=derived_df.columns
    # conv = dict(zip(cols ,[str] * len(cols)))
    # derived_df=pd.read_excel(opfname, converters=conv)

    ## derived dataframe
    derived_df=derive_global_groups(ipfname,opfname,new_column)
    derived_df=derived_df[['employee_id',new_column]]
    derived_df['Emp ID']=derived_df['employee_id']
    derived_df=derived_df[['Emp ID',new_column]]
    derived_df['Emp ID'] = derived_df['Emp ID'].apply(lambda x: x.zfill(9))
    print(derived_df.dtypes)
    
    ## audit file to dataframe
    audit_df=pd.read_excel(audit_fname,sheet_name='Data')    
    cols=audit_df.columns
    conv = dict(zip(cols ,[str] * len(cols)))
    audit_df=pd.read_excel(audit_fname, converters=conv,sheet_name='Data')
    print(audit_df.dtypes)
    audit_df['Emp ID'] = audit_df['Emp ID'].apply(lambda x: x.zfill(9)) # left fill to employee id of length 10

    ## manual edited file reading to dataframe
    manual_df=pd.read_excel(manual_fname,sheet_name='Manual_Changes')
    print(list(manual_df.columns))
    cols=manual_df.columns
    conv = dict(zip(cols ,[str] * len(cols)))
    manual_df=pd.read_excel(manual_fname, converters=conv,sheet_name='Manual_Changes')

    ## dataframe to hold outlier records
    outliers=pd.DataFrame()
    outliers=audit_df[0:0]
    outliers[new_column]=""
    outliers['Updated_Global_Group']=""

    ## calculating outliers if values of audit file global group name not equal to derived dataframe global group name
    temp_df=audit_df.merge(derived_df,on='Emp ID',how='inner')
    temp_df=temp_df[temp_df['Global_Group']!=temp_df[new_column]]
    temp_df['Updated_Global_Group']=""
    outliers=outliers.append(temp_df,ignore_index=True)
    outliers.to_excel(r'c:\users\asrilekh\downloads\derived_diff_from_audit.xlsx',index=False)

    ## Capturing employee ids of audit file and derived file
    audit_empids=list(audit_df['Emp ID'])
    derived_empids=list(derived_df['Emp ID'])

    ## emplids only in audit file dataframe and vice versa and their respective dataframes
    only_audit_empids=list(set(audit_empids)-set(derived_empids))
    only_derived_empids=list(set(derived_empids)-set(audit_empids))

    only_audit_df=audit_df[audit_df['Emp ID'].isin(only_audit_empids)]
    only_derived_df=derived_df[derived_df['Emp ID'].isin(only_derived_empids)]

    outliers=outliers.append(only_audit_df,ignore_index=True)
    outliers=outliers.append(only_derived_df,ignore_index=True)
    outliers.to_excel(r'c:\users\asrilekh\downloads\Till_audit_Comparison.xlsx',index=False)

    # print(outliers)   

    ## Cleansing manual dataframe columns to match derived and audit dataframe empl id column
    manual_df['Emp ID']=manual_df['Employee_ID']
    manual_df=manual_df.drop(columns=['Employee_ID'])
    manual_df['Emp ID'] = manual_df['Emp ID'].apply(lambda x: x.zfill(9)) # left fill to employee id of length 10

    ## removing outliers if derived global group is equal to manually updated global group
    outliers=outliers.drop(columns=['Updated_Global_Group'])
    temp_df=outliers.merge(manual_df,on='Emp ID',how='outer')
    print(list(temp_df.columns))
    temp_df=temp_df[temp_df[new_column]!=temp_df['Updated_Global_Group']]
    outliers=outliers.append(temp_df,ignore_index=True)

    print(outliers)  
    outliers.to_excel(outliersfname,index=False)
    
    # audit_empid_ggs = dict(zip(audit_empids ,audit_global_groups))

    
ipfname=r'c:\users\asrilekh\downloads\OT_Roster_03152021.xlsx'
opfname=r'c:\users\asrilekh\downloads\OT_Roster_revised.xlsx'
new_column=r'derived_global_group'
audit_fname=r'c:\users\asrilekh\downloads\UCHT_GG_Audit 2021 03 17 (1).xlsx'
manual_fname=r'c:\users\asrilekh\downloads\UHC_Technology_Manual_GG.xlsx'
outliersfname=r'c:\users\asrilekh\downloads\OT_Outliers_revised.xlsx'
audit_global_group(ipfname,opfname,new_column,audit_fname,manual_fname,outliersfname)