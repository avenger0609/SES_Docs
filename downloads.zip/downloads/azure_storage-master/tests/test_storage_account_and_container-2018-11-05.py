from azure.mgmt.storage.models import SkuTier
from azure.mgmt.storage.models import SkuName
from azure.mgmt.storage.models import DefaultAction
from azure.mgmt.storage.models import ProvisioningState
from azure.storage.blob.baseblobservice import BaseBlobService
from azure.mgmt.storage.models import Kind
from azure.mgmt.storage.models import AccessTier
import requests
import utils


class TestStorageAccountAndContainer():
    """Integration tests for examples/storage_account_and_container"""

    def setup_class(self):
        """This runs before all tests"""
        try:
            self.tfstate = utils.parse_tfstate(
                "examples/storage_account_and_container/terraform.tfstate")
            self.resource_group_name = self.tfstate["resource_group"]["name"]
            self.storage_account_name = self.tfstate["storage_account"]["name"]
            self.storage_container_name = self.tfstate["storage_container"]["name"]
            self.whitelisted_ips = [
                "198.203.177.177", "198.203.175.175", "198.203.181.181", "168.183.84.12",
                "149.111.26.128", "149.111.28.128", "149.111.30.128", "220.227.15.70",
                "203.39.148.18", "161.249.192.14", "161.249.72.14", "161.249.80.14",
                "161.249.96.14", "161.249.144.14", "161.249.176.14", "161.249.16.0/23",
                "12.163.96.0/24"
            ]
        except Exception:
            pass

    def test_resource_group_deployed(self, resource_management_client):
        """Test the deployed resource group"""

        print("RG")
        resource_group = resource_management_client.resource_groups.get(
            self.resource_group_name)

        assert resource_group is not None
        assert resource_group.name == self.resource_group_name
        assert resource_group.location == "centralus"
        assert resource_group.properties.provisioning_state == "Succeeded"

    def test_storage_account_deployed(self, storage_management_client):
        """Test the deployed storage account"""

        storage_account = storage_management_client.storage_accounts.get_properties(
            self.resource_group_name, self.storage_account_name)

        assert storage_account is not None
        assert storage_account.kind == Kind.storage_v2
        assert storage_account.access_tier == AccessTier.hot
        assert storage_account.enable_https_traffic_only
        assert storage_account.location == "centralus"
        assert storage_account.sku.tier == SkuTier.standard
        assert storage_account.sku.name == SkuName.standard_lrs
        assert storage_account.encryption.key_source == "Microsoft.Storage"
        assert storage_account.encryption.services.blob.enabled
        assert storage_account.encryption.services.file.enabled
        assert storage_account.network_rule_set.default_action == DefaultAction.deny
        for ip_rule in storage_account.network_rule_set.ip_rules:
            assert ip_rule.ip_address_or_range in self.whitelisted_ips
        assert storage_account.provisioning_state == ProvisioningState.succeeded
        assert "cc-eac_azure_storage" in storage_account.tags
        assert storage_account.primary_endpoints.blob == "https://" + \
            self.storage_account_name + ".blob.core.windows.net/"
        assert storage_account.primary_endpoints.queue == "https://" + \
            self.storage_account_name + ".queue.core.windows.net/"
        assert storage_account.primary_endpoints.table == "https://" + \
            self.storage_account_name + ".table.core.windows.net/"
        assert storage_account.primary_endpoints.file == "https://" + \
            self.storage_account_name + ".file.core.windows.net/"

    def test_storage_container(self, storage_management_client):
        """Test the deployed storage container"""
        block_blob_service = BaseBlobService(
            account_name=self.storage_account_name,
            account_key=utils.get_storage_account_key(
                storage_management_client,
                self.resource_group_name,
                self.storage_account_name)
        )
        container_acl = block_blob_service.get_container_acl(
            self.storage_container_name)
        assert container_acl == {}  # public access is none

    def test_endpoints(self, storage_management_client):
        """Test the storage account's endpoint's"""

        storage_account = storage_management_client.storage_accounts.get_properties(
            self.resource_group_name, self.storage_account_name)

        # Blob endpoint
        blob_status_code = None
        try:
            blob_request = requests.get(storage_account.primary_endpoints.blob)
            blob_status_code = blob_request.status_code
        except Exception:
            pass
        assert blob_status_code is not None

        # File endpoint
        file_status_code = None
        try:
            file_request = requests.get(storage_account.primary_endpoints.file)
            file_status_code = file_request.status_code
        except Exception:
            pass
        assert file_status_code is not None

        # Queue endpoint
        queue_status_code = None
        try:
            queue_request = requests.get(
                storage_account.primary_endpoints.queue)
            queue_status_code = queue_request.status_code
        except Exception:
            pass
        assert queue_status_code is not None

        # Table endpoint
        table_status_code = None
        try:
            table_request = requests.get(
                storage_account.primary_endpoints.table)
            table_status_code = table_request.status_code
        except Exception:
            pass
        assert table_status_code is not None
