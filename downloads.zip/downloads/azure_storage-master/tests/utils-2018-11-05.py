import json
import pytest
import logging

# Helper functions used in testing.

LOGGER = logging.getLogger()


def parse_tfstate(path_to_state_file):
    """Reads the Terraform state file and returns a data
    structure with the outputs from the modules.
    The outputs from the Terraform run will be used in the integration tests.

    :param string path_to_state_file: path to Terraform state file
    """
    try:
        with open(path_to_state_file) as file:
            state = json.load(file)
        data = {}
        for module in state["modules"]:
            if len(module["path"]) == 1:
                joined = "root"
            else:
                module["path"].pop(0)
                joined = ".".join(module["path"])
            data[joined] = {}
            for key in module["outputs"]:
                data[joined][key] = module["outputs"][key]["value"]
        return data
    except Exception as exception:
        LOGGER.error(
            "Could not parse the Terraform state file: %s", str(exception))


def get_storage_account_key(storage_client, resource_group, storage_account):
    """Returns the storage account key for the specified storage account.

    :param StorageManagementClient storage_client: a storage client used in the request
    :param string resource_group: the resource group that the storage account is in
    :param string storage_account: the name of the storage account
    """
    try:
        storage_keys = storage_client.storage_accounts.list_keys(
            resource_group,
            storage_account
        )
        # Return first key
        for key in storage_keys.keys:
            return key.value
    except Exception as exception:
        LOGGER.error(
            "Could not parse the storage account keys: %s", str(exception))
