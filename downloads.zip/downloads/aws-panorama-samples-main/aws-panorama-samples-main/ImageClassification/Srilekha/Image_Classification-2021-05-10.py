video_to_use = "mountain.mp4" 
import cv2
import numpy as np
from matplotlib import pyplot as plt

def preprocess(
    img,
    resize_short=256,
    crop_size=224,
    mean=(0.485, 0.456, 0.406),
    std=(0.229, 0.224, 0.225),
):
    """"""

    # resize to resize short
    # find the short size,
    width = img.shape[0]
    height = img.shape[1]

    height_is_short = int(width > height)  #

    if height_is_short:
        width = int(width * (resize_short / height))
        height = resize_short
    else:
        height = int(height * (resize_short / width))
        width = resize_short

    img = cv2.resize(img, (height, width))

    # center crop
    xmin = int(width / 2 - crop_size / 2)
    xmax = int(width / 2 + crop_size / 2)
    ymin = int(height / 2 - crop_size / 2)
    ymax = int(height / 2 + crop_size / 2)

    img = img[xmin:xmax, ymin:ymax, :]
    # normalize

    img = normalize(img, mean=mean, std=std)

    return img


def normalize(img, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]):

    img = img.astype(np.float32) / 255.0  # converting array of ints to floats
    img_a = img[:, :, 0]
    img_b = img[:, :, 1]
    img_c = img[:, :, 2]

    # Extracting single channels from 3 channel image
    # The above code could also be replaced with cv2.split(img) << which will return 3 numpy arrays (using opencv)

    # normalizing per channel data:
    img_a = (img_a - mean[0]) / std[0]
    img_b = (img_b - mean[1]) / std[1]
    img_c = (img_c - mean[2]) / std[2]

    # putting the 3 channels back together:
    x1 = [[[], [], []]]
    x1[0][0] = img_a
    x1[0][1] = img_b
    x1[0][2] = img_c

    # x1 = mx.nd.array(np.asarray(x1))
    x1 = np.asarray(x1)

    return x1


def softmax(logits):
    ps = np.exp(logits)
    ps /= np.sum(ps)

    return ps

filename = "mt_baker.jpg"
img = cv2.imread(filename)

# x is in the input that goes directly into the model
x = preprocess(img)
plt.figure(figsize=(10, 5))
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

def topk(array, k=5):
    enum_vals = [(i, val) for i, val in enumerate(array)]
    sorted_vals = sorted(enum_vals, key=lambda tup: tup[1])
    top_k = sorted_vals[::-1][:k]
    return [tup[0] for tup in top_k]
from imagenet_classes import get_classes
from gluoncv import model_zoo
import mxnet as mx

model = model_zoo.get_model("resnet50_v2", pretrained=True)
classes = get_classes()
logits = model(mx.nd.array(x))
probs = softmax(logits[0].asnumpy())

topK = 5
ind = topk(probs, k=topK)

top = "The input picture is classified to be:"
image = cv2.putText(
    img, top, (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 0), 5
)
for j in range(topK):
    line = "class [%s], with probability %.3f." % (
        classes[ind[j]],
        probs[ind[j]],
    )
    coords = (50, 100 + (j + 1) * 100)
    image = cv2.putText(
        image, line, coords, cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 0), 5
    )

plt.figure(figsize=(10, 5))
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.show()