from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
URL="https://health.wyo.gov/publichealth/infectious-disease-epidemiology-unit/disease/novel-coronavirus/"

chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get(URL)

html = driver.page_source
time.sleep(2)
# print(html)
html=str(html)
content_start=str(html).index('<p><strong>Albany',0)
content_end=str(html).index('</p>',content_start)
data=html[content_start:content_end]
data=str(data).replace('<strong>','').replace('<strong>','').replace('<p>','').replace('<br />','').replace('</strong>',';').replace('<br>','')
data_lst=str(data).split(';')
county_lst=[]
value_lst=[]
for i in data_lst:
    if len(i.strip(' '))==0:
        continue
    county_lst.append(i.split(':')[0].strip(' '))
    value_lst.append((i.split(':')[1]).split('(')[0].strip(' '))
print(len(county_lst))
print(len(value_lst))
df=pd.DataFrame()
df['County']=county_lst
df['Cumulative Cases']=value_lst    
df.to_csv(r'WY_County_Cumulative_cases.csv',index=False,quoting=csv.QUOTE_ALL)
driver.close()

   
