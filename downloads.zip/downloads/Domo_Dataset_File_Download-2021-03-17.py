from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.keys import Keys

## Parameters
username='rizwan.syedali@optum.com'
password='UHGdomo-2'
url='https://optumcare.domo.com/datasources/533094f2-8414-4785-a148-29ec73a71417/details/overview?internal=true'

#script
driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://optumcare.domo.com/")
driver.find_element_by_xpath('//*[@id="login-wrapper"]/div[1]/div/div[4]/div[2]/div[2]/div/a').click()
driver.find_element_by_xpath('//*[@id="login-wrapper"]/div[1]/div/div[4]/form/p[1]/input').send_keys(username)
driver.find_element_by_xpath('//*[@id="login-wrapper"]/div[1]/div/div[4]/form/p[2]/input').send_keys(password)
driver.find_element_by_xpath('//*[@id="login-wrapper"]/div[1]/div/div[4]/form/div[1]/button').click()
time.sleep(30)
driver.get(url)
time.sleep(40)
driver.find_element_by_xpath('//*[@id="csstyle"]/body/div[1]/div/div[1]/div/main/div/div[2]/div/ds-details-header/dm-react-render/div/div[3]/div[1]/div/div[3]/div[2]/button/span/i').click()
driver.find_element_by_xpath('//*[@id="csstyle"]/body/div[7]/div/nav/ul/li[11]/button/div/div/div[2]').click()
driver.find_element_by_xpath('//*[@id="export-excel"]/i').click()
driver.close()