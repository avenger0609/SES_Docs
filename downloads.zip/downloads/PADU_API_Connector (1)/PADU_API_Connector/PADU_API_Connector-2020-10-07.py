#!/usr/bin/env python3
#!/bin/bash

import requests
import json
import csv 
import os 
import subprocess

data_file = open('PADU_API.csv', 'w') 
  
csv_writer = csv.writer(data_file) 

url = "https://otdatahub.optum.com/api/executive/applicationspadu/v1/filter"

headers = {
    'accept': "application/json",
    'Content-Type': "application/json",
    }

response = (requests.request("POST", url, headers=headers, verify=False)).json().get('result')

count = 0

for x in response: 
    if count == 0: 
        header = x.keys() 
        csv_writer.writerow(header) 
        count += 1
    csv_writer.writerow(x.values()) 
  
data_file.close()

os.system("java -jar C:/Users/asrilekh/Downloads/domoUtil.jar -script C:/Users/asrilekh/Downloads/uploadfile.domo")
os._exit
