import paramiko  # module creates ssh client
ssh = paramiko.SSHClient()  # creates ssh client 
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # asks confiramtion yes/no while connecting with remote server
ssh.coonect(hostname=" abcd  ",username='107',password='***',port=22    # establish the connection with remote server 
sftp_client =ssh.open_sftp()   #opening the sftp connection with remote server (107)
sftp_client.put('path for tranfer files on remote server ', 'path to destination on local server' ) #tranfer the files from remote server (107) to local server (156)
sftp_client.close() # closes the sftp connection
ssh.close()  # closes the ssh connection 