from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
URL = "https://appointment.questdiagnostics.com/patient/findlocation"
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get(URL)
time.sleep(30)
Name = []
Address = []
alphabet=[]

alpha_lst=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

try:
    for ai in alpha_lst:
        print(ai)
        driver.find_element_by_id("input-1").clear()
        driver.find_element_by_id("input-1").send_keys(ai)
        time.sleep(10)
        x = driver.find_element_by_xpath('//*[@id="ul-1"]')
        y=driver.find_element_by_xpath('/html/body/div[2]').text
        z = x.find_elements_by_tag_name('li')
        if len(z) > 0:
            for rowno in range (1,(len(z)+1)):
                try:
                    print("index no: "+str(rowno))
                    driver.find_element_by_xpath('//*[@id="ul-1"]/li['+str(rowno)+']').click()
                    time.sleep(30)
                    try:
                        str1=driver.find_element_by_xpath('//*[@id="locationResultScroll"]')
                        # print(str1)
                        str2= str1.find_elements_by_tag_name('li')
                        # print(str2)
                        for s1 in str2:
                            try:
                                s11=s1.find_element_by_id('popTimeChartContainer')
                                try:
                                    s12=s11.find_elements_by_tag_name('span')[1]
                                    # print(s12.text)
                                    Name.append(s12.text)
                                except Exception as e:
                                    print(str(e))
                                    Name.append("")
                                try:
                                    s13=s11.find_elements_by_tag_name('div')[3].text
                                    # print(s13)
                                    Address.append(s13)
                                except Exception as e:
                                    print(str(e))
                                    Address.append("")
                                alphabet.append(ai)
                                
                            except Exception as e:
                                print(str(e))
                    except Exception as e:
                        print(str(e))
                except Exception as e:
                    print(str(e))
                

                driver.find_element_by_id("input-1").clear()
                driver.find_element_by_id("input-1").send_keys(ai)
                time.sleep(15)
except Exception as e:
    print(str(e))
finally:
    df=pd.DataFrame()
    df['Alphabet']=alphabet
    df['Name']=Name
    df['add_line1']=Address

    df.to_csv(r'c:\users\asrilekh\documents\Quest_'+str(datetime.now().strftime('%Y%m%d%H%M%S%f'))+r'.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')
