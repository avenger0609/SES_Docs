from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://uhgazure.sharepoint.com/sites/orxtech/pfm/Lists/ORx%20Portfolio%20Log1/AllItems.aspx")
time.sleep(6)
driver.find_element_by_xpath('//*[@id="i0116"]').send_keys('rizwan.syedali@optum.com')
driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()
time.sleep(45)
parent_div=driver.find_element_by_xpath('//*[@id="appRoot"]/div[1]/div[3]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div/div[3]/div/div/div/div')
child_els=parent_div.find_elements_by_class_name('ms-List-cell')

header_parent = driver.find_element_by_xpath('//*[@id="appRoot"]/div[1]/div[3]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div/div[3]/div/div/div/div/div[1]/div')
header_child_els = header_parent.find_elements_by_class_name('ms-DetailsHeader-cell')
header_child_els_lst=[]
for hcei in header_child_els:
    header_child_els_lst.append((hcei.text).split('\n')[0])
header_child_els_lst = header_child_els_lst[1:]


content_parent = driver.find_element_by_xpath('//*[@id="appRoot"]/div[1]/div[3]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div/div[3]/div/div/div/div/div[2]/div/div/div/div/div[1]')
content_child_els = content_parent.find_elements_by_class_name('ms-DetailsRow-fields') ## rows

row_counter=0
data_lst=[]
for ccei in content_child_els:
    row_counter=row_counter+1
    content_child_els_lst=[]
    ccei_fields = ccei.find_elements_by_class_name('ms-DetailsRow-cell')
    # print(len(ccei_fields))
    for cceii in ccei_fields:
        content_child_els_lst.append(cceii.text)
    data={}
    for di in range(header_child_els_lst):
        try:
            data[header_child_els_lst[di]]=content_child_els_lst[di]
        except:
            print("Exception in row number ",ccei," in column ",header_child_els_lst[di])
            data[header_child_els_lst[di]]=""
    data_lst.append(data)

content_parent = driver.find_elements_by_class_name('ms-List-page')[1]
content_child_els = content_parent.find_elements_by_class_name('ms-DetailsRow-fields') ## rows

for ccei in content_child_els:
    row_counter=row_counter+1
    content_child_els_lst=[]
    ccei_fields = ccei.find_elements_by_class_name('ms-DetailsRow-cell')
    # print(len(ccei_fields))
    for cceii in ccei_fields:
        content_child_els_lst.append(cceii.text)
    data={}
    for di in range(header_child_els_lst):
        try:
            data[header_child_els_lst[di]]=content_child_els_lst[di]
        except:
            print("Exception in row number ",ccei," in column ",header_child_els_lst[di])
            data[header_child_els_lst[di]]=""
    data_lst.append(data)

df=pd.DataFrame(data=data_lst)
df.to_csv(r'C:\Users\sali1045\Downloads\SharePoint_ALL_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv",index=False,encoding='utf-8')


