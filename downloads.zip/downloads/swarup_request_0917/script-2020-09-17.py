import numpy as np
import pandas as pd
import recordlinkage as rl
import pandas as pd
from recordlinkage.preprocessing import clean, phonetic

df1=pd.read_excel("All_defhc_ds.xlsx",dtype=str)
df2=pd.read_excel("eem_edi_data.xlsx",dtype=str)
df1 = df1.head(10)
df2 = df2.head(10)

def miss_data(df):
    x = ['column_name','missing_data', 'missing_in_percentage']
    missing_data = pd.DataFrame(columns=x)
    columns = df.columns
    for col in columns:
        icolumn_name = col
        imissing_data = df[col].isnull().sum()
        imissing_in_percentage = (df[col].isnull().sum()/df[col].shape[0])*100

        missing_data.loc[len(missing_data)] = [icolumn_name, imissing_data, imissing_in_percentage]
    # print(missing_data)

miss_data(df2)
df2=df2.fillna("NA")

# print(df2.shape)
# for i in df2.columns:
#     print(i, "---> Unique values=", df2[i].nunique(),"|||| NA Values=", sum(pd.isnull(df2[i])), "|||type=", df2[i].dtype)

# print(df1.shape)
# for i in df1.columns:
#     print(i, "---> Unique values=", df1[i].nunique(),"|||| NA Values=", sum(pd.isnull(df1[i])), "|||type=", df1[i].dtype)

miss_data(df2)
miss_data(df1)

df1["NETWORK_PARENT_NAME"]=rl.preprocessing.clean(df1["NETWORK_PARENT_NAME"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df1["HQ_ADDRESS"]=rl.preprocessing.clean(df1["HQ_ADDRESS"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df1["HQ_CITY"]=rl.preprocessing.clean(df1["HQ_CITY"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df1["HQ_STATE"]=rl.preprocessing.clean(df1["HQ_STATE"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df1["HQ_ZIP_CODE"]=rl.preprocessing.clean(df1["HQ_ZIP_CODE"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')

df2["Billing_Name"]=rl.preprocessing.clean(df2["Billing_Name"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df2["Billing_NPPES_Parent_Name"]=rl.preprocessing.clean(df2["Billing_NPPES_Parent_Name"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df2["Billing_NPPES_DBA_Name"]=rl.preprocessing.clean(df2["Billing_NPPES_DBA_Name"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df2["Billing_NPPES_NPI_Name"]=rl.preprocessing.clean(df2["Billing_NPPES_NPI_Name"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df2["Billing_Adr1"]=rl.preprocessing.clean(df2["Billing_Adr1"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df2["Billing_City"]=rl.preprocessing.clean(df2["Billing_City"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df2["Billing_State"]=rl.preprocessing.clean(df2["Billing_State"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')
df2["Billing_Zip"]=rl.preprocessing.clean(df2["Billing_Zip"], lowercase=True, replace_by_none='[^ \\-\\_A-Za-z0-9]+', replace_by_whitespace='[\\-\\_]', strip_accents=None, remove_brackets=True, encoding='utf-8', decode_error='strict')

indexer = rl.Index()
indexer.full()
pairs = indexer.index(df1, df2)

# print (len(df1), len(df2), len(pairs))

compare_cl = rl.Compare()

compare_cl.string('NETWORK_PARENT_NAME','Billing_Name', method='levenshtein',label='NAME')
compare_cl.string('NETWORK_PARENT_NAME','Billing_NPPES_Parent_Name', method='levenshtein',label='Parent_Name')
compare_cl.string('NETWORK_PARENT_NAME','Billing_NPPES_DBA_Name', method='levenshtein',label='DBA_Name')
compare_cl.string('NETWORK_PARENT_NAME','Billing_NPPES_NPI_Name', method='levenshtein',label='NPI_Name')

compare_cl.string('HQ_ADDRESS','Billing_Adr1', method='levenshtein', label='ADDRESS')
compare_cl.string('HQ_CITY','Billing_City', method='levenshtein',  label='CITY')
compare_cl.exact('HQ_STATE','Billing_State',label='STATE')
compare_cl.exact('HQ_ZIP_CODE','Billing_Zip',label='ZIP')

print(df1.columns)
print(df2.columns)
features = compare_cl.compute(pairs, df1, df2)
print(features)
print(len(features))
print(features.columns)
features.index.names = ['Id_All_EDI', 'id_Defhc']
features = features.reset_index()
df1["id_df1"]=df1.index
df2["id_df2"]=df2.index
result= pd.merge(features, df1, left_on = 'id_Defhc', right_on = 'id_df1', how='left')
result= pd.merge(result, df2, left_on = 'Id_All_EDI', right_on = 'id_df2', how='left')
result["Name_score_max"]= result[['NAME', 'Parent_Name','DBA_Name','NPI_Name']].max(axis=1)
result["TotalScore"]=result["Name_score_max"]+result["ADDRESS"]+result["CITY"]+result['STATE']+result["ZIP"]
Result_match=result[result.TotalScore >= 3.5]
Result_unmatch=result[result.TotalScore < 3.5]
Result_match.to_csv("Result_match.csv")
Result_unmatch.to_csv("Result_unmatch.csv")
Result_match_Top= Result_match.groupby(["Id_All_EDI"]).apply(lambda x: x.sort_values(["TotalScore"], ascending = False)).reset_index(drop=True)
Result_match_Top=Result_match_Top.groupby("Id_All_EDI").head(1)
Result_match_Top.to_excel("AllEDI_Defhc_ascensiontop1.xlsx")