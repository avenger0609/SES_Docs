import os
import pandas as pd
import csv
from datetime import datetime


def sas_to_csv(fname,fullfn,p):
    
    time1 = datetime.now()        
    print("Conversion of "+str(fname)+" Started at "+str(datetime.now()))

    ## log file creation##
    logdt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')    
    logdir=r'/mapr/datalake/uhc/ei/hcemi/app/Logs'
    logfile= open(os.path.join(logdir,fname.split('.')[0]+logdt+'.log'),"w+")

    ## conversion start time
    logfile.write("Conversion of "+str(fname)+" Started at "+str(datetime.now())+"\n")

    sas_file=fullfn
    text_fname=fname.split('.')[0]+'.txt'    
    op_dir=r'/mapr/datalake/uhc/ei/hcemi/in/restricted/interim_files'
    txt_file=os.path.join(op_dir,text_fname)

    # print("sas file full path: "+sas_file)
    logfile.write("sas file full path: "+sas_file+"\n")
    

    try:
        c=1/p
        df = pd.read_sas(sas_file,encoding='latin-1')
        logfile.write("Number of columns present: "+str(len(df.columns))+"\n")
        logfile.write("Columns extracted:"+"\n")
        for lcwi in list(df.columns):                   
            logfile.write(str(lcwi)+"\n")
        logfile.write("Data Types of columns converted:")
        for lcwi in list(df.dtypes):                   
            logfile.write(str(lcwi)+"\n")
        df.to_csv(txt_file, sep='|', index=False)
        output_msg="converted text file has "+str(len(df))+" rows and "+str(len(df.columns))+" columns"
        # print(output_msg)
        logfile.write("Conversion of "+str(fname)+" Completed at "+str(datetime.now())+"\n")
        # logfile.write("Success|"+fname+"|"+fullfn+"|"+txt_file+"|"+str(output_msg)+"\n")
        logfile.write("converted file full path: "+txt_file+"\n")
        logfile.write(output_msg+"\n")
        return ["Success",fname,fullfn,txt_file,output_msg]
    except Exception as e:
        try:
            print("Running chunk option")
            reader = pd.read_sas(sas_file, chunksize=1000000,encoding='latin-1')
            no_of_lines_written=0
            for df in reader:
                if no_of_lines_written==0:    
                    logfile.write("Number of columns present: "+str(len(df.columns))+"\n")
                    logfile.write("Columns extracted:"+"\n")
                    for lcwi in list(df.columns):                   
                        logfile.write(str(lcwi)+"\n")
                    logfile.write("Data Types of columns converted:")
                    for lcwi in list(df.dtypes):                   
                        logfile.write(str(lcwi)+"\n")
                    df.to_csv(txt_file, sep='|', index=False)
                    no_of_lines_written=no_of_lines_written+len(df)
                    logfile.write("Number of lines written to file="+str(no_of_lines_written)+" at "+str(datetime.now())+"\n")
                else:                
                    df.to_csv(txt_file,mode="a",header=False,sep='|', index=False)
                    no_of_lines_written=no_of_lines_written+len(df)
                    logfile.write("Number of lines written to file="+str(no_of_lines_written)+" at "+str(datetime.now())+"\n")
                # print("One iteration completed")
            output_msg="converted text file has "+str(no_of_lines_written)+" rows and "+str(len(df.columns))+" columns"
            logfile.write("Conversion of "+str(fname)+" Completed at "+str(datetime.now())+"\n")
            # logfile.write("Success|"+fname+"|"+fullfn+"|"+txt_file+"|"+str(output_msg)+"\n")
            logfile.write("converted file full path: "+txt_file+"\n")
            logfile.write(output_msg+"\n")
            return ["Success",fname,fullfn,txt_file,output_msg]
        except Exception as e:
            logfile.write("Failed|"+fname+"|"+fullfn+"|"+txt_file+"|"+str(e)+"\n")
            return ["Failed",fname,fullfn,txt_file,str(e)]
    time2 = datetime.now()
    elapsedTime = time2 - time1    
    logfile.write("Time taken to transform "+str(elapsedTime.total_seconds())+" seconds\n")
    logfile.close()

    
def main(p):
    print("main function called")
    thisdir = r'/mapr/datalake/uhc/ei/hcemi/in/restricted/inbound'
    filter_lst=[]
    filter_lst=['pulse_adr_xref_fmts.sas7bdat']    
    for r, d, f in os.walk(thisdir):
        for file in f:
            if os.path.exists(os.path.join(r, file)) and (file.lower().endswith(".sas7bdat")):
                if len(filter_lst) > 0:
                    if file in filter_lst:
                        try:   
                            print(file)
                            res=sas_to_csv(file,os.path.join(r, file),p)          
                            # print(res)
                        except Exception as e:                                    
                            print(str(e))
                else:
                    try:   
                        res=sas_to_csv(file,os.path.join(r, file),p)          
                        # print(res)
                    except Exception as e:                                    
                        print(str(e))
main(1)
main(0)