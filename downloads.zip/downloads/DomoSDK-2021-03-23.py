from pydomo import Domo
import pandas
from datetime import datetime

 

CLIENT_ID = '1c42f21c-5029-45c6-8393-5f8c48c50327'
CLIENT_SECRET = '13466d70aec77f70041cae3a3af6791327fd6da0f9a2c862028336587bd08102'
API_HOST = 'api.domo.com'
domo = Domo(CLIENT_ID, CLIENT_SECRET, api_host=API_HOST)

# Download a data set from Domo
car_data = domo.ds_get('a119ab-1bad-40cc-af9c-9cbbfd192b02')
print(list(car_data.columns))

# # Create a summary data set, taking the mean of dollars by make and model.
# car_summary = car_data.groupby(['make','model']).agg({'dollars':'mean'}).reset_index()

# # Create a new data set in Domo with the result, the return value is the data set id of the new data set.
# car_ds = domo.ds_create(car_summary,'Python | Car Summary Data Set','Python | Generated during demo')
# print(car_ds)

# # Modify summary and then upload to the data set we already created. The SDK will update the data set schema automatically.
# car_summary2 = car_data.groupby(['make','model'],as_index=False).agg({'dollars':'mean','email':'count'}).reset_index()
# car_update = domo.ds_update(car_ds,car_summary2)
