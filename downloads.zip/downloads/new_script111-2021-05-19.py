import pandas as pd
import os
from pyhive import hive
from datetime import datetime
from pathlib import Path

paths = sorted(Path("/mapr/datalake/uhc/ei/hcemi/in/permitted/inbound").iterdir(), key=os.path.getmtime)
print(paths[-1])
absfilename=str(paths[-1])
db_name=absfilename.split('/')[-1].split('_')[0]
print(db_name)
conn = hive.Connection(host='apvrp80107', port=10494, database=db_name+'_hce_offshore', username='hcemioff', password='65V7NHzv', auth='CUSTOM')
cur=conn.cursor()
df=pd.read_csv(paths[-1],sep='\t')
df=df[0:1]
table_names=list(df['table'])
visited_tables=[]
row_counts=list(df['NOBS'])
visited_row_counts=[]
offshore_count_lst=[]
onshore_count_lst=[]
raw_count_lst=[]
status_lst=[]
outputfile='Outputfile'+'_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv'
for tni in range(0,len(table_names)):
    visited_tables.append(table_names[tni])
    visited_row_counts.append(row_counts[tni])
    try:
        sql_stmt="select sum(case when b.source like '"+db_name+"_hce_raw%' then value else 0 end) as count_at_raw,sum(case when b.source like'"+db_name+"_hce_onshore%' then value else 0 end) as count_at_onshore,sum(case when b.source like '"+db_name+"_hce_offshore%' then value else 0 end) as count_at_offshore from common.dq_analyzer_result as b join (select max(de_imported_date_ts) as run_date,source from common.dq_analyzer_result where name = 'Size' group by source)as run_date1 on run_date1.run_date=b.de_imported_date_ts and run_date1.source=b.source where b.name = 'Size' and b.source in('"+db_name+"_hce_raw."+table_names[tni]+"','"+db_name+"_hce_onshore."+table_names[tni]+"_vw','adr_hce_offshore."+table_names[tni]+"_vw')"
        print(sql_stmt)
        cur.execute(sql_stmt)
        record = cur.fetchone()
        raw_value= record[0]
        onshore_value= record[1]
        offshore_value= record[2]        
    except:
        raw_value=0
        onshore_value= 0
        offshore_value= 0

    
    raw_count_lst.append(raw_value)
    onshore_count_lst.append(onshore_value)
    offshore_count_lst.append(offshore_value)

    if (int(str(row_counts[tni]).replace(',',''))==raw_value) and raw_value==onshore_value and onshore_value==offshore_value:
        status_lst.append(True)        
    else:
        status_lst.append(False)
   
    df1=pd.DataFrame()
    df1['Table name']=visited_tables
    df1['Text file rowcount']=visited_row_counts
    df1['count_at_onshore']=onshore_count_lst
    df1['count_at_offshore']=offshore_count_lst
    df1['count_at_raw']=row_counts
    df1['Status']=status_lst
    df1.to_csv(outputfile,index=False)