from selenium import webdriver
import pandas as pd
import time
# from selenium.webdriver.support.select import select
import csv
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os


URL='https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers'
driverpath = r"C:\ProgramData\chromedriver_win32\chromedriver.exe"
# driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
output_dir='\\\\APVEP78970\\Users\\sali54\\Documents\\SES POC\\Downloads\\'+"Dept_Toys & Games_"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', True)
# chromeOptions.add_extension(r"C:\Users\sali54\Documents\SES POC\Scripts\Amazon Quick View by AMZScout.crx")
Start_time = datetime.now()
driver = webdriver.Chrome(executable_path=driverpath,chrome_options=chromeOptions)
driver.get(URL)
def get_best_seller_urls():
  
  ##----------------declarations
  final_urls_only=[]
  final_urls=[]
  dept_urls=[]
  sub_dept_urls_l1=[]
  sub_dept_urls_l2=[]
  sub_dept_urls_l3=[]
  sub_dept_urls_l4=[]
  sub_dept_urls_l5=[]
  sub_dept_urls_l6=[]
  sub_dept_urls_l7=[]
  sub_dept_urls_l8=[]
  sub_dept_urls_l9=[]
  sub_dept_urls_l10=[]  
  
  dept_urls_file=output_dir+'dept_urls_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l1_file=output_dir+'sub_dept_urls_l1_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l2_file=output_dir+'sub_dept_urls_l2_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l3_file=output_dir+'sub_dept_urls_l3_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l4_file=output_dir+'sub_dept_urls_l4_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l5_file=output_dir+'sub_dept_urls_l5_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l6_file=output_dir+'sub_dept_urls_l6_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l7_file=output_dir+'sub_dept_urls_l7_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l8_file=output_dir+'sub_dept_urls_l8_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l9_file=output_dir+'sub_dept_urls_l9_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
  sub_dept_urls_l10_file=output_dir+'sub_dept_urls_l10_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"

  ##----------------dept_urls
  URL='https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers'
  
  # driver.get(URL)
  dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]')
  dept_links = dept_lst.find_elements_by_tag_name('a')
  for dli in dept_links:
    dept_url = dli.get_attribute('href')
    # print(dept_url)
    final_urls_only.append(dept_url)
    dept_urls.append(dli.text+"!!!!!!!!!!"+dept_url)
    final_urls.append(dli.text+"!!!!!!!!!!"+dept_url)
    print(dli.text+"!!!!!!!!!!"+dept_url)
  print("First Level fetched in ",(datetime.now()-Start_time).total_seconds()," seconds")
  ## filter
  dept_urls=[dept_urls[0]]
  final_urls_only=[final_urls_only[0]]
  final_urls=[final_urls[0]]

  # try:
  #   uwfi=open(dept_urls_file,'w', encoding="utf-8")
  #   for uwfii in dept_urls:
  #     uwfi.write(uwfii+"\n")
  #   uwfi.close()
  # except Exception as e:
  #   print("Exception while writing to dept_urls_file ",e)

  ##---------------sub_dept_urls_l1
  print("level 1 started")
  for dui in dept_urls[0:1]:  
    
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l1.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            print(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
        print("Second Level fetched in ",(datetime.now()-Start_time).total_seconds()," seconds")
      except:
        pass
    except Exception as e:
      print(e)
  sub_dept_urls_l1_tmp=sub_dept_urls_l1
  sub_dept_urls_l1=[]
  for sli in sub_dept_urls_l1_tmp:
    if 'Toys & Baby' in sli:
      sub_dept_urls_l1.append(sli)


  # try:
  #   uwfi=open(sub_dept_urls_l1_file,'w', encoding="utf-8")
  #   for uwfii in sub_dept_urls_l1:
  #     uwfi.write(uwfii+"\n")
  #   uwfi.close()
  # except Exception as e:
  #   print("Exception while writing to sub_dept_urls_l1_file ",e)
  ##---------------sub_dept_urls_l2
  print("level 2 started")
  for dui in list(set(sub_dept_urls_l1))[0:1]:
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l2.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            print(print(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url))
      except:
        pass
    except Exception as e:
      print(e)
  try:
    uwfi=open(sub_dept_urls_l2_file,'w', encoding="utf-8")
    for uwfii in sub_dept_urls_l2:
      uwfi.write(uwfii+"\n")
    uwfi.close()
  except Exception as e:
    print("Exception while writing to sub_dept_urls_l2_file ",e)
  sub_dept_urls_l2=[]
  ##---------------sub_dept_urls_l3
  print("level 3 started")
  for dui in list(set(sub_dept_urls_l2)):
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l3.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            print(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except:
        pass
    except Exception as e:
      print(e)
  # try:
  #   uwfi=open(sub_dept_urls_l3_file,'w', encoding="utf-8")
  #   for uwfii in sub_dept_urls_l3:
  #     uwfi.write(uwfii+"\n")
  #   uwfi.close()
  # except Exception as e:
  #   print("Exception while writing to sub_dept_urls_l3_file ",e)
  ##---------------sub_dept_urls_l4
  print("level 4 started")
  for dui in list(set(sub_dept_urls_l3))[0:1]:
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l4.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            print(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except:
        pass
    except Exception as e:
      print(e)
  try:
    uwfi=open(sub_dept_urls_l4_file,'w', encoding="utf-8")
    for uwfii in sub_dept_urls_l4:
      uwfi.write(uwfii+"\n")
    uwfi.close()
  except Exception as e:
    print("Exception while writing to sub_dept_urls_l4_file ",e)
  ##---------------sub_dept_urls_l5
  print("level 5 started")
  for dui in list(set(sub_dept_urls_l4))[0:1]:
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l5.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            print(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except:
        pass
    except Exception as e:
      print(e)
  # try:
  #   uwfi=open(sub_dept_urls_l5_file,'w', encoding="utf-8")
  #   for uwfii in sub_dept_urls_l5:
  #     uwfi.write(uwfii+"\n")
  #   uwfi.close()
  # except Exception as e:
  #   print("Exception while writing to sub_dept_urls_l5_file ",e)
  ##---------------sub_dept_urls_l6
  print("level 6 started")
  for dui in list(set(sub_dept_urls_l5))[0:1]:
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l6.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            print(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except:
        pass
    except Exception as e:
      print(e)
  # try:
  #   uwfi=open(sub_dept_urls_l6_file,'w', encoding="utf-8")
  #   for uwfii in sub_dept_urls_l6:
  #     uwfi.write(uwfii+"\n")
  #   uwfi.close()
  # except Exception as e:
  #   print("Exception while writing to sub_dept_urls_l6_file ",e)
  ##---------------sub_dept_urls_l7
  print("level 7 started")
  for dui in set(sub_dept_urls_l6):
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul/ul/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l7.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except:
        pass
    except Exception as e:
      print(e)
  try:
    uwfi=open(sub_dept_urls_l7_file,'w', encoding="utf-8")
    for uwfii in sub_dept_urls_l7:
      uwfi.write(uwfii+"\n")
    uwfi.close()
  except Exception as e:
    print("Exception while writing to sub_dept_urls_l7_file ",e)
  ##---------------sub_dept_urls_l8
  print("level 8 started")
  for dui in set(sub_dept_urls_l7):
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul/ul/ul/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l8.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except:
        pass
    except Exception as e:
      print(e)
  try:
    uwfi=open(sub_dept_urls_l8_file,'w', encoding="utf-8")
    for uwfii in sub_dept_urls_l8:
      uwfi.write(uwfii+"\n")
    uwfi.close()
  except Exception as e:
    print("Exception while writing to sub_dept_urls_l8_file ",e)
  ##---------------sub_dept_urls_l9
  print("level 9 started")
  for dui in set(sub_dept_urls_l8):
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul/ul/ul/ul/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l9.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except:
        pass
    except Exception as e:
      print(e)
  try:
    uwfi=open(sub_dept_urls_l9_file,'w', encoding="utf-8")
    for uwfii in sub_dept_urls_l9:
      uwfi.write(uwfii+"\n")
    uwfi.close()
  except Exception as e:
    print("Exception while writing to sub_dept_urls_l9_file ",e)
  ##---------------sub_dept_urls_l10
  print("level 10 started")
  for dui in set(sub_dept_urls_l9):
    try:
      driver.get(dui.split("!!!!!!!!!!")[1])
      try:
        dept_lst=driver.find_element_by_xpath('//*[@id="zg_browseRoot"]/ul/ul/ul/ul/ul/ul/ul/ul/ul/ul')
        dept_links = dept_lst.find_elements_by_tag_name('a')
        for dli in dept_links:
          dept_url = dli.get_attribute('href')
          if dept_url not in final_urls_only:
            final_urls_only.append(dept_url)
            sub_dept_urls_l10.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
            final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
      except Exception as e:
        pass
    except Exception as e:
      print(str(e))
  try:
    uwfi=open(sub_dept_urls_l10_file,'w', encoding="utf-8")
    for uwfii in sub_dept_urls_l10:
      uwfi.write(uwfii+"\n")
    uwfi.close()
  except Exception as e:
    print("Exception while writing to sub_dept_urls_l10_file ",e)

  print(len(dept_urls))
  print(len(sub_dept_urls_l1))
  print(len(sub_dept_urls_l2))
  print(len(sub_dept_urls_l3))
  print(len(sub_dept_urls_l4))
  print(len(sub_dept_urls_l5))
  print(len(sub_dept_urls_l6))
  print(len(sub_dept_urls_l7))
  print(len(sub_dept_urls_l8))
  print(len(sub_dept_urls_l9))
  print(len(sub_dept_urls_l10))
  
  pagination_urls=[]

  for fi in set(final_urls):
    print(fi)
    driver.get(fi.split("!!!!!!!!!!")[1])
    ##-- to scroll to end
    ht=driver.execute_script("return document.documentElement.scrollHeight;")
    while True:
      prev_ht=driver.execute_script("return document.documentElement.scrollHeight;")
      driver.execute_script("window.scrollTo(0, document.documentElement.scrollHeight);")
      time.sleep(3)
      ht=driver.execute_script("return document.documentElement.scrollHeight;")
      if prev_ht==ht:
          break
    
    ##-- to scroll to end
    try:
      dept_lst=driver.find_element_by_xpath('//*[@id="zg-center-div"]/div[2]/div/ul')
      dept_links = dept_lst.find_elements_by_tag_name('a')
      for dli in dept_links:
        dept_url = dli.get_attribute('href')
        print(dept_url)
        # sub_dept_urls_l10.append(dept_url)
        pagination_urls.append(fi.split("!!!!!!!!!!")[0]+"!"+dli.text+"!!!!!!!!!!"+dept_url)
    except Exception as e:
      print(e)

  fname= output_dir+'Amazon_URLs_Best_Sellers_'+datetime.now().strftime('%d%m%Y%H%M%S')+'.csv'
  unq_fname=output_dir+'Amazon_Page_URLs_Best_Sellers_'+datetime.now().strftime('%d%m%Y%H%M%S')+'.csv'
  print(fname)
  print(unq_fname)
  
  try:
    abs_urls=open(fname,'w', encoding="utf-8")
    abs_urls_unq=open(unq_fname,'w', encoding="utf-8")

    for fi in (final_urls):
      abs_urls.write(fi+"\n")
    abs_urls.close()

    for fi in (pagination_urls):
      abs_urls_unq.write(fi+"\n")
    abs_urls_unq.close()
  except Exception as e:
    print(str(e))

  return set(pagination_urls)

# get_best_seller_urls()

def best_seller_products_details():

  output_fname=output_dir+'AMZRankExtractor'+datetime.now().strftime('%d%m%Y%H%M%S')+'.csv'
  # puef=open(r'\\APVEP78970\Users\sali54\Documents\SES POC\Downloads\Amazon_Page_URLs_Best_Sellers_09112020042935.csv',encoding='utf-8')
  # page_urls_extracted=list(set(puef.readlines()))
  page_urls_extracted=list(set(get_best_seller_urls()))
  for pgui in range(0,len(page_urls_extracted)):
    try:
      url1=page_urls_extracted[pgui].replace('\n','')
      print(url1.split("!!!!!!!!!!")[1])
      # time.sleep(60)
      driver.get(url1.split("!!!!!!!!!!")[1])
      # driver.find_element_by_xpath('/html/body/div[3]/div/div[1]/img').click()
      ##-- to scroll to end
      ht=driver.execute_script("return document.documentElement.scrollHeight;")
      while True:
        prev_ht=driver.execute_script("return document.documentElement.scrollHeight;")
        driver.execute_script("window.scrollTo(0, document.documentElement.scrollHeight);")
        time.sleep(5)
        ht=driver.execute_script("return document.documentElement.scrollHeight;")
        if prev_ht==ht:
            break  
      ##-- to scroll to end
      time.sleep(30)
      products=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]')
      li_lst=products.find_elements_by_tag_name('li')
      sno_lst=[]
      product_url_lst=[]
      product_title_lst=[]
      ratings_url_lst=[]
      ratings_lst=[]  
      reviews_url_lst=[]
      reviews_lst=[]
      price_lst=[]
      price_url_lst=[]

      product_rank_dept_sec_lst=[]
      product_rank_sec_lst=[]
      product_rank_dept_lst=[]
      product_rank_lst=[]
      product_weight_lst=[]
      product_size_lst=[]
      product_available_from_lst=[]
      product_brand_url_lst=[]
      product_brand_lst=[]
      product_asin_lst=[]
      Left_Pane_Data=url1.split("!!!!!!!!!!")[0]

      for lili in range(1,len(li_lst)+1):
      # for lili in range(1,5):
        print(lili)
        try:
          sno=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/div/span[1]/span').text 
        except:
          sno=""
        try:
          product_url=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/a').get_attribute('href')
        except:
          product_url=""
        try:
          product_title=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/a/div').text
          print(product_title)
        except:
          product_title=''
        try:
          ratings_url=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/div[1]/a[1]').get_attribute('href')
        except:
          ratings_url=""
        try:
          ratings=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/div[1]/a[1]').get_attribute('title')
        except:
          ratings=""
        try:
          reviews_url=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/div[1]/a[2]').get_attribute('href')
        except:
          reviews_url=""
        try:
          reviews=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/div[1]/a[2]').text
        except:
          reviews=""
        try:
          price=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/div[2]/a').text
        except:
          price=""
        try:
          price_url=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/div[2]/a').get_attribute('href')
        except:
          price_url=""
        
        product_asin=""
        product_brand=""
        product_brand_url=""
        product_available_from=""
        product_size=""
        product_weight=''

        try:
          # quick_view_data=driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/quick-view/div/div[2]/div[1]')
          quick_view_data=driver.find_elements_by_class_name('c0133')[lili]      
          print(len(driver.find_elements_by_class_name('c0133')))
          
          quick_view_elements=quick_view_data.find_elements_by_tag_name('div')
          print(len(quick_view_elements))
          for qvei in quick_view_elements:
            print(qvei.text)
            if 'asin:' in qvei.text.lower():
              product_asin=qvei.text
            elif 'Brand:'.lower() in  qvei.text.lower():
              product_brand=qvei.text
              product_brand_url=qvei.find_element_by_tag_name('a').get_attribute('href')
            elif 'Available From:'.lower() in qvei.text.lower():
              product_available_from=qvei.text
            elif 'Size:'.lower() in qvei.text.lower():
              product_size=qvei.text
            elif 'Weight:'.lower() in qvei.text.lower():
              product_weight=qvei.text
        except Exception as e:
          print("exception while reading qv data ",e)    

        
        try:
          product_rank=(driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/quick-view/div/div/div[2]/div/div/div[1]/span').text) # ranking in dept
        except:
          product_rank=""
        try:
          product_rank_dept=(driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/quick-view/div/div/div[2]/div/div/span[2]').text) # department
        except:
          product_rank_dept=""
        try:
          driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/quick-view/div/div/div[2]/div/div/div[2]/span').click()
          time.sleep(5)
          product_rank_sec=(driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/quick-view/div/div/div[2]/div[2]/div/div/span').text) # ranking in other dept
          # print(product_rank_sec)
        except:
          product_rank_sec=""
        try:
          product_rank_dept_sec=(driver.find_element_by_xpath('//*[@id="zg-ordered-list"]/li['+str(lili)+']/span/div/span/quick-view/div/div/div[2]/div[2]/div/span[2]').text) # department
          # print(product_rank_dept_sec)
        except:
          product_rank_dept_sec=""


        sno_lst.append(sno.strip(' '))
        product_url_lst.append(product_url.strip(' '))
        product_title_lst.append(product_title.strip(' '))
        ratings_url_lst.append(ratings_url.strip(' '))
        ratings_lst.append(ratings.strip(' ')) 
        reviews_url_lst.append(reviews_url.strip(' '))
        reviews_lst.append(reviews.strip(' '))
        price_lst.append(price.strip(' '))
        price_url_lst.append(price_url.strip(' '))


        product_rank_dept_sec_lst.append(product_rank_dept_sec.strip(' '))
        product_rank_sec_lst.append(product_rank_sec.strip(' '))
        product_rank_dept_lst.append(product_rank_dept.strip(' '))
        product_rank_lst.append(product_rank.strip(' '))
        product_weight_lst.append(product_weight.split(':')[1].strip(' '))
        product_size_lst.append(product_size.split(':')[1].strip(' '))
        product_available_from_lst.append(product_available_from.split(':')[1].strip(' '))
        product_brand_url_lst.append(product_brand_url.strip(' '))
        product_brand_lst.append(product_brand.split(':')[1].strip(' '))
        product_asin_lst.append(product_asin.split(':')[1].strip(' '))

        # print(product_available_from_lst,"Available")
        # print("Product weight",product_weight_lst)
        # print("Product size",product_size_lst)


      df=pd.DataFrame()
      df["S.No"]=sno_lst
      df["Title"]=product_title_lst
      df["Product URL"]=product_url_lst
      df["Ratings URL"]=ratings_url_lst
      df["Ratings"]=ratings_lst
      df["Reviews"]=reviews_lst
      df["Reviews URL"]=reviews_url_lst
      df["Price"]=price_lst
      df["Price URL"]=price_url_lst
      df["Secondary Rank Department"]=product_rank_dept_sec_lst
      df["Secondary Rank"]=product_rank_sec_lst
      df["Primary Rank Department"]=product_rank_dept_lst
      df["Primary Rank"]=product_rank_lst
      df["weight"]=product_weight_lst
      df["Size"]=product_size_lst
      df["Available From"]=product_available_from_lst
      df["Brand URL"]=product_brand_url_lst
      df["Brand"]=product_brand_lst
      df["ASIN"]=product_asin_lst
      df["Date Extracted"]=datetime.now().strftime('%d-%b-%Y %H:%M:%S')
      df["Left Pane Dept Data"]=Left_Pane_Data
      df["URL"]=url1.split("!!!!!!!!!!")[1]
      if pgui==0:
        df.to_csv(output_fname, index=False,quoting=csv.QUOTE_ALL,mode='w')
      else:
        df.to_csv(output_fname, index=False,quoting=csv.QUOTE_ALL,mode='a')
    except Exception as e:
      print(str(e))

get_best_seller_urls()


