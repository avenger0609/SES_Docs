from shutil import copyfile

# copyfile('\\\\NAS00038pn\\data\\Tech_Economics\\VMWare_ITBM\\Outgoing_Prod\\VM Ware_DISPLAY_NAME_1012001_1902_MPWR_ChargebackData.csv', 'C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\VM Ware_DISPLAY_NAME_1012001_1902_MPWR_ChargebackData.csv')
# copyfile(r'C:\Program Files (x86)\Google\Chrome\Temp\scoped_dir32856_1603187056\old_chrome.exe', r'C:\users\asrilekh\documents\old_chrome.exe')
fname='sqlalchemy_presto.py'
copyfile('C:\\Users\\asrilekh\\Downloads\\PyHive-master\\PyHive-master\\PyHive-master\\pyhive\\'+fname, 'C:\\ProgramData\\Anaconda3\\Lib\\site-packages\\pyhive\\'+fname)

# import os
# for dirs,fnames,test in os.walk(r'c:\users\asrilekh\documents\hive_test'):
#     print(dirs)
#     print(fnames)
#     print(test)


