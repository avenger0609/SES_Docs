
## worked
import pyodbc
from pandas import DataFrame
from datetime import datetime
import csv
print(datetime.now())
pyodbc.autocommit = True
con = pyodbc.connect("DSN=rada_Prod", autocommit=True)
cursor = con.cursor()
cursor.execute("select * from hsr_1.hsr_adr_xref_fmts union all select * from hsr_1.midm_adr_xref_fmts union all select * from hsr_1.pnl_adr_xref_fmts union all select * from hsr_1.std_adr_xref_fmts union all select * from hsr_1.uid_adr_xref_fmts")
df = DataFrame(cursor.fetchall())
df.columns = cursor.keys()
df.to_csv('C:\\Users\\asrilekh\\Documents\\Hive_Test.csv',index=False,quoting=csv.QUOTE_ALL)
print(df[0:10])
print(list(df.columns))
print(datetime.now())

## worked

