import os

root=r'c:\users\asrilekh'
root_files=[os.path.join(root, f) for f in os.listdir(root) if os.path.isfile(os.path.join(root, f))]
print(root_files)