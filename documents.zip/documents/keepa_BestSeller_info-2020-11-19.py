import keepa
from datetime import datetime
import pandas as pd
import csv

accesskey="c12t22821ud26l55gu3gj38t1a3bcsml88o57lpn9h6f63h638sskfkhu424blvt"
api=keepa.Keepa(accesskey)
output_dir='c:\\users\\asrilekh\\documents\\Keepa_Data_Extract\\'

def get_best_seller_asins(categoryID,CategoryName):

    resp=api.best_sellers_query(categoryID,domain='IN',rank_avg_range=0) # rank_avg_range 0 current BSR  #1 Average BSR
    print(resp)
    print(type(resp))
    filename=CategoryName+"_Best_Seller_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\Best Seller Search\\"+filename,"w")
    resf.write(str(resp))
    return resp

print(get_best_seller_asins('15412167031','Gardening'))