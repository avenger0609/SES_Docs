import keepa
from datetime import datetime
import pandas as pd
import csv
import requests

accesskey="c12t22821ud26l55gu3gj38t1a3bcsml88o57lpn9h6f63h638sskfkhu424blvt"
api=keepa.Keepa(accesskey)
output_dir='c:\\users\\asrilekh\\documents\\Keepa_Data_Extract\\'


def get_asin_info(CategoryName, search_asins_lst):
    print("Started ASIN Data Extracting for ",CategoryName)
    resp=api.query(search_asins_lst,domain='IN',history=True,rating=True,to_datetime=True,out_of_stock_as_nan=False
    ,stock=True,product_code_is_asin=True,progress_bar=True
    ,buybox=False,stats=365,offers=None,update=None)
    
    filename=output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN__Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    csvfilename=output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv"
    history_str=str(datetime.now().strftime('%d_%b_%Y_%H%M%S'))

    resf=open(filename,"w")
    resf.write(str(resp))
    resf.close()

    # df_asins_data=pd.DataFrame()
    df_AMAZON=pd.DataFrame()
    df_NEW=pd.DataFrame()
    df_USED=pd.DataFrame()
    df_SALES=pd.DataFrame()
    df_LISTPRICE=pd.DataFrame()
    df_NEW_FBM_SHIPPING=pd.DataFrame()
    df_NEW_FBA=pd.DataFrame()
    df_COUNT_NEW=pd.DataFrame()
    df_COUNT_USED=pd.DataFrame()
    df_EXTRA_INFO_UPDATES=pd.DataFrame()
    df_RATING=pd.DataFrame()
    df_COUNT_REVIEWS=pd.DataFrame()
    df_BUY_BOX_SHIPPING=pd.DataFrame()
    df_COLLECTIBLE=pd.DataFrame()
    df_REFURBISHED=pd.DataFrame()
    df_LIGHTNING_DEAL=pd.DataFrame()
    df_WAREHOUSE=pd.DataFrame()
    df_COUNT_REFURBISHED=pd.DataFrame()
    df_COUNT_COLLECTIBLE=pd.DataFrame()
    df_USED_NEW_SHIPPING=pd.DataFrame()
    df_USED_VERY_GOOD_SHIPPING=pd.DataFrame()
    df_USED_GOOD_SHIPPING=pd.DataFrame()
    df_USED_ACCEPTABLE_SHIPPING=pd.DataFrame()
    df_COLLECTIBLE_NEW_SHIPPING=pd.DataFrame()
    df_COLLECTIBLE_VERY_GOOD_SHIPPING=pd.DataFrame()
    df_COLLECTIBLE_GOOD_SHIPPING=pd.DataFrame()
    df_COLLECTIBLE_ACCEPTABLE_SHIPPING=pd.DataFrame()
    df_REFURBISHED_SHIPPING=pd.DataFrame()
    df_TRADE_IN=pd.DataFrame()

    products=resp

    final_dicts=[]
    print("Number of product information extracted ",len(products))
    for pi in range(0,len(products)):
        print("Collecting Product Information for Product Number ",pi+1)
        try:
            product=products[pi]
        except Exception as e:
            print(str(e)," Exceptin while retrieveing product number ",pi)
            continue
        
        final_result={}
        try:
            print(search_asins_lst[pi])
            final_result['SearchASIN']=search_asins_lst[pi]
        except:
            pass
        try:
            final_result['Categories']='&'.join([str(i) for i in product['categories']])
        except:
            final_result['Categories']=""
        try:
            final_result['FBAStorageFee']=str(product['fbaFees']['storageFee'])
        except:
            final_result['FBAStorageFee']=""
        try:
            final_result['FBAStorageFeeTax']=str(product['fbaFees']['storageFeeTax'])
        except:
            final_result['FBAStorageFeeTax']=""
        try:
            final_result['FBApickAndPackFee']=str(product['fbaFees']['pickAndPackFee'])
        except:
            final_result['FBApickAndPackFee']=""
        try:
            final_result['FBApickAndPackFeeTax']=str(product['fbaFees']['pickAndPackFeeTax'])
        except:
            final_result['FBApickAndPackFeeTax']=""
        try:
            CategoryTreeElements=product['categoryTree']
            # [{'catId': 976389031, 'name': 'Books'}, {'catId': 1318118031, 'name': 'Crafts, Hobbies & Home'}, {'catId': 1318122031, 'name': 'Gardening & Landscape Design'}]
            cat_tree_ids=[]
            cat_tree_names=[]
            try:
                for ctei in CategoryTreeElements:
                    cat_tree_ids.append(ctei['catId'])
                    cat_tree_names.append(ctei['name'])
                cat_tree_id=">".join(cat_tree_ids)
                cat_tree_names=">".join(cat_tree_names)   
                final_result['CategoryTreeID']=cat_tree_id  
                final_result['CategoryTreeNames']=cat_tree_names   
            except:
                final_result['CategoryTreeID']=""  
                final_result['CategoryTreeNames']=""  
        except:
            final_result['CategoryTreeID']=""  
            final_result['CategoryTreeNames']=""  

        print("Entered stage 1:")
        # print(final_result)

        direct_from_product= ['manufacturer','title','lastUpdate','lastPriceChange','rootCategory','productType','parentAsin','asin','domainId','type','hasReviews','trackingSince'
        ,'brand','productGroup','partNumber','model','color','size','edition','format','packageHeight','packageLength','packageWidth','packageWeight','packageQuantity','isAdultProduct','isEligibleForTradeIn','isEligibleForSuperSaverShipping'
        ,'isRedirectASIN','isSNS','author','binding','numberOfItems','numberOfPages','publicationDate','releaseDate'
        ,'lastRatingUpdate','description','newPriceIsMAP','availabilityAmazon','listedSince','itemHeight','itemLength','itemWidth','itemWeight','salesRankReference','launchpad','offersSuccessful','g'
        ]

        from_prod_stats=['stockAmazon','stockBuyBox','retrievedOfferCount','totalOfferCount','tradeInPrice','lastOffersUpdate','isAddonItem','offerCountFBA'
        ,'offerCountFBM','salesRankDrops30','salesRankDrops90','salesRankDrops180','salesRankDrops365','buyBoxPrice','buyBoxShipping','buyBoxIsUnqualified'
        ,'buyBoxIsShippable','buyBoxIsPreorder','buyBoxIsFBA','buyBoxIsAmazon','buyBoxIsMAP','buyBoxIsUsed','buyBoxIsBackorder','buyBoxIsPrimeExclusive'
        ,'buyBoxIsFreeShippingEligible','buyBoxIsPrimePantry','buyBoxIsPrimeEligible','buyBoxMinOrderQuantity','buyBoxMaxOrderQuantity','buyBoxCondition','buyBoxAvailabilityMessage','buyBoxShippingCountry','buyBoxSellerId','buyBoxIsWarehouseDeal'
        ]

        from_prod_offers=['lastSeen','sellerId','isPrime','isMAP','isShippable','isAddonItem','isPreorder','isWarehouseDeal','isScam','isAmazon'
        ,'isPrimeExcl','offerId','isFBA','shipsFromChina'
        ]

        for dfpi in direct_from_product:
            try:
                final_result[dfpi]=str(product[dfpi])
            except Exception as e:
                print("Exception while extracting directly from product ",dfpi,' ',str(e))
                final_result[dfpi]=str("")
        
        print("Entered stage 2:")
        # print(final_result)
        
        for dfpi in from_prod_stats:
            try:
                final_result['stats_'+dfpi]=str(product['stats'][dfpi])
            except Exception as e:
                print("Exception while extracting directly from product stats ",dfpi,' ',str(e))
                final_result['stats_'+dfpi]=""
        
        print("Entered stage 3:")
        # print(final_result)

        # for dfpi in from_prod_offers:
        #     try:
        #         final_result['offers_'+dfpi]=str(product['offers'][0][dfpi])
        #     except Exception as e:
        #         print("Exception while extracting directly from product offers ",dfpi,' ',str(e))
        #         final_result['offers_'+dfpi]=""
        
        # if len(product['offers']) > 1:
        #     for fpoi in range(1,len(product['offers'])):
        #         for dfpi in from_prod_offers:            
        #             try:
        #                 final_result['offers_'+dfpi]=final_result['offers_'+dfpi]+"&"+str(product['offers'][fpoi][dfpi])
        #             except Exception as e:
        #                 print("Exception while extracting directly from product offers ",dfpi,' ',str(e))
        #                 final_result['offers_'+dfpi]=""
        try:
            final_result['dfs available']=str(list(product['data'].keys()))
        except:
            final_result['dfs available']=""

        print("Entered stage 4:")
        # print(final_result)
        final_dicts.append(final_result)

        try:            
            pdo_keys=product['data'].keys()
            for pdki in pdo_keys:
                if pdki.upper().startswith('DF_'):
                    try:
                        df_temp=product['data'][pdki]
                        df_temp['SearchASIN']=search_asins_lst[pi]
                        product['data'][pdki]=df_temp
                    except:
                        pass
        except:
            pass
    
        try:
            if len(df_AMAZON) == 0:
                df_AMAZON=product['data']['df_AMAZON']
            else:
                df_AMAZON=df_AMAZON.append(product['data']['df_AMAZON'])
        except:
            pass
        try:
            if len(df_NEW) == 0:
                df_NEW=product['data']['df_NEW']
            else:
                df_NEW=df_NEW.append(product['data']['df_NEW'])
        except:
            pass
        try:
            if len(df_USED) == 0:
                df_USED=product['data']['df_USED']
            else:
                df_USED=df_USED.append(product['data']['df_USED'])
        except:
            pass
        try:
            if len(df_SALES) == 0:
                df_SALES=product['data']['df_SALES']
            else:
                df_SALES=df_SALES.append(product['data']['df_SALES'])
        except:
            pass
        try:
            if len(df_LISTPRICE) == 0:
                df_LISTPRICE=product['data']['df_LISTPRICE']
            else:
                df_LISTPRICE=df_LISTPRICE.append(product['data']['df_LISTPRICE'])
        except:
            pass
        try:
            if len(df_NEW_FBM_SHIPPING) == 0:
                df_NEW_FBM_SHIPPING=product['data']['df_NEW_FBM_SHIPPING']
            else:
                df_NEW_FBM_SHIPPING=df_NEW_FBM_SHIPPING.append(product['data']['df_NEW_FBM_SHIPPING'])
        except:
            pass
        try:
            if len(df_NEW_FBA) == 0:
                df_NEW_FBA=product['data']['df_NEW_FBA']
            else:
                df_NEW_FBA=df_NEW_FBA.append(product['data']['df_NEW_FBA'])
        except:
            pass
        try:
            if len(df_COUNT_NEW) == 0:
                df_COUNT_NEW=product['data']['df_COUNT_NEW']
            else:
                df_COUNT_NEW=df_COUNT_NEW.append(product['data']['df_COUNT_NEW'])
        except:
            pass
        try:
            if len(df_COUNT_USED) == 0:
                df_COUNT_USED=product['data']['df_COUNT_USED']
            else:
                df_COUNT_USED=df_COUNT_USED.append(product['data']['df_COUNT_USED'])
        except:
            pass
        try:
            if len(df_EXTRA_INFO_UPDATES) == 0:
                df_EXTRA_INFO_UPDATES=product['data']['df_EXTRA_INFO_UPDATES']
            else:
                df_EXTRA_INFO_UPDATES=df_EXTRA_INFO_UPDATES.append(product['data']['df_EXTRA_INFO_UPDATES'])
        except:
            pass
        try:
            if len(df_RATING) == 0:
                df_RATING=product['data']['df_RATING']
            else:
                df_RATING=df_RATING.append(product['data']['df_RATING'])
        except:
            pass
        try:
            if len(df_COUNT_REVIEWS) == 0:
                df_COUNT_REVIEWS=product['data']['df_COUNT_REVIEWS']
            else:
                df_COUNT_REVIEWS=df_COUNT_REVIEWS.append(product['data']['df_COUNT_REVIEWS'])
        except:
            pass
        try:
            if len(df_BUY_BOX_SHIPPING) == 0:
                df_BUY_BOX_SHIPPING=product['data']['df_BUY_BOX_SHIPPING']
            else:
                df_BUY_BOX_SHIPPING=df_BUY_BOX_SHIPPING.append(product['data']['df_BUY_BOX_SHIPPING'])
        except:
            pass
        try:
            if len(df_COLLECTIBLE) == 0:
                df_COLLECTIBLE=product['data']['df_COLLECTIBLE']
            else:
                df_COLLECTIBLE=df_COLLECTIBLE.append(product['data']['df_COLLECTIBLE'])
        except:
            pass
        try:
            if len(df_REFURBISHED) == 0:
                df_REFURBISHED=product['data']['df_REFURBISHED']
            else:
                df_REFURBISHED=df_REFURBISHED.append(product['data']['df_REFURBISHED'])
        except:
            pass
        try:
            if len(df_LIGHTNING_DEAL) == 0:
                df_LIGHTNING_DEAL=product['data']['df_LIGHTNING_DEAL']
            else:
                df_LIGHTNING_DEAL=df_LIGHTNING_DEAL.append(product['data']['df_LIGHTNING_DEAL'])
        except:
            pass
        try:
            if len(df_WAREHOUSE) == 0:
                df_WAREHOUSE=product['data']['df_WAREHOUSE']
            else:
                df_WAREHOUSE=df_WAREHOUSE.append(product['data']['df_WAREHOUSE'])
        except:
            pass
        try:
            if len(df_COUNT_REFURBISHED) == 0:
                df_COUNT_REFURBISHED=product['data']['df_COUNT_REFURBISHED']
            else:
                df_COUNT_REFURBISHED=df_COUNT_REFURBISHED.append(product['data']['df_COUNT_REFURBISHED'])
        except:
            pass
        try:
            if len(df_COUNT_COLLECTIBLE) == 0:
                df_COUNT_COLLECTIBLE=product['data']['df_COUNT_COLLECTIBLE']
            else:
                df_COUNT_COLLECTIBLE=df_COUNT_COLLECTIBLE.append(product['data']['df_COUNT_COLLECTIBLE'])
        except:
            pass        
        
        try:
            if len(df_USED_NEW_SHIPPING) == 0:
                df_USED_NEW_SHIPPING=product['data']['df_USED_NEW_SHIPPING']
            else:
                df_USED_NEW_SHIPPING=df_USED_NEW_SHIPPING.append(product['data']['df_USED_NEW_SHIPPING'])
        except:
            pass 
        try:
            if len(df_USED_VERY_GOOD_SHIPPING) == 0:
                df_USED_VERY_GOOD_SHIPPING=product['data']['df_USED_VERY_GOOD_SHIPPING']
            else:
                df_USED_VERY_GOOD_SHIPPING=df_USED_VERY_GOOD_SHIPPING.append(product['data']['df_USED_VERY_GOOD_SHIPPING'])
        except:
            pass
        try:
            if len(df_USED_GOOD_SHIPPING) == 0:
                df_USED_GOOD_SHIPPING=product['data']['df_USED_GOOD_SHIPPING']
            else:
                df_USED_GOOD_SHIPPING=df_USED_GOOD_SHIPPING.append(product['data']['df_USED_GOOD_SHIPPING'])
        except:
            pass
        try:
            if len(df_USED_ACCEPTABLE_SHIPPING) == 0:
                df_USED_ACCEPTABLE_SHIPPING=product['data']['df_USED_ACCEPTABLE_SHIPPING']
            else:
                df_USED_ACCEPTABLE_SHIPPING=df_USED_ACCEPTABLE_SHIPPING.append(product['data']['df_USED_ACCEPTABLE_SHIPPING'])
        except:
            pass
        try:
            if len(df_COLLECTIBLE_NEW_SHIPPING) == 0:
                df_COLLECTIBLE_NEW_SHIPPING=product['data']['df_COLLECTIBLE_NEW_SHIPPING']
            else:
                df_COLLECTIBLE_NEW_SHIPPING=df_COLLECTIBLE_NEW_SHIPPING.append(product['data']['df_COLLECTIBLE_NEW_SHIPPING'])
        except:
            pass
        try:
            if len(df_COLLECTIBLE_NEW_SHIPPING) == 0:
                df_COLLECTIBLE_NEW_SHIPPING=product['data']['df_COLLECTIBLE_NEW_SHIPPING']
            else:
                df_COLLECTIBLE_NEW_SHIPPING=df_COLLECTIBLE_NEW_SHIPPING.append(product['data']['df_COLLECTIBLE_NEW_SHIPPING'])
        except:
            pass
        try:
            if len(df_COLLECTIBLE_VERY_GOOD_SHIPPING) == 0:
                df_COLLECTIBLE_VERY_GOOD_SHIPPING=product['data']['df_COLLECTIBLE_VERY_GOOD_SHIPPING']
            else:
                df_COLLECTIBLE_VERY_GOOD_SHIPPING=df_COLLECTIBLE_VERY_GOOD_SHIPPING.append(product['data']['df_COLLECTIBLE_VERY_GOOD_SHIPPING'])
        except:
            pass
        try:
            if len(df_COLLECTIBLE_GOOD_SHIPPING) == 0:
                df_COLLECTIBLE_GOOD_SHIPPING=product['data']['df_COLLECTIBLE_GOOD_SHIPPING']
            else:
                df_COLLECTIBLE_GOOD_SHIPPING=df_COLLECTIBLE_GOOD_SHIPPING.append(product['data']['df_COLLECTIBLE_GOOD_SHIPPING'])
        except:
            pass
        try:
            if len(df_COLLECTIBLE_ACCEPTABLE_SHIPPING) == 0:
                df_COLLECTIBLE_ACCEPTABLE_SHIPPING=product['data']['df_COLLECTIBLE_ACCEPTABLE_SHIPPING']
            else:
                df_COLLECTIBLE_ACCEPTABLE_SHIPPING=df_COLLECTIBLE_ACCEPTABLE_SHIPPING.append(product['data']['df_COLLECTIBLE_ACCEPTABLE_SHIPPING'])
        except:
            pass
        try:
            if len(df_REFURBISHED_SHIPPING) == 0:
                df_REFURBISHED_SHIPPING=product['data']['df_REFURBISHED_SHIPPING']
            else:
                df_REFURBISHED_SHIPPING=df_REFURBISHED_SHIPPING.append(product['data']['df_REFURBISHED_SHIPPING'])
        except:
            pass
        try:
            if len(df_TRADE_IN) == 0:
                df_TRADE_IN=product['data']['df_TRADE_IN']
            else:
                df_TRADE_IN=df_TRADE_IN.append(product['data']['df_TRADE_IN'])
        except:
            pass
        
        try:
            df = pd.DataFrame(final_dicts)    
            df.to_csv(csvfilename,index=False,quoting=csv.QUOTE_ALL)
        except Exception as e:
            print("Exception while writing main dataframe data to csv file "," ",str(e))

        dfs_names_lst=['AMAZON','NEW','USED','SALES','LISTPRICE','NEW_FBM_SHIPPING','NEW_FBA','COUNT_NEW','COUNT_USED','EXTRA_INFO_UPDATES'
        ,'RATING','COUNT_REVIEWS','BUY_BOX_SHIPPING','COLLECTIBLE','REFURBISHED','LIGHTNING_DEAL','WAREHOUSE','COUNT_REFURBISHED'
        ,'COUNT_COLLECTIBLE','USED_NEW_SHIPPING','USED_VERY_GOOD_SHIPPING','USED_GOOD_SHIPPING','USED_ACCEPTABLE_SHIPPING','COLLECTIBLE_NEW_SHIPPING'
        ,'COLLECTIBLE_VERY_GOOD_SHIPPING','COLLECTIBLE_GOOD_SHIPPING','COLLECTIBLE_ACCEPTABLE_SHIPPING','REFURBISHED_SHIPPING','TRADE_IN']

        dfs_lst=[df_AMAZON,df_NEW,df_USED,df_SALES,df_LISTPRICE,df_NEW_FBM_SHIPPING,df_NEW_FBA,df_COUNT_NEW,df_COUNT_USED,df_EXTRA_INFO_UPDATES,df_RATING
        ,df_COUNT_REVIEWS,df_BUY_BOX_SHIPPING,df_COLLECTIBLE,df_REFURBISHED,df_LIGHTNING_DEAL,df_WAREHOUSE,df_COUNT_REFURBISHED,df_COUNT_COLLECTIBLE
        ,df_USED_NEW_SHIPPING,df_USED_VERY_GOOD_SHIPPING,df_USED_GOOD_SHIPPING,df_USED_ACCEPTABLE_SHIPPING,df_COLLECTIBLE_NEW_SHIPPING,df_COLLECTIBLE_VERY_GOOD_SHIPPING
        ,df_COLLECTIBLE_GOOD_SHIPPING,df_COLLECTIBLE_ACCEPTABLE_SHIPPING,df_REFURBISHED_SHIPPING,df_TRADE_IN]
        
        # print(len(dfs_names_lst))
        # print(len(dfs_lst))
        for dfli in range(0,len(dfs_lst)):
            try:
                df1=dfs_lst[dfli]                
                if len(df1) >0:
                    # df1['SearchASIN']=search_asins_lst[pi]
                    df1.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_"+str(dfs_names_lst[dfli])+"_History_Data"+history_str+".csv",index=False,quoting=csv.QUOTE_ALL)
            except Exception as e:
                print("Exception while writing dataframe data to csv file ",str(dfs_names_lst[dfli])," ",str(e))
        # df_AMAZON.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Amazon_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_NEW.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_New_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_USED.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Used_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_SALES.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Sales_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_LISTPRICE.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_ListPrice_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_NEW_FBM_SHIPPING.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_New_FBM_Shipping_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_NEW_FBA.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_New_FBA_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_COUNT_NEW.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Count_New_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_COUNT_USED.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Count_Used_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_EXTRA_INFO_UPDATES.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Extra_Info_Updates_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_RATING.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Rating_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_COUNT_REVIEWS.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Count_Reviews_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
        # df_BUY_BOX_SHIPPING.to_csv(output_dir+"\\Consolidated_Category_Best_Selling\\"+CategoryName+"_ASIN_Buy_Box_Shipping_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,quoting=csv.QUOTE_ALL)
    print("Completed ASIN Data Extracting for ",CategoryName)

def get_best_seller_asins(categoryID,CategoryName):
    print(categoryID,CategoryName)
    resp=api.best_sellers_query(categoryID,domain='IN',rank_avg_range=0) # rank_avg_range 0 current BSR  #1 Average BSR
    # print(resp)
    # print(type(resp))
    filename=CategoryName+"_Best_Seller_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\Consolidated_Category_Best_Selling\\"+filename,"w")
    resf.write(str(resp))
    print(CategoryName," Contains ",len(resp)," best selling products")
    get_asin_info(CategoryName,resp)

print(requests.get('https://api.keepa.com/token?key='+accesskey).text.split(':')[2].replace(',"refillIn"',''))
# src_df=pd.read_excel(output_dir+"\\"+'Src_Categories.xlsx')
# src_cat_ids=list(src_df['CategoryID'])[0:2]
# src_cat_names=list(src_df['CategoryName'])[0:2]
# for sci in range(0,len(src_cat_ids)):
#     get_best_seller_asins(str(src_cat_ids[sci]).strip(' '),str(src_cat_names[sci]).strip(' '))
    
get_asin_info('CategoryName',['B00W9EM4J0', 'B07VS4GSX4', 'B085GQ4NG8', 'B085GP7TWF', 'B085GPYYQ9', 'B06XQPFZ5L', 'B00JDACH3Q', 'B07V1X67VT', 'B079R9VZ9F'])
print(requests.get('https://api.keepa.com/token?key='+accesskey).text.split(':')[2].replace(',"refillIn"',''))


