import subprocess, sys

p = subprocess.Popen(["powershell.exe","C:\\Users\\asrilekh\\documents\\lighthouse_ts.ps1"],stdout=sys.stdout)
p.communicate() 