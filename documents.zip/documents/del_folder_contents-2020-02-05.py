import os
import shutil

for root, dirs, files in os.walk(r'C:\Users\asrilekh\AppData\Local\Temp'):
    for f in files:
        try:
            os.unlink(os.path.join(root, f))
        except:
            pass
    for d in dirs:
        try:
            shutil.rmtree(os.path.join(root, d))
        except:
            pass