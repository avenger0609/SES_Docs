from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
import numpy as np
from datetime import datetime

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
output_filename='JungleScout_Sales_Estimates_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
df=pd.DataFrame()
df['ASIN']=[]
df["Category"]=[]
df['Category Rank']=[]
df['Estimated Monthly Sales']=[]
df['Estimated Daily Sales']=[]
df['Extracted Date']=[]  #str(datetime.now().strftime('%Y%m%d%H%M%S'))
df.to_csv(output_filename,index=False,quoting=csv.QUOTE_ALL)
driver.get('https://www.junglescout.com/estimator/')
Country="India"
Categories={}
Categories['Baby']=15
Categories['Baby Products']=17
Categories['Bags, Wallets & Luggage']=19
Categories['Beauty']=25
Categories['Books']=38
Categories['Car & Motorbike']=44
Categories['Clothing & Accessories']=53
Categories['Electronics']=75
Categories['Gift Cards']=92
Categories['Grocery & Gourmet Foods']=98
Categories['Health & Personal Care']=104
Categories['Home & Kitchen']=113
Categories['Industrial & Scientific']=121
Categories['Jewellery']=132
Categories['Movies & TV Shows']=159
Categories['Music']=162
Categories['Musical Instruments']=166
Categories['Office Products']=173
Categories['Pet Supplies']=184
Categories['Shoes & Handbags']=197
Categories['Software']=202
Categories['Sports, Fitness & Outdoors']=213
Categories['Toys & Games']=224
Categories['Video Games']=230
Categories['Watches']=237

def get_estimates(cat_value,cat_rank,asn_value):

    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[2]/td[2]/input').send_keys(cat_rank)
    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[3]/td[2]/div/span/i').click()
    time.sleep(3)
    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[3]/td[2]/div/input').send_keys(Country[0:3])
    time.sleep(3)
    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[3]/td[2]/div/ul/li[6]').click()
    ## India plus 496 tested successfully

    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[4]/td[2]/div/span/i').click()
    time.sleep(3)
    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[4]/td[2]/div/input').send_keys(cat_value[0:3])

    cat_index=Categories.get(cat_value)
    print(cat_index,cat_value,cat_rank)
    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[4]/td[2]/div/ul/li['+str(cat_index)+']').click()
    driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[5]/td[2]/a[2]').click()
    time.sleep(5)
    Estimates=driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[1]/td[2]/p').text
    print(Estimates)
    df=pd.DataFrame()
    df['ASIN']=[asn_value]
    df["Category"]=[cat_value]
    df['Category Rank']=[cat_rank]    
    df['Estimated Monthly Sales']=[Estimates]
    df['Estimated Daily Sales']=[str(round(int(Estimates)/30,2))]
    
    df['Extracted Date']=str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    df.to_csv(output_filename,index=False,quoting=csv.QUOTE_ALL,mode='a',header=False)
    # driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[5]/td[2]/a[1]').click()
    driver.get('https://www.junglescout.com/estimator/')
    time.sleep(5)

# get_estimates("Baby","496")
def main():
    df_ip=pd.read_excel('ProductDetails06112020230709230999.xlsx')
    rank_dept=list(df_ip['Primary Rank Department'])    
    asn_lst=list(df_ip['ASIN'])  
    rank=list(df_ip['Primary Rank'])
    for rdi in range(0,5):
        get_estimates(rank_dept[rdi],rank[rdi].replace('#','').replace(',',''),asn_lst[rdi])

main()