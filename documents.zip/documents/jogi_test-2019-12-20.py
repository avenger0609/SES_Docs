import json
import time
import boto3
import datetime
import calendar
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# athena constant
DATABASE = "p360_clia"
TABLE = "p360_clia_offered_tmp5"

# S3 constant
S3_OUTPUT = 's3://p360-poc-analytics-tools/Athena_Staging_Area/'

S3_BUCKET = 'location-data-query-results'

# number of retries
RETRY_COUNT = 10
    
def lambda_handler(event, context):

    def execute_query(query):
        client = boto3.client('athena')
        
        # Execution
        response = client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={
                'Database': DATABASE
            },
            ResultConfiguration={
                'OutputLocation': S3_OUTPUT,
            }
        )
        
        # get query execution id
        print(str(response))
        query_execution_id = response['QueryExecutionId']
        return query_execution_id
        
            
    def prepare_table():
        table_name='%s.%s' % (DATABASE, TABLE)
       
        result = execute_query("SHOW TABLES")
        list_of_tables=[]
        for i in range(len(result["ResultSet"]["Rows"])):
            list_of_tables.append(result["ResultSet"]["Rows"][i]["Data"][0]['VarCharValue'])  
        if table_name in list_of_tables:
            logging.exception(f"The Table {DATABASE}.{TABLE} available")
            query = 'DROP TABLE %s.%s' % (DATABASE, TABLE)
            result = execute_query(query)  
        else:
            logging.exception(f"The Table {DATABASE}.{TABLE} not available")
    logger.info('## EVENT')
    logger.info(event)
    print("test")
    
    prepare_table()
    return
    
    
