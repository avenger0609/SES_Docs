## worked ###

from selenium import webdriver
driverpath = "C:\\ProgramData\\Chrome_driver_2.46\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
# driver = webdriver.Chrome("C:\\ProgramData\\Chrome_driver_2.46\\chromedriver.exe")
driver.get("http://cfrservices.uhg.com/Info/TreeReport")
driver.find_element_by_link_text('UHG_OPERATING_UNIT_GEN_PSTREE.csv').click()
