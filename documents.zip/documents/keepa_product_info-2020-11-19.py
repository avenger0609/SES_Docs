import keepa
from datetime import datetime
import pandas as pd
import csv

accesskey="c12t22821ud26l55gu3gj38t1a3bcsml88o57lpn9h6f63h638sskfkhu424blvt"
api=keepa.Keepa(accesskey)
output_dir='c:\\users\\asrilekh\\documents\\Keepa_Data_Extract\\'

def get_asin_info(search_asin):

    resp=api.query(search_asin,domain='IN',history=True,rating=True,to_datetime=True,out_of_stock_as_nan=False
    ,stock=True,product_code_is_asin=True,progress_bar=True
    ,buybox=False,stats=365,offers=21,update=0)
    
    filename=output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    csvfilename=output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv"
    
    df_AMAZON=pd.DataFrame()
    df_NEW=pd.DataFrame()
    df_USED=pd.DataFrame()
    df_SALES=pd.DataFrame()
    df_LISTPRICE=pd.DataFrame()
    df_NEW_FBM_SHIPPING=pd.DataFrame()
    df_NEW_FBA=pd.DataFrame()
    df_COUNT_NEW=pd.DataFrame()
    df_COUNT_USED=pd.DataFrame()
    df_EXTRA_INFO_UPDATES=pd.DataFrame()
    df_RATING=pd.DataFrame()
    df_COUNT_REVIEWS=pd.DataFrame()
    df_BUY_BOX_SHIPPING=pd.DataFrame()


    resf=open(filename,"w")
    resf.write(str(resp))
    final_dicts=[]
    products=resp
    final_result={}
    product=products[0]

    try:
        final_result['Categories']='&'.join([str(i) for i in product['categories']])
    except:
        pass
    try:
        final_result['FBAStorageFee']=product['fbaFees']['storageFee']
    except:
        pass
    try:
        final_result['FBAStorageFeeTax']=product['fbaFees']['storageFeeTax']
    except:
        pass
    try:
        final_result['FBApickAndPackFee']=product['fbaFees']['pickAndPackFee']
    except:
        pass
    try:
        final_result['FBApickAndPackFeeTax']=product['fbaFees']['pickAndPackFeeTax']
    except:
        pass

    CategoryTreeElements=product['categoryTree']
    # [{'catId': 976389031, 'name': 'Books'}, {'catId': 1318118031, 'name': 'Crafts, Hobbies & Home'}, {'catId': 1318122031, 'name': 'Gardening & Landscape Design'}]
    cat_tree_ids=[]
    cat_tree_names=[]
    try:
        for ctei in CategoryTreeElements:
            cat_tree_ids.append(ctei['catId'])
            cat_tree_names.append(ctei['name'])
        cat_tree_id=">".join(cat_tree_ids)
        cat_tree_names=">".join(cat_tree_names)   
        final_result['CategoryTreeID']=cat_tree_id  
        final_result['CategoryTreeNames']=cat_tree_names   
    except:
        pass

    print("Entered stage 1:")
    print(final_result)

    direct_from_product= ['manufacturer','title','lastUpdate','lastPriceChange','rootCategory','productType','parentAsin','asin','domainId','type','hasReviews','trackingSince'
    ,'brand','productGroup','partNumber','model','color','size','edition','format','packageHeight','packageLength','packageWidth','packageWeight','packageQuantity','isAdultProduct','isEligibleForTradeIn','isEligibleForSuperSaverShipping'
    ,'isRedirectASIN','isSNS','author','binding','numberOfItems','numberOfPages','publicationDate','releaseDate'
    ,'lastRatingUpdate','description','newPriceIsMAP','availabilityAmazon','listedSince','itemHeight','itemLength','itemWidth','itemWeight','salesRankReference','launchpad','offersSuccessful','g'
    ]

    from_prod_stats=['stockAmazon','stockBuyBox','retrievedOfferCount','totalOfferCount','tradeInPrice','lastOffersUpdate','isAddonItem','offerCountFBA'
    ,'offerCountFBM','salesRankDrops30','salesRankDrops90','salesRankDrops180','salesRankDrops365','buyBoxPrice','buyBoxShipping','buyBoxIsUnqualified'
    ,'buyBoxIsShippable','buyBoxIsPreorder','buyBoxIsFBA','buyBoxIsAmazon','buyBoxIsMAP','buyBoxIsUsed','buyBoxIsBackorder','buyBoxIsPrimeExclusive'
    ,'buyBoxIsFreeShippingEligible','buyBoxIsPrimePantry','buyBoxIsPrimeEligible','buyBoxMinOrderQuantity','buyBoxMaxOrderQuantity','buyBoxCondition','buyBoxAvailabilityMessage','buyBoxShippingCountry','buyBoxSellerId','buyBoxIsWarehouseDeal'
    ]

    from_prod_offers=['lastSeen','sellerId','isPrime','isMAP','isShippable','isAddonItem','isPreorder','isWarehouseDeal','isScam','isAmazon'
    ,'isPrimeExcl','offerId','isFBA','shipsFromChina'
    ]

    for dfpi in direct_from_product:
        try:
            final_result[dfpi]=str(product[dfpi])
        except Exception as e:
            print("Exception while extracting directly from product ",dfpi,' ',str(e))
    
    print("Entered stage 2:")
    print(final_result)
    
    for dfpi in from_prod_stats:
        try:
            final_result['stats_'+dfpi]=str(product['stats'][dfpi])
        except Exception as e:
            print("Exception while extracting directly from product stats ",dfpi,' ',str(e))
    
    print("Entered stage 3:")
    print(final_result)

    for dfpi in from_prod_offers:
        try:
            final_result['offers_'+dfpi]=str(product['offers'][0][dfpi])
        except Exception as e:
            print("Exception while extracting directly from product offers ",dfpi,' ',str(e))
    
    if len(product['offers']) > 1:
        for fpoi in range(1,len(product['offers'])):
            for dfpi in from_prod_offers:            
                try:
                    final_result['offers_'+dfpi]=final_result['offers_'+dfpi]+"&"+str(product['offers'][fpoi][dfpi])
                except Exception as e:
                    print("Exception while extracting directly from product offers ",dfpi,' ',str(e))

    
    print("Entered stage 4:")
    print(final_result)

    final_dicts.append(final_result)
    df = pd.DataFrame(final_dicts)
    df['SearchASIN']=search_asin
    df.to_csv(csvfilename,index=False,quoting=csv.QUOTE_ALL)

    if len(df_AMAZON) > 0:
        df_AMAZON=product['data']['df_AMAZON']
    else:
        df_AMAZON=df_AMAZON.append(product['data']['df_AMAZON'])
    if len(df_NEW) > 0:
        df_NEW=product['data']['df_NEW']
    else:
        df_NEW=df_NEW.append(product['data']['df_NEW'])
    if len(df_USED) > 0:
        df_USED=product['data']['df_USED']
    else:
        df_USED=df_USED.append(product['data']['df_USED'])
    if len(df_SALES) > 0:
        df_SALES=product['data']['df_SALES']
    else:
        df_SALES=df_SALES.append(product['data']['df_SALES'])
    if len(df_LISTPRICE) > 0:
        df_LISTPRICE=product['data']['df_LISTPRICE']
    else:
        df_LISTPRICE=df_LISTPRICE.append(product['data']['df_LISTPRICE'])
    if len(df_NEW_FBM_SHIPPING) > 0:
        df_NEW_FBM_SHIPPING=product['data']['df_NEW_FBM_SHIPPING']
    else:
        df_NEW_FBM_SHIPPING=df_NEW_FBM_SHIPPING.append(product['data']['df_NEW_FBM_SHIPPING'])
    if len(df_NEW_FBA) > 0:
        df_NEW_FBA=product['data']['df_NEW_FBA']
    else:
        df_NEW_FBA=df_NEW_FBA.append(product['data']['df_NEW_FBA'])
    if len(df_COUNT_NEW) > 0:
        df_COUNT_NEW=product['data']['df_COUNT_NEW']
    else:
        df_COUNT_NEW=df_COUNT_NEW.append(product['data']['df_COUNT_NEW'])
    if len(df_COUNT_USED) > 0:
        df_COUNT_USED=product['data']['df_COUNT_USED']
    else:
        df_COUNT_USED=df_COUNT_USED.append(product['data']['df_COUNT_USED'])
    if len(df_EXTRA_INFO_UPDATES) > 0:
        df_EXTRA_INFO_UPDATES=product['data']['df_EXTRA_INFO_UPDATES']
    else:
        df_EXTRA_INFO_UPDATES=df_EXTRA_INFO_UPDATES.append(product['data']['df_EXTRA_INFO_UPDATES'])
    if len(df_RATING) > 0:
        df_RATING=product['data']['df_RATING']
    else:
        df_RATING=df_RATING.append(product['data']['df_RATING'])
    if len(df_COUNT_REVIEWS) > 0:
        df_COUNT_REVIEWS=product['data']['df_COUNT_REVIEWS']
    else:
        df_COUNT_REVIEWS=df_COUNT_REVIEWS.append(product['data']['df_COUNT_REVIEWS'])
    if len(df_BUY_BOX_SHIPPING) > 0:
        df_BUY_BOX_SHIPPING=product['data']['df_BUY_BOX_SHIPPING']
    else:
        df_BUY_BOX_SHIPPING=df_BUY_BOX_SHIPPING.append(product['data']['df_BUY_BOX_SHIPPING'])
    
    df_AMAZON.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Amazon_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_NEW.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_New_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_USED.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Used_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_SALES.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Sales_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_LISTPRICE.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_ListPrice_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_NEW_FBM_SHIPPING.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_New_FBM_Shipping_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_NEW_FBA.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_New_FBA_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_COUNT_NEW.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Count_New_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_COUNT_USED.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Count_Used_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_EXTRA_INFO_UPDATES.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Extra_Info_Updates_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_RATING.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Rating_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_COUNT_REVIEWS.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Count_Reviews_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)
    df_BUY_BOX_SHIPPING.to_csv(output_dir+"\\ASIN Search\\"+search_asin+"_ASIN_Buy_Box_Shipping_History_Data"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv",index=False,encoding=csv.QUOTE_ALL)

get_asin_info('178472369X')
