from flask import Flask
from flask import render_template,jsonify,request
import requests
from demo_module import *
import random
import urllib3
from flask_cors import CORS
import json



app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False
app.secret_key = '12345'
CORS(app)

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route("/parse", methods=['GET', 'POST', 'OPTIONS'])
def parse():

    try:
        ### to read parameters###

        # parsed=(urllib3.util.url.parse_url(request.url))        
        # s1=str(str(parsed.query).split('&')[0].split('=')[1].replace('+',' ')) # first query        
        # while True:
        #     a=s1.find("%")
        #     if a > -1:
        #         ss=s1[a]+s1[a+1]+s1[a+2]
        #         s1=s1.replace(ss," ")
        #     else:
        #         break 
        # s1=s1.replace('  ',' ').replace('  ',' ').strip(' ')         
        # uid_gen=0 # to check if user id was sent or not
        # sessid_gen=0 # to check if session id was sent or not
        # userid_ang="DEFAULT" # to store user id sent from angular
        # sess_id_ang="DEFAULT"# to store session id sent from angular      
        
        # try:
            # userid_ang=str(str(parsed.query).split('&')[1].split('=')[1].replace('+',' ')) # second query
            # uid_gen=1            
        # except:
        #     uid_gen=0
        # try:
        #     sess_id_ang=str(str(parsed.query).split('&')[2].split('=')[1].replace('+',' ')) # second query
            # sessid_gen=1
        # except:
        #     sessid_gen=0

        ### to read parameters###
        res=test_module()
        return jsonify({"response":str(res)})
        # return jsonify({"response":conv_answer,"object_id":conv_obj_id,"Suggestions":sugg_list})
    except Exception as e:    
        print(e) 
        return jsonify({"response":"Sorry I do not have an answer for that. You may reach out to us through call or email for assistance."})   


app.config["DEBUG"] = True
if __name__ == "__main__":
    # app.run(host='localhost',port=5050,debug=True)
    app.run(host='apsrp03693',port=5051,debug=True)