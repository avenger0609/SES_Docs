def test_module():
    return "Hello world"