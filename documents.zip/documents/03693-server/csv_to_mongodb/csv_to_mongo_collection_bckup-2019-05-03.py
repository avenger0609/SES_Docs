import pandas as pd
from pymongo import MongoClient
import pymongo



myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
print(myclient.list_database_names())
mydb = myclient["HandsFreeAnalytics"]
print(mydb.list_collection_names())
mycol = mydb["hfa_claims_1819"]
mycol.drop()
cdf=pd.read_csv('/home/asrilekh/csv_to_mongodb/detail1.csv',sep='\t',encoding = 'unicode_escape')
print(cdf.columns)
converterS = {col: str for col in cdf.columns}
df = pd.read_csv('/home/asrilekh/csv_to_mongodb/detail1.csv',sep='\t',converters=converterS,encoding = 'unicode_escape')
print(str(len(df)))
print(str(len(df.columns)))
data =[]
for row in range(0,len(df)):
    print(str(row))
    elm = {}
    for col in range(0,len(df.columns)):
        elm[df.columns[col]]=str(df.iloc[row,col])
    data.append(elm)
# print(data)
x = mycol.insert_many(data)
print(str(x.inserted_ids))
    