import pandas as pd
from pymongo import MongoClient
import pymongo
import time
import datetime

def encode_date(value):
    return datetime.datetime.combine(value,datetime.datetime.min.time())

myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
print(myclient.list_database_names())
mydb = myclient["HandsFreeAnalytics"]
print(mydb.list_collection_names())
mycol = mydb["hfa_claims_1819_20190619"]
mycol.drop()
cdf=pd.read_csv('/app/qualtrics/rasa/detailmay.csv',sep='\t',encoding = 'unicode_escape',skiprows=1)
print(cdf.columns)
converterS = {col: str for col in cdf.columns}
df = pd.read_csv('/app/qualtrics/rasa/detailmay.csv',sep='\t',converters=converterS,encoding = 'unicode_escape',skiprows=1)
print(str(len(df)))
print(str(len(df.columns)))
data =[]
time.sleep(30)
for row in range(0,len(df)):
# for row in range(0,10):
    print(str(row))
    try:
        elm = {}
        for col in range(0,len(df.columns)):
            elm[str(df.columns[col]).split('.')[1]]=str(df.iloc[row,col])
        rdcs=str(df.iloc[row,5]).replace(' 00:00:00.0','')
        elm['received_date_str']=rdcs
        rdcs=str(df.iloc[row,6]).replace(' 00:00:00.0','')
        elm['from_date_str']=rdcs
        rdcs=str(df.iloc[row,7]).replace(' 00:00:00.0','')
        elm['adjustment_date_str']=rdcs
        rdcs=str(df.iloc[row,14]).replace(' 00:00:00.0','')
        elm['paid_date_str']=rdcs
        data.append(elm)        
    except Exception as e:
        print(str(e)+" Exception in row "+str(row)+"-"+str(df.iloc[row,5])+"-"+ str(df.iloc[row,6])+"-"+ str(df.iloc[row,7])+"-"+ str(df.iloc[row,14]))
x = mycol.insert_many(data)
print(str(x.inserted_ids))
    