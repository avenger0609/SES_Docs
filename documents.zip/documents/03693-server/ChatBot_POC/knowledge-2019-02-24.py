##dict of response for each type of intent
import random
from sqlite_python import *


startsearch_response_dict = {
    "delhi":'<Here is a list of top 5 startups in Delhi based on the funding amount: <UL><li>Snapdeal</li><li>Hike</li><li>Oyo</li><li>Delhivery</li><li>OyoRooms</li></ul>For more info: <a href=\"http://www.github.com/lkamat\">Startups in Mumbai</a>',
    "bangalore":'Here is a list of top 5 startups in Bangalore based on the funding amount: <UL><li>Paytm</li><li>Flipkart</li><li>Ola</li><li>Ola Cabs</li><li>Paytm Marketplace</li></ul>For more info: <a href=\"http://www.github.com/lkamat\">Startups in India</a>',
    "mumbai":'Here is a list of top 5 startups in Mumbai based on the funding amount: <UL><li>CarTrade</li><li>Fractal Analytics</li><li>BookMyShow</li><li>FreeCharge</li><li>Cartrade</li></ul>For more info: <a href=\"http://www.github.com/lkamat\">Startups in India</a>',
    "faq_link":'You can check out the list of startups here <a href=\"http://www.github.com/lkamat\">Startups in India</a>'
}


startupinfo_respose_dict = {
    "investors":'Here are the top 5 investors: <UL><li>Undisclosed Investors</li><li>Kalaari Capital</li><li>Indian Angel Network</li><li>Info Edge (India) Ltd</li><li>Brand Capital</li></ul>For more info: <a href=\"http://www.github.com/lkamat\">Startups in India</a>',
    "startups":'Top 5 startups based on funding.<UL><li>Paytm</li><li>Flipkart</li><li>Ola</li><li>Ola Cabs</li><li>Oyo Rooms</li></ul> For more info: <a href="http://www.github.com/lkamat">Startups in India</a>',
    "industries":'Top 5 industries based on funding.<UL><li>Consumer Internet</li><li>Technology </li><li>ecommerce </li><li>Logistics </li><li>Education</li></ul>For more info: <a href="http://www.github.com/lkamat">Startups in India</a>',
    "categories":'Top 5 categories based on funding.<UL><li>Food Delivery Platform</li><li>Online lending platform</li><li>eOnline Pharmacy</li><li>Online Learning Platform</li><li>ECommerce Marketplace</li></ul>For more info: <a href="http://www.github.com/lkamat">Startups in India</a>',
    "city": 'Top 5 cities with the most startup funding:<UL><li>Bangalore</li><li>Mumbai</li><li>New Delhi</li><li>Gurgaon</li><li>Pune</li></ul>For more info: <a href="http://www.github.com/lkamat">Startups in India</a>',
    "type": 'Startup funded by investment type:<UL><li>Private Equity</li><li>Seed Funding </li><li>Debt Funding </li></ul>Fo rmore info: <a href="http://www.github.com/lkamat">Startups in India</a>',
    "faq_link":'You can check out the list of startups here <a href="http://www.github.com/lkamat">Startups in India</a>'
}


GREETING_RESPONSES = ["sup bro", "hey", "Hi", "how can i help?","hello"]
GOODBYE_RESPONSES = ["bye", "cya", "take care", "good", "bye bye","Bye..Tc"]
AFFIRM_RESPONSES = ["indeed", "OK", "that's right", "great", "cool"]

##########
claim_numbers_req=list()
##########

def greeting():
    """If any of the words in the user's input was a greeting, return a greeting response"""
    return random.choice(GREETING_RESPONSES)

def goodbye():
    """If any of the words in the user's input was a goodbye, return a goddbye response"""
    return random.choice(GOODBYE_RESPONSES)

def affirm():
    """If any of the words in the user's input was a goodbye, return a goddbye response"""
    return random.choice(AFFIRM_RESPONSES)

def claim_enquiry(entities,text):
    print('entered')
    if entities==[]:
        return " Could not fetch results for you <br> Please make sure you entered correct information"
    if len(entities)>=1:
        print("entered if")
        print(entities)
        #### to get status of claim #####
        res=""        

        if "STATUS" in text.upper() and str(entities[0]['entity']).upper()=='Claim_Number'.upper() and len(entities)==1:
            print("3")
            print(entities)
            res=str(get_status(str(entities[0]['value']))) 
            claim_numbers_req.append(str(entities[0]['value'])) 
            print(str(claim_numbers_req))
            print(res)
            return res

        if "STATUS" in text.upper() and len(entities) > 1:
            print(str(len(entities)))
            if (str(entities[0]['value']).upper()=='STATUS' and str(entities[0]['entity']).upper()=='CONTEXT'):
                print(str(len(entities)))
                print(entities)
                res=str(get_status(str(entities[1]['value']))) 
                claim_numbers_req.append(str(entities[1]['value'])) 
                print(str(claim_numbers_req))
                print(res)
                return res 
            if (str(entities[1]['value']).upper()=='STATUS' and str(entities[1]['entity']).upper()=='CONTEXT'):
                print("2")
                print(entities)
                res=str(get_status(str(entities[0]['value']))) 
                claim_numbers_req.append(str(entities[0]['value'])) 
                print(str(claim_numbers_req))
                print(res)
                return res

                 
        
        #### to get status of claim #####

        #### to get Processing time ###        

        if (str(entities[0]['value']).upper()=='TIME' or str(entities[0]['value']).upper()=='DAYS' or str(entities[0]['value']).upper()=='LONG') and str(entities[0]['entity']).upper()=='CONTEXT':
            if len(entities)==1:
                res=str(get_processing_time(claim_numbers_req[len(claim_numbers_req)-1]))                
            else:
                res=str(get_processing_time(str(entities[1]['value'])))
            return res
                

        #### to get Processing time ###

        #### to get reason for denial ####

        if "DENIED" in text.upper() or 'DENIAL' in text.upper():
            n_entities=0
            claim_number_den=""
            for i in entities:                
                if i['value'].upper()=="DENIED" or i['value'].upper()=="DENIAL":
                    entities[0]['value']="DENIED"
                    entities[0]['entity']="CONTEXT"
                if i['entity'].upper()=="Claim_Number".upper():
                    n_entities=1
                    claim_number_den=i['value']
                    

            if (str(entities[0]['value']).upper()=='DENIED' or str(entities[0]['value']).upper()=='DENIAL') and str(entities[0]['entity']).upper()=='CONTEXT':
                if n_entities==0:
                    res=str(get_denial_reason(claim_numbers_req[len(claim_numbers_req)-1]))                
                elif n_entities==1:
                    res=str(get_denial_reason(str(claim_number_den)))
                return res
                

        #### to get reason for denial ####

        #### how to resubmit claim ####

        resubmit_flag=0
        for i in entities:                
            if i['value'].upper()=="RESUBMIT" or i['value'].upper()=="RESUBMISSION":
                entities[0]['value']="RESUBMIT"
                entities[0]['entity']="CONTEXT"
            if i['entity'].upper()=="Claim_Number".upper():
                n_entities=1
                entities[1]['value']=i['value']
                entities[1]['entity']=i['entity']


        if (str(entities[0]['value']).upper()=='RESUBMIT' or str(entities[0]['value']).upper()=='RESUBMISSION') and str(entities[0]['entity']).upper()=='CONTEXT':        
            res=str(get_resubmit_proc())
            return res             

        #### how to resubmit claim ####

        #### amount paid after adjustments ###
        adj_reason_flag=0
        adj_amt_paid_flag=0
        adj_amt_flag=0
        adj_claim_num=0
        n_entities=0
        if "AMOUNT" in text.upper() and ("ADJUSTED" in text.upper() or "ADJUSTMENT" in text.upper() or "ADJUSTMENTS" in text.upper()):
            adj_amt_flag=1

        for i in entities:
            print(str(i['value'].upper()))
            if i['value'].upper()=="ADJUSTED" or i['value'].upper()=="ADJUSTMENT" or i['value'].upper()=="ADJUSTMENTS":
                print("entered")
                adj_reason_flag=1
            if i['entity'].upper()=="Claim_Number".upper():
                n_entities=1
                adj_claim_num=i['value']                
            if i['value'].upper()=='SPENT' or i['value'].upper()=='PAID' or i['value'].upper()=='COLLECTED':
                adj_amt_paid_flag=1

        print(str(adj_amt_paid_flag))
        print(str(adj_amt_flag))
        print(str(adj_claim_num))
        print(str(adj_reason_flag))

        if adj_amt_paid_flag==1:
            if n_entities==0:
                res=str(get_adj_amt_paid(claim_numbers_req[len(claim_numbers_req)-1]))
                
            if n_entities==1:
                res=str(get_adj_amt_paid(str(adj_claim_num)))
            return res
                

        #### amount paid after adjustments ###

        #### to get reason for adjustment ####

        if adj_amt_flag==0 and adj_amt_paid_flag==0 and adj_reason_flag==1:
            print("adjusted")
            if n_entities==0:
                res=str(get_adjustment_reason(claim_numbers_req[len(claim_numbers_req)-1]))
                
            if n_entities==1:
                res=str(get_adjustment_reason(str(adj_claim_num)))
            return res
                

        #### to get reason for Adjustment ####

        #### amount paid towards adjustments ###

        if adj_amt_flag==1 and adj_amt_paid_flag==0:
            if n_entities==0:
                res=str(get_adjusted_amt(claim_numbers_req[len(claim_numbers_req)-1]))
                
            if n_entities==1:
                res=str(get_adjusted_amt(str(adj_claim_num)))
            return res
                

        #### amount paid towards adjustments ###

        #### to get reason Partially denied ###########

        if (str(entities[0]['value']).upper()=='PARTIALLY DENIED' or str(entities[0]['value']).upper()=='PARTIALLY DENIAL') and str(entities[0]['entity']).upper()=='CONTEXT':
            if len(entities)==1:
                res=str(get_denial_reason(claim_numbers_req[len(claim_numbers_req)-1]))
                
            else:
                res=str(get_denial_reason(str(entities[1]['value'])))
            return res
        
        #### to get reason Partially denied ###########

    return "Sorry.. Could not fetch results for you"    
        


