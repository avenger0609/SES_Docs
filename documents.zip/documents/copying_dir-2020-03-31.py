import os
import shutil



folder1=r'c:\users\asrilekh\documents\test1'
folder2=r'c:\users\asrilekh\documents\test2'

folder1_subdir=[]
folder1_subdir_path=[]

for f in os.scandir(folder1):

    if f.is_dir():
        print(f.path) 
        print(str(f.path).split('\\')[-1])
        folder1_subdir_path.append(f.path)
        folder1_subdir.append(str(f.path).split('\\')[-1])

folder2_subdir=[]
folder2_subdir_path=[]
for f in os.scandir(folder2):
    if f.is_dir():
        print(f.path) 
        print(str(f.path).split('\\')[-1])
        folder2_subdir_path.append(f.path)
        folder2_subdir.append(str(f.path).split('\\')[-1])

for i in range(0,len(folder1_subdir)):

    print(folder1_subdir[i])
    print(folder1_subdir_path[i])
    
    if folder1_subdir[i] not in folder2_subdir:   
                
        shutil.copytree(folder1_subdir_path[i],folder2+"\\"+folder1_subdir[i])
        print("copied "+ folder1_subdir[i])