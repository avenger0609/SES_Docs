import pandas as pd
import csv
from datetime import datetime


first_file='/app/Apache Druid POC/bkup-join_res_uidxwalk.csv'
output_file='/app/Apache Druid POC/join_uidxwalktop_1K.csv'

df1=pd.read_csv(first_file,encoding = 'latin_1')
print("completed reading all case data "+str(len(df1)))
df=df1[0:1000]
df['hour']='00'
df['minute']='00'
df['second']='10'
df['timestamp']=pd.to_datetime(df[['year', 'month', 'week','hour','minute','second']])
df=df.drop(columns=['hour', 'minute','second'])
df.to_csv(output_file,index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')