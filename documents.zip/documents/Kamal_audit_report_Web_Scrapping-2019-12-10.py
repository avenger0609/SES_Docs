## worked ###
from selenium.webdriver.common.keys import Keys 
from selenium import webdriver
import time
import pandas as pd
import xlsxwriter
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime

driverpath = "C:\\ProgramData\\Chrome_driver_76.0.3809.68\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
# chromeOptions.add_experimental_option('useAutomationExtension', False)
download_dir='c:\\users\\asrilekh\\documents'
preferences = {"download.default_directory": download_dir ,
                      "directory_upgrade": True,
                      "safebrowsing.enabled": True,
                      "useAutomationExtension":True }
chromeOptions.add_experimental_option("prefs", preferences)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://uhg.apptio.com/#TBMStudio:dev:uhg.com:Cost+Transparency")
## to check if page is loaded
c=0
while True:
    try:
        elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
        # elem.click()
        break
    except NoSuchElementException:  
        c=c+1
        if c==10:
            print("checked for 10 times")
            break
        time.sleep(90)
## to check if page is loaded
driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div/div[3]/div[4]/div[2]').click()
time.sleep(5)
tbl_id=driver.find_element_by_xpath('/html/body/div[7]/div/div/div/div[1]/div/div/div[1]/div[2]/div')
rows=tbl_id.find_elements_by_tag_name('div')
previous_month = datetime.now().month - 1
if previous_month == 0:        
    previous_month = 12
if previous_month==12:
    for i in range(0,len(rows)-1):
        rows[i].click()
        time.sleep(10)
else:
    for i in range(0,len(rows)):
        rows[i].click()
        time.sleep(10)


# driver.find_element_by_xpath('/html/body/div[7]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[1]').click()
# driver.find_element_by_xpath('/html/body/div[12]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[2]').click() ## need to change yearly
# /html/body/div[12]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[2]
time.sleep(15)
if previous_month==1:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[1]/div/div/div[2]').click()
elif previous_month==2:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[2]/div/div/div[2]').click()
elif previous_month==3:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[3]/div/div/div[2]').click()
elif previous_month==4:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[5]/div/div/div[2]').click()
elif previous_month==5:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[6]/div/div/div[2]').click()
elif previous_month==6:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[7]/div/div/div[2]').click()
elif previous_month==7:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[9]/div/div/div[2]').click()
elif previous_month==8:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[10]/div/div/div[2]').click()
elif previous_month==9:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[11]/div/div/div[2]').click()
elif previous_month==10:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[13]/div/div/div[2]').click()
elif previous_month==11:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[14]/div/div/div[2]').click()
elif previous_month==12:
    driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[15]/div/div/div[2]').click()
#################################     SRC ACT ASK Application                  ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT ASK Application List and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT ASK Application List')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT ASK Application List and click
    ## to get required data from SRC ACT ASK Application List

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT ASK Application List':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT ASK Application List data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()

    ## to get required data from SRC ACT ASK Application List
except Exception as e:
    print("Exception took place in SRC ACT ASK Application "+str(e) )

#################################     SRC ACT ASK Application                  ##########################################################################

#################################     SRC ACT User Counts                 ##########################################################################
time.sleep(10)

try:
    ## to search for required table SRC ACT User Counts and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT User Counts')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT User Counts and click

    ## to get required data from SRC ACT User Counts

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT User Counts':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT User Counts data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print("Exception took place in SRC ACT User Counts "+str(e) )
## to get required data from SRC ACT User Counts

#################################     SRC ACT User Counts
       
#################################     SRC ACT Midrange Configured MIPS                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Midrange Configured MIPS and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Midrange Configured MIPS')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Midrange Configured MIPS and click

    ## to get required data from SRC ACT Midrange Configured MIPS

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Midrange Configured MIPS':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Midrange Configured MIPS data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()

except Exception as e:
    print(" Exception in SRC ACT Midrange Configured MIPS "+str(e))

## to get required data from SRC ACT Midrange Configured MIPS

#################################     SRC ACT Midrange Configured MIPS                  ##########################################################################

#################################     SRC ACT Desk Phones                ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Desk Phones and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Desk Phones')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Desk Phones and click

    ## to get required data from SRC ACT Desk Phones

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Desk Phones':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Desk Phones data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[2]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()

    ## to get required data from SRC ACT Desk Phones
except Exception as e:
    print(" Exception in SRC ACT Desk Phones "+str(e))

#################################     SRC ACT Desk Phones                  ##########################################################################

#################################     SRC ACT Personal Computers                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Personal Computers and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Personal Computers')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Personal Computers and click

    ## to get required data from SRC ACT Personal Computers

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Personal Computers':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Personal Computers data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Personal Computers "+str(e))
## to get required data from SRC ACT Personal Computers

#################################     SRC ACT Personal Computers                  ##########################################################################

#################################     SRC ACT Middleware Instances                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Middleware Instances and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Middleware Instances')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Middleware Instances and click

    ## to get required data from SRC ACT Middleware Instances

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Middleware Instances':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Middleware Instances data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Middleware Instances "+str(e))
## to get required data from SRC ACT Middleware Instances

#################################     SRC ACT Middleware Instances                  ##########################################################################

#################################     SRC ACT Mainframe Middleware                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Mainframe Middleware and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Mainframe Middleware')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Mainframe Middleware and click

    ## to get required data from SRC ACT Mainframe Middleware

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Mainframe Middleware':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Mainframe Middleware data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Maiframe Middleware "+str(e))
## to get required data from SRC ACT Mainframe Middleware

#################################     SRC ACT Mainframe Middleware                  ##########################################################################

#################################     SRC ACT Mainframe Configured MIPS               ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Mainframe Configured MIPS and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Mainframe Configured MIPS')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Mainframe Configured MIPS and click

    ## to get required data from SRC ACT Mainframe Configured MIPS

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Mainframe Configured MIPS':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Mainframe Configured MIPS data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[2]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Mainframe Configured MIPS "+str(e))
## to get required data from SRC ACT Mainframe Configured MIPS

#################################     SRC ACT Mainframe Configured MIPS                  ##########################################################################

#################################     SRC ACT Email               ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Email and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Email')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Email and click

    ## to get required data from SRC ACT Email

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Email':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Email data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[5]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Email "+str(e))
## to get required data from SRC ACT Email

#################################     SRC ACT Email                  ##########################################################################

#################################     SRC ACT Database                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Database and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Database')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Database and click

    ## to get required data from SRC ACT Database

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Database':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Database data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Database "+str(e))
## to get required data from SRC ACT Database

#################################     SRC ACT Database                 ##########################################################################

#################################     SRC ACT Project Capex              ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Project Capex and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Project Capex')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Project Capex and click

    ## to get required data from SRC ACT Project Capex

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Project Capex':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Project Capex data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Project Capex "+str(e))
## to get required data from SRC ACT Project Capex

#################################     SRC ACT Project Capex                  ##########################################################################

#################################     SRC ACT Fixed Assets                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Fixed Assets and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Fixed Assets')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Fixed Assets and click

    ## to get required data from SRC ACT Fixed Assets

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Fixed Assets':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Fixed Assets data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Fixed Assets "+str(e))
## to get required data from SRC ACT Fixed Assets

#################################     SRC ACT Fixed Assets                ##########################################################################

#################################     SRC SMPL ACT Labor Headcount Data                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC SMPL ACT Labor Headcount Data and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC SMPL ACT Labor Headcount Data')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC SMPL ACT Labor Headcount Data and click

    ## to get required data from SRC SMPL ACT Labor Headcount Data

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC SMPL ACT Labor Headcount Data':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC SMPL ACT Labor Headcount Data data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC SMPL ACT Labor Headcount Data MIPS "+str(e))
## to get required data from SRC SMPL ACT Labor Headcount Data

#################################     SRC SMPL ACT Labor Headcount Data                ##########################################################################

#################################     SRC ACT Headcount Plan Taleo                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Headcount Plan Taleo and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Headcount Plan Taleo')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Headcount Plan Taleo and click

    ## to get required data from SRC ACT Headcount Plan Taleo

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Headcount Plan Taleo':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Headcount Plan Taleo data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Headcount Plan Taleo "+str(e))
## to get required data from SRC ACT Headcount Plan Taleo

#################################     SRC ACT Headcount Plan Taleo                 ##########################################################################

#################################     SRC ACT Headcount Plan Fieldglass                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Headcount Plan Fieldglass and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Headcount Plan Fieldglass')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Headcount Plan Fieldglass and click

    ## to get required data from SRC ACT Headcount Plan Fieldglass

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Headcount Plan Fieldglass':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Headcount Plan Fieldglass data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Headcount Plan field glass "+str(e))
## to get required data from SRC ACT Headcount Plan Fieldglass

#################################    SRC ACT Headcount Plan Fieldglass                ##########################################################################

#################################     SRC ACT Time Tracking 01540             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Time Tracking 01540 and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Time Tracking 01540')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Time Tracking 01540 and click

    ## to get required data from SRC ACT Time Tracking 01540

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Time Tracking 01540':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Time Tracking 01540 data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Time tracking 01540 "+str(e))
## to get required data from SRC ACT Time Tracking 01540

#################################     SRC ACT Time Tracking 01540                  ##########################################################################

#################################     SRC ACT Time Tracking 01530             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Time Tracking 01530 and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Time Tracking 01530')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Time Tracking 01530 and click

    ## to get required data from SRC ACT Time Tracking 01530

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Time Tracking 01530':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Time Tracking 01530 data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Time tracking 01530 "+str(e))
## to get required data from SRC ACT Time Tracking 01530

#################################     SRC ACT Time Tracking 01530                  ##########################################################################


#################################     SRC ACT Time Tracking 01510             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Time Tracking 01510 and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Time Tracking 01510')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Time Tracking 01510 and click

    ## to get required data from SRC ACT Time Tracking 01510

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Time Tracking 01510':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Time Tracking 01510 data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Time tracking 01510 "+str(e))
## to get required data from SRC ACT Time Tracking 01510

#################################     SRC ACT Time Tracking 01510                  ##########################################################################

#################################     SRC ACT Time Tracking 01508 PE             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Time Tracking 01508 PE and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Time Tracking 01508 PE')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Time Tracking 01508 PE and click

    ## to get required data from SRC ACT Time Tracking 01508 PE

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Time Tracking 01508 PE':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Time Tracking 01508 PE data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Time tracking 01508 PE "+str(e))
## to get required data from SRC ACT Time Tracking 01508 PE

#################################     SRC ACT Time Tracking 01508 PE                  ##########################################################################

#################################     SRC ACT Time Tracking 01508 DS             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Time Tracking 01508 DS and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Time Tracking 01508 DS')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Time Tracking 01508 DS and click

    ## to get required data from SRC ACT Time Tracking 01508 DS

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Time Tracking 01508 DS':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Time Tracking 01508 DS data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Time tracking 01508 DS "+str(e))
## to get required data from SRC ACT Time Tracking 01508 DS

#################################     SRC ACT Time Tracking 01508 DS                  ##########################################################################

#################################     SRC SMPL AP Details                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table \SRC SMPL AP Details and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC SMPL AP Details')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC SMPL AP Details and click

    ## to get required data from SRC SMPL AP Details

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC SMPL AP Details':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC SMPL AP Details data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC SMPL AP Details "+str(e))
## to get required data from SRC SMPL AP Details

#################################    SRC SMPL AP Details                ##########################################################################

#################################     SRC ACT Mainframe Storage On-Off             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Mainframe Storage On-Off and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Mainframe Storage On-Off')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Mainframe Storage On-Off and click

    ## to get required data from SRC ACT Mainframe Storage On-Off

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Mainframe Storage On-Off':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Mainframe Storage On-Off data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Mainframe Storage On-Off "+str(e))
## to get required data from SRC ACT Mainframe Storage On-Off

#################################     SRC ACT Mainframe Storage On-Off                  ##########################################################################

#################################     SRC eGRC Vendor Details                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC eGRC Vendor Details and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC eGRC Vendor Details')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC eGRC Vendor Details and click

    ## to get required data from SRC eGRC Vendor Details

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC eGRC Vendor Details':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC eGRC Vendor Details data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC eGRC Vendor Details "+str(e))
## to get required data from SRC eGRC Vendor Details

#################################    SRC eGRC Vendor Details               ##########################################################################

#################################     SRC ACT Server Master                 ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Server Master and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Server Master')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Server Master and click

    ## to get required data from SRC ACT Server Master

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Server Master':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Server Master data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Server Master "+str(e))
## to get required data from SRC ACT Server Master

#################################    SRC ACT Server Master               ##########################################################################

#################################     SRC ACT Forecast Project CapEx             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Forecast Project CapEx and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Forecast Project CapEx')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Forecast Project CapEx and click

    ## to get required data from SRC ACT Forecast Project CapEx

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Forecast Project CapEx':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Forecast Project CapEx data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Forecast Project CapEx "+str(e))
## to get required data from SRC ACT Forecast Project CapEx

#################################     SRC ACT Forecast Project CapEx                  ##########################################################################

#################################     SRC ACT Service Desk Tickets                ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Service Desk Tickets and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Service Desk Tickets')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Service Desk Tickets and click

    ## to get required data from SRC ACT Service Desk Tickets

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Service Desk Tickets':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Service Desk Tickets data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Service Desk Tickets "+str(e))
## to get required data from SRC ACT Service Desk Tickets

#################################    SRC ACT Service Desk Tickets               ##########################################################################

#################################     SRC ACT NAS             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT NAS and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT NAS')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT NAS and click

    ## to get required data from SRC ACT NAS

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT NAS':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT NAS")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[5]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT NAS  "+str(e))
## to get required data from SRC ACT NAS

#################################     SRC ACT NAS                  ##########################################################################

#################################     SRC ACT Storage             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Storage and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Storage')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Storage and click

    ## to get required data from SRC ACT Storage

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Storage':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Storage data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[7]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Storage  "+str(e))
## to get required data from SRC ACT Storage

#################################     SRC ACT Storage                  ##########################################################################

#################################     SRC ACT Mainframe Database             ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Mainframe Database and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Mainframe Database')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Mainframe Database and click

    ## to get required data from SRC ACT Mainframe Database CapEx

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Mainframe Database':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Mainframe Database data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[6]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Mainframe Database  "+str(e))
## to get required data from SRC ACT Mainframe Database

#################################     SRC ACT Mainframe Database                  ##########################################################################

#################################     SRC ACT Bus Seg Headcount                ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Bus Seg Headcount and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Bus Seg Headcount')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Bus Seg Headcount and click

    ## to get required data from SRC ACT Bus Seg Headcount

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Bus Seg Headcount':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Bus Seg Headcount data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Bus Seg Headcount  "+str(e))
## to get required data from SRC ACT Bus Seg Headcount

#################################    SRC ACT Bus Seg Headcount              ##########################################################################

#################################     SRC ACT Server App               ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Server App and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Server App')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Server App and click

    ## to get required data from SRC ACT Server App

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Server App':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Server App data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Server App  "+str(e))
## to get required data from SRC ACT Server App

#################################    SRC ACT Server App               ##########################################################################

#################################     SRC ACT MPWR Service Volumes               ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT MPWR Service Volumes and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT MPWR Service Volumes')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT MPWR Service Volumes and click

    ## to get required data from SRC ACT MPWR Service Volumes

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT MPWR Service Volumes':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT MPWR Service Volumes data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
            s=str(ele.get_attribute('innerHTML'))
            s1=s.split('of')
            s1=s1[-1].strip(' ')
            print(s1)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT MPWR Service Volumes  "+str(e))
## to get required data from SRC ACT MPWR Service Volumes

#################################    SRC ACT MPWR Service Volumes               ##########################################################################

#################################     SRC ACT Data Center          ##########################################################################
time.sleep(10)
try:
    ## to search for required table SRC ACT Data Center and click
    c=0
    while True:
        try:
            elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
            elem.clear()
            elem.send_keys('SRC ACT Data Center')
            time.sleep(20)
            elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
            elem.click()
            time.sleep(10)
            break
        except  NoSuchElementException:  
            c=c+1
            if c==10:
                print("checked for 10 times")
                break
            time.sleep(90)
    ## to search for required table SRC ACT Data Center and click

    ## to get required data from SRC ACT Data Center CapEx

    time.sleep(10)
    tbl_id=driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div')
    # /html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div
    rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
    rows_len=len(rows)
    if rows[rows_len-1].get_attribute('title')=='SRC ACT Data Center':

        rows[rows_len-1].click()
        try:
            elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
        except:
            elements=[]   
        c=0
        while len(elements)==0:
            time.sleep(90)
            c=c+1
            if c==10:
                print("checked for 10 times for SRC ACT Data Center data")
                break
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]
        if len(elements) > 0:
            ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
            s=str(ele.get_attribute('innerHTML'))
            print(s)
            # print(ele.text)
    driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
except Exception as e:
    print(" Exception in SRC ACT Data Center  "+str(e))
## to get required data from SRC ACT Data Center

#################################     SRC ACT Data Center                 ##########################################################################