import pyspark
from pyspark.sql import SparkSession



def read_csv(fp):
    for line in fp.readlines():        
        yield line


def main():
    global sparkSession
    sparkSession = SparkSession.builder.getOrCreate()
    sc=sparkSession.sparkContext
    fp=open('/mapr/datalake/optum/optuminsight/rada_anltx_prod/hive/warehouse/hsr_sas_test.db/hsr_adr_trans_comm/hsr_adr_trans_comm.txt','r')
    csvRDD = sc.parallelize(read_csv(fp), numSlices=16)
    csvDF = sparkSession.read.csv(csvRDD)      
    print(csvDF.count())
    print(csvDF.columns)
    ## drop duplicates    
    csvDF=csvDF.dropDuplicates(subset=['case_key'])    
    ## drop a column
    csvDF=csvDF.drop('cmcnt_dttm ')    
    ## split a column
    split_col = pyspark.sql.functions.split(csvDF['case_key'], '-')
    csvDF = csvDF.withColumn('Case_key_1', split_col.getItem(0))
    csvDF = csvDF.withColumn('Case_key_2', split_col.getItem(1))    
    ## format column type    
    csvDF = csvDF.withColumn("Case_key_2",csvDF['Case_key_2'].cast('string'))    
    ## left fill
    csvDF = csvDF.withColumn('Case_key_2', lpad(csvDF.Case_key_2,10, '0'))    
    ## temporary df
    joinDF=csvDF.select('case_key','cmcnt_dttm')    
    ## joining 2 dataframes
    csvDF=csvDF.join(joinDF, csvDF.case_key == joinDF.case_key).select(csvDF["*"],joinDF["cmcnt_dttm"])    
    csvDF.write.csv('hsr_adr_trans_comm.txt',sep='|')

main()