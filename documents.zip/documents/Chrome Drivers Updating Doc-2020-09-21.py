### chrome driver documentation how to work

# Download the chrome driver desired for your chrome browser
# https://chromedriver.chromium.org/downloads

# Then rename the existing chrome driver.exe to _old or _[Version_number]

import os
os.rename(r'C:\ProgramData\ChromeDriver_81\chromedriver.exe',r'C:\ProgramData\ChromeDriver_81\chromedriver_83.exe') 

# Copy the downloaded chrome driver from line number 4 to the above folder

copy_cmd="copy C:\\users\\asrilekh\\documents\\chromedriver_win32\\chromedriver.exe C:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
os.system(copy_cmd) 

