import shutil, os
# shutil.copy(r'C:\Users\asrilekh\Downloads', r'H:\Downloads')

# os.path.getmtime

def copytree(src, dst, symlinks=False, ignore=None):
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            shutil.copytree(s, d, symlinks, ignore)
        else:
            if os.path.exists(d):

                if str(os.path.getmtime(s))==str(os.path.getmtime(d)):
                    pass
                else:
                    shutil.copy2(s, d)

            else:
                shutil.copy2(s, d)
copytree(r'C:\Users\asrilekh\Downloads', r'H:\Downloads')