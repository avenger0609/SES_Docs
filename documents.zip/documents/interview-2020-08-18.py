def main():
    l=[]    
    n=int(str(input('Enter number of elements in list:')))
    if n>0:
        for _ in range(0,n):
            try:
                l.append(int(str(input('Enter integer number:'))))
            except Exception as e:
                print("Error encountered "+str(e))
                print("Make sure you are entering a valid integer and try again")
                break
        else:
            print(len([(el1, el2) for el1 in l for el2 in l if el1 != el2]))
    else:
        print("Number of elements to be stored in list should be greater than zero")
if __name__ == "__main__":
    main()
