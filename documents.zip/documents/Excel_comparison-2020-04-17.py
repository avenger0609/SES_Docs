import pandas as pd

first_file=r'c:\users\asrilekh\documents\HCE_MI_EnI_Gap_Case_Rpt_20200414_Test1.xlsx'
second_file=r'c:\users\asrilekh\documents\HCE_MI_EnI_Gap_Case_Rpt_20200414_Test2.xlsx'
output_file=r'c:\users\asrilekh\documents\Compare_HCE_MI_EnI_Gap_Case_Rpt_20200414.xlsx'

df1 = pd.read_excel(first_file,sheet_name='CaseDetail',skiprows=5 ,na_values=['N/A'])
print(df1.head(5))
print("number of columns in first file="+str(len(list(df1.columns))))
print("number of rows in first file="+str(len(df1)))
df1 = df1.dropna(how='all')
print("number of columns after removing blank rows in first file="+str(len(list(df1.columns))))
print("number of rows after removing blank rows in first file="+str(len(df1)))

df2 = pd.read_excel(second_file,sheet_name='CaseDetail',skiprows=5 ,na_values=['N/A'])
print(df2.head(5))
print("number of columns in second file="+str(len(list(df2.columns))))
print("number of rows in second file="+str(len(df2)))
df2 = df2.dropna(how='all')
print("number of columns after removing blank rows in second file="+str(len(list(df2.columns))))
print("number of rows after removing blank rows in second file="+str(len(df2)))




first_case_key_lst=list(df1['CaseKey'])
second_case_key_lst=list(df2['CaseKey'])

print("number of case keys from first file="+str(len(first_case_key_lst)))
print("number of case keys from second file="+str(len(second_case_key_lst)))

present_in_first_abs_in_secnd=list(set(first_case_key_lst) - set(second_case_key_lst))
print("number of case keys that are in first file but absent in second file="+str(len(present_in_first_abs_in_secnd)))

present_in_secnd_abs_in_first=list(set(second_case_key_lst) - set(first_case_key_lst))
print("number of case keys that are in second file but absent in first file="+str(len(present_in_secnd_abs_in_first)))

df_present_in_first_abs_in_secnd=(df1.loc[df1['CaseKey'].isin(present_in_first_abs_in_secnd)])
print("number of rows that are in first file but absent in second file="+str(len(df_present_in_first_abs_in_secnd)))

df_present_in_secnd_abs_in_first=(df2.loc[df2['CaseKey'].isin(present_in_secnd_abs_in_first)])
print("number of case keys that are in second file but absent in absent file="+str(len(df_present_in_secnd_abs_in_first)))

# df_present_in_first_abs_in_secnd.to_excel(output_file,sheet_name='Present in first',index=False)
# df_present_in_secnd_abs_in_first.to_excel(output_file,sheet_name='Present in second',index=False)

with pd.ExcelWriter(output_file) as writer:  
    df_present_in_first_abs_in_secnd.to_excel(writer,sheet_name='Present in first',index=False)
    df_present_in_secnd_abs_in_first.to_excel(writer,sheet_name='Present in second',index=False)


