from turbodbc import connect

##create connection

connection = connect(dsn='TRMDB-PROD')
cursor = connection.cursor()
# stmt="select * from itfb.DBO.history_ledger_active_ets"
stmt="select trmdb.DBO.CB_ChargebackData_UnAgg.AccountingYearMonth, trmdb.DBO.CB_ChargebackData_UnAgg.ServiceUniqueIdentifier, trmdb.DBO.CB_ChargebackData_UnAgg.BillingCode, trmdb.DBO.CB_ChargebackData_UnAgg.ServiceName, trmdb.DBO.CB_ChargebackData_UnAgg.ServiceVirtual, trmdb.DBO.CB_ChargebackData_UnAgg.CustomerAcceptance, trmdb.DBO.CB_ChargebackData_UnAgg.AppName, trmdb.DBO.CB_ChargebackData_UnAgg.ProdNonProd, trmdb.DBO.CB_ChargebackData_UnAgg.ServiceRequestNumber, trmdb.DBO.CB_ChargebackData_UnAgg.ServiceDeliveryDate, trmdb.DBO.CB_ChargebackData_UnAgg.ProjectManager, trmdb.DBO.CB_ChargebackData_UnAgg.ParentCreateDate, trmdb.DBO.CB_ChargebackData_UnAgg.ParentDescription, trmdb.DBO.CB_ChargebackData_UnAgg.ParentRequestID, trmdb.DBO.CB_ChargebackData_UnAgg.ParentRequestType, trmdb.DBO.CB_ChargebackData_UnAgg.ParentRequestor, trmdb.DBO.CB_ChargebackData_UnAgg.ParentRequestorEmail, trmdb.DBO.CB_ChargebackData_UnAgg.RequestType, trmdb.DBO.CB_ChargebackData_UnAgg.Requestor, trmdb.DBO.CB_ChargebackData_UnAgg.RequestorEmail, trmdb.DBO.CB_ChargebackData_UnAgg.Description, trmdb.DBO.CB_ChargebackData_UnAgg.CreateDate, trmdb.DBO.CB_ChargebackData_UnAgg.GL_CodeOwner, trmdb.DBO.CB_ChargebackData_UnAgg.ProjectName, trmdb.DBO.CB_ChargebackData_UnAgg.ProjectRequestor, trmdb.DBO.CB_ChargebackData_UnAgg.Prompt_ID, trmdb.DBO.CB_ChargebackData_UnAgg.DataCenterCode from trmdb.DBO.CB_ChargebackData_UnAgg where ((trmdb.DBO.CB_ChargebackData_UnAgg.AccountingYearMonth)='1903');"
##execute query
cursor.execute(stmt)
all_rows = cursor.fetchall()
print(len(all_rows))