import keepa
from datetime import datetime
import pandas as pd
import csv

accesskey="c12t22821ud26l55gu3gj38t1a3bcsml88o57lpn9h6f63h638sskfkhu424blvt"
api=keepa.Keepa(accesskey)
output_dir='c:\\users\\asrilekh\\documents\\Keepa_Data_Extract\\'

def get_category_ids(category):
    filename=category+"_Category_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    csvfilename=category+"_Category_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".csv"
    resp=api.search_for_categories(category,domain='IN')
    
    try:
        
        resf=open(output_dir+"\\Category Search\\"+filename,"w")
        resf.write(str(resp))
    except Exception as e:
        print(str(e))
    
    ## working code

    # cat_ids=[]
    # cat_names=[]
    # for cat_id in resp:
    #     print(resp[cat_id]['name'],"-->",cat_id )
    #     cat_ids.append(str(cat_id))
    #     cat_names.append(str(resp[cat_id]['name']))
    # df=pd.DataFrame()    
    # df['CategoryID']=cat_ids
    # df['Category']=cat_names
    # df['SearchTerm']=category
    # df.to_csv(output_dir+"\\Category Search\\"+csvfilename,index=False,quoting=csv.QUOTE_ALL)

    ## working code

    dicts=[]
    # cat_ids=resp.keys()
    for cii in resp:
        # cat_id_keys=cii.keys()
        dicts.append(resp[cii])
    df = pd.DataFrame(dicts)
    df['SearchTerm']=category
    df.to_csv(output_dir+"\\Category Search\\"+csvfilename,index=False,quoting=csv.QUOTE_ALL)


    return resp

for gci in ['Kitchen','Games','Toys','Toys & Games','Garden','Sports, Fitness & Outdoors','Jewellery','Home Improvement','Home & Kitchen']:
    print(gci," Started")
    get_category_ids(gci)
    print(gci," Completed")