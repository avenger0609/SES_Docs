##https://www.tutorialspoint.com/cryptography_with_python/cryptography_with_python_simple_substitution_cipher.htm

import random, sys
import pandas as pd

LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
NUMBERS= '1234567890'

### used for encrypting only alphabets

def encrypt_alpha(message):

    key = getRandomKey_alpha()
    # key="IQRYVOCPNALMHTZGKFXJSEBDWU"
    translated = translateMessage_alpha(message, key)
    print('Using key: %s' % (key))
    return translated    
   
def translateMessage_alpha(message, key):

    translated = ''
    charsA = LETTERS
    charsB = key
    for symbol in message:
        if symbol.upper() in charsA:
            symIndex = charsA.find(symbol.upper())
            if symbol.isupper():
                translated += charsB[symIndex].upper()
            else:
                translated += charsB[symIndex].lower()
        else:
            translated += symbol
    return translated

def getRandomKey_alpha():
    randomList = list(LETTERS)
    random.shuffle(randomList)
    return ''.join(randomList)

### used for encrypting only alphabets

### used for encrypting only numbers

def encrypt_num(message):

    key = getRandomKey_num()
    translated = translateMessage_num(message, key)
    print('Using key: %s' % (key))
    return translated    
   
def translateMessage_num(message, key):

    translated = ''
    charsA = NUMBERS
    charsB = key
    for symbol in message:
        if symbol.upper() in charsA:
            symIndex = charsA.find(symbol.upper())
            if symbol.isupper():
                translated += charsB[symIndex].upper()
            else:
                translated += charsB[symIndex].lower()
        else:
            translated += symbol
    return translated

def getRandomKey_num():
    randomList = list(NUMBERS)
    random.shuffle(randomList)
    return ''.join(randomList)

### used for encrypting only alphabets


if __name__ == '__main__':

    df=pd.read_excel(r'c:\users\asrilekh\documents\source_file_demo.xlsx')
    col_list=list(df.columns)
    print(df[col_list[1]].str.extract(r'([ab])(\d)'))
    df[col_list[0]] = df[col_list[0]].apply(lambda x: encrypt_num(str(x)))
    df[col_list[1]] = df[col_list[1]].apply(lambda x: encrypt_alpha(str(x)))
    df.to_excel(r'c:\users\asrilekh\documents\encrypted_file_demo.xlsx')