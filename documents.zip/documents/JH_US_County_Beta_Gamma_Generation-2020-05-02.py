

import pandas as pd 
import numpy as np

df_final=pd.DataFrame()
df_final_beta_gamma=pd.DataFrame()

dfs=pd.read_csv(r'c:\users\asrilekh\downloads\US+County+Level+download.csv')

fips_list=list(dfs['FIPS'].unique())
fips_list=[36061]
for fli in fips_list:
    
    df=dfs[dfs['FIPS']==fli]      
    df=df.sort_values(["Report_Date"], ascending = (True))
    print(df)

    ### using confirmed field values if active is not populated

    df['Active']=df['Active'].mask(pd.isnull, df['Confirmed'])

    ### using confirmed field values if active is not populated

    df['Susceptible']=df['Population']-df['Active']-df['Deaths']
    df['Susceptible_min_1']=df['Susceptible'].shift(1)
    df['Susceptible_Diff']=df['Susceptible']-df['Susceptible_min_1']

    df['Deaths_min_1']=df['Deaths'].shift(1)
    df['New Deaths']=df['Deaths']-df['Deaths_min_1']

    df['Confirmed_min_1']=df['Confirmed'].shift(1)

    df['New Cases']=df['Confirmed']-df['Confirmed_min_1']

    df['New_Cases_min_1']=df['New Cases'].shift(1)

    df['Active_Cases_min_1']=df['Active'].shift(1)

    df['Beta']=(df['Susceptible_Diff']/df['Population'])/(df['Susceptible_min_1']/df['Population']*-1*df['Active_Cases_min_1']/df['Population'])
    print(df["Beta"])

    print(df['Beta'].mean())

    df['Recovered']=df['Active']-df['Active_Cases_min_1']-df['New Deaths']-df['New_Cases_min_1']
    df['Recovered']=df['Recovered']*-1
    df['Recovered_min_1']=df['Recovered'].shift(1)
    df['Recovered_Diff']=df['Recovered']-df['Recovered_min_1']

    df['Gamma']=df['Recovered_Diff']/df['Active_Cases_min_1']

    ### testing the other way to generate gamma value

    # df['Active_Diff']=df['Active']-df['Active_Cases_min_1']
    # df['Gamma_test']=(-df['Susceptible_Diff']-df['Active_Diff'])/df['Active_Cases_min_1']

    ### testing the other way to generate gamma value

    df['Gamma'] = df['Gamma'].replace([np.inf, -np.inf], np.nan)
    df['Beta'] = df['Beta'].replace([np.inf, -np.inf], np.nan)

    ### testing the other way to generate gamma value
    # df['Gamma_test'] = df['Gamma_test'].replace([np.inf, -np.inf], np.nan)
    ### testing the other way to generate gamma value

    print(df['Gamma'].mean())

    df=df[0:len(df)-1]
    

    
    df_gamma=df[['FIPS','Gamma']]
    df_gamma=df_gamma.dropna(subset=['Gamma'])
    df_gamma=df_gamma[-10:]

    sf=df.groupby(['FIPS'])['Gamma'].mean()
    df_gamma=pd.DataFrame({'FIPS':sf.index, 'Gamma_Mean':sf.values})
    print(df_gamma)

    df_beta=df[['FIPS','Beta']]
    
    df_beta=df_beta.dropna(subset=['Beta'])
    df_beta=df_beta[-5:]
    print(df_beta)

    sf=df_beta.groupby(['FIPS'])['Beta'].mean()
    df_beta=pd.DataFrame({'FIPS':sf.index, 'Beta_Mean':sf.values})
    print(df_beta)

    ### testing the other way to generate gamma value

    # df_gamma_test=df[['FIPS','Gamma_test']]
    # df_gamma_test=df_gamma_test.dropna(subset=['Gamma_test'])
    # df_gamma_test=df_gamma_test[-10:]

    # sf=df.groupby(['FIPS'])['Gamma_test'].mean()
    # df_gamma_test=pd.DataFrame({'FIPS':sf.index, 'Gamma_test_Mean':sf.values})
    # print(df_gamma_test)

    ### testing the other way to generate gamma value

    df_beta_gamma=pd.merge(df_beta, df_gamma, how='inner', on=['FIPS'])

    ### testing the other way to generate gamma value

    # df_beta_gamma=pd.merge(df_beta_gamma, df_gamma_test, how='inner', on=['FIPS'])

    ### testing the other way to generate gamma value

    ######## consolidating ### testing the other way to generate gamma value

    df['Active_Diff']=df['Active']-df['Active_Cases_min_1']
    df['Gamma_test']=(-df['Susceptible_Diff']-df['Active_Diff'])/df['Active_Cases_min_1']
    df['Gamma_test'] = df['Gamma_test'].replace([np.inf, -np.inf], np.nan)
    df_gamma_test=df[['FIPS','Gamma_test']]
    df_gamma_test=df_gamma_test.dropna(subset=['Gamma_test'])
    df_gamma_test=df_gamma_test[-10:]

    sf=df.groupby(['FIPS'])['Gamma_test'].mean()
    df_gamma_test=pd.DataFrame({'FIPS':sf.index, 'Gamma_test_Mean':sf.values})
    print(df_gamma_test)
    df_beta_gamma=pd.merge(df_beta_gamma, df_gamma_test, how='inner', on=['FIPS'])
    ######## consolidating ### testing the other way to generate gamma value


    if len(df_final_beta_gamma) > 0:
        df_final_beta_gamma=df_final_beta_gamma.append(df_beta_gamma)
    else:
        df_final_beta_gamma=df_beta_gamma

    if len(df_final) > 0:
        df_final=df_final.append(df)
    else:
        df_final=df
    
print(df_final_beta_gamma)
print(len(df_final_beta_gamma))
print(len(df_final))
df_final_beta_gamma.to_excel(r'JH_US_County_Beta_Gamma_Test_Generation.xlsx')
df_final.to_excel(r'JH_US_County_Beta_Gamma_Value_Gen_Test.xlsx')

