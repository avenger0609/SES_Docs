import requests
from datetime import datetime

output_dir='c:\\users\\asrilekh\\documents\\Keepa_Data_Extract\\'
accesskey="xXXXXXXX"

def get_category_ids(category):

    resp1=requests.get('https://api.keepa.com/search?key='+accesskey+"&domain=IN&type=category&term="+str(category).strip(' ').replace(' ','%20').replace('&','%26'))
    resp=resp1.text

    filename=category+"_Category_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\Category Search\\"+filename,"w")
    resf.write(resp)

    return resp

def get_best_seller_asins(categoryID,CategoryName):

    resp1=requests.get('https://api.keepa.com/search?key='+accesskey+"&domain=IN&category="+categoryID+"&range="+rank_avg_range) # rank_avg_range 0 current BSR  #1 Average BSR
    resp=resp1.text
    
    filename=CategoryName+"_Best_Seller_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\Best Seller Search\\"+filename,"w")
    resf.write(resp)

    return resp

# Update flag may incur extra cost
# buybox incurs extra cost of 2 per product
def get_asin_info(search_asin):

    resp=api.query(search_asin,domain='IN',history=True,rating=True,to_datetime=True,out_of_stock_as_nan=True
    ,stock=True,product_code_is_asin=True,progress_bar=True
    ,buybox=True,stats=365,offers=20,update=0)

    filename=search_asin+"_ASIN_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\ASIN Search\\"+filename,"w")
    resf.write(resp)

    return resp


cat_file=open(output_dir+'Src_Categories.txt','r')
cat_lst_tmp=cat_file.readlines()
cat_lst=[]
for clti in cat_lst_tmp:
    cat_lst.append(clti.replace('\n','').strip(' '))
for cli in cat_lst:
    resp=get_category_ids(cli)
    for cat_id in resp:
        print(resp[cat_id]['name'],"-->",cat_id )
        resp1=get_best_seller_asins(str(cat_id),resp[cat_id]['name'])
        for asin in list(resp1["asinList"]):
            print(asin)
            get_asin_info(asin)

