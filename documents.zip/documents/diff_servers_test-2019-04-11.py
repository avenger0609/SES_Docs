import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3

params = quote_plus(r'Driver={SQL Server};Server=TRMDB-PROD;Database=TRMDB;Trusted_Connection=yes;')

engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)

sql_string="SELECT dbo.GL_OU_staging.GL_OU AS oper_unit, dbo.GL_OU_staging.BusinessUnitDescription AS ShortDescription, dbo.GL_OU_staging.BusinessSegmentName AS LongDescription, dbo.GL_OU_staging.EffectiveStatus, dbo.GL_OU_staging.RowInsertDate FROM dbo.GL_OU_staging;"

final_data_fetch = pd.read_sql_query(sql_string, engine)
db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\april\\refresh.db"
con = sqlite3.connect(db_file)
cur = con.cursor()
final_data_fetch.to_sql("refresh_tbl", con, if_exists='replace', index=False)
df = pd.read_sql_query("SELECT * FROM refresh_tbl limit 5;", con)
# cur.execute("SELECT * FROM refresh_tbl")
# rows = cur.fetchall()
# print(rows[0])
df.to_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\April\\1903 test.csv',index=False,quoting=csv.QUOTE_ALL)
con.commit()
con.close()

