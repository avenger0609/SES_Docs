from pymongo import MongoClient
# pprint library is used to make the output look more pretty
from pprint import pprint
# connect to MongoDB, change the << MONGODB URL >> to reflect your own connection string
# client = MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
# db=client.HandsFreeAnalytics
# # Issue the serverStatus command and print the results
# serverStatusResult=db.command("serverStatus")
# # print(serverStatusResult)

# collection=db.claims_2
# # collection.
# fivestarcount = collection.find({'root_claim_num': '7454205018'}).count()
# print(fivestarcount)

import pymongo

myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
print(myclient.list_database_names())
mydb = myclient["HandsFreeAnalytics"]
print(mydb.list_collection_names())
mycol = mydb["Claims_2"]
mydoc = mycol.find({"root_claim_num": "7454176508"}).sort("root_claim_num")
print(str(mydoc.count()))
for x in mydoc:
  print(x)

