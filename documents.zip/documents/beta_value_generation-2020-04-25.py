import pandas as pd 

df=pd.read_excel(r'C:\users\asrilekh\Documents\US_collated_20200423114132.xlsx',sheet_name='Sheet2')
df['Susceptible']=df['Total Population']-df['Total Cases']
df['Susceptible_min_1']=df['Susceptible'].shift(1)
df['Susceptible_diff'] = df['Susceptible'] - df['Susceptible'].shift(1)
df['beta']=df['Susceptible_diff']/(df['Susceptible'].shift(1)*-1*df['Active Cases'].shift(1))
df['Susceptible_Calc']=(df['beta']*-1*df['Susceptible'].shift(1)*df['Active Cases'].shift(1))+df['Susceptible'].shift(1)
df['Recovered_Count']=(df['Active Cases'].shift(1)+df['New Cases']-df['New Deaths'])-df['Active Cases']
df['gamma']=(df['Recovered_Count'] - df['Recovered_Count'].shift(1))/df['Active Cases'].shift(1)
df['gamma'] = df['gamma'].abs()
# print(type(df.groupby(['County'])['beta'].mean()))
# df['beta_mean']=df.groupby(['County'])['beta'].mean()
# df['gamma_mean']=df.groupby(['County'])['gamma'].mean()

sf=df.groupby(['County'])['beta'].mean()
df_beta=pd.DataFrame({'County':sf.index, 'Beta_Mean':sf.values})
print(df_beta)

sf=df.groupby(['County'])['gamma'].mean()
df_gamma=pd.DataFrame({'County':sf.index, 'Gamma_Mean':sf.values})
print(df_gamma)

df_County_beta_gamma=pd.merge(df_beta, df_gamma, how='inner', on=['County'])

# df.to_excel(r'C:\users\asrilekh\Documents\US_collated_Python_means.xlsx')
# print(df)
