import pandas as pd
from collections import defaultdict
from collections import Counter
from collections import OrderedDict
import numpy as np
import csv

claim_agg_sub = pd.read_csv('claim_agg_full_pop.csv',dtype={'SBSCR_MBR_PTY_ID':str})
claim_agg_ets = pd.read_csv('ETS_claim_agg.csv',dtype={'SBSCR_MBR_PTY_ID':str})
call_agg_sub = pd.read_csv('call_agg_full_pop.csv',dtype={'SBSCR_MBR_PTY_ID':str})
call_agg_ets = pd.read_csv('ets_call_agg.csv',dtype={'member_id':str})

print(pd.concat([claim_agg_sub.SBSCR_MBR_PTY_ID.apply(lambda x: len(x)), claim_agg_sub.SBSCR_MBR_PTY_ID], axis=1))
print(claim_agg_sub.dtypes)
print(Counter(['.0' in x for x in claim_agg_sub.SBSCR_MBR_PTY_ID]))

if any(['.0' in x for x in claim_agg_sub.SBSCR_MBR_PTY_ID]):
    # Remove the last 2 characters '.0' from ID because not need float and need to retain leading zeros
    claim_agg_sub.SBSCR_MBR_PTY_ID = claim_agg_sub.SBSCR_MBR_PTY_ID.apply(lambda x: x[:-2])
claim_agg_sub.SBSCR_MBR_PTY_ID = [x.zfill(12) for x in claim_agg_sub.SBSCR_MBR_PTY_ID]
print(pd.concat([call_agg_sub.SBSCR_MBR_PTY_ID.apply(lambda x: len(str(x))), call_agg_sub.SBSCR_MBR_PTY_ID], axis=1))
call_agg_sub.SBSCR_MBR_PTY_ID = [str(x).zfill(12) for x in call_agg_sub.SBSCR_MBR_PTY_ID]
print('claim ets')
    # There are variable length IDs in this column, ranging from length of 11 to 14.
print(pd.concat([claim_agg_ets.SBSCR_MBR_PTY_ID.apply(lambda x: len(x)), claim_agg_ets.SBSCR_MBR_PTY_ID], axis=1))

    # Check to see if we can remove the last characters '.0' from all the IDs. Specifically check if this is in every ID value.
print(Counter(['.0' in x for x in claim_agg_ets.SBSCR_MBR_PTY_ID]))
    
if any(['.0' in x for x in claim_agg_ets.SBSCR_MBR_PTY_ID]):
        # Remove the last 2 characters '.0' from ID because not need float and need to retain leading zeros
    claim_agg_ets.SBSCR_MBR_PTY_ID = claim_agg_ets.SBSCR_MBR_PTY_ID.apply(lambda x: x[:-2])
    
claim_agg_ets.SBSCR_MBR_PTY_ID = [x.zfill(12) for x in claim_agg_ets.SBSCR_MBR_PTY_ID]
    
print('call ets')
print(pd.concat([call_agg_ets.SBSCR_MBR_PTY_ID.apply(lambda x: len(str(x))), call_agg_ets.SBSCR_MBR_PTY_ID], axis=1))
call_agg_ets.SBSCR_MBR_PTY_ID = [str(x).zfill(12) for x in call_agg_ets.SBSCR_MBR_PTY_ID]

print("Number of SBSCR_MBR_PTY_IDs matching between claims and calls data:",len(set(claim_agg_sub.SBSCR_MBR_PTY_ID) & set(call_agg_sub.SBSCR_MBR_PTY_ID)))

print("Number of SBSCR_MBR_PTY_IDs matching between claims and calls data in ETS:",len(set(claim_agg_ets.SBSCR_MBR_PTY_ID) & set(call_agg_ets.SBSCR_MBR_PTY_ID)))

print(claim_agg_sub.duplicated().value_counts())
print(call_agg_sub.duplicated().value_counts())


# remove complete duplicates
claim_agg_sub.drop_duplicates(inplace=True)
call_agg_sub.drop_duplicates(inplace=True)

claim_agg_sub.drop_duplicates(inplace=True)
call_agg_sub.drop_duplicates(inplace=True)

claim_agg_ets.drop_duplicates(inplace=True)
call_agg_ets.drop_duplicates(inplace=True)

claim_agg_sub[claim_agg_sub.SBSCR_MBR_PTY_ID.duplicated(keep=False)].sort_values('SBSCR_MBR_PTY_ID')
print('How many SBSCR_MBR_PTY_IDs have multiple rows:', (claim_agg_sub[claim_agg_sub.SBSCR_MBR_PTY_ID.duplicated(keep=False)].sort_values('SBSCR_MBR_PTY_ID')).SBSCR_MBR_PTY_ID.nunique())

call_agg_sub[call_agg_sub.SBSCR_MBR_PTY_ID.duplicated(keep=False)].sort_values('SBSCR_MBR_PTY_ID')
print('How many SBSCR_MBR_PTY_IDs have multiple rows:',call_agg_sub[call_agg_sub.SBSCR_MBR_PTY_ID.duplicated(keep=False)].sort_values('SBSCR_MBR_PTY_ID').SBSCR_MBR_PTY_ID.nunique())
# remove subscribers with multiple rows
call_agg_sub = call_agg_sub[list(~np.array(call_agg_sub.SBSCR_MBR_PTY_ID.duplicated(keep=False)))].copy()

full_baseline = pd.merge(claim_agg_sub, call_agg_sub, how='inner', on='SBSCR_MBR_PTY_ID')
print(full_baseline.shape)
print(full_baseline.head())

full_ets = pd.merge(claim_agg_ets, call_agg_ets, how='inner', on='SBSCR_MBR_PTY_ID')
print(full_ets.shape)
print(full_ets.head())

overlap_ids = set(full_baseline.SBSCR_MBR_PTY_ID) & set(full_ets.SBSCR_MBR_PTY_ID)
print("Number of IDs that are in both files:",len(overlap_ids))
full_baseline.shape
print('\nRemove these IDS:')
full_baseline = full_baseline[~full_baseline.SBSCR_MBR_PTY_ID.isin(list(overlap_ids))]
print(full_baseline.shape)

full_ets.dropna(inplace=True)

with pd.option_context('display.max_rows', None, 'display.max_columns', None):  # more options can be specified also
    print(full_baseline.isna().sum(axis=0))

full_baseline[full_baseline[[x for x in full_baseline.columns if '_AMT_' in x]].isna().sum(axis=1) ==  len([x for x in full_baseline.columns if '_AMT_' in x])]

full_baseline = full_baseline[~full_baseline.index.isin(full_baseline[full_baseline[[x for x in full_baseline.columns if '_AMT_' in x]].isna().sum(axis=1) == len([x for x in full_baseline.columns if '_AMT_' in x])].index)]

full_baseline.fillna(0,inplace=True)

print(full_baseline.shape)
print(full_ets.shape)

same_columns = list(set(full_baseline.columns) & set(full_ets.columns))
full_baseline = full_baseline[same_columns]
full_ets = full_ets[same_columns]

# df_pivot=pd.read_csv("decn_otcum_typ_desc_rsn_grp_join0514.csv",dtype={'SBSCR_MBR_PTY_ID':str})
# if any(['.0' in x for x in df_pivot.SBSCR_MBR_PTY_ID]):
#     # Remove the last 2 characters '.0' from ID because not need float and need to retain leading zeros
#     df_pivot.SBSCR_MBR_PTY_ID = df_pivot.SBSCR_MBR_PTY_ID.apply(lambda x: x[:-2])
# df_pivot.SBSCR_MBR_PTY_ID = [x.zfill(12) for x in df_pivot.SBSCR_MBR_PTY_ID]

# df_baseline_pivots_join=pd.merge(df_pivot,full_baseline,how='inner',on=["SBSCR_MBR_PTY_ID"])
# df_ets_pivots_join=pd.merge(df_pivot,full_ets,how='inner',on=["SBSCR_MBR_PTY_ID"])

# print(df_ets_pivots_join.shape)
# print(df_baseline_pivots_join.shape)

# df_ets_pivots_join.to_csv('ETS_And_Pivot_Merge_0521.csv',index=False,quoting=csv.QUOTE_ALL)
# df_baseline_pivots_join.to_csv('Baseline_And_Pivot_Merge_0521.csv',index=False,quoting=csv.QUOTE_ALL)

df_join_res=pd.read_csv('/app/qualtrics/pera/PA Data Analysis/pa_all_matched.csv',dtype={'SBSCR_MBR_PTY_ID':str},usecols=['SBSCR_MBR_PTY_ID'])
print(df_join_res.shape)
df_join_res = df_join_res.dropna(axis = 0, how ='any') 
print(df_join_res.shape)
if any(['.0' in x for x in df_join_res.SBSCR_MBR_PTY_ID]):
    # Remove the last 2 characters '.0' from ID because not need float and need to retain leading zeros
    df_join_res.SBSCR_MBR_PTY_ID = df_join_res.SBSCR_MBR_PTY_ID.apply(lambda x: x[:-2])
df_join_res.SBSCR_MBR_PTY_ID = [x.zfill(12) for x in df_join_res.SBSCR_MBR_PTY_ID]
# print(pd.concat([df_join_res.SBSCR_MBR_PTY_ID.apply(lambda x: len(x)), df_join_res.SBSCR_MBR_PTY_ID], axis=1))
df_unq=df_join_res.drop_duplicates(['SBSCR_MBR_PTY_ID'])

print(df_unq.shape)

result1 = pd.merge(df_unq, full_ets, how='inner', on=['SBSCR_MBR_PTY_ID', 'SBSCR_MBR_PTY_ID'])
print(result1.shape)

result2 = pd.merge(df_unq, full_baseline, how='inner', on=['SBSCR_MBR_PTY_ID', 'SBSCR_MBR_PTY_ID'])
print(result2.shape)

first_file='/app/qualtrics/pera/PA Data Analysis/pa_all_matched.csv'
second_file='/app/qualtrics/pera/PA Data Analysis/decn_rsn_grouping.csv'
output_file='join_res_0522.csv'
columns_list=['decn_rsn_typ_desc']

df_pa_matched=pd.read_csv(first_file,dtype={'SBSCR_MBR_PTY_ID':str},usecols=['SBSCR_MBR_PTY_ID','decn_rsn_typ_desc','decn_otcome_typ_desc'])
print(len(df_pa_matched))
df_decn_rsn_grouping=pd.read_csv(second_file,encoding = 'latin_1')
df=pd.merge(df_pa_matched,df_decn_rsn_grouping,how='left',on=columns_list)
print(df.columns)


print(df.shape)
df = df.dropna(axis = 0, how ='any') 
print(df.shape)
if any(['.0' in x for x in df.SBSCR_MBR_PTY_ID]):
    # Remove the last 2 characters '.0' from ID because not need float and need to retain leading zeros
    df.SBSCR_MBR_PTY_ID = df.SBSCR_MBR_PTY_ID.apply(lambda x: x[:-2])
df.SBSCR_MBR_PTY_ID = [x.zfill(12) for x in df.SBSCR_MBR_PTY_ID]
df_unq=df.drop_duplicates(['SBSCR_MBR_PTY_ID'])

print(df_unq.shape)

df_unq['SBSCR_MBR_PTY_ID_pivot']=df_unq['SBSCR_MBR_PTY_ID']

table = pd.pivot_table(df_unq, values='SBSCR_MBR_PTY_ID_pivot', index=['SBSCR_MBR_PTY_ID'],columns=['decn_otcome_typ_desc'], aggfunc='count', fill_value=0)
table=table.reset_index()

print(table.shape)

table1 = pd.pivot_table(df_unq, values='SBSCR_MBR_PTY_ID_pivot', index=['SBSCR_MBR_PTY_ID'],columns=['descn_rsn_group'], aggfunc='count', fill_value=0)
table1=table1.reset_index()

print(table1.shape)

df_pivots_join=pd.merge(table,table1,how='inner',on=["SBSCR_MBR_PTY_ID"])

print(df_pivots_join.shape)

result1 = pd.merge(df_pivots_join, full_ets, how='inner', on=['SBSCR_MBR_PTY_ID', 'SBSCR_MBR_PTY_ID'])
print(result1.shape)

result2 = pd.merge(df_pivots_join, full_baseline, how='inner', on=['SBSCR_MBR_PTY_ID', 'SBSCR_MBR_PTY_ID'])
print(result2.shape)

result1.to_csv('ETS_And_Pivot_Merge_0521.csv',index=False,quoting=csv.QUOTE_ALL)
result2.to_csv('Baseline_And_Pivot_Merge_0521.csv',index=False,quoting=csv.QUOTE_ALL)
