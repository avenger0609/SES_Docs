import cx_Oracle
import pandas as pd

Host_Name=""
Port_Number=""
Service_Name=""
User_Name=""
Password=""

dsn_tns = cx_Oracle.makedsn(Host_Name,Port_Number, service_name=Service_Name) 
conn = cx_Oracle.connect(user=User_Name, password=Password, dsn=dsn_tns) 

sql_string="SELECT MAX(dcycleof) FROM point.dbo.amgbizflags"

df = pd.read_sql_query(sql_string, conn)
print(df)