import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3

params = quote_plus(r'Driver={SQL Server};Server=TRMDB-PROD;Database=TRMDB;Trusted_Connection=yes;')
engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
sql_string="SELECT dbo.CB_ChargebackData_UnAgg.AccountingYearMonth,dbo.CB_ChargebackData_UnAgg.ServiceUniqueIdentifier,dbo.CB_ChargebackData_UnAgg.BillingCode,dbo.CB_ChargebackData_UnAgg.ServiceName,dbo.CB_ChargebackData_UnAgg.ServiceVirtual,dbo.CB_ChargebackData_UnAgg.CustomerAcceptance,dbo.CB_ChargebackData_UnAgg.AppName,dbo.CB_ChargebackData_UnAgg.ProdNonProd,dbo.CB_ChargebackData_UnAgg.ServiceRequestNumber,dbo.CB_ChargebackData_UnAgg.ServiceDeliveryDate,dbo.CB_ChargebackData_UnAgg.ProjectManager,dbo.CB_ChargebackData_UnAgg.ParentCreateDate,dbo.CB_ChargebackData_UnAgg.ParentDescription,dbo.CB_ChargebackData_UnAgg.ParentRequestID,dbo.CB_ChargebackData_UnAgg.ParentRequestType,dbo.CB_ChargebackData_UnAgg.ParentRequestor,dbo.CB_ChargebackData_UnAgg.ParentRequestorEmail,dbo.CB_ChargebackData_UnAgg.RequestType,dbo.CB_ChargebackData_UnAgg.Requestor,dbo.CB_ChargebackData_UnAgg.RequestorEmail,dbo.CB_ChargebackData_UnAgg.Description,dbo.CB_ChargebackData_UnAgg.CreateDate,dbo.CB_ChargebackData_UnAgg.GL_CodeOwner,dbo.CB_ChargebackData_UnAgg.ProjectName,dbo.CB_ChargebackData_UnAgg.ProjectRequestor,dbo.CB_ChargebackData_UnAgg.Prompt_ID,dbo.CB_ChargebackData_UnAgg.DataCenterCode FROM dbo.CB_ChargebackData_UnAgg WHERE (((dbo.CB_ChargebackData_UnAgg.AccountingYearMonth)='1903'));"
final_data_fetch = pd.read_sql_query(sql_string, engine)
print("data fetched")
db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\78000DFITBM.db"
con = sqlite3.connect(db_file)
final_data_fetch.to_sql("tbl_trmcbsource", con, if_exists='replace', index=False)
print("trmdbc source inserted")
params = quote_plus(r'Driver={SQL Server};Server=MPWR;Database=ITFB;Trusted_Connection=yes;')
engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
sql_string="SELECT dbo.history_ledger_active_ets.HISTORY_PERIOD, dbo.history_ledger_active_ets.HISTORY_VERSION, dbo.history_ledger_active_ets.SEGMENT, '' AS [Current Year], '' AS [Current Month], dbo.rates_active.GL_DEPT AS CS_SERVICE_GROUP_COTS_CENTER, dbo.rates_active.SERVCAT AS CS_SERVICE_GROUP, dbo.history_ledger_active_ets.SERVICE, dbo.history_ledger_active_ets.SV_DESC, dbo.history_ledger_active_ets.APPL AS CS_APPLICATION_NAME, dbo.history_ledger_active_ets.PROJECT AS CS_PROJECT_NUMBER, dbo.history_ledger_active_ets.GL_BU, dbo.history_ledger_active_ets.GL_OP_UNIT, dbo.history_ledger_active_ets.GL_LOC, dbo.history_ledger_active_ets.GL_ACCT, dbo.history_ledger_active_ets.GL_DEPT, dbo.history_ledger_active_ets.GL_PROD, dbo.history_ledger_active_ets.GL_CUSTOMER, dbo.history_ledger_active_ets.GL_PROJECT, dbo.history_ledger_active_ets.CS_SERVICE_PHYSICAL, '' AS CS_SERVICE_STORAGE, dbo.history_ledger_active_ets.CS_SERVICE_UNIQUE_IDENTIFIER, dbo.history_ledger_active_ets.QUANTITY AS CS_SERVICE_UNITS, dbo.history_ledger_active_ets.Rate AS CS_SERVICE_RATE_PER_UOM,CAST(dbo.history_ledger_active_ets.CHARGES AS Float)  AS CS_BASE_SERVICE_COST, '' AS CS_SUPP_STORAGE_COST, dbo.history_ledger_active_ets.CS_CB_UNIQUE_KEY, dbo.history_ledger_active_ets.GL_BU_ORIGINAL, dbo.history_ledger_active_ets.GL_OP_UNIT_ORIGINAL, dbo.history_ledger_active_ets.GL_LOC_ORIGINAL, dbo.history_ledger_active_ets.GL_DEPT_ORIGINAL, dbo.history_ledger_active_ets.GL_PROD_ORIGINAL, dbo.history_ledger_active_ets.GL_CUSTOMER_ORIGINAL, dbo.history_ledger_active_ets.GL_PROJECT_ORIGINAL, '' AS CS_FINANCE_DELTAS, dbo.history_ledger_active_ets.CS_SUI_DESCRIPTION, dbo.history_ledger_active_ets.PUBLISHED, '' AS CS_SERVICE, dbo.history_ledger_active_ets.ADJ_REF_ID, dbo.history_ledger_active_ets.DATASRC, '' AS BUSINESS_APP_NAME, dbo.history_ledger_active_ets.TMDB_APP_CODE, dbo.history_ledger_active_ets.GLOBAL_APP_ID, dbo.history_ledger_active_ets.LONG_APP_NAME, '' AS COMPUTE_UNIT_PCT_CPU, '' AS COMPUTE_UNIT_PCT_RAM, '' AS CPU_ALLOCATED, '' AS CPU_AVG_UTIL_PCT, '' AS CPU_PEAK_UTIL_PCT, '' AS Data_Center_NAME, '' AS PCT_UPTIME, '' AS RAM_ALLOCATED, '' AS RAM_AVG_UTIL_PCT, '' AS RAM_PEAK_UTIL_PCT, dbo.history_ledger_active_ets.EMP_ID, dbo.history_ledger_active_ets.SITE_CODE, dbo.history_ledger_active_ets.SUSPEND, dbo.history_ledger_active_ets.EMAIL_ADDRESS, dbo.history_ledger_active_ets.EMP_TYPE, dbo.history_ledger_active_ets.FIRST_NAME, dbo.history_ledger_active_ets.LAST_NAME, dbo.history_ledger_active_ets.VCC_SITEFROM (dbo.history_ledger_active_ets LEFT JOIN dbo.rates_active ON dbo.history_ledger_active_ets.SERVICE = dbo.rates_active.SERVICE) WHERE (((dbo.history_ledger_active_ets.HISTORY_PERIOD)='201902') AND ((dbo.history_ledger_active_ets.GL_ACCT)='78000'));"
final_data_fetch = pd.read_sql_query(sql_string, engine)
print("data fetched")
db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\78000DFITBM.db"
final_data_fetch.to_sql("tbl_7800_dfitbm", con, if_exists='replace', index=False)
print("another table inserted")
con.commit()
con.close()

