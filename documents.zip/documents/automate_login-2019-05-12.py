## worked ###
from selenium import webdriver
driverpath = "C:\\ProgramData\\Chrome_driver_2.46\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
# driver = webdriver.Chrome("C:\\ProgramData\\Chrome_driver_2.46\\chromedriver.exe")
driver.get("https://ecg.healthtechnologygroup.com/httpsportal/login.do")
driver.find_element_by_id('userName').send_keys('ih007k1')
driver.find_element_by_id ('password').send_keys('MMG2eHmW')
driver.find_element_by_css_selector('.btn.btn-block.btn-warning').click()
driver.find_element_by_id('transfertab').click()
driver.find_element_by_xpath("//select[@id='folderPath']/option[text()='/vmware/dev']").click()
# driver.find_element_by_id('fileName').click().send_keys( "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\april.zip")
driver.find_element_by_id('fileName').click()

