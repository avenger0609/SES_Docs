import requests 
file_url = "http://cfrservices.uhg.com/Info/TreeReport/UHG_OPERATING_UNIT_GEN_PSTREE.csv"
  
r = requests.get(file_url, stream = True) 
requests.get(file_url,stream=True,auth=('asrilekh', 'UHGtech-1'))
with open("UHG_OPERATING_UNIT_GEN_PSTREE.csv","wb") as pdf: 
    for chunk in r.iter_content(chunk_size=1024): 
  
         # writing one chunk at a time to pdf file 
         if chunk: 
             pdf.write(chunk) 