import os


Result_Folder=['ASIN_Result']
History_folder_names=['AMAZON','NEW','USED','SALES','LISTPRICE','NEW_FBM_SHIPPING','NEW_FBA','COUNT_NEW','COUNT_USED','EXTRA_INFO_UPDATES'
        ,'RATING','COUNT_REVIEWS','BUY_BOX_SHIPPING','COLLECTIBLE','REFURBISHED','LIGHTNING_DEAL','WAREHOUSE','COUNT_REFURBISHED'
        ,'COUNT_COLLECTIBLE','USED_NEW_SHIPPING','USED_VERY_GOOD_SHIPPING','USED_GOOD_SHIPPING','USED_ACCEPTABLE_SHIPPING','COLLECTIBLE_NEW_SHIPPING'
        ,'COLLECTIBLE_VERY_GOOD_SHIPPING','COLLECTIBLE_GOOD_SHIPPING','COLLECTIBLE_ACCEPTABLE_SHIPPING','REFURBISHED_SHIPPING','TRADE_IN']

consolidated_folder='c:\\users\\asrilekh\\documents\\Keepa_Data_Extract\\Consolidated_Category_Best_Selling'
for rfi in Result_Folder:
    if os.path.exists(consolidated_folder+"\\"+rfi):
        ok=1
    else:
        os.mkdir(consolidated_folder+"\\"+rfi)

for rfi in History_folder_names:
    if os.path.exists(consolidated_folder+"\\"+rfi):
        ok=1
    else:
        os.mkdir(consolidated_folder+"\\"+rfi)

cons_files=[f for f in os.listdir(consolidated_folder) if os.path.isfile(os.path.join(consolidated_folder, f))]
for rfi in Result_Folder:
    for cfi in cons_files:
        if (rfi.lower().strip(' ') in cfi.lower().strip(' ')) and '_History_Data' not in cfi :
            src_file=consolidated_folder+"\\"+cfi
            dest_file=consolidated_folder+"\\"+rfi+"\\"+cfi
            copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'   
            print(copy_cmd)
            try:
                os.system(copy_cmd)   
            except Exception as e:
                print(e) 

for rfi in History_folder_names:
    for cfi in cons_files:
        if (rfi.lower().strip(' ') in cfi.lower().strip(' ')) and '_History_Data' in cfi :
            src_file=consolidated_folder+"\\"+cfi
            dest_file=consolidated_folder+"\\"+rfi+"\\"+cfi
            copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'   
            print(copy_cmd)
            try:
                os.system(copy_cmd)   
            except Exception as e:
                print(e) 