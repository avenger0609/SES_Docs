import pandas as pd

data = [['Alex',10],['Bob',12],['Clarke',13]]
df = pd.DataFrame(data,columns=['Name','Age'])
df.sort_values("Age", axis = 0, ascending = False,inplace = True, na_position ='last') 
print(df)
