import os
from shutil import copyfile


# thisdir = r'c:\users\asrilekh\desktop\work'
# thisdir = r'c:\users\asrilekh\documents'
# thisdir = r'c:\users\asrilekh\downloads'
thisdir = r'c:\users\asrilekh\desktop'
# thisdir=r'C:\Users\asrilekh\Pictures'
# thisdir=r'C:\Users\asrilekh\Music'
# thisdir=r'C:\Users\asrilekh\MTech'

# for thisdir in [r'c:\users\asrilekh\desktop',r'C:\Users\asrilekh\Pictures',r'C:\Users\asrilekh\Pictures',r'C:\Users\asrilekh\MTech']:
#     # r=root, d=directories, f = files
#     for r, d, f in os.walk(thisdir):
#         for file in f:
#             # if file.endswith(".py"):            
#             try:   
#                 if r.startswith("c:\\users\\asrilekh\\desktop\\work") or file.endswith("all_case_data.zip"):
#                     continue
#                 # destpath=str(r).replace(r"c:\users\asrilekh\",r"\desktop\python programs test")
#                 # destpath=str(r).replace(r"c:\users\asrilekh\",r"\desktop\python programs test")
#                 destpath=str(r).replace("c:\\users\\asrilekh\\","\\\\nas05151pn\\ii519_homedirs\\asrilekh\\")                
#                 if not os.path.exists(destpath):
#                     os.makedirs(destpath) 
#                 src_file=os.path.join(r, file)
#                 dest_file=os.path.join(destpath, file)
#                 copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'            
#                 if not os.path.exists(os.path.join(destpath, file)):
#                     # copyfile(os.path.join(r, file),os.path.join(destpath, file))
#                     # os.system('copy C:\\Users\\asrilekh\\Documents\\Doc1.pdf C:\\Users\\asrilekh\\Downloads\\Doc1.pdf')
#                     print(copy_cmd)
#                     os.system(copy_cmd)                
#                 else:
#                     if os.path.getmtime(dest_file)==os.path.getmtime(src_file):
#                         pass
#                     else:
#                         # copyfile(os.path.join(r, file),os.path.join(destpath, file))
#                         print(copy_cmd)
#                         os.system(copy_cmd)
#             except Exception as e:
#                 print(os.path.join(r, file))
#                 print(str(e))


homedir_files=[f for f in os.listdir('c:\\users\\asrilekh') if os.path.isfile(os.path.join('c:\\users\\asrilekh', f))]
for f in homedir_files:
    src_file=os.path.join('c:\\users\\asrilekh', f)
    dest_file=src_file.replace("c:\\users\\asrilekh\\","\\\\nas05151pn\\ii519_homedirs\\asrilekh\\")                
    copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'            
    if not os.path.exists(dest_file):
        # copyfile(os.path.join(r, file),os.path.join(destpath, file))
        # os.system('copy C:\\Users\\asrilekh\\Documents\\Doc1.pdf C:\\Users\\asrilekh\\Downloads\\Doc1.pdf')
        print(copy_cmd)
        os.system(copy_cmd)                
    else:
        if os.path.getmtime(dest_file)==os.path.getmtime(src_file):
            pass
        else:
            # copyfile(os.path.join(r, file),os.path.join(destpath, file))
            print(copy_cmd)
            os.system(copy_cmd)
