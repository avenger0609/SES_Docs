from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime

acc_mon_lst=[]
billing_file_lst=[]
service_code_lst=[]
service_name_lst=[]
status_lst=[]
comments_lst=[]
signoff_by_list=[]
signoff_date_list=[]
svc_urls_lst=[]

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://dmp.optum.com/ChargebackManagement/Signoff")
pending_only=driver.find_element_by_xpath('//*[@id="chkPendingOnly"]')
if pending_only.is_selected:
    pass
else:
    pending_only.click()
cur_cycle=driver.find_element_by_xpath('//*[@id="chkCurrentCycle"]')
if cur_cycle.is_selected:
    pass
    # cur_cycle.click()
else:
    cur_cycle.click()
    # pass

time.sleep(15)

## changes done after success

select_fr = Select(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/div[1]/div[2]/label/select'))
select_fr.select_by_index(3)
time.sleep(15)

## changes done after success

nopages_s=driver.find_element_by_xpath('//*[@id="signoff-table_paginate"]/span')
nopages_lst=nopages_s.find_elements_by_tag_name('a')
nopages=nopages_lst[len(nopages_lst)-1].text
print("number of pages="+str(nopages))
counter=1
exception_flag=0
try:
    while counter <= int(nopages) :

        # if len(acc_mon_lst) >= 5:
        #     break


        print("page number="+str(counter))
        # if counter==1:
        #     counter=counter+1
        #     continue
        row_counter=1
        driver.get("https://dmp.optum.com/ChargebackManagement/Signoff")
        pending_only=driver.find_element_by_xpath('//*[@id="chkPendingOnly"]')
        if pending_only.is_selected:
            pass
        else:
            pending_only.click()
        cur_cycle=driver.find_element_by_xpath('//*[@id="chkCurrentCycle"]')
        if cur_cycle.is_selected:
            pass
            # cur_cycle.click()
        else:
            cur_cycle.click()
            # pass
        time.sleep(15)
        ## changes done after success

        select_fr = Select(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/div[1]/div[2]/label/select'))
        select_fr.select_by_index(3)
        time.sleep(15)

        ## changes done after success
        tbl_id=driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody')             
        rows=tbl_id.find_elements_by_tag_name("tr")
        comment_flag=0
        ######
        break1=0
        while row_counter<=len(rows):
            # if len(acc_mon_lst) >= 5:
            #     break
            try:
                print("page number-rown number="+str(counter)+"-"+str(row_counter))
                
                next_counter=counter
                page_counter=1    
                try:
                    pending_only=driver.find_element_by_xpath('//*[@id="chkPendingOnly"]')
                    if pending_only.is_selected:
                        pass
                    else:
                        pending_only.click()
                    cur_cycle=driver.find_element_by_xpath('//*[@id="chkCurrentCycle"]')
                    if cur_cycle.is_selected:
                        pass
                        # cur_cycle.click()
                    else:
                        cur_cycle.click()
                except:
                    pass
                
                if row_counter==1:
                    ###    navigate to page when row_counter=0
                    driver.get("https://dmp.optum.com/ChargebackManagement/Signoff")
                    pending_only=driver.find_element_by_xpath('//*[@id="chkPendingOnly"]')
                    if pending_only.is_selected:
                        pass
                    else:
                        pending_only.click()
                    cur_cycle=driver.find_element_by_xpath('//*[@id="chkCurrentCycle"]')
                    if cur_cycle.is_selected:
                        pass
                        # cur_cycle.click()
                    else:
                        cur_cycle.click()
                        # pass
                    time.sleep(15)
                    ## changes done after success

                    select_fr = Select(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/div[1]/div[2]/label/select'))
                    select_fr.select_by_index(3)
                    time.sleep(15)

                    ## changes done after success
                    while page_counter<next_counter:
                        elem = driver.find_element_by_xpath('//*[@id="signoff-table_next"]')
                        elem.click() 
                        print('clicked next pls wait') 
                        time.sleep(15) 
                        # pending_only=driver.find_element_by_xpath('//*[@id="chkPendingOnly"]')
                        # if pending_only.is_selected:
                        #     pending_only.click()
                        # cur_cycle=driver.find_element_by_xpath('//*[@id="chkCurrentCycle"]')
                        # if cur_cycle.is_selected:
                        #     pass
                        #     # cur_cycle.click()
                        # else:
                        #     cur_cycle.click()
                        #     # pass
                        time.sleep(15)
                        page_counter=page_counter+1 
                    ###    navigate to page when row_counter=0

                ### respective page navigation
                if comment_flag==1:
                    print("comment flag is set to 1")
                    driver.get("https://dmp.optum.com/ChargebackManagement/Signoff")
                    pending_only=driver.find_element_by_xpath('//*[@id="chkPendingOnly"]')
                    if pending_only.is_selected:
                        pass
                    else:
                        pending_only.click()
                    cur_cycle=driver.find_element_by_xpath('//*[@id="chkCurrentCycle"]')
                    if cur_cycle.is_selected:
                        # pass
                        cur_cycle.click()
                    else:
                        # cur_cycle.click()
                        pass
                    time.sleep(15)
                    ## changes done after success

                    select_fr = Select(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/div[1]/div[2]/label/select'))
                    select_fr.select_by_index(3)
                    time.sleep(15)

                    ## changes done after success
                    while page_counter<next_counter:
                        elem = driver.find_element_by_xpath('//*[@id="signoff-table_next"]')
                        elem.click() 
                        print('clicked next pls wait') 
                        time.sleep(15) 
                        page_counter=page_counter+1 
                ### respective page navigation
                time.sleep(15)
                print(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[4]').text))
                j_tds=driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[7]')
                j_tds_a=j_tds.find_elements_by_tag_name('span')
                print(len(j_tds_a))
                print(len(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[7]').text).strip(' ')))
                if len(j_tds_a)==0:
                    if len(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[7]').text).strip(' '))==0:
                        # row_counter=row_counter+1
                        comment_flag=0
                        # continue
                # else:
                #     td_country=(tds_a)[0].text
                #     country_lst.append(td_country)
                # if len(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[7]').text).strip(' '))==0:
                #     row_counter=row_counter+1
                #     comment_flag=0
                #     continue
                comment_flag=1
                print(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[4]').text))
                # if str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[2]').text) in ['May 2020','April 2020']:
                #     pass
                # else:
                #     break1=1
                #     break
                acc_mon_lst.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[2]').text))
                billing_file_lst.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[3]').text))
                service_code_lst.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[4]').text))
                service_name_lst.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[5]').text))
                status_lst.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[6]').text))
                #comments_lst.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[7]').text))
                signoff_by_list.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[8]').text))
                signoff_date_list.append(str(driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[9]').text))

                ### to pick the comments 
                
                driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody/tr['+str(row_counter)+']/td[1]/span/a').click()
                svc_url=driver.current_url
                print(svc_url)
                svc_urls_lst.append(svc_url)
                time.sleep(15)
                fc_text=(driver.find_element_by_xpath('//*[@id="Comments"]')).text
                sc_text=""
                parent_id=driver.find_element_by_xpath('//*[@id="signoff-observation-grid"]/tbody')
                parent_rows=parent_id.find_elements_by_tag_name('tr')
                for pr in parent_rows:
                    try:
                        pd_1=pr.find_elements_by_tag_name('td')[1]
                        if str(pd_1.text).upper().strip(' ')==str('Month over Month decrease in recovery (does not include ETS) exceeded -20000.00').upper().strip(' '):
                            pd_3=pr.find_elements_by_tag_name('td')[3]
                            pd_3_div=pd_3.find_elements_by_tag_name('div')[0]
                            pd_3_ta=pd_3_div.find_elements_by_tag_name('textarea')[0]
                            sc_text=pd_3_ta.text
                    except:
                        pass
                if len(sc_text) > 0:
                    final_comments="1."+str(fc_text)+"\n2."+str(sc_text)
                    comments_lst.append(final_comments)
                else:
                    comments_lst.append(str(fc_text))

                ### to pick the comments 
            except Exception as e:
                exception_flag=1
                print(str(e))  
                break  
            if break1==1:
                break
            row_counter=row_counter+1
        #######
        if exception_flag==1:
            break
        counter=counter+1
except Exception as e:
    print(str(e))
finally:
    print(len(acc_mon_lst))
    print(len(billing_file_lst))
    print(len(service_code_lst))
    print(len(service_name_lst))
    print(len(status_lst))
    print(len(comments_lst))
    print(len(signoff_by_list))
    print(len(signoff_date_list))
    print(len(svc_urls_lst))
    df=pd.DataFrame()
    df['acc_mon_lst']=acc_mon_lst
    df['Actual CB Feed Name']=billing_file_lst
    df['Service Code']=service_code_lst
    df['service_name_lst']=service_name_lst
    df['status_lst']=status_lst
    df['comments_lst']=comments_lst
    df['signoff_by_list']=signoff_by_list
    df['signoff_date_list']=signoff_date_list
    df['Signoff URL']=svc_urls_lst

    last_month = datetime.now() #- relativedelta(months=1)
    last_mon_text = format(last_month, '%m-%B-%Y')
    # last_mon_text='06-June-2020'
    print(last_mon_text)

    mon_name=last_mon_text.split('-')[1]
    Year_Val=str(last_mon_text.split('-')[2])
    mon_Val_sngl_num=str(int(str(last_mon_text.split('-')[0]))*1)
    mon_Val_doubl_num=str(last_mon_text.split('-')[0])
    df['CB Feed Name']=df['Actual CB Feed Name'].str.replace('CB_'+Year_Val+mon_Val_doubl_num+'_','')

    df_svc_emails=pd.read_excel(r'c:\users\asrilekh\documents\Service owner name.xlsx')
    df_svc_emails=df_svc_emails.drop_duplicates()
    # df_svc_emails=df_svc_emails[df_svc_emails['Service Status']=='Active']
    df_svc_emails['Service Code']=df_svc_emails['Service Code'].astype(str)
    df['Service Code']=df['Service Code'].astype(str)

    df_merge=pd.merge(df,df_svc_emails,how='left',on=['Service Code','CB Feed Name'])
    # df.to_excel(r'c:\users\asrilekh\documents\new_cases_cnt_yesterday.xlsx',index=False)
    df_merge.to_csv(r'c:\users\asrilekh\documents\dmp_portal_pending_'+str(datetime.now().strftime('%Y%m%d%H%M%S%f'))+r'.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')
    df_merge.to_csv(r'C:\Users\asrilekh\Documents\dmp_portal.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')
# print(len(acc_mon_lst))
# print(len(billing_file_lst))
# print(len(service_code_lst))
# print(len(service_name_lst))
# print(len(status_lst))
# print(len(comments_lst))
# print(len(signoff_by_list))
# print(len(signoff_date_list))


driver.close()

