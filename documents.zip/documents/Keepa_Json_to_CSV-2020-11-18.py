import pandas as pd

df=pd.read_json(r'C:\Users\asrilekh\Documents\Keepa_Data_Extract\Category Search\Games_Category_Search_Result18_Nov_2020_215522.txt',dtype=False,encoding='latin-1')
print(df)
print(len(df))
print(df.iloc[0])
