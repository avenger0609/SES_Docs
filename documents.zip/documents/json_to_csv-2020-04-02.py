## not worked may be because of json file not in proper format

import pandas as pd
import csv

import csv, json, sys

input = open(r'c:\users\asrilekh\documents\practitioner response.txt')
data = json.load(input)
print(data)
input.close()

output = csv.writer(sys.stdout)

output.writerow(data[0].keys())  # header row

for row in data:
    output.writerow(row.values())