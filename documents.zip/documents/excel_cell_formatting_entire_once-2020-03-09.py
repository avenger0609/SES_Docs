import pandas as pd
import numpy as np
import xlsxwriter
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell

df = pd.DataFrame()
# writer = pd.ExcelWriter('pandas_simple.xlsx', engine='xlsxwriter')
df.to_excel('pandas_simple.xlsx', sheet_name='Sheet1')
wb = openpyxl.load_workbook('pandas_simple.xlsx')
c=0
for ws in wb.worksheets:
    print("entered")    
    ws.sheet_view.showGridLines = False
wb.save('pandas_simple.xlsx')
wb.close()
        