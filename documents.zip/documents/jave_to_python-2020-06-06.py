source={}
source['type']='source_type'
coord=[8,9,10]
result="varuniswastefellow{u}againvaruniswf"
if source['type'] == 'source_type':

    def replace_func():
        u = ''
        zoom = coord[2]
        while zoom > 0:
            b = 0
            mask = 1 << zoom - 1
            if (coord[0] & mask) != 0:
                b += 1
            if (coord[1] & mask) != 0:
                b += 2
            u += str(b)
            zoom -= 1
        return u
    print(replace_func())
    result = result.replace('{u}', replace_func())
    print(result)