from flask import Flask
from flask import render_template,jsonify,request
import requests
from models import *
from pblm_solving_files.knowledge_rev import *
from pblm_solving_files.duckling_wrapper import *
from pblm_solving_files.conv_history import *
from pblm_solving_files.uid_sessid_storing import *
from pblm_solving_files.mongodb_interaction import *
from pblm_solving_files.context_history import *
import random
import urllib3
from flask_cors import CORS



app = Flask(__name__)
app.secret_key = '12345'
CORS(app)

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route("/parse", methods=['GET', 'POST', 'OPTIONS'])
def parse():

    try:
        # print((request.url))
        parsed=(urllib3.util.url.parse_url(request.url))
        print(str(parsed.query))
        s1=str(str(parsed.query).split('&')[0].split('=')[1].replace('+',' ')) # first query
        uid_gen=1 # to check if user id was sent or not
        sessid_gen=1 # to check if session id was sent or not
        userid_ang="DEFAULT" # to store user id sent from angular
        sess_id_ang="DEFAULT"# to store session id sent from angular
        try:
            userid_ang=str(str(parsed.query).split('&')[1].split('=')[1].replace('+',' ')) # second query
        except:
            uid_gen=0
        try:
            sess_id_ang=str(str(parsed.query).split('&')[2].split('=')[1].replace('+',' ')) # second query
        except:
            sessid_gen=0
        if uid_gen==1 and sessid_gen==1:
            uid_sessid(userid_ang,sess_id_ang)
        # to remove unwanted characters
        print("userid="+userid_ang+"session id="+sess_id_ang)
        while True:
            a=s1.find("%")
            if a > -1:
                ss=s1[a]+s1[a+1]+s1[a+2]
                s1=s1.replace(ss," ")
            else:
                break        
        s1=s1.replace('  ',' ').replace('  ',' ').strip(' ').lower()        
        print(s1)
        # to remove unwanted characters
        if 'queries' in s1.lower().split(' ') and 'related' in s1.lower().split(' ') and 'to' in s1.lower().split(' ') and 'claims' in s1.lower().split(' '):
            s1="status of claim "
        user_message = s1 # to store original user message in some variable
        um1=user_message # to store original user message in some variable

        #### context storing variables ##

        context_uid=userid_ang
        context_sessid=sess_id_ang
        context_type_of_req="default"
        context_claim_r_claims="default"
        context_context="default"
        context_claim_num="default"
        context_from="default"
        context_to="default"
        context_days=list()
        context_months=list()
        context_years=list()

        #### context storing variables ##

        #days,months,years extracted to be returned
        dmy_lst=time_extract(um1) # returned from duckling
        dte_text_lst=list() # to replace text which refers to duaration of time
        if len(dte_text_lst) > 0:
            context_claim_r_claims="CLAIMS"
            if len(dmy_lst)==3:            
                context_from=dmy_lst[0]
                context_to=dmy_lst[1]            
                dte_text_lst=dmy_lst[2]         
            elif len(dmy_lst)==4:
                context_days=(dmy_lst[0])
                context_months=(dmy_lst[1])
                context_years=(dmy_lst[2])
                dte_text_lst=dmy_lst[3]            
            for dte_i in dte_text_lst:
                user_message=user_message.replace(" "+dte_i+" "," ")
        #days,months,years extracted to be returned

        #########   DERIVING CLAIM NUMBER AND IT'S CONTEXT IF CLAIM NUMBER IS IN REQUEST  #########

        claim_num='0'
        if len(dte_text_lst)==0:            
            claim_num=str(claim_num_extract(um1))
            if str(claim_num)=='0':
                junk=1
            else:
                context_claim_r_claims="CLAIM"
                context_claim_num=claim_num  
                context_context=get_status(str(context_claim_num))
                if context_context.split('}')[0]=='1':
                    context_context="DENIED"
                elif context_context.split('}')[0]=='2':
                    context_context="PAID"
                elif context_context.split('}')[0]=='3':
                    context_context="ADJUSTED" 
                elif context_context.split('}')[0]=='4':
                    context_context="PARTIALLY DENIED"   
                elif context_context.split('}')[0]=='5':
                    context_context="NOT FOUND"
                user_message=user_message.replace(context_claim_num,'')
                if len(user_message.strip(' '))==0:
                    print("entered if length 0")
                    um=pop_conv_hist(userid_ang,sess_id_ang)+" "+um1.strip(' ')
                    user_message=um
                    um1=um
                    # print("returned user message when only claim number is sent="+str(um))
                    # response = requests.post("http://localhost:5050/parse",params={"q":um,"uid":userid_ang,"sessid":sess_id_ang})   
                    # print("response when user message contains only claim number"+str(response.json()))
                    # return response.json()

        #########   DERIVING CLAIM NUMBER AND IT'S CONTEXT IF CLAIM NUMBER IS IN REQUEST  #########
        print("user_message is "+user_message)
        user_message=user_message.replace(" - ","-")
        user_message=corrected_ip_string_1(user_message)
        user_message=corrected_ip_string_1(user_message.replace('-',' '))           

        #### retrieving values from context collection ########

        if len(dte_text_lst)==0 and str(claim_num)=='0':
            ret_cntxt=pop_context_hist(context_uid,context_sessid)
            print("returned context"+str(ret_cntxt))
            if len(ret_cntxt) > 0:  
                context_type_of_req=ret_cntxt[2]
                context_claim_r_claims=ret_cntxt[3]
                context_context=ret_cntxt[4]
                context_claim_num=ret_cntxt[5]
                context_from=ret_cntxt[6]
                context_to=ret_cntxt[7]
                context_days=ret_cntxt[8]
                context_months=ret_cntxt[9]
                context_years=ret_cntxt[10]
            else:
                conv_uid=userid_ang
                conv_sesid=sess_id_ang
                conv_question=um1
                conv_answer="question incomplete"
                conv_intent="request incomplete"
                conv_int_conf="0"
                conv_like_r_dislike="default"
                conv_obj_id=conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
                return jsonify({"response":"Please enter claim number"})   


        #### retrieving values from context collection ########

        #########   DERIVING CONTEXT IF THERE IS DURATION IS IN REQUEST  #########
        if str(context_claim_r_claims)=="CLAIMS":            
            if "denied" in user_message.lower():
                context_context="DENIED"            
            elif "partial" in user_message.lower() and "denied" in user_message.lower():
                context_context="PARTIALLY DENIED"
            elif "high" in user_message.lower() and "dollar" in user_message.lower():
                context_context="HIGH DOLLAR"
            elif "received" in user_message.lower():
                context_context="RECEIVED" 
            elif "adjusted" in user_message.lower():
                context_context="ADJUSTED"
            else:
                ret_cntxt=pop_context_hist(context_uid,context_sessid)
                if len(ret_cntxt) > 0:  
                    context_context=ret_cntxt[4]
        #########   DERIVING CONTEXT IF THERE IS DURATION IS IN REQUEST  #########   

        ##### addding claim/claims accordingly #######

        if context_claim_r_claims=='CLAIM':
            if 'claim' not in user_message.lower():
                user_message=user_message+" for claim"
        elif context_claim_r_claims=='CLAIMS':
            if 'claims' not in user_message.lower():
                user_message=user_message+" towards claims"

        user_message=str(user_message).strip(' ').lower() 
               
        ##### addding claim/claims accordingly #######

        response = requests.get("http://apsrp03693:5000/parse",params={"q":user_message})                
        response = response.json()
        

        # response text to be returned
        res_text=um1
        # response text to be returned

        # intent to be returned
        intent = response.get("intent")
        res_intent=intent['name']
        res_intent_confidence=intent['confidence']
        res_claim_num=context_claim_num
        # intent to be returned
        # entities=response.get("entities")                
        print("returned intent is "+res_intent)
        
        ans="Unanswered"

        if res_intent.upper().strip(' ')=="STATUS":
            ans=get_status(str(res_claim_num))
            ans=ans.split('}')[1]
            print(ans)

        elif res_intent.upper().strip(' ')=="TIME":
            ans=get_proc_time(res_claim_num)
            print(ans)

        elif res_intent.upper().strip(' ')=="ACTION_REASON":
            
            if "denied" in user_message.lower() and "partial" in user_message.lower():

                if context_context=="PAID" or context_context=="ADJUSTED" or context_context=="DENIED":
                    ans="Your claim has no partial denials instead "+get_status(str(res_claim_num)).split('}')[1]
                else:
                    ans=get_denial_reason(res_claim_num)
                    print(ans)
            elif "denied" in user_message.lower():
                if context_context=="PAID" or context_context=="ADJUSTED":
                    ans="Your claim has no denials instead "+get_status(str(res_claim_num)).split('}')[1]
                else:
                    ans=get_denial_reason(res_claim_num)
                    print(ans)
            elif "adjusted" in user_message.lower():
                if context_context=="PAID" or context_context=="PARTIALLY DENIED" or context_context=="DENIED":
                    ans="Your claim has no adjustments instead "+get_status(str(res_claim_num)).split('}')[1]
                else:
                    ans=get_adj_reason(res_claim_num)
            print(ans)

        elif res_intent.upper().strip(' ')=='RESUBMIT':
            ans=get_resubmit_proc()
            print(ans)
        elif res_intent.upper().strip(' ')=="CLAIM_AMOUNT":
            if 'billed' in user_message.lower():
                ans=get_billed_amt(res_claim_num)
            elif 'allowed' in user_message.lower():
                ans=get_allowed_amt(res_claim_num)
            elif 'interest' in user_message.lower():
                ans=get_interest_amt(res_claim_num)
            elif 'paid'  in user_message.lower():
                if context_context=="DENIED":
                   ans= "Your claim is Completely denied and "+get_billed_amt(res_claim_num)
                else:
                    ans=get_paid_amt(res_claim_num)
            elif "denied" in user_message.lower():
                if context_context=="PAID" or context_context=="ADJUSTED":
                    ans="You have no denials for your claim"
                else:
                    ans=get_denied_amt(res_claim_num)
            elif "adjusted" in user_message.lower():
                if context_context=="ADJUSTED":
                    ans=get_adjusted_amt(res_claim_num)
                else:
                    ans="Your claim doesn't have any adjustments"
            print(ans)
        
        elif res_intent.upper().strip(' ')=="CLAIM_DATE":
            if 'service' in user_message.lower():
                ans=get_service_date_of_claim(res_claim_num)
            elif 'received' in user_message.lower():
                ans=get_rcvd_date_of_claim(res_claim_num)            
            elif 'paid'  in user_message.lower():
                if context_context=="DENIED":
                   ans= "Your claim is Completely denied and "+get_dend_date_of_claim(res_claim_num)
                else:
                    ans=get_paid_date_of_claim(res_claim_num)
            elif "denied" in user_message.lower():
                if context_context=="PAID" or context_context=="ADJUSTED":
                    ans="You have no denials for your claim and "+get_paid_date_of_claim(res_claim_num)
                else:
                    ans=get_dend_date_of_claim(res_claim_num)
            elif "adjusted" in user_message.lower():
                if context_context=="ADJUSTED":
                    ans=get_adjstd_date_of_claim(res_claim_num)
                else:
                    ans="Your claim doesn't have any adjustments and "+get_paid_date_of_claim(res_claim_num)
            print(ans)
        elif res_intent.upper().strip(' ')== "CLAIM_LINE_ITEMS":
            ans=get_line_items(res_claim_num)
        elif res_intent.upper().strip(' ')== "TYPE_OF_CLAIM":
            ans=get_type_of_claim(res_claim_num)
        elif res_intent.upper().strip(' ')== "PAR_R_NON_PAR_CLAIM":
            ans=get_par_non_par(res_claim_num)
        elif res_intent.upper().strip(' ')=="NPI_OF_CLAIM":
            ans=get_npi_of_claim(res_claim_num)
        elif res_intent.upper().strip(' ')=="LOB_OF_CLAIM":
            ans=get_lob_of_claim(res_claim_num)
        elif res_intent.upper().strip(' ')== "CLAIM_TAX_ID":
            ans=get_tax_id_claim(res_claim_num)
        elif res_intent.upper().strip(' ')== "CLAIM_DIAG_CODES":
            ans=get_diag_cd_claim(res_claim_num)
        elif res_intent.upper().strip(' ')== "claim_submsn_mode".upper():
            ans=get_mode_submission_claim(res_claim_num)
        else:
            ans="I am not prepare for your question as of now"


        
        print("answer="+ans)
        ## suugestions list to be derived##
        # sugg_list=list()
        # sugg=ans.split('!')
        # print(str(len(sugg)))
        # for si in range(1,len(sugg)):
        #     print(sugg[si])
        #     sugg_list.append(sugg[si])
        ## suugestions list to be derived##

        ## suggestions list to be derived ##

        sugg_list=list()
        if context_claim_r_claims=='CLAIM':
            if context_context=='PAID':
                sugg_list.append("TAT")
                # sugg_list.append("Allowed Amount")
                # sugg_list.append("Interest Amount")            
                # sugg_list.append("Par Or Non-Par Claim")
                # sugg_list.append("Received Date")
                # sugg_list.append("Date Of Service")
                # sugg_list.append("Paid Date")
                # sugg_list.append("Time")
                # sugg_list.append("Tax ID")
                # sugg_list.append("NPI")
                # sugg_list.append("LOB")
                # sugg_list.append("Diagnosis Codes")
                # sugg_list.append("Type Of Claim")
                # sugg_list.append("Line Items Of Claim")              
            elif context_context=='DENIED':
                sugg_list.append("Billed Amount")
                sugg_list.append("Denial Reason")
                sugg_list.append("Resubmit Procedure")
                sugg_list.append("TAT") 
                # sugg_list.append("Allowed Amount")
                # sugg_list.append("Interest Amount")            
                # sugg_list.append("Par Or Non-Par Claim")
                # sugg_list.append("Received Date")
                # sugg_list.append("Date Of Service")
                # sugg_list.append("Paid Date")
                # sugg_list.append("Time")
                # sugg_list.append("Tax ID")
                # sugg_list.append("NPI")
                # sugg_list.append("LOB")
                # sugg_list.append("Diagnosis Codes")
                # sugg_list.append("Type Of Claim")
                # sugg_list.append("Line Items Of Claim")              
            elif context_context=="PARTIALLY DENIED":
                sugg_list.append("TAT")
                sugg_list.append("Billed Amount")
                sugg_list.append("Paid Amount")
                sugg_list.append("Denial Amount")
                sugg_list.append("Denial Reason")
                sugg_list.append("Resubmit Procedure")   
                # sugg_list.append("Allowed Amount")
                # sugg_list.append("Interest Amount")            
                # sugg_list.append("Par Or Non-Par Claim")
                # sugg_list.append("Received Date")
                # sugg_list.append("Date Of Service")
                # sugg_list.append("Paid Date")
                # sugg_list.append("Time")
                # sugg_list.append("Tax ID")
                # sugg_list.append("NPI")
                # sugg_list.append("LOB")
                # sugg_list.append("Diagnosis Codes")
                # sugg_list.append("Type Of Claim")
                # sugg_list.append("Line Items Of Claim")                  
            elif context_context=="ADJUSTED":
                sugg_list.append("TAT")
                sugg_list.append("Billed Amount")
                sugg_list.append("Paid Amount")
                sugg_list.append("Adjusted Amount")
                sugg_list.append("Adjusments Reason")            
                # sugg_list.append("Allowed Amount")
                # sugg_list.append("Interest Amount")            
                # sugg_list.append("Par Or Non-Par Claim")
                # sugg_list.append("Received Date")
                # sugg_list.append("Date Of Service")
                # sugg_list.append("Paid Date")
                # sugg_list.append("Time")
                # sugg_list.append("Tax ID")
                # sugg_list.append("NPI")
                # sugg_list.append("LOB")
                # sugg_list.append("Diagnosis Codes")
                # sugg_list.append("Type Of Claim")
                # sugg_list.append("Line Items Of Claim")

        # elif context_claim_r_claims=='CLAIMS':
            
            # if 'claims' not in user_message.lower():
            #     user_message=user_message+" towards claims"

        ## suugestions static##

        # sugg_list=list()
        # sugg_list.append("Billed Amount")
        # sugg_list.append("Allowed Amount")
        # sugg_list.append("Interest Amount")
        # sugg_list.append("Billed Amount")
        # sugg_list.append("Par Or Non-Par Claim")
        # sugg_list.append("Received Date")
        # sugg_list.append("Date Of Service")
        # sugg_list.append("Paid Date")
        # sugg_list.append("Time")
        # sugg_list.append("Tax ID")
        # sugg_list.append("NPI")
        # sugg_list.append("LOB")
        # sugg_list.append("Diagnosis Codes")
        # sugg_list.append("Type Of Claim")
        # sugg_list.append("Line Items Of Claim")
        # sugg_list.append("Adjustment Reason")
        # sugg_list.append("Denial Reason")
        # sugg_list.append("Resubmit")

        ## suugestions static##

        ans=ans.split('!')[0]
        ###### context history push call #######   
        print(context_uid,context_sessid,context_type_of_req,context_claim_r_claims,context_context,context_claim_num,context_from,context_to,context_days,context_months,context_years)     
        push_context_hist(context_uid,context_sessid,context_type_of_req,context_claim_r_claims,context_context,context_claim_num,context_from,context_to,context_days,context_months,context_years)
        ###### context history push call #######
        #####conv_history parameters and function call ########
        conv_uid=userid_ang
        conv_sesid=sess_id_ang
        conv_question=res_text
        conv_answer=ans
        conv_intent=res_intent
        conv_int_conf=res_intent_confidence
        conv_like_r_dislike="default"
        conv_obj_id=conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
        #####conv_history parameters and function call ########
        print(conv_uid)
        print(conv_sesid)
        print(conv_question)
        print(conv_answer)
        print(conv_intent)
        print(conv_int_conf)
        print(conv_like_r_dislike)
        return jsonify({"response":conv_answer,"object_id":conv_obj_id,"Suggestions":sugg_list})
    except Exception as e:
    # else:
        print(e)
        return jsonify({"response":"Sorry I am not trained to do that yet..."})   


app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(host='apsrp03693',port=5050,debug=True)