##dict of response for each type of intent
# from autocorrect import spell

##########
claim_numbers_req=list()
##########

def claim_num_extract(s1):
    claim_num=0    
    if claim_num==0:
        text=s1
        s2=text.split(' ')
        for i in range(0,len(s2)):            
            n=""
            for j in range(0,len(s2[i])):                    
                    try:
                        n1=int(s2[i][j])
                        n=n+str(n1)
                    except:
                        w=1
            if len(str(n)) > 4 and int(str(n)) > 0:
                claim_num=s2[i]
                claim_numbers_req.append(claim_num)
                return claim_num
    # claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    return claim_num

def corrected_ip_string_1(s1,context_claim_r_claims):
    print("corrected_ip_string")
    try:
        if context_claim_r_claims.upper()=="CLAIM":
            s1=s1.replace('  ',' ').replace('  ',' ').strip(' ')
            s2=s1.split(' ')
            s3=""
            for i in range(0,len(s2)):
                
                if s2[i].lower() in ["tat"]:
                    s3=s3+" "+"time".lower()+" "
                elif s2[i].lower() in ["tin"]:
                    s3=s3+" "+"tax id".lower()+" "
                elif s2[i].lower() in ["dos"]:
                    s3=s3+" "+"date of service".lower()+" "
                elif s2[i].lower() in ["participant","participate","participating"]:
                    s3=s3+" "+"par".lower()+" "
                elif s2[i].lower() in ["non-participant","non-participate","non-participating"]:
                    s3=s3+" "+"non par".lower()+" "
                elif s2[i].lower() in ["network","n/w"]:
                    s3=s3+" "+"par".lower()+" "
                elif s2[i].lower() in ["prov","provide","provider","provided","providing","provides","providers"]:
                    s3=s3+" "+"provider".lower()+" "
                elif s2[i].lower() in ["advoc","advocate","advocates","advocating"]:
                    s3=s3+" "+"provider".lower()+" "
                elif s2[i].lower() in ["national","nation","ntnl"]:
                    s3=s3+" "+"national".lower()+" "                
                elif s2[i].lower() in ["claims"]:
                    s3=s3+" "+"claim".lower()+" "
                elif s2[i].lower() in ["claim","lob","non","par","npi","non-par"]:
                    s3=s3+" "+str(s2[i]).lower()+" "
                elif str(s2[i]).lower() in ["details","detail","condition","position","place","situation","stage","about","status"]:
                    s3=s3+" "+"status".lower()+" "
                elif str(s2[i]).lower() in ["deny","denied","denial","denials","denying","denies","decline","declines","declined","declination","declining","declinations","reject","rejects","rejected","rejecting","rejection","rejections","refuse","refused","refusals","refusal","refusing","refuses","repudiate","repudiates","repudiated","repudiation","repudiations","repudiating","rebuff","rebuffs","rebuffed","rebuffing","dismiss","dismissed","dismisses","dismissing","veto","vetoed","vetoing","vetoes","refute","refutes","refuted","refuting","refutation","rebuff","rebuffs","rebuffed","rebuffing"]:
                    s3=s3+" "+"denied".lower()+" "
                elif str(s2[i]).lower() in ['partially','partial','incomplete','incompletely','partials','uncompleted']:
                    s3=s3+" "+"partial".lower()+" "
                elif str(s2[i]).lower() in ['adjust','adjusting','adjusted','adjustment','adjustments','adjusts']:
                    s3=s3+" "+"adjusted".lower()+" "
                elif str(s2[i]).lower() in ['completely','complete','totally','total','completes','totals']:
                    s3=s3+" "+"complete".lower()+" "
                elif str(s2[i]).lower().replace('-','') in ['resubmit','resubmits','resubmitted','resubmitting','resubmission']:
                    s3=s3+" "+"resubmit".lower()+" "
                elif str(s2[i]).lower().replace('-','') in ['submit','submits','submitted','submitting','submission']:
                    s3=s3+" "+"submitted".lower()+" "
                elif str(s2[i]).lower() in ['justification','explanation','rationalization','vindication','clarification','simplification','description','elucidation','exposition','explication','delineation']:
                    # s3=s3+" "+"justification".lower()+" "
                    s3=s3+" "+"justified".lower()+" "
                elif str(s2[i]).lower() in ['justified','explained','rationalized','vindicated','clarified','simplified','described','elucidated','exposited','explicated','delineated']:
                    s3=s3+" "+"justified".lower()+" "
                elif str(s2[i]).lower() in ['amount','money','cash','buck','bucks','capital']:
                    s3=s3+" "+"amount".lower()+" "
                elif str(s2[i]).lower() in ['reason','cause','root','basis']:
                    s3=s3+" "+"reason".lower()+" "
                elif str(s2[i]).lower() in ['reasons','causes']:
                    s3=s3+" "+"reason".lower()+" "
                elif str(s2[i]).lower() in ['paid','pay','pays','paying','payment','compensating','compensated','compensates','compensate','indemnifying','indemnifies','indemnify','indemnified','refund','refunds','refunded','refunding','remunerate','remunerated','remunerates','remunerating','recompensed','recompense','recompensing','recompenses','reimburse','reimburses','reimbursing','reimbursed','repaid','repay','repays','repaying','repayment']:
                    s3=s3+" "+"paid".lower()+" "
                elif str(s2[i]).lower() in ['period','duration','span','term','days','long','time','times']:
                    s3=s3+" "+"time".lower()+" "
                elif str(s2[i]).lower() in ['process','processing','processed','processes']:
                    s3=s3+" "+"process".lower()+" "
                elif str(s2[i]).lower() in ['bill','bills','billed','billing']:
                    s3=s3+" "+"billed".lower()+" "
                elif str(s2[i]).lower() in ['allow','allows','allowed','allowing']:
                    s3=s3+" "+"allowed".lower()+" "
                elif str(s2[i]).lower() in ['interest','interests','interested','interesting']:
                    s3=s3+" "+"interest".lower()+" "
                elif str(s2[i]).lower() in ['diagnose','diagnosis','diag']:
                    s3=s3+" "+"diagnosis".lower()+" "
                elif str(s2[i]).lower() in ['code','codes','coded','coding']:
                    s3=s3+" "+"codes".lower()+" "
                elif str(s2[i]).lower() in ['line','lines','lined','lining']:
                    s3=s3+" "+"line".lower()+" "
                elif str(s2[i]).lower() in ['item','items']:
                    s3=s3+" "+"items".lower()+" "
                elif str(s2[i]).lower() in ['service','services','serviced','servicing',"svc","svcs","svcing"]:
                    s3=s3+" "+"service".lower()+" "
                elif str(s2[i]).lower() in ['tax','taxation','taxes','taxing','taxed']:
                    s3=s3+" "+"tax".lower()+" "
                elif str(s2[i]).lower() in ['action','actions']:
                    s3=s3+" "+"tax".lower()+" "
                elif str(s2[i]).lower() in ["adjudicated","adjudicate","adjudication","adjudicates","adjudicating"]:
                    s3=s3+" "+"adjudicated".lower()+" "
                elif str(s2[i]).lower() in ['type','types','category','categories','kind','kinds','sort','breed','breeds','form','forms','group','groups','variety','varieties','classify','classification','classifying','classified']:
                    s3=s3+" "+"type".lower()+" "
                elif str(s2[i]).lower() in ['mode','approach','form','mechanism','technique','course','modes','approaches','forms','mechanisms','techniques','courses']:
                    s3=s3+" "+"mode".lower()+" "
                elif str(s2[i]).lower() in ['top','main','major','prime','vital','primary','preeminent','crucial','dominant','chief','head','first','lead']:
                    s3=s3+" "+"top".lower()+" "
                elif str(s2[i]).lower() in ['count','number','sum','whole','reckon','figure','enumerate','add']:
                    s3=s3+" "+"count".lower()+" "
                elif str(s2[i]).lower() in ['receipt','receive','received','receiving','receives','receiving','collect','collects','collected','collecting','gather','gathers','gathering','gathered']:
                    s3=s3+" "+"received".lower()+" "
                elif str(s2[i]).lower() in ['hgh','high','higher','highest']:
                    s3=s3+" "+"high".lower()+" "
                elif str(s2[i]).lower() in ['dlr','dllr','dollar','dollars','dlrs','dllrs']:
                    s3=s3+" "+"dollar".lower()+" "
                elif str(s2[i]).lower() in ['id','identifier']:
                    s3=s3+" "+"id".lower()+" "
                elif str(s2[i]).lower() in ['icd-10','icd']:
                    s3=s3+" "+"diag codes".lower()+" "
                elif str(s2[i]).lower() in ['turn','around','time','high','dollar','claims','claim']:
                    s3=s3+" "+str(s2[i]).lower()+" "
                else:
                    s3=s3+" "+str(s2[i]).lower()+" "
                
            s3=s3.replace('  ',' ').replace('  ',' ').strip(' ').replace('turn','').replace('around','').replace('non par','non-par')
            ent_list=['diagnosis','codes','line','items','tax','id','lob','NPI','par','non-par','type','facility','professional']
            cntxt_replace_ind=0
            for s in s3.split(' '):
                if s in ent_list:
                    cntxt_replace_ind=1
            if cntxt_replace_ind==1:
                s3=s3.replace('denied','').replace('partial','').strip(' ').replace('adjusted','').replace('high',' ').replace('dollar',' ')
                s3=s3.replace('  ',' ').replace('  ',' ')
            if "line" in s3.lower() and "business" in s3.lower():
                s3=s3.replace('line','').replace('business','lob').strip(' ')
                s3=s3.replace('  ',' ').replace('  ',' ')
            if "national" in s3.lower() and "provider" in s3.lower() and "id" in s3.lower():
                s3=s3.replace('national','').replace('provider','npi').strip(' ').replace('id',' ')
                s3=s3.replace('  ',' ').replace('  ',' ')
            if "taxpayer" in s3.lower() and "identification" in s3.lower() and "number" in s3.lower():
                s3=s3.replace('taxpayer','').replace('identification','tax id').strip(' ').replace('number',' ')
                s3=s3.replace('  ',' ').replace('  ',' ')
            return s3
        elif context_claim_r_claims.upper()=="CLAIMS":
            s1=s1.replace('  ',' ').replace('  ',' ').strip(' ')
            s2=s1.split(' ')
            s3=""
            for i in range(0,len(s2)):
                
                if s2[i].lower() in ["tat"]:
                    s3=s3+" "+"time".lower()+" "
                elif s2[i].lower() in ["tin"]:
                    s3=s3+" "+"tax id".lower()+" "
                elif s2[i].lower() in ["dos"]:
                    s3=s3+" "+"date of service".lower()+" "
                elif s2[i].lower() in ["participant","participate","participating"]:
                    s3=s3+" "+"par".lower()+" "
                elif s2[i].lower() in ["non-participant","non-participate","non-participating"]:
                    s3=s3+" "+"non par".lower()+" "
                elif s2[i].lower() in ["network","n/w"]:
                    s3=s3+" "+"par".lower()+" "
                elif s2[i].lower() in ["prov","provide","provider","provided","providing","provides","providers"]:
                    s3=s3+" "+"provider".lower()+" "
                elif s2[i].lower() in ["advoc","advocate","advocates","advocating"]:
                    s3=s3+" "+"provider".lower()+" "
                elif s2[i].lower() in ["national","nation","ntnl"]:
                    s3=s3+" "+"national".lower()+" "
                elif s2[i].lower() in ["claim"]:
                    s3=s3+" "+"claims".lower()+" "
                elif s2[i].lower() in ["claims","lob","non","par","npi","non-par"]:
                    s3=s3+" "+str(s2[i]).lower()+" "
                elif str(s2[i]).lower() in ["details","detail","condition","position","place","situation","stage","about","status"]:
                    s3=s3+" "+"status".lower()+" "
                elif str(s2[i]).lower() in ["adjudicated","adjudicate","adjudication","adjudicates","adjudicating"]:
                    s3=s3+" "+"adjudicated".lower()+" "
                elif str(s2[i]).lower() in ["deny","denied","denial","denials","denying","denies","decline","declines","declined","declination","declining","declinations","reject","rejects","rejected","rejecting","rejection","rejections","refuse","refused","refusals","refusal","refusing","refuses","repudiate","repudiates","repudiated","repudiation","repudiations","repudiating","rebuff","rebuffs","rebuffed","rebuffing","dismiss","dismissed","dismisses","dismissing","veto","vetoed","vetoing","vetoes","refute","refutes","refuted","refuting","refutation","rebuff","rebuffs","rebuffed","rebuffing"]:
                    s3=s3+" "+"denied".lower()+" "
                elif str(s2[i]).lower() in ['partially','partial','incomplete','incompletely','partials','uncompleted']:
                    s3=s3+" "+"partial".lower()+" "
                elif str(s2[i]).lower() in ['adjust','adjusting','adjusted','adjustment','adjustments','adjusts']:
                    s3=s3+" "+"adjusted".lower()+" "
                elif str(s2[i]).lower() in ['completely','complete','totally','total','completes','totals']:
                    s3=s3+" "+"complete".lower()+" "
                elif str(s2[i]).lower().replace('-','') in ['resubmit','resubmits','resubmitted','resubmitting','resubmission']:
                    s3=s3+" "+"resubmit".lower()+" "
                elif str(s2[i]).lower().replace('-','') in ['submit','submits','submitted','submitting','submission']:
                    s3=s3+" "+"submitted".lower()+" "
                elif str(s2[i]).lower() in ['justification','explanation','rationalization','vindication','clarification','simplification','description','elucidation','exposition','explication','delineation']:
                    # s3=s3+" "+"justification".lower()+" "
                    s3=s3+" "+"justified".lower()+" "
                elif str(s2[i]).lower() in ['justified','explained','rationalized','vindicated','clarified','simplified','described','elucidated','exposited','explicated','delineated']:
                    s3=s3+" "+"justified".lower()+" "
                elif str(s2[i]).lower() in ['amount','money','cash','buck','bucks','capital']:
                    s3=s3+" "+"amount".lower()+" "
                elif str(s2[i]).lower() in ['reason','cause','root','basis']:
                    s3=s3+" "+"reasons".lower()+" "
                elif str(s2[i]).lower() in ['reasons','causes']:
                    s3=s3+" "+"reasons".lower()+" "
                elif str(s2[i]).lower() in ['paid','pay','pays','paying','payment','compensating','compensated','compensates','compensate','indemnifying','indemnifies','indemnify','indemnified','refund','refunds','refunded','refunding','remunerate','remunerated','remunerates','remunerating','recompensed','recompense','recompensing','recompenses','reimburse','reimburses','reimbursing','reimbursed','repaid','repay','repays','repaying','repayment']:
                    s3=s3+" "+"paid".lower()+" "
                elif str(s2[i]).lower() in ['period','duration','span','term','days','long','time','times']:
                    s3=s3+" "+"time".lower()+" "
                elif str(s2[i]).lower() in ['process','processing','processed','processes']:
                    s3=s3+" "+"process".lower()+" "
                elif str(s2[i]).lower() in ['bill','bills','billed','billing']:
                    s3=s3+" "+"billed".lower()+" "
                elif str(s2[i]).lower() in ['allow','allows','allowed','allowing']:
                    s3=s3+" "+"allowed".lower()+" "
                elif str(s2[i]).lower() in ['interest','interests','interested','interesting']:
                    s3=s3+" "+"interest".lower()+" "
                elif str(s2[i]).lower() in ['diagnose','diagnosis','diag']:
                    s3=s3+" "+"diagnosis".lower()+" "
                elif str(s2[i]).lower() in ['code','codes','coded','coding']:
                    s3=s3+" "+"codes".lower()+" "
                elif str(s2[i]).lower() in ['line','lines','lined','lining']:
                    s3=s3+" "+"line".lower()+" "
                elif str(s2[i]).lower() in ['item','items']:
                    s3=s3+" "+"items".lower()+" "
                elif str(s2[i]).lower() in ['service','services','serviced','servicing','svc']:
                    s3=s3+" "+"service".lower()+" "
                elif str(s2[i]).lower() in ['tax','taxation','taxes','taxing','taxed']:
                    s3=s3+" "+"tax".lower()+" "
                elif str(s2[i]).lower() in ['action','actions']:
                    s3=s3+" "+"tax".lower()+" "
                elif str(s2[i]).lower() in ['type','types','category','categories','kind','kinds','sort','breed','breeds','form','forms','group','groups','variety','varieties','classify','classification','classifying','classified']:
                    s3=s3+" "+"type".lower()+" "
                elif str(s2[i]).lower() in ['mode','approach','form','mechanism','technique','course','modes','approaches','forms','mechanisms','techniques','courses']:
                    s3=s3+" "+"mode".lower()+" "
                elif str(s2[i]).lower() in ['top','main','major','prime','vital','primary','preeminent','crucial','dominant','chief','head','first','lead']:
                    s3=s3+" "+"top".lower()+" "
                elif str(s2[i]).lower() in ['count','number','sum','whole','reckon','figure','enumerate','add']:
                    s3=s3+" "+"count".lower()+" "
                elif str(s2[i]).lower() in ['receipt','receive','received','receiving','receives','receiving','collect','collects','collected','collecting','gather','gathers','gathering','gathered']:
                    s3=s3+" "+"received".lower()+" "
                elif str(s2[i]).lower() in ['hgh','high','higher','highest']:
                    s3=s3+" "+"high".lower()+" "
                elif str(s2[i]).lower() in ['dlr','dllr','dollar','dollars','dlrs','dllrs']:
                    s3=s3+" "+"dollar".lower()+" "
                elif str(s2[i]).lower() in ['id','identifier']:
                    s3=s3+" "+"id".lower()+" "
                elif str(s2[i]).lower() in ['icd-10','icd']:
                    s3=s3+" "+"diag codes".lower()+" "
                elif str(s2[i]).lower() in ['turn','around','time','high','dollar','claims','claim']:
                    s3=s3+" "+str(s2[i]).lower()+" "
                else:
                    s3=s3+" "+str(s2[i]).lower()+" "
                
            s3=s3.replace('  ',' ').replace('  ',' ').strip(' ').replace('turn','').replace('around','').replace('non par','non-par')
            ent_list=['diagnosis','codes','line','items','tax','id','lob','NPI','par','non-par','type','facility','professional']
            cntxt_replace_ind=0
            for s in s3.split(' '):
                if s in ent_list:
                    cntxt_replace_ind=1
            if cntxt_replace_ind==1:
                s3=s3.replace('denied','').replace('partial','').strip(' ').replace('adjusted','').replace('high','').replace('dollar','').replace('received','')
                s3=s3.replace('  ',' ').replace('  ',' ')
            if "national" in s3.lower() and "provider" in s3.lower() and "id" in s3.lower():
                s3=s3.replace('national','').replace('provider','npi').strip(' ').replace('id',' ')
                s3=s3.replace('  ',' ').replace('  ',' ')
            if "taxpayer" in s3.lower() and "identification" in s3.lower() and "number" in s3.lower():
                s3=s3.replace('taxpayer','').replace('identification','tax id').strip(' ').replace('number',' ')
                s3=s3.replace('  ',' ').replace('  ',' ')
            return s3
    except:
        print("error in correcting string")


# print(claim_num_extract("what is 12dfs2323"))
# print(corrected_ip_string_1("what is status"))