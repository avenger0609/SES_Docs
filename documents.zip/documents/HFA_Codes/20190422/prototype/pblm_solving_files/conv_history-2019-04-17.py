from pymongo import MongoClient
import pymongo
from datetime import datetime
def conv_hist(userid,sess_id,quest,resp,intnt,conf,like_r_dislke):
    myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
    print(myclient.list_database_names())
    mydb = myclient["HandsFreeAnalytics"]
    print(mydb.list_collection_names())
    mycol = mydb["Conversation_History"]
    dt=str(datetime.now()).replace(' ','').replace('-','').replace(':','')
    mydict = { "User_ID": userid, "Session_ID": sess_id,"question":quest,"response":resp,"Intent":intnt,"Confidence":conf,"like_r_dislike":like_r_dislke,"creation_dt":dt}
    x = mycol.insert_one(mydict)
    return str(x.inserted_id)
    
