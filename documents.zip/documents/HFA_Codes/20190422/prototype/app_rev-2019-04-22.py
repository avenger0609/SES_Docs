from flask import Flask
from flask import render_template,jsonify,request
import requests
from models import *
from pblm_solving_files.knowledge_rev import *
from pblm_solving_files.duckling_wrapper import *
from pblm_solving_files.conv_history import *
from pblm_solving_files.uid_sessid_storing import *
from pblm_solving_files.mongodb_interaction import *
import random
import urllib3
from flask_cors import CORS



app = Flask(__name__)
app.secret_key = '12345'
CORS(app)

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route("/parse", methods=['GET', 'POST', 'OPTIONS'])
def parse():

    try:
        # print((request.url))
        parsed=(urllib3.util.url.parse_url(request.url))
        print(str(parsed.query))
        s1=str(str(parsed.query).split('&')[0].split('=')[1].replace('+',' ')) # first query
        uid_gen=1
        sessid_gen=1
        userid=""
        sess_id=""
        userid_ang="DEFAULT"
        sess_id_ang="DEFAULT"
        try:
            userid_ang=str(str(parsed.query).split('&')[1].split('=')[1].replace('+',' ')) # second query
        except:
            uid_gen=0
        try:
            sess_id_ang=str(str(parsed.query).split('&')[2].split('=')[1].replace('+',' ')) # second query
        except:
            sessid_gen=0
        if uid_gen==1 and sessid_gen==1:
            uid_sessid(userid_ang,sess_id_ang)
        while True:
            a=s1.find("%")
            if a > -1:
                ss=s1[a]+s1[a+1]+s1[a+2]
                s1=s1.replace(ss," ")
            else:
                break
        s1=s1.replace('  ',' ').replace('  ',' ').strip(' ').lower()
        print(s1)
        user_message = s1
        um1=user_message

        #days,months,years extracted to be returned
        dmy_lst=time_extract(um1)
        dte_text_lst=list()
        if len(dmy_lst)==3:
            res_from=str(dmy_lst[0].split(' ')[0]).split('-')[1]+"/"+str(dmy_lst[0].split(' ')[0]).split('-')[2]+"/"+str(dmy_lst[0].split(' ')[0]).split('-')[0]
            res_to=str(dmy_lst[1].split(' ')[0]).split('-')[1]+"/"+str(dmy_lst[1].split(' ')[0]).split('-')[2]+"/"+str(dmy_lst[1].split(' ')[0]).split('-')[0]
            dte_text_lst=dmy_lst[2]
            res_days=""
            res_months=""
            res_years=""
        elif len(dmy_lst)==4:
            res_from=""
            res_to=""
            res_days=str(dmy_lst[0])
            res_months=str(dmy_lst[1])
            res_years=str(dmy_lst[2])
            dte_text_lst=dmy_lst[3]
        else:
            res_from=""
            res_to=""
            res_days=""
            res_months=""
            res_years=""
        for dte_i in dte_text_lst:
            user_message=user_message.replace(" "+dte_i+" "," ")
        #days,months,years extracted to be returned

        user_message=corrected_ip_string_1(user_message)
        user_message=corrected_ip_string_1(user_message.replace('-',' '))
        user_message=str(user_message).strip(' ').lower()           
        response = requests.get("http://apsrp03693:5000/parse",params={"q":user_message})                
        response = response.json()
        # response["text"]=um1

        # response text to be returned
        res_text=um1
        # response text to be returned

        # intent to be returned
        intent = response.get("intent")
        res_intent=intent['name']
        res_intent_confidence=intent['confidence']
        # intent to be returned
        # entities=response.get("entities")                
        if res_intent in ["status","time","action_reason","resubmit","adj_amount"]:
            # claim number and entities to be returned            
            claim_num=0        
            if claim_num==0:
                claim_num=claim_num_extract(um1)
            res_claim_num=claim_num
            # claim number and entities to be returned
            if res_intent in ["action_reason"]:
                if "denied" in user_message:
                    res_intent="action_reason-denial_reason"
                elif "adjust" in user_message:
                    res_intent="action_reason-adjusted_reason"
            if res_intent in ["adj_amount"]:
                if " paid " in user_message:
                    res_intent="adj_amount-paid"        
        else:
            res_claim_num=""
        ans="Unanswered"
        if res_intent.upper().strip(' ')=="STATUS":
            ans=get_status(str(res_claim_num))
            ans=ans.split('}')[1]
            print(ans)
        elif res_intent.upper().strip(' ')=="TIME":
            ans=get_proc_time(res_claim_num)
            print(ans)
        elif res_intent.upper().strip(' ')=='ACTION_REASON-DENIAL_REASON':
            ans=get_denial_reason(res_claim_num)
            print(ans)
        elif res_intent.upper().strip(' ')=='ACTION_REASON-ADJUSTED_REASON':
            ans=get_adj_reason(res_claim_num)
            print(ans)
        elif res_intent.upper().strip(' ')=='RESUBMIT':
            ans=get_resubmit_proc()
            print(ans)
        elif res_intent.upper().strip(' ')=='ADJ_AMOUNT-PAID':
            ans=get_paid_amt(res_claim_num)
            print(ans)
        elif res_intent.upper().strip(' ')=='ADJ_AMOUNT':
            ans=get_adjusted_amt(res_claim_num)
            print(ans)
        
        print("answer="+ans)
        ## suugestions list to be derived##
        # sugg_list=list()
        # sugg=ans.split('!')
        # print(str(len(sugg)))
        # for si in range(1,len(sugg)):
        #     print(sugg[si])
        #     sugg_list.append(sugg[si])
        ## suugestions list to be derived##

        ## suugestions static##
        sugg_list=list()
        sugg_list.append("Billed Amount")
        sugg_list.append("Allowed Amount")
        sugg_list.append("Interest Amount")
        sugg_list.append("Billed Amount")
        sugg_list.append("Par Or Non-Par Claim")
        sugg_list.append("Received Date")
        sugg_list.append("Date Of Service")
        sugg_list.append("Paid Date")
        sugg_list.append("Time")
        sugg_list.append("Tax ID")
        sugg_list.append("NPI")
        sugg_list.append("LOB")
        sugg_list.append("Diagnosis Codes")
        sugg_list.append("Type Of Claim")
        sugg_list.append("Line Items Of Claim")
        sugg_list.append("Adjustment Reason")
        sugg_list.append("Denial Reason")
        sugg_list.append("Resubmit")

        ## suugestions static##

        ans=ans.split('!')[0]
        #####conv_history parameters and function call ########
        conv_uid=userid_ang
        conv_sesid=sess_id_ang
        conv_question=res_text
        conv_answer=ans
        conv_intent=res_intent
        conv_int_conf=res_intent_confidence
        conv_like_r_dislike="default"
        conv_obj_id=conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
        #####conv_history parameters and function call ########
        print(conv_uid)
        print(conv_sesid)
        print(conv_question)
        print(conv_answer)
        print(conv_intent)
        print(conv_int_conf)
        print(conv_like_r_dislike)
        return jsonify({"response":conv_answer,"object_id":conv_obj_id,"Suggestions":sugg_list})
    except Exception as e:
        print(e)
        return jsonify({"response":"Sorry I am not trained to do that yet..."})   

app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(host='apsrp03693',port=5050,debug=True)