import pymongo
import datetime
import calendar
import ast
import random
from pblm_solving_files.duckling_wrapper import *
from pblm_solving_files.knowledge_rev import *
import requests

def main_fun(userid,sessid,req,prov_lst):
    dur_lst=list()
    dur_lst=time_extract(req)
    s1=corrected_ip_string_1(req,'claims')
    response = requests.get("http://apsrp03693:5088/parse",params={"q":s1})                
    response = response.json()
    intent = response.get("intent")
    intnt1=intent['name']   
    print(intnt1) 
    if intnt1.lower()=='claims_count':
        if 'received' in s1:
            intnt="rcvd_claim_vol_trend"
        elif 'paid' in s1:
            intnt="paid_claim_vol_trend"
    if intnt=="rcvd_claim_vol_trend":
        return get_rcvd_claim_vol_trend(dur_lst,prov_lst)
    elif intnt=="paid_claim_vol_trend":
        print(get_paid_claim_vol_trend(dur_lst,prov_lst))
        
def mon_name(tt):

    tt=str(int(tt))
    if tt=='1':
        return 'Jan'
    elif tt=='2':
        return 'Feb'
    elif tt=='3':
        return 'Mar'
    elif tt=='4':
        return 'Apr'
    elif tt=='5':
        return 'May'
    elif tt=='6':
        return 'Jun'
    elif tt=='7':
        return 'Jul'
    elif tt=='8':
        return 'Aug'
    elif tt=='9':
        return 'Sep'
    elif tt=='10':
        return 'Oct'
    elif tt=='11':
        return 'Nov'
    elif tt=='12':
        return 'Dec'
    return "None"

def get_rcvd_claim_vol_trend(dur_lst,provider_lst):

    try:
        cond=""
        n_records="0"
        myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")        
        mydb = myclient["HandsFreeAnalytics"]        
        mycol = mydb["hfa_claims_1819"] 
        key_lst=list()
        val_lst=list()
        r_from_dt=""
        r_end_dt=""
        r_graph_type="line"
        if len(dur_lst)==3:
            r_from_dt=dur_lst[0]
            r_end_dt=dur_lst[1]
            print(dur_lst)
            strt_lst=list()            
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[0])
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[1])
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[2])
            end_lst=list()            
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[0])
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[1])
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[2])            
            yr_strt=int(str(strt_lst[0]))
            yr_end=int(str(end_lst[0]))
            mon_strt=int(str(strt_lst[1]))
            mon_end=int(str(end_lst[1]))
            while True:
                mon_frmt=""
                if mon_strt < 10:
                    mon_frmt='0'+str(mon_strt)
                else:
                    mon_frmt=str(mon_strt)
                cond=cond+"{'received_date':{'$regex':'.*-"+str(mon_frmt)+"-.*'}}"
                cond=cond+",{'received_date':{'$regex':'"+str(yr_strt)+"-.*-.*'}}"
                if len(provider_lst) > 0:
                    pc=",{'payto_provider_tax_id':{'$in':"+str(provider_lst)+"}}"
                    cond="{'$and':["+cond+pc+"]}"
                else:
                    cond="{'$and':["+cond+"]}"
                print(cond)
                my_dict = ast.literal_eval(cond)                    
                mydoc = mycol.find(my_dict)
                n_records='0'
                n_records=str(mydoc.count()) 
                print(str(mon_strt))
                key_val=mon_name(mon_strt)+"-"+str(str(yr_strt)[-2:])
                val_val=n_records                
                key_lst.append(key_val)
                val_lst.append(val_val)
                cond=""
                mon_strt=mon_strt+1
                print(type(mon_strt))
                print((mon_strt))
                if (mon_strt) >= 13:
                    mon_strt=1
                    yr_strt=yr_strt+1
                
                if  (mon_strt < mon_end or mon_strt > mon_end) and (yr_strt<=yr_end):
                    bypass=1
                else:
                    break

        elif len(dur_lst) ==4:
            if len(dur_lst[1])==0:
                dur_lst[1]=['01','02','03','04','05','06','07','08','09','10','11','12']
            if len(dur_lst[2])==0:
                dur_lst[2].append(str(datetime.datetime.now().year))
            
            for dl in dur_lst[2]:
                for dl1 in dur_lst[1]:
                    cond=cond+"{'received_date':{'$regex':'.*-"+str(dl1)+"-.*'}}"
                    cond=cond+",{'received_date':{'$regex':'"+str(dl)+"-.*-.*'}}"
                    if len(provider_lst) > 0:
                        pc=",{'payto_provider_tax_id':{'$in':"+str(provider_lst)+"}}"
                        cond="{'$and':["+cond+pc+"]}"
                    else:
                        cond="{'$and':["+cond+"]}"
                    print(cond)
                    my_dict = ast.literal_eval(cond)                    
                    mydoc = mycol.find(my_dict)
                    n_records='0'
                    n_records=str(mydoc.count()) 
                    print(str(dl1))
                    key_val=mon_name(dl1)+"-"+str(dl[-2:])
                    val_val=n_records                
                    key_lst.append(key_val)
                    val_lst.append(val_val)
                    cond=""
        kv="{"
        kv=kv+"'"+str("From")+"'"+":"+"'"+str(r_from_dt)+"'"+","
        kv=kv+"'"+str("End")+"'"+":"+"'"+str(r_end_dt)+"'"+","
        kv=kv+"'"+str("Title")+"'"+":"+"'"+str("Claims Trend (Volume)")+"'"+","
        kv=kv+"'"+str("Graph Type")+"'"+":"+"'"+str("Line")+"'"+","
        kv=kv+"'"+str("Header")+"'"+":"+""+str(key_lst)+""+","
        kv=kv+"'"+str("Value")+"'"+":"+""+str(val_lst)+""+","
        kv=kv[0:len(kv)-1]+"}"
        print(kv)
        kv=ast.literal_eval(kv)
        return kv

    except Exception as e:
        print(str(e))       
        return "Sorry, Could not fetch you results at this time"

def get_paid_claim_vol_trend(dur_lst,provider_lst):

    try:
        cond=""
        n_records="0"
        myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")        
        mydb = myclient["HandsFreeAnalytics"]        
        mycol = mydb["hfa_claims_1819"] 
        key_lst=list()
        val_lst=list()
        if len(dur_lst)==3:
            print(dur_lst)
            strt_lst=list()
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[0])
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[1])
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[2])
            end_lst=list()
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[0])
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[1])
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[2])
            yr_strt=int(str(strt_lst[0]))
            yr_end=int(str(end_lst[0]))
            mon_strt=int(str(strt_lst[1]))
            mon_end=int(str(end_lst[1]))
            while True:
                mon_frmt=""
                if mon_strt < 10:
                    mon_frmt='0'+str(mon_strt)
                else:
                    mon_frmt=str(mon_strt)
                cond=cond+"{'paid_date':{'$regex':'.*-"+str(mon_frmt)+"-.*'}}"
                cond=cond+",{'paid_date':{'$regex':'"+str(yr_strt)+"-.*-.*'}}"
                if len(provider_lst) > 0:
                    pc=",{'payto_provider_tax_id':{'$in':"+str(provider_lst)+"}}"
                    di=",{'claim_denial_ind':'0'}"
                    cond="{'$and':["+cond+pc+di+"]}"
                else:
                    di=",{'claim_denial_ind':'0'}"
                    cond="{'$and':["+cond+di+"]}"
                print(cond)
                my_dict = ast.literal_eval(cond)                    
                mydoc = mycol.find(my_dict)
                n_records='0'
                n_records=str(mydoc.count()) 
                print(str(mon_strt))
                key_val=mon_name(mon_strt)+"-"+str(str(yr_strt)[-2:])
                val_val=n_records                
                key_lst.append(key_val)
                val_lst.append(val_val)
                cond=""
                mon_strt=mon_strt+1
                print(type(mon_strt))
                print((mon_strt))
                if (mon_strt) >= 13:
                    mon_strt=1
                    yr_strt=yr_strt+1
                
                if  (mon_strt < mon_end or mon_strt > mon_end) and (yr_strt<=yr_end):
                    bypass=1
                else:
                    break

        elif len(dur_lst) ==4:
            if len(dur_lst[1])==0:
                dur_lst[1]=['01','02','03','04','05','06','07','08','09','10','11','12']
            if len(dur_lst[2])==0:
                dur_lst[2].append(str(datetime.datetime.now().year))
            
            for dl in dur_lst[2]:
                for dl1 in dur_lst[1]:
                    cond=cond+"{'paid_date':{'$regex':'.*-"+str(dl1)+"-.*'}}"
                    cond=cond+",{'paid_date':{'$regex':'"+str(dl)+"-.*-.*'}}"
                    cond="{'$and':["+cond+"]}"
                    if len(provider_lst) > 0:
                        pc=",{'payto_provider_tax_id':{'$in':"+str(provider_lst)+"}}"
                        di=",{'claim_denial_ind':'0'}"
                        cond="{'$and':["+cond+pc+di+"]}"
                    else:
                        di=",{'claim_denial_ind':'0'}"
                        cond="{'$and':["+cond+di+"]}"
                    print(cond)
                    my_dict = ast.literal_eval(cond)                    
                    mydoc = mycol.find(my_dict)
                    n_records='0'
                    n_records=str(mydoc.count()) 
                    print(str(dl1))
                    key_val=mon_name(dl1)+"-"+str(dl[-2:])
                    val_val=n_records                
                    key_lst.append(key_val)
                    val_lst.append(val_val)
                    cond=""
        kv="{"
        for k in range(0,len(key_lst)):
            kv=kv+"'"+str(key_lst[k])+"'"+":"+"'"+str(val_lst[k])+"'"+","
        kv=kv[0:len(kv)-1]+"}"
        print(kv)
        kv=ast.literal_eval(kv)
        return kv

    except Exception as e:
        print(str(e))       
        return "Sorry, Could not fetch you results at this time"


    try:
        cond=""
        n_records=""
        myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")        
        mydb = myclient["HandsFreeAnalytics"]        
        mycol = mydb["hfa_claims_1819"] 
        key_lst=list()
        val_lst=list()
        if len(dur_lst)==3:
            print(dur_lst)
            strt_lst=list()
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[0])
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[1])
            strt_lst.append(dur_lst[0].split(' ')[0].split('-')[2])
            end_lst=list()
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[0])
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[1])
            end_lst.append(dur_lst[1].split(' ')[0].split('-')[2])
            yr_strt=int(str(strt_lst[0]))
            yr_end=int(str(end_lst[0]))
            mon_strt=int(str(strt_lst[1]))
            mon_end=int(str(end_lst[1]))
            while True:
                mon_frmt=""
                if mon_strt < 10:
                    mon_frmt='0'+str(mon_strt)
                else:
                    mon_frmt=str(mon_strt)
                cond=cond+"{'paid_date':{'$regex':'.*-"+str(mon_frmt)+"-.*'}}"
                cond=cond+",{'paid_date':{'$regex':'"+str(yr_strt)+"-.*-.*'}}"
                if len(provider_lst) > 0:
                    pc=",{'payto_provider_tax_id':{'$in':"+str(provider_lst)+"}}"
                    di=",{'claim_denial_ind':'0'}"
                    cond="{'$and':["+cond+pc+di+"]}"
                else:
                    di=",{'claim_denial_ind':'0'}"
                    cond="{'$and':["+cond+di+"]}"
                print(cond)
                my_dict = ast.literal_eval(cond)  
                pipe = [{'$match':my_dict},{'$group': {'_id':'$claim_receipt_type_cd', 'total': {'$sum': 1}}},{'$sort': {'total':-1}}] ## sum after type conversion of field                              
                mydoc=(mycol.aggregate(pipeline=pipe))
                n_records=""                
                for x in mydoc:
                    print(str(x['_id']+"!"+str(x['total'])))
                    n_records=n_records+"}"+(str(x['_id'].strip(' ')+"!"+str(x['total'])))
                n_records=n_records[1:]
                print(str(mon_strt))
                key_val=mon_name(mon_strt)+"-"+str(str(yr_strt)[-2:])
                val_val=n_records                
                key_lst.append(key_val)
                val_lst.append(val_val)
                cond=""
                mon_strt=mon_strt+1
                print(type(mon_strt))
                print((mon_strt))
                if (mon_strt) >= 13:
                    mon_strt=1
                    yr_strt=yr_strt+1
                
                if  (mon_strt < mon_end or mon_strt > mon_end) and (yr_strt<=yr_end):
                    bypass=1
                else:
                    break

        elif len(dur_lst) ==4:
            if len(dur_lst[1])==0:
                dur_lst[1]=['01','02','03','04','05','06','07','08','09','10','11','12']
            if len(dur_lst[2])==0:
                dur_lst[2].append(str(datetime.datetime.now().year))
            
            for dl in dur_lst[2]:
                for dl1 in dur_lst[1]:
                    cond=cond+"{'paid_date':{'$regex':'.*-"+str(dl1)+"-.*'}}"
                    cond=cond+",{'paid_date':{'$regex':'"+str(dl)+"-.*-.*'}}"
                    
                    if len(provider_lst) > 0:
                        pc=",{'payto_provider_tax_id':{'$in':"+str(provider_lst)+"}}"
                        di=",{'claim_denial_ind':'0'}"
                        cond="{'$and':["+cond+pc+di+"]}"
                    else:
                        di=",{'claim_denial_ind':'0'}"
                        cond="{'$and':["+cond+di+"]}"
                    print(cond)
                    my_dict = ast.literal_eval(cond)  
                    pipe = [{'$match':my_dict},{'$group': {'_id':'$claim_receipt_type_cd', 'total': {'$sum': 1}}},{'$sort': {'total':-1}}] ## sum after type conversion of field                              
                    mydoc=(mycol.aggregate(pipeline=pipe))
                    n_records=""                    
                    for x in mydoc:
                        print(str(x['_id']+"!"+str(x['total'])))
                        n_records=n_records+"}"+(str(x['_id'].strip(' ')+"!"+str(x['total'])))
                    n_records=n_records[1:]
                    print(str(dl1))
                    key_val=mon_name(dl1)+"-"+str(dl[-2:])
                    val_val=n_records                
                    key_lst.append(key_val)
                    val_lst.append(val_val)
                    cond=""
        kv="{"
        for k in range(0,len(key_lst)):
            kv=kv+"'"+str(key_lst[k])+"'"+":"+"'"+str(val_lst[k])+"'"+","
        kv=kv[0:len(kv)-1]+"}"
        print(kv)
        kv=ast.literal_eval(kv)
        return kv

    except Exception as e:
        print(str(e))       
        return "Sorry, Could not fetch you results at this time"


provider_lst1=['111888924','133964321']