import pandas as pd
a = {"column1":['a','d'],
     "column2":['b','e'],
     "column3":['c','f']}
b = {"column1":['g','j'],
     "column2":['h','k'],
     "column3":['i','l']}

c = {"column1":['m','p'],
      "column2":['n','q'],
      "column3":['o','r']}


df1 = pd.DataFrame(a)
df2 = pd.DataFrame(b)
df3 = pd.DataFrame(c)

df_final = pd.concat([df1, df2, df3]) #.reset_index()
print(df_final)