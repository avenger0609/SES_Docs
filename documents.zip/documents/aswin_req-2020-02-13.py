import pandas as pd
import openpyxl
import win32com.client as win32

df=pd.read_csv("C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\bkumar87@corpimsvcs.com\\PVO_Eligible_Certified_Rules_File_20200210.csv",delimiter='|')
df.to_excel('C:\\Users\\asrilekh\\Documents\\output_file.xlsx',index=False)
excel = win32.gencache.EnsureDispatch('Excel.Application')
wb = excel.Workbooks.Add()
## first sheet
f='C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\bkumar87@corpimsvcs.com\\Summary_template.xls'
w = excel.Workbooks.Open(f)
w.Sheets(1).Copy(wb.Sheets(1))
f='C:\\Users\\asrilekh\\Documents\\output_file.xlsx'
w = excel.Workbooks.Open(f)
w.Sheets(1).Copy(wb.Sheets(2))
## first sheet
wb.SaveAs('C:\\Users\\asrilekh\\Documents\\output_file_test.xlsx')
excel.Application.Quit()


