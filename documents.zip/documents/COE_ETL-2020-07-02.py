import pandas as pd
from pymongo import MongoClient
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3
from datetime import datetime
from dateutil.relativedelta import relativedelta

def MongoDbData_Extraction():    
    myclient = MongoClient(u"mongodb://apsrp03693.uhc.com:27017")        
    mydb = myclient["COE_ETL_POC"]        
    mycol = mydb["COE_WOM_US_COVID_DATA"]
    mydoc=mycol.find() #.limit(100)
    print(mydoc)
    df =  pd.DataFrame(list(mydoc))
    df['Source File']='Mongo Collection'
    print(list(df.columns))
    return df

def SQLServer_Extraction():
    params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;Trusted_Connection=yes;')
    engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)        
    sql_string="select dbo.uv_CB_Vetting.RowID,dbo.uv_CB_Vetting.AccountingYearMonth,dbo.uv_CB_Vetting.VolumeYearMonth,dbo.uv_CB_Vetting.DateOfChargeback,dbo.uv_CB_Vetting.DivisionID,dbo.uv_CB_Vetting.ServiceGroup,dbo.uv_CB_Vetting.ServiceGroupCostCenter,dbo.uv_CB_Vetting.ServiceCodeName,dbo.uv_CB_Vetting.ServiceCode,dbo.uv_CB_Vetting.BillCodeName,dbo.uv_CB_Vetting.BillingCode,dbo.uv_CB_Vetting.BillCodeStatus,dbo.uv_CB_Vetting.ServiceUniqueIdentifier,dbo.uv_CB_Vetting.SUIdescription,dbo.uv_CB_Vetting.ServicePhysical,dbo.uv_CB_Vetting.ServiceVirtual,dbo.uv_CB_Vetting.InternalComment,dbo.uv_CB_Vetting.AppName,dbo.uv_CB_Vetting.TMDB_SearchCode,dbo.uv_CB_Vetting.Published,dbo.uv_CB_Vetting.ProjectNumber,dbo.uv_CB_Vetting.Project_Name,dbo.uv_CB_Vetting.Project_Manager,dbo.uv_CB_Vetting.ServiceRequestNumber,dbo.uv_CB_Vetting.ServiceDeliveryDate,dbo.uv_CB_Vetting.CustomerAcceptance,dbo.uv_CB_Vetting.BusinessSegmentName,dbo.uv_CB_Vetting.GL_BU,dbo.uv_CB_Vetting.GL_OU,dbo.uv_CB_Vetting.GL_LOC,dbo.uv_CB_Vetting.GL_ACCT,dbo.uv_CB_Vetting.GL_DEPT,dbo.uv_CB_Vetting.ConsumingServiceGroup,dbo.uv_CB_Vetting.GL_PROD,dbo.uv_CB_Vetting.GL_CUST,dbo.uv_CB_Vetting.GL_PID,dbo.uv_CB_Vetting.UnadjustedUnits,dbo.uv_CB_Vetting.AdjustedUnits,dbo.uv_CB_Vetting.UnadjustedStorage,dbo.uv_CB_Vetting.AdjustedStorage,dbo.uv_CB_Vetting.AdjSanOrAdjStorage,dbo.uv_CB_Vetting.San_Cost,dbo.uv_CB_Vetting.BaseService_Cost,dbo.uv_CB_Vetting.ProdNonProd,dbo.uv_CB_Vetting.EnvironmentCode,dbo.uv_CB_Vetting.DataCenterCode,dbo.uv_CB_Vetting.DRMates,dbo.uv_CB_Vetting.DRCode,dbo.uv_CB_Vetting.NetworkZone,dbo.uv_CB_Vetting.ChangeReason,dbo.uv_CB_Vetting.Requestor,dbo.uv_CB_Vetting.Description,dbo.uv_CB_Vetting.RequestorEmail,dbo.uv_CB_Vetting.CreateDate,dbo.uv_CB_Vetting.RequestType,dbo.uv_CB_Vetting.ParentRequestID,dbo.uv_CB_Vetting.ParentRequestor,dbo.uv_CB_Vetting.ParentRequestorEmail,dbo.uv_CB_Vetting.ParentDescription,dbo.uv_CB_Vetting.ParentCreateDate,dbo.uv_CB_Vetting.ParentRequestType,dbo.uv_CB_Vetting.ProjectName,dbo.uv_CB_Vetting.ProjectRequestor,dbo.uv_CB_Vetting.ProjectManager,dbo.uv_CB_Vetting.Prompt_ID,dbo.uv_CB_Vetting.BusinessApplicationName,dbo.uv_CB_Vetting.GL_CodeOwner,dbo.uv_CB_Vetting.LongApplicationName,dbo.uv_CB_Vetting.GlobalApplicationId,dbo.uv_CB_Vetting.ComputeUnitPctCPU,dbo.uv_CB_Vetting.ComputeUnitPctRAM,dbo.uv_CB_Vetting.CPUAllocated,dbo.uv_CB_Vetting.CPUAverageUtilPct,dbo.uv_CB_Vetting.CPUPeakUtilPct,dbo.uv_CB_Vetting.RAMAllocated,dbo.uv_CB_Vetting.RAMAverageUtilPct,dbo.uv_CB_Vetting.RAMPeakUtilPct,dbo.uv_CB_Vetting.PctUptime,dbo.uv_CB_Vetting.FileName,dbo.uv_CB_Vetting.FileKey,dbo.uv_CB_Vetting.RecordID,dbo.uv_CB_Vetting.TransactionCycleKey,dbo.uv_CB_Vetting.FileOutput,dbo.uv_CB_Vetting.OutputYesNo,dbo.uv_CB_Vetting.RateTypeID,dbo.uv_CB_Vetting.UnitRate,dbo.uv_CB_Vetting.UnitCost,dbo.uv_CB_Vetting.AdjUnitCost,dbo.uv_CB_Vetting.AdjUnitCost_presplit,dbo.uv_CB_Vetting.StorageRate,dbo.uv_CB_Vetting.StorageCost,dbo.uv_CB_Vetting.AdjStorageCost,dbo.uv_CB_Vetting.AdjStorageCost_presplit,dbo.uv_CB_Vetting.[Rate Type],dbo.uv_CB_Vetting.[GL Source],dbo.uv_CB_Vetting.[App Source],dbo.uv_CB_Vetting.[Project Source],dbo.uv_CB_Vetting.Cap,dbo.uv_CB_Vetting.Floor,dbo.uv_CB_Vetting.Multiplier  from dbo.uv_CB_Vetting where (dbo.uv_CB_Vetting.AccountingYearMonth='1910' and upper(rtrim(ltrim(dbo.uv_CB_Vetting.ServiceCode)))='92'  order by ServiceUniqueIdentifier,SUIdescription "        
    df = pd.read_sql_query(sql_string, engine)
    print(str(len(df)))
    return df

def FlatFiles_Extraction():
    df=pd.read_csv(r'c:\users\asrilekh\documents\decomm_may_2020_apps.csv')
    df1=pd.read_csv(r'c:\users\asrilekh\documents\decomm_june_2020_apps.csv')
    # converterS={c: str for c in df.columns}
    # df=pd.read_csv(r'c:\users\asrilekh\documents\decomm_may_2020_apps.csv')
    # df1=pd.read_csv(r'c:\users\asrilekh\documents\decomm_june_2020_apps.csv')
    df=df.append(df1)
    print(df.columns)
    print(len(df))
    return df


## appending the columns and deriving the new one
def Derivation(df,col1,col2):
    df[col1]=df[col1].astype(str)
    df[col2]=df[col2].astype(str)
    df['New Column']=df[col1]+"-"+df[col2]
    print(df['New Column'])
    return df
## removing duplicates
def Remove_Dup(df):
    df=df.drop_duplicates()
    return df

df=FlatFiles_Extraction()
print(list(df.columns))
df=Derivation(df,'GL_BU','GL_LOC')

## duplicating the rows
print(len(df))
df=df.append(df[0:10])
print(len(df))

## removing duplicates

df=Remove_Dup(df)
print(len(df))
print(df.head(10))

## filter rows

df['HISTORY_PERIOD']=df['HISTORY_PERIOD'].astype(str)

df_may=df.loc[df['HISTORY_PERIOD']=='202005']
print(len(df_may))
df_may['May_Charges']=df_may['CHARGES']

df_june=df.loc[df['HISTORY_PERIOD']=='202006']
print(len(df_june))
df_june['June_Charges']=df_june['CHARGES']

## Joining

df_june=df_june[['GL_BU','June_Charges']]
df = pd.merge(df_may, df_june, how='left', left_on='GL_BU', right_on='GL_BU')
print(list(df.columns))

## Splitting

df[['Split1','Split2']] = df['New Column'].str.split('-',expand=True) 
print(df[['Split1','Split2']])

## Summarization

df['May_Charges']=df['May_Charges'].astype(float)
s1=((df.groupby('GL_LOC')['May_Charges'].agg('sum')))
df_temp=s1.to_frame().reset_index()
print(df_temp.columns)

df = pd.merge(df, df_temp, how='left', left_on='GL_LOC', right_on='GL_LOC')

df['Const Col']=datetime.now()

## Date operations

df['Date Opn Res']=df['Const Col'].map(lambda ts: ts - relativedelta(months=1))

print(df.dtypes)