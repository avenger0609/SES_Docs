import pandas as pd
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell

# Read in the two files but call the data old and new and create columns to track
f1='C:\\Users\\asrilekh\\Documents\\Vaidation_Domo_10102019.xlsx'
old = pd.read_excel(f1,sheet_name='Actuals')

converterS = {col: str for col in old.columns}
old = pd.read_excel(f1,sheet_name='Actuals',converters=converterS)
for i in list(old.columns):
    try:
        old[i]=old[i].str.replace("nan","")
    except:
        pass
        
new = pd.read_excel(f1,sheet_name='Actuals_Email')
converterS = {col: str for col in new.columns}
new = pd.read_excel(f1,sheet_name='Actuals_Email',converters=converterS)


old['version'] = "old"
new['version'] = "new"
new.fillna('0')
old_accts_all = set(old['UCMG ID'])
new_accts_all = set(new['UCMG ID'])

dropped_accts = old_accts_all - new_accts_all
added_accts = new_accts_all - old_accts_all
all_data = pd.concat([old,new],ignore_index=True)
changes = all_data.drop_duplicates(subset=["UCMG ID","Program  Name","2019  Non ASG  Actuals","Optum Insight","ETS Labor","HW/SW","Other IT","Business Labor","External  Dev","Optum  Rx","Other  (Non-IT)","ASG  MPWR  Report","2019 Total Actuals  (ASG+Non ASG)","2019 ASG Actuals"], keep='last')
dupe_accts = changes[changes['UCMG ID'].duplicated() == True]['UCMG ID'].tolist()
dupes = changes[changes['UCMG ID'].isin(dupe_accts)]
# Pull out the old and new data into separate dataframes
change_new = dupes[(dupes["version"] == "new")]
change_old = dupes[(dupes["version"] == "old")]

# Drop the temp columns - we don't need them now
change_new = change_new.drop(['version'], axis=1)
change_old = change_old.drop(['version'], axis=1)

# Index on the account numbers
change_new.set_index('UCMG ID', inplace=True)
change_old.set_index('UCMG ID', inplace=True)

# Combine all the changes together
df_all_changes = pd.concat([change_old, change_new],
                            axis='columns',
                            keys=['old', 'new'],
                            join='outer')
# Define the diff function to show the changes in each field
def report_diff(x):
    return x[0] if x[0] == x[1] else '{} ---> {}'.format(*x)
df_all_changes = df_all_changes.swaplevel(axis='columns')[change_new.columns[0:]]
df_changed = df_all_changes.groupby(level=0, axis=1).apply(lambda frame: frame.apply(report_diff, axis=1))
df_changed = df_changed.reset_index()
print(df_changed)
df_changed['UCMG ID']=df_changed['index']
df_removed = changes[changes['UCMG ID'].isin(dropped_accts)]
df_added = changes[changes['UCMG ID'].isin(added_accts)]
output_columns = ["UCMG ID","Program  Name","2019  Non ASG  Actuals","Optum Insight","ETS Labor","HW/SW","Other IT","Business Labor","External  Dev","Optum  Rx","Other  (Non-IT)","ASG  MPWR  Report","2019 Total Actuals  (ASG+Non ASG)","2019 ASG Actuals"]
writer = pd.ExcelWriter("C:\\users\\asrilekh\\documents\\my-diff_Actuals.xlsx")
df_changed.to_excel(writer,"changed", index=False, columns=output_columns)
df_removed.to_excel(writer,"removed",index=False, columns=output_columns)
df_added.to_excel(writer,"added",index=False, columns=output_columns)
# df_changed.to_excel(writer,"changed", index=False)
# df_removed.to_excel(writer,"removed",index=False)
# df_added.to_excel(writer,"added",index=False)
writer.save()
wb = openpyxl.load_workbook("C:\\users\\asrilekh\\documents\\my-diff_Actuals.xlsx")
sheet = wb.get_sheet_by_name("changed")
print(sheet.max_row)
print(sheet.max_column)
mr=sheet.max_row
mc=sheet.max_column
for i in range(1, mr + 1):
    for j in range(1,mc+1):        
        cell = sheet.cell(row=i, column=j)
        val=cell.value
        if "--->" in str(val):
            if "nan" in (str(val).split('--->'))[0] or "nan" in (str(val).split('--->'))[1]:
                # print("entered")
                cell.value=str(val).split('--->')[0].replace("nan","")+"--->"+str(val).split('--->')[1].replace("nan","")
            else:
                cell.value=cell.value

            # cell.value=(str(val).split('--->'))[0]
            # cell.value=cell.value
            # cell.font = Font(color='ffff0000')
            redFill = PatternFill(start_color='FFffC7CE',end_color='FFffC7CE',fill_type='solid')
            cell.fill = redFill
        else:
            cell.value=cell.value

wb.save("C:\\users\\asrilekh\\documents\\my-diff_Actuals.xlsx")
wb.close()
print("completed")