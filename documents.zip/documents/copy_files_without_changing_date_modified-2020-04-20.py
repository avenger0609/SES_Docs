import os

# os.system(command)

# In Linux/Unix
# os.system('cp source.txt destination.txt')  

# In Windows
os.system('copy C:\\Users\\asrilekh\\Documents\\Doc1.pdf C:\\Users\\asrilekh\\Downloads\\Doc1.pdf')