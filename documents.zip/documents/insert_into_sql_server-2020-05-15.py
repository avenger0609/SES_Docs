import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import glob
import os
import shutil

new_df=pd.DataFrame()

def combine_files():
    filelist=[]
    ndf=0
    d=r"C:\Users\asrilekh\Documents\MyJabberFiles\mpawante@corpimsvcs.com\sql server data insert test"
    a=r"C:\Users\asrilekh\Documents\MyJabberFiles\mpawante@corpimsvcs.com\sql server data insert test\Archive"
    if True:

        print(d)    
        filelist = glob.glob(str(d)+'\\*.xlsx')    
        
        print(len(filelist))
        if ndf==0:
            files2 = pd.read_excel(filelist[0])
            files2['FileName'] = filelist[0]
            new_df=files2[0:0]
            ndf=1

        for i in  filelist: 
            
            files2 = pd.read_excel(i)
            files2['FileName'] = i 
            new_df = new_df.append(files2) 
            print (i)
            shutil.move(i, a)


    
    return new_df
    

df=combine_files()
print(df)
print(df.columns)
print(len(df))


# params = quote_plus(r'Driver={SQL Server Native Client 11.0};Server=dbvep37336;Database=TCMHUB_DB;Trusted_Connection=yes;') #### MPWR Server
# engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)        

# df.to_sql("SPM_TEST", engine, if_exists='append', index=False)