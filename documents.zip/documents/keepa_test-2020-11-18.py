import keepa
from datetime import datetime
import pandas as pd

accesskey="c12t22821ud26l55gu3gj38t1a3bcsml88o57lpn9h6f63h638sskfkhu424blvt"
api=keepa.Keepa(accesskey)
output_dir='c:\\users\\asrilekh\\documents\\Keepa_Data_Extract\\'

def get_category_ids(category):

    resp=api.search_for_categories(category,domain='IN')
    try:
        filename=category+"_Category_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
        resf=open(output_dir+"\\Category Search\\"+filename,"w")
        resf.write(str(resp))
    except Exception as e:
        print(str(e))

    return resp

def get_best_seller_asins(categoryID,CategoryName):

    resp=api.best_sellers_query(categoryID,domain='IN',rank_avg_range=0) # rank_avg_range 0 current BSR  #1 Average BSR
    
    filename=CategoryName+"_Best_Seller_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\Best Seller Search\\"+filename,"w")
    resf.write(str(resp))

    return resp

# Update flag may incur extra cost
# buybox incurs extra cost of 2 per product
def get_asin_info(search_asin):

    resp=api.query(search_asin,domain='IN',history=True,rating=True,to_datetime=True,out_of_stock_as_nan=False
    ,stock=True,product_code_is_asin=True,progress_bar=True
    ,buybox=False,stats=365,offers=21,update=0)

    filename=search_asin+"_ASIN_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\ASIN Search\\"+filename,"w")
    resf.write(str(resp))

    return resp

def json_to_csv():
    filename=r'c:\users\asrilekh\downloads\178472369X_ASIN_Search_Result18_Nov_2020_134238.txt'
    df= pd.read_json(filename,dtype=False,encoding='latin-1')               
    print("converted json to csv ",len(df))

def main():
    cat_file=open(output_dir+'Src_Categories.txt','r')
    cat_lst_tmp=cat_file.readlines()
    cat_lst=[]
    for clti in cat_lst_tmp:
        cat_lst.append(clti.replace('\n','').strip(' '))
    for cli in cat_lst:
        resp=get_category_ids(cli)
        for cat_id in resp:
            print(resp[cat_id]['name'],"-->",cat_id )
            resp1=get_best_seller_asins(str(cat_id),resp[cat_id]['name'])
            for asin in list(resp1["asinList"]):
                print(asin)
                get_asin_info(asin)

def testing():
    asin = '178472369X'
    products = api.query(asin, offers=20,domain='IN')
    product = products[0]
    offers = product['offers']
    # each offer contains the price history of each offer
    offer = offers[0]
    csv = offer['offerCSV']
    # convert these values to numpy arrays
    times, prices = keepa.convert_offer_history(csv)
    # print the first 10 prices
    print('%20s %s' % ('Date', 'Price'))
    for i in range(10):
        print('%20s $%.2f' % (times[i], prices[i]))

testing()
# print(get_category_ids('Garden'))
# print(get_best_seller_asins('15412167031','Gardening'))
# print(get_asin_info('178472369X'))
# json_to_csv()
