from turbodbc import connect
from pandas import DataFrame
import xlsxwriter
import openpyxl
import csv

def isfloat(float_check):
    try:
        float(float_check)
        return True
    except:
        return False

connection = connect(dsn='TRMDB')
cursor = connection.cursor()
# stmt="SELECT * FROM dbo.uv_cb_vetting WHERE globalapplicationid in ('UHGWM110-005266') and computeunitpctram IS NOT NULL and computeunitpctcpu IS NOT NULL and accountingyearmonth=\'1804\'"
# stmt="SELECT * FROM dbo.uv_cb_vetting WHERE GL_OU in ('01510') and accountingyearmonth=\'1805\'"
stmt="SELECT * FROM dbo.uv_cb_vetting WHERE GL_OU in ('01510') and accountingyearmonth in ('1905','1904','1903','1902','1901','1812','1811','1810','1809,'1808','1807','1806','1805')"
cursor.executemany(stmt)
cur_df=DataFrame(cursor.fetchall())
# x=list()
# x.append('RowID!AccountingYearMonth!VolumeYearMonth!DateOfChargeback!DivisionID!ServiceGroup!ServiceGroupCostCenter!ServiceCodeName!ServiceCode!BillCodeName!BillingCode!BillCodeStatus!ServiceUniqueIdentifier!SUIdescription!ServicePhysical!ServiceVirtual!InternalComment!AppName!TMDB_SearchCode!Published!ProjectNumber!Project_Name!Project_Manager!ServiceRequestNumber!ServiceDeliveryDate!CustomerAcceptance!BusinessSegmentName!GL_BU!GL_OU!GL_LOC!GL_ACCT!GL_DEPT!ConsumingServiceGroup!GL_PROD!GL_CUST!GL_PID!UnadjustedUnits!AdjustedUnits!UnadjustedStorage!AdjustedStorage!AdjSanOrAdjStorage!San_Cost!BaseService_Cost!ProdNonProd!EnvironmentCode!DataCenterCode!DRMates!DRCode!NetworkZone!ChangeReason!Requestor!Description!RequestorEmail!CreateDate!RequestType!ParentRequestID!ParentRequestor!ParentRequestorEmail!ParentDescription!ParentCreateDate!ParentRequestType!ProjectName!ProjectRequestor!ProjectManager!Prompt_ID!BusinessApplicationName!GL_CodeOwner!LongApplicationName!ComputeUnitPctCPU!ComputeUnitPctRAM!CPUAllocated!CPUAverageUtilPct!CPUPeakUtilPct!RAMAllocated!RAMAverageUtilPct!RAMPeakUtilPct!PctUptime!FileName!FileKey!RecordID!TransactionCycleKey!FileOutput!OutputYesNo!RateTypeID!UnitRate!UnitCost!AdjUnitCost!AdjUnitCost_presplit!StorageRate!StorageCost!AdjStorageCost!AdjStorageCost_presplit!Rate Type!GL Source!App Source!Project Source!Cap!Floor!Multiplier!RecordID_presplit!GL_PRAC!CBUniqueKey')
cur_df.columns=['RowID','AccountingYearMonth','VolumeYearMonth','DateOfChargeback','DivisionID','ServiceGroup','ServiceGroupCostCenter','ServiceCodeName','ServiceCode','BillCodeName','BillingCode','BillCodeStatus','ServiceUniqueIdentifier','SUIdescription','ServicePhysical','ServiceVirtual','InternalComment','AppName','TMDB_SearchCode','Published','ProjectNumber','Project_Name','Project_Manager','ServiceRequestNumber','ServiceDeliveryDate','CustomerAcceptance','BusinessSegmentName','GL_BU','GL_OU','GL_LOC','GL_ACCT','GL_DEPT','ConsumingServiceGroup','GL_PROD','GL_CUST','GL_PID','UnadjustedUnits','AdjustedUnits','UnadjustedStorage','AdjustedStorage','AdjSanOrAdjStorage','San_Cost','BaseService_Cost','ProdNonProd','EnvironmentCode','DataCenterCode','DRMates','DRCode','NetworkZone','ChangeReason','Requestor','Description','RequestorEmail','CreateDate','RequestType','ParentRequestID','ParentRequestor','ParentRequestorEmail','ParentDescription','ParentCreateDate','ParentRequestType','ProjectName','ProjectRequestor','ProjectManager','Prompt_ID','BusinessApplicationName','GL_CodeOwner','LongApplicationName','Global Application Id','ComputeUnitPctCPU','ComputeUnitPctRAM','CPUAllocated','CPUAverageUtilPct','CPUPeakUtilPct','RAMAllocated','RAMAverageUtilPct','RAMPeakUtilPct','PctUptime','FileName','FileKey','RecordID','TransactionCycleKey','FileOutput','OutputYesNo','RateTypeID','UnitRate','UnitCost','AdjUnitCost','AdjUnitCost_presplit','StorageRate','StorageCost','AdjStorageCost','AdjStorageCost_presplit','Rate Type','GL Source','App Source','Project Source','Cap','Floor','Multiplier','RecordID_presplit','GL_PRAC','CBUniqueKey']
print(type(cur_df))
try:
    cur_df.to_excel("c:\\users\\asrilekh\\documents\\TRMDB_Data_OU_01510.xlsx",index=False)
except Exception as e:
    print(str(e))
    cur_df.to_csv("c:\\users\\asrilekh\\documents\\TRMDB_Data_OU_01510.csv",index=False,quoting=csv.QUOTE_ALL)
# cur_lst=list(cursor.fetchall())



# for row in cur_lst:
#     # print(row)
#     s1=""
#     for i in range(0,len(row)):
#         try:
#             # print(row[i].strftime('%Y-%m-%d'))
#             s1=s1+str(row[i].strftime('%m/%d/%Y'))+"!"

#         except:
#             if row[i]==None:
#                 s1=s1+""+"!"
#             else:
#                 s1=s1+str(row[i]).replace('!','').replace('~','').replace("http://","~").strip(' ')+"!"    
#     # print(s1)
#     x.append(s1)

# merged_x = "C:\\users\\asrilekh\\documents\\1904_extracted_KR.xlsx"
# merged_x_wb = xlsxwriter.Workbook(merged_x)
# merged_sheet = merged_x_wb.add_worksheet("1904_data")

# for deli in range(0, len(x)):
#     del_str = x[deli].split('!')
#     for delsi in range(0, len(del_str)):
#         merged_sheet.write(deli, delsi, del_str[delsi])
# merged_x_wb.close()
# wb = openpyxl.load_workbook(merged_x)
# sheet = wb.get_sheet_by_name("1904_data")
# for i in range(0, len(x)):
#     del_str = x[i].split('!')
#     for j in range(0, len(del_str)):                
#         sheet.cell(i+1,j+1).value="N/A" if sheet.cell(i+1,j+1).value==None else sheet.cell(i+1,j+1).value.replace('~','http://')
#         if isfloat(sheet.cell(i+1,j+1).value) and (j==86 or j==87 or j==88 or j==89 or j==90 or j==91 or j==92 or j==93 or j==37 or j==38 or j==39 or j==40 or j==41 or j==42 or j==43):
#             sheet.cell(i+1,j+1).value=round(float(sheet.cell(i+1,j+1).value),2)
#             sheet.cell(i+1,j+1).number_format = "###,###,##0.00"
# wb.save(merged_x)
# wb.close()
            