import pandas as pd
from pymongo import MongoClient
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3
from datetime import datetime
from dateutil.relativedelta import relativedelta

def Remove_Dup(df):
    df=df.drop_duplicates()
    return df

# df=pd.read_excel(r'c:\users\asrilekh\downloads\COE_POC.xlsx')

df1=pd.read_excel(r'c:\users\asrilekh\downloads\COE_POC_1.xlsx')
df2=pd.read_excel(r'c:\users\asrilekh\downloads\COE_POC_2.xlsx')

print(list(df1.columns))
print(list(df2.columns))

df1['Source File']=r'c:\users\asrilekh\downloads\COE_POC_1.xlsx'
df2['Source File']=r'c:\users\asrilekh\downloads\COE_POC_2.xlsx'

df=df1.append(df2)

def MongoDbData_Extraction():    
    myclient = MongoClient(u"mongodb://apsrp03693.uhc.com:27017")        
    mydb = myclient["COE_ETL_POC"]        
    mycol = mydb["COE_WOM_US_COVID_DATA"]
    mydoc=mycol.find() #.limit(100)
    print(mydoc)
    df =  pd.DataFrame(list(mydoc))
    df['Source File']='Mongo Collection'
    print(list(df.columns))
    return df

df=MongoDbData_Extraction()

df['USA State']=df['USA State'].map(lambda ts: 'Noise' if str(ts)=='USA Total' or str(ts)=='Total:' else ts )

df=df.loc[df['USA State']!='Noise']



df_state_abb=pd.read_excel(r'c:\users\asrilekh\downloads\State Abbreviations.xlsx')

df['Date Updated_1']=df['Date Updated'].astype(str)
print(df['Date Updated'])
df['Date']=df['Date Updated_1'].map(lambda ts: str(ts).split(' ')[0])

df['Date']=pd.to_datetime(df['Date'], format='%Y-%m-%d')

df["Date_Rank"]=df.groupby('Date')['Date Updated'].rank(method='dense').astype(int)
df=df.loc[df['Date_Rank']==1]
df=df.append(df[0:10])
df=Remove_Dup(df)

df = pd.merge(df, df_state_abb, how='left', left_on='USA State', right_on='State')

df=df[['USA State','Total Cases','New Cases','Total Deaths','New Deaths','Active Cases','Tot Cases/ 1M pop','Deaths/ 1M pop','Total Tests','Tests/  1M pop','Source','Projections','Date Updated','Date','Abbreviation','Source File']]

moving_avg_days=7

df["New Cases MA"] = df.groupby('USA State')['New Cases'].transform(lambda x: x.rolling(moving_avg_days, moving_avg_days).mean())
df["New Cases MA Shift 7"] =df.groupby('USA State')['New Cases MA'].shift(7)
df["New Cases MA Pct change"] = (df["New Cases MA"] - df["New Cases MA Shift 7"])/df["New Cases MA Shift 7"]*100

# df['Date shift 7']=df.groupby('USA State')['Date'].shift(7)
df['Date Minus 7']=df['Date'].map(lambda ts: ts - relativedelta(days=7))

print(df['Date'].unique())
print(df['Date shift 7'].unique())
print(df['Date Minus 7'].unique())

print(df.columns)
print(df.dtypes)

df.to_excel(r'C:\users\asrilekh\documents\COE_OP.xlsx')
