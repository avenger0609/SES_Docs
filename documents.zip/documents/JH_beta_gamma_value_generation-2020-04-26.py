import pandas as pd 
import numpy as np

df_final=pd.DataFrame()
df_final_beta_gamma=pd.DataFrame()
dfs=pd.read_excel(r'C:\users\asrilekh\Documents\JH_US_County_Level_Data.xlsx')
# dfs=pd.read_csv(r'C:\users\asrilekh\Downloads\Johns+Hopkins+w_+Normalized+FIPS.csv')

dfs['County']=dfs['Admin2']
# print(len(dfs['County'].unique()))

dfm=pd.read_csv(r'C:\users\asrilekh\Downloads\Modelo+All+Combined+Data.csv')
# print(len(dfm['County'].unique()))


dfs['FIPS']= dfs['FIPS'].astype(str)
dfs['FIPS'] = dfs['FIPS'].apply(lambda x: x.zfill(5))

dfm['FIPS']= dfm['FIPS'].astype(str)
dfm['FIPS'] = dfm['FIPS'].apply(lambda x: x.zfill(5))


print(len(dfs['FIPS'].unique()))
print(len(dfm['FIPS'].unique()))
print(len(list(set(dfs['FIPS']) - set(dfm['FIPS']))))
print(len(list(set(dfm['FIPS']) - set(dfs['FIPS']))))



dfs=pd.merge(dfs, dfm[['FIPS','Population']], how='inner', on=['FIPS'])
# print(len(dfs['County'].unique()))

fips_lst=[]
fips_lst=dfs['FIPS'].unique()

dfs["Active"] = pd.to_numeric(dfs["Active"])

print(dfs.dtypes)

# fips_lst=fips_lst[-1:]
for fli in fips_lst:   
    
    df=dfs[dfs['FIPS']==fli]    
    df=df.sort_values(["Report_Date"], ascending = (True))

    # df['Population']=df['Population']-df['Deaths']
    df['New Deaths']=df['Deaths']-df['Deaths'].shift(1)
    ## we need to take active but as active is not correctly populated using the same technique using Confirmed cases count
    df['New Cases']=(df['Confirmed']-df['Confirmed'].shift(1))-df['New Deaths']
    df['Susceptible']=df['Population']-df['Active']-df['Deaths']  
    df['Susceptible_min_1']=df['Susceptible'].shift(1)    
    df['Susceptible_diff'] = df['Susceptible'] - df['Susceptible'].shift(1)
    df['beta']=df['Susceptible_diff']/(df['Susceptible'].shift(1)*-1*(df['New Cases'].shift(1)))
    df['beta'] = df['beta'].replace([np.inf, -np.inf], np.nan)
    df['Susceptible_Calc']=((df['Susceptible_diff']/(df['Susceptible'].shift(1)*-1*(df['New Cases'])))*-1*df['Susceptible'].shift(1)*df['New Cases'])+df['Susceptible'].shift(1)
    
    df_beta=df[['FIPS','beta']]
    df_beta=df_beta.dropna(subset=['beta'])
    df_beta=df_beta[-10:]
    sf=df.groupby(['FIPS'])['beta'].mean()
    df_beta=pd.DataFrame({'FIPS':sf.index, 'Beta_Mean':sf.values})
    print(df_beta)

    df['Recovered_Count']=(df['Confirmed']-df['Confirmed'].shift(1))-df['New Deaths']

    df['gamma']=(((df['New Cases']-df['New Cases'].shift(1))+df['Susceptible_diff'])*-1)/(df['New Cases'].shift(1))
    df['gamma']=(df['Recovered_Count']-df['Recovered_Count'].shift(1))/df['New Cases']
    df['gamma'] = df['gamma'].replace([np.inf, -np.inf], np.nan)
    df_gamma=df[['FIPS','gamma']]
    df_gamma=df_gamma.dropna(subset=['gamma'])
    df_gamma=df_gamma[-10:]
    sf=df.groupby(['FIPS'])['gamma'].mean()
    df_gamma=pd.DataFrame({'FIPS':sf.index, 'Gamma_Mean':sf.values})
    print(df_gamma)

    # print(df[['Population','Confirmed','Deaths','Active','Deaths','Susceptible','Susceptible_diff','New Cases','beta','Susceptible_Calc','Recovered_Count','gamma']])  

    if len(df_final) > 0:
        df_final=df_final.append(df)
    else:
        df_final=df
    
    df_fips_beta_gamma=pd.merge(df_beta, df_gamma, how='inner', on=['FIPS'])

    if len(df_final_beta_gamma) > 0:
        df_final_beta_gamma=df_final_beta_gamma.append(df_fips_beta_gamma)
    else:
        df_final_beta_gamma=df_fips_beta_gamma
    # # df.to_excel(r'C:\users\asrilekh\Documents\US_collated_Python_means.xlsx')
    # # print(df)

# print(df_final)
print(df_final_beta_gamma)
# df.to_excel(r'C:\users\asrilekh\Documents\test_beta_gamma.xlsx')



    