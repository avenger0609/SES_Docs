import pandas_profiling
import pandas as pd

# Read in the two files but call the data old and new and create columns to track
df = pd.read_excel('C:\\Users\\asrilekh\\Desktop\\work\\swing analysis\\using odbc\\July\\Citrix - Mgd_OPTUM_1907_extracted.xlsx',index_col=0, na_values=['N/A'])
print((df[df.index.duplicated()]))
df = df[~df.index.duplicated()]
print(len(df[df.index.duplicated()]))
pfrep=pandas_profiling.ProfileReport(df)
pfrep.to_file('./profile_report.html')
print("completed")
exit()