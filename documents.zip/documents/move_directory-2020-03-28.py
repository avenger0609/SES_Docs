### to be tested ####

import os  
import shutil
src=r'C:\Users\asrilekh\Downloads\domo-stream-uploader-master\domo_stream_uploader'
dest=r''
shutil.copytree(src, dest, copy_function = shutil.copy)