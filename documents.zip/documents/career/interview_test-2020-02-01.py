def test(a):
    a[0]='2'
A=['1']
test(A)
print(A)
a="abcd"
b=list(a)
print(b)

def fast (items= []):
    items.append (1)
    return items

print(fast ())
print(fast ())