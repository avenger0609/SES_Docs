from selenium import webdriver
import pandas as pd
import time

service_name_lst=[]
acc_mon_lst=[]
billing_file_lst=[]
service_code_lst=[]
status_lst=[]
comments_lst=[]
href_list=[]


def comments_extract():

    for href_i in href_list:

        print(href_i)
        driver.get(href_i)
        time.sleep(30)
        fc_text=(driver.find_element_by_xpath('//*[@id="Comments"]')).text
        sc_text=""
        parent_id=driver.find_element_by_xpath('//*[@id="signoff-observation-grid"]/tbody')
        parent_rows=parent_id.find_elements_by_tag_name('tr')
        for pr in parent_rows:
            pd_1=pr.find_elements_by_tag_name('td')[1]
            if str(pd_1.text).upper().strip(' ')==str('Month over Month decrease in recovery (does not include ETS) exceeded -20000.00').upper().strip(' '):
                pd_3=pr.find_elements_by_tag_name('td')[3]
                pd_3_div=pd_3.find_elements_by_tag_name('div')[0]
                pd_3_ta=pd_3_div.find_elements_by_tag_name('textarea')[0]
                sc_text=pd_3_ta.text
        if len(sc_text) > 0:
            final_comments="1."+str(fc_text)+"\n2."+str(sc_text)
            comments_lst.append(final_comments)
        else:
            comments_lst.append(str(fc_text))



driverpath = "C:\\ProgramData\\Chrome_driver_80.0.3987.16\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://dmp.optum.com/ChargebackManagement/Signoff")
pending_only=driver.find_element_by_xpath('//*[@id="chkPendingOnly"]')
if pending_only.is_selected:
    pending_only.click()
cur_cycle=driver.find_element_by_xpath('//*[@id="chkCurrentCycle"]')
if cur_cycle.is_selected:
    pass
else:
    cur_cycle.click()
time.sleep(30)
nopages_s=driver.find_element_by_xpath('//*[@id="signoff-table_paginate"]/span')
nopages_lst=nopages_s.find_elements_by_tag_name('a')
nopages=nopages_lst[len(nopages_lst)-1].text
print("number of pages="+str(nopages))
counter=1
# time.sleep(90)
while counter <= int(nopages) :
    counter=counter+1
    tbl_id=driver.find_element_by_xpath('/html/body/div[2]/section/div/div[4]/div/div/table/tbody')             
    rows=tbl_id.find_elements_by_tag_name("tr")
    print(len(rows))
    for row in rows:
        try:
            c=0
            tds=row.find_elements_by_tag_name("td")
            if len(str(tds[6].text).strip(' ')) == 0:
                continue
            print("len of tds "+str(len(tds)))
            # print((tds))
            # print(type(tds))
            for tds_i in tds:
                print("entered")
                if c==0:
                    print("test")
                    spanid=tds_i.find_elements_by_tag_name("span")[0]
                    ahref=spanid.find_elements_by_tag_name("a")[0]
                    href_list.append(ahref.get_attribute('href'))
                    # ahref.click()
                    # time.sleep(30)
                    # fc_text=(driver.find_element_by_xpath('//*[@id="Comments"]')).text
                    # sc_text=""
                    # parent_id=driver.find_element_by_xpath('//*[@id="signoff-observation-grid"]/tbody')
                    # parent_rows=parent_id.find_elements_by_tag_name('tr')
                    # for pr in parent_rows:
                    #     pd_1=pr.find_elements_by_tag_name('td')[1]
                    #     if str(pd_1.text).upper().strip(' ')==str('Month over Month decrease in recovery (does not include ETS) exceeded -20000.00').upper().strip(' '):
                    #         pd_3=pr.find_elements_by_tag_name('td')[3]
                    #         pd_3_div=pd_3.find_elements_by_tag_name('div')[0]
                    #         pd_3_ta=pd_3_div.find_elements_by_tag_name('textarea')[0]
                    #         sc_text=pd_3_ta.text
                    # if len(sc_text) > 0:
                    #     final_comments="1."+str(fc_text)+"\n2."+str(sc_text)
                    #     comments_lst.append(final_comments)
                    # else:
                    #     comments_lst.append(str(fc_text))               
                    # time.sleep(60)
                    # driver.back()
                elif c==1:
                    acc_mon_lst.append(tds_i.text)
                elif c==2:
                    billing_file_lst.append(tds_i.text)
                elif c==3:
                    service_code_lst.append(tds_i.text)
                elif c==4:
                    service_name_lst.append(tds_i.text)
                elif c==5:
                    status_lst.append(tds_i.text)
                c=c+1

        except Exception as e:
            print("exception="+str(e))
    elem = driver.find_element_by_xpath('//*[@id="signoff-table_next"]')
    elem.click()  
    time.sleep(30)  

comments_extract()

print(status_lst)
print(service_code_lst)
print(service_name_lst)
print(acc_mon_lst)
print(billing_file_lst)
print(comments_lst)