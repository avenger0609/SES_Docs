import pandas as pd
import xlsxwriter

for f in glob.glob('./*.xlsx'):
   df = pd.read_excel(f)
   all_data = all_data.append(df, ignore_index=True)
writer = pd.ExcelWriter('mycollected_data.xlsx', engine='xlsxwriter')
all_data.to_excel(writer, sheet_name='Sheet1')
writer.save()