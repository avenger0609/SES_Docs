import pandas as pd

large_file='/app/Apache Druid POC/join_res_uidxwalk.csv'

for i,chunk in enumerate(pd.read_csv(large_file,skiprows=1,header=None, chunksize=1250000)):
    chunk.to_csv('/app/Apache Druid POC/Chunks/join_res_uidxwalk_chunk_{}.csv'.format(i), index=False)

print('completed')