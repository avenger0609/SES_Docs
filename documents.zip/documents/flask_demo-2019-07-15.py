from flask import Flask
from flask import render_template,jsonify,request,send_file
import requests
import random
import urllib3
from flask_cors import CORS
import json
import glob
import os

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False
app.secret_key = '12345'
CORS(app)

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route("/parse", methods=['GET', 'POST', 'OPTIONS'])
def parse():

    try:
        ### to read parameters###

        parsed=(urllib3.util.url.parse_url(request.url)) 
        ######## Used in case of any parameters passed ###########       
        # s1=str(str(parsed.query).split('&')[0].split('=')[1].replace('+',' ')) # first query        
        # while True:
        #     a=s1.find("%")
        #     if a > -1:
        #         ss=s1[a]+s1[a+1]+s1[a+2]
        #         s1=s1.replace(ss," ")
        #     else:
        #         break 
        # s1=s1.replace('  ',' ').replace('  ',' ').strip(' ') 
        # print(s1)    
        ######## Used in case of any parameters passed ###########    
        # path1='\\app\\Analytics_POCS\\'
        # list_of_files = glob.glob(path1+'*.xlsx') # * means all if need specific format then *.csv
        # latest_file = max(list_of_files, key=os.path.getctime)
        # latest_file_name=latest_file.split('\\')[len(latest_file.split('\\'))-1]
        # print('latest file name along with path '+path1+latest_file_name)
        # fn=data_pp_np_prediction(path1,latest_file_name)
        # fn=eda_nlp_prediction(path1,fn)
        ## after resolving issue##
        # res=nlp_prediction(path1,fn)
        ## after resolving issue##
        # res=test_module()
        # return send_file('C:\\Users\\asrilekh\\Desktop\\work\\Krishna_request\\flask_demo.py', attachment_filename='flask_demo.py')
        # return jsonify({"response":str(fn)})
        # return jsonify({"response":conv_answer,"object_id":conv_obj_id,"Suggestions":sugg_list})
    except Exception as e:    
        print(e) 
        return jsonify({"response":"Sorry I do not have an answer for that. You may reach out to us through call or email for assistance."})   


app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(host='localhost',port=5050,debug=True)
    # app.run(host='apsrp03693',port=5051,debug=True)