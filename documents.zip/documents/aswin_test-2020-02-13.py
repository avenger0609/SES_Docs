########### generating itbm datasets and swing analysis reports at a once
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell
import xlsxwriter
from datetime import datetime
import openpyxl
import pandas as pd
import numpy as np
import datetime
import time
import redis
import re
from datetime import datetime
import datetime
from openpyxl.formula.translate import Translator
from turbodbc import connect
import xlsxwriter
from datetime import datetime
import os
import csv
import openpyxl
import pandas as pd
import numpy as np
