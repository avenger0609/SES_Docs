import os
from shutil import copyfile


# srcdir = 'c:\\users\\asrilekh\\desktop\\work'
# srcdir = 'c:\\users\\asrilekh\\documents'
srcdir = 'c:\\users\\asrilekh\\downloads'

# destdir = '\\\\nas05151pn\\ii519_homedirs\\asrilekh\\desktop\\work'
# destdir = '\\\\nas05151pn\\ii519_homedirs\\asrilekh\\documents'
destdir = '\\\\nas05151pn\\ii519_homedirs\\asrilekh\\downloads'

srcfiles_lst=[]
destfiles_lst=[]

for r, d, f in os.walk(srcdir):
    for file in f:
        try:                    
            srcfiles_lst.append(str(os.path.join(r, file)).replace("c:\\users\\asrilekh\\","\\\\nas05151pn\\ii519_homedirs\\asrilekh\\")+"="+str(os.path.getmtime(os.path.join(r, file))))
        except Exception as e:
            print(str(e))

print(len(srcfiles_lst))
print(srcfiles_lst[0:5])
print(srcfiles_lst[0])

file1 = open("c:\\users\\asrilekh\\documents\\HDriveDownloads.txt","w")

for r, d, f in os.walk(destdir):
    for file in f:
        try:
            dest_file=os.path.join(r, file)            
            file1.write(str(dest_file)+"="+str(os.path.getmtime(dest_file))+"\n")            
            destfiles_lst.append(str(dest_file)+"="+str(os.path.getmtime(dest_file)))
        except Exception as e:
            print(str(e))

file1.close()

print(len(destfiles_lst))
print(destfiles_lst[0:5])

not_in_src_lst=list(set(srcfiles_lst) - set(destfiles_lst))

print(len(not_in_src_lst))
print(not_in_src_lst[0:5])

for f in not_in_src_lst:
    try:
        dest_f=str(f).split('=')[0]
        src_f=dest_f.replace("\\\\nas05151pn\\ii519_homedirs\\asrilekh\\","c:\\users\\asrilekh\\")        
        destpath=dest_f[0:dest_f.rfind('\\')]
        print(destpath)
        if not os.path.exists(destpath):
            os.makedirs(destpath) 
        copy_cmd='copy "'+src_f+'" '+'"'+dest_f+'"'  
        print(copy_cmd)  
        os.system(copy_cmd)                        
    except Exception as e:
        print(str(e))
