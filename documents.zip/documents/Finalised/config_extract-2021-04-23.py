
import configparser

def read_ini(file_path,key):
    print("Entered")
    config = configparser.ConfigParser()
    config.read(file_path)
    for section in config.sections():
        print(config[section])
        return config[section][key]
        # for key in config[section]:
        #     print((key, config[section][key]))
 
# print(read_ini("coonfig.ini"),key)