from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://uhgazure.sharepoint.com/sites/orxtech/pfm/Lists/Site%20Remediation_1/Allitemsg.aspx")
time.sleep(6)
driver.find_element_by_xpath('//*[@id="i0116"]').send_keys('rizwan.syedali@optum.com')
driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()
time.sleep(45)
parent_div=driver.find_element_by_xpath('//*[@id="spgridcontainer_WPQ1_leftpane_mainTable"]/tbody')
child_els=parent_div.find_elements_by_tag_name('tr')
child_els_lst=(child_els[0].text).split('\n')
for celi in range(len(child_els_lst)):
    print(child_els_lst[celi],celi)

col_names_lst=[]
col_indices_lst=[]
for celi in range(len(child_els_lst)):
    if str(child_els_lst[celi]).isalnum():
        col_names_lst.append(child_els_lst[celi])
        col_indices_lst.append(celi)

col_names_lst=['ID','Title','Emp ID','Resource Name','Supervisor name','HR Site','FMS Site','Remediation Status']
col_indices_lst=[1,3,5,7,9,11,13,15]
print(col_names_lst)
print(col_indices_lst)

values_lst=[]
for _ in col_indices_lst:
    values_lst.append([])

for cei in range(1,len(child_els)):
    print("Procesing Row number ",cei)
    child_els_lst=(child_els[cei].find_elements_by_tag_name('td'))
    print("Number of Columns in row ",len(child_els_lst))
    col_counter=0
    for cili in col_indices_lst:
        try:
            print(child_els_lst[col_counter+1].text,col_counter)
            values_lst[col_counter].append(str(child_els_lst[col_counter+1].text))
        except:            
            values_lst[col_counter].append('')
        col_counter=col_counter+1

df=pd.DataFrame()
for cnli in range(len(col_names_lst)):
    df[col_names_lst[cnli]]=values_lst[cnli]
#print(df)
    
df = df.drop_duplicates()
df.to_csv(r'C:\Users\sali1045\Downloads\SharePoint_SiteRemediation_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv",index=False,encoding='utf-8')
driver.close()
