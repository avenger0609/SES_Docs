from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://uhgazure.sharepoint.com/sites/orxtech/pfm/Lists/Product%20Line%20Commitments/AllItems.aspx")
time.sleep(6)
driver.find_element_by_xpath('//*[@id="i0116"]').send_keys('rizwan.syedali@optum.com')
driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()
time.sleep(45)
parent_div=driver.find_element_by_xpath('//*[@id="appRoot"]/div[1]/div[3]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div/div[3]/div/div/div/div')
child_els=parent_div.find_elements_by_class_name('ms-List-cell')

header_parent = driver.find_element_by_xpath('//*[@id="appRoot"]/div[1]/div[3]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div/div[3]/div/div/div/div/div[1]/div')
header_child_els = header_parent.find_elements_by_class_name('ms-DetailsHeader-cell')
header_child_els_lst=[]
for hcei in header_child_els:
    header_child_els_lst.append((hcei.text).split('\n')[0])
header_child_els_lst = header_child_els_lst[1:]

row_counter=0
data_lst=[]
c=0

## previous iteration
prev_records_count=0
prev_start_field=""
prev_end_field=""
## previous iteration 
while c < 20:
    c=c+1
    print(c)
    actions=ActionChains(driver)
    actions.send_keys(Keys.PAGE_DOWN)
    actions.perform()
    time.sleep(8)
    print(len(driver.find_elements_by_class_name('ms-DetailsRow-fields')))
    print(driver.find_elements_by_class_name('ms-DetailsRow-fields')[0].text.split('\n')[0])
    print(driver.find_elements_by_class_name('ms-DetailsRow-fields')[len(driver.find_elements_by_class_name('ms-DetailsRow-fields'))-2].text.split('\n')[0])
    if prev_records_count==0:
        prev_records_count=len(driver.find_elements_by_class_name('ms-DetailsRow-fields'))
        prev_start_field=driver.find_elements_by_class_name('ms-DetailsRow-fields')[0].text.split('\n')[0]
        prev_end_field=driver.find_elements_by_class_name('ms-DetailsRow-fields')[len(driver.find_elements_by_class_name('ms-DetailsRow-fields'))-2].text.split('\n')[0]
    elif prev_records_count==len(driver.find_elements_by_class_name('ms-DetailsRow-fields')) and prev_start_field==driver.find_elements_by_class_name('ms-DetailsRow-fields')[0].text.split('\n')[0] and prev_end_field==driver.find_elements_by_class_name('ms-DetailsRow-fields')[len(driver.find_elements_by_class_name('ms-DetailsRow-fields'))-2].text.split('\n')[0]:
        continue
    else:
        prev_records_count=len(driver.find_elements_by_class_name('ms-DetailsRow-fields'))
        prev_start_field=driver.find_elements_by_class_name('ms-DetailsRow-fields')[0].text.split('\n')[0]
        prev_end_field=driver.find_elements_by_class_name('ms-DetailsRow-fields')[len(driver.find_elements_by_class_name('ms-DetailsRow-fields'))-2].text.split('\n')[0]
            
    
    content_child_els = driver.find_elements_by_class_name('ms-DetailsRow-fields') ## rows    
    content_child_els = content_child_els[0:len(content_child_els)]
    for ccei in content_child_els:
        row_counter=row_counter+1
        content_child_els_lst=[]
        ccei_fields = ccei.find_elements_by_class_name('ms-DetailsRow-cell')
        # print(len(ccei_fields))
        for cceii in ccei_fields:
            content_child_els_lst.append(cceii.text.split('\n')[0])
        data={}
        for di in range(len(header_child_els_lst)):
            try:
                data[header_child_els_lst[di]]=content_child_els_lst[di]
            except:
                print("Exception in row number ",ccei," in column ",header_child_els_lst[di])
                data[header_child_els_lst[di]]=""
        data_lst.append(data)
df = pd.DataFrame(data=data_lst)
df = df.drop_duplicates()
df.to_csv(r'C:\Users\sali1045\Downloads\SharePoint_ProductLine_Commitments_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv",index=False,encoding='utf-8')
driver.close()
