Email = "rizwan.syedali@optum.com"
username = 'sali1045'
password='UHGtech-0'
chromedriver_path="c:/ProgramData/ChromeDriver_81/chromedriver.exe"

f=open('config.ini','r')
l=f.readlines()
Email = l[0].replace('\n','').split('=')[1].strip(' ')
username = l[1].replace('\n','').split('=')[1].strip(' ')
password=l[2].replace('\n','').split('=')[1].strip(' ')
chromedriver_path=l[3].replace('\n','').split('=')[1].strip(' ')
print(chromedriver_path)

def get_email():
    return Email

def get_username():
    return username

def get_password():
    return password

def get_driver_path():
    return chromedriver_path