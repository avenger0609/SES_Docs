import pandas as pd
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell

def validation(old,new,columns_lst,key_val,type_val):
    # print(len(old.columns))
    # print(len(new.columns))
    old['version'] = "old"
    new['version'] = "new"
    old_accts_all = set(old[key_val])
    new_accts_all = set(new[key_val])

    dropped_accts = old_accts_all - new_accts_all
    added_accts = new_accts_all - old_accts_all
    all_data = pd.concat([old,new],ignore_index=True)
    changes = all_data.drop_duplicates(subset=columns_lst, keep='last')
    dupe_accts = changes[changes[key_val].duplicated() == True][key_val].tolist()
    dupes = changes[changes[key_val].isin(dupe_accts)]
    # Pull out the old and new data into separate dataframes
    change_new = dupes[(dupes["version"] == "new")]
    change_old = dupes[(dupes["version"] == "old")]

    # Drop the temp columns - we don't need them now
    change_new = change_new.drop(['version'], axis=1)
    change_old = change_old.drop(['version'], axis=1)

    # Index on the account numbers
    change_new.set_index(key_val, inplace=True)
    change_old.set_index(key_val, inplace=True)

    # Combine all the changes together
    df_all_changes = pd.concat([change_old, change_new],
                                axis='columns',
                                keys=['old', 'new'],
                                join='outer')
    # Define the diff function to show the changes in each field
    def report_diff(x):
        return x[0] if x[0] == x[1] else '{} ---> {}'.format(*x)

    df_all_changes = df_all_changes.swaplevel(axis='columns')[change_new.columns[0:]]
    df_changed = df_all_changes.groupby(level=0, axis=1).apply(lambda frame: frame.apply(report_diff, axis=1))
    df_changed = df_changed.reset_index()
    # print(df_changed)
    # df_changed['Program Code']=df_changed['index']
    df_removed = changes[changes[key_val].isin(dropped_accts)]
    df_added = changes[changes[key_val].isin(added_accts)]
    output_columns =columns_lst
    writer = pd.ExcelWriter("C:\\users\\asrilekh\\documents\\"+type_val+".xlsx")
    df_changed.to_excel(writer,"changed", index=False, columns=output_columns)
    df_removed.to_excel(writer,"removed",index=False, columns=output_columns)
    df_added.to_excel(writer,"added",index=False, columns=output_columns)
    writer.save()
    wb = openpyxl.load_workbook("C:\\users\\asrilekh\\documents\\"+type_val+".xlsx")
    sheet = wb.get_sheet_by_name("changed")
    mr=sheet.max_row
    mc=sheet.max_column
    for i in range(1, mr + 1):
        for j in range(1,mc+1):        
            cell = sheet.cell(row=i, column=j)
            val=cell.value
            if "--->" in str(val):
                if "nan" in (str(val).split('--->'))[0] or "nan" in (str(val).split('--->'))[1]:
                    # print("entered")
                    cell.value=str(val).split('--->')[0].replace("nan","")+"--->"+str(val).split('--->')[1].replace("nan","")
                    redFill = PatternFill(start_color='FFffC7CE',end_color='FFffC7CE',fill_type='solid')
                    cell.fill = redFill
                else:
                    v1=(str(val).split('--->')[0]).strip(' ')
                    v2=(str(val).split('--->')[1]).strip(' ')
                    try:
                        v1_r=round(float(v1),0)
                        v2_r=round(float(v1),0)
                        # print(v1_r)
                        # print(v2_r)
                        if (v1_r-v2_r) == 1 or (v1_r-v2_r) == -1 or (v1_r-v2_r) == 0:
                            # print("entered")
                            cell.value=str(v1)
                        else:
                            cell.value=cell.value
                            redFill = PatternFill(start_color='FFffC7CE',end_color='FFffC7CE',fill_type='solid')
                            cell.fill = redFill
                    except:
                        if v1.replace('  ',' ').lower()==v2.replace('  ',' ').lower():
                            cell.value=str(v1)
                        else:
                            cell.value=cell.value
                            redFill = PatternFill(start_color='FFffC7CE',end_color='FFffC7CE',fill_type='solid')
                            cell.fill = redFill

                    # cell.value=cell.value

                # cell.value=(str(val).split('--->'))[0]
                # cell.value=cell.value
                # cell.font = Font(color='ffff0000')
                # redFill = PatternFill(start_color='FFffC7CE',end_color='FFffC7CE',fill_type='solid')
                # cell.fill = redFill
            else:
                cell.value=cell.value

    wb.save("C:\\users\\asrilekh\\documents\\"+type_val+".xlsx")
    wb.close()
    


f1='C:\\Users\\asrilekh\\Documents\\Vaidation_Domo_10172019.xlsx'
def actuals_validation_junk():
    email=pd.read_excel(f1,sheet_name='email')
    email_columns=list(email.columns)
    actuals = pd.read_excel(f1,sheet_name='Actuals')
    actuals_columns=list(actuals.columns)
    print(str(len(actuals_columns))+" before filtering with email columns")
    actuals_columns_req=[]
    actuals_columns_req_1=[]
    for x in actuals_columns:
        if x in email_columns:
            actuals_columns_req.append(x) 
            actuals_columns_req_1.append(x)   
    print(actuals_columns_req_1)
    print(actuals_columns_req)
    try:
        actuals_columns_req.remove("Program Name")
    except:
        pass
    try:
        actuals_columns_req.remove("PPMO Program Manager")
    except:
        pass
    converterS = {col: int for col in actuals_columns_req}
    email=pd.read_excel(f1,sheet_name='email',converters=converterS)
    actuals = pd.read_excel(f1,sheet_name='Actuals',converters=converterS)
    print(actuals_columns_req_1)
    print(actuals_columns_req)
    email=email[actuals_columns_req_1]
    actuals=actuals[actuals_columns_req_1]
    print(str(len(actuals_columns_req_1))+" after filtering with email columns")
    validation(actuals,email,actuals_columns_req_1,"Program Code","Actuals")

def actuals_validation():
    email=pd.read_excel(f1,sheet_name='email')
    email_columns=list(email.columns)
    actuals = pd.read_excel(f1,sheet_name='Actuals')
    actuals_columns=list(actuals.columns)
    print(str(len(actuals_columns))+" before filtering with email columns")
    actuals_columns_req=[]
    actuals_columns_req_1=[]
    for x in actuals_columns:
        if x in email_columns:
            actuals_columns_req.append(x) 
            actuals_columns_req_1.append(x)   
    # print(actuals_columns_req_1)
    # print(actuals_columns_req)
    try:
        actuals_columns_req.remove("Program Name")
    except:
        pass
    try:
        actuals_columns_req.remove("PPMO Program Manager")
    except:
        pass
    converterS_e = {col: str for col in email_columns}
    converterS_f = {col: str for col in actuals_columns}
    email=pd.read_excel(f1,sheet_name='email',converters=converterS_e)
    actuals = pd.read_excel(f1,sheet_name='Actuals',converters=converterS_f)
    # print(actuals_columns_req_1)
    # print(actuals_columns_req)
    email=email[actuals_columns_req_1]
    actuals=actuals[actuals_columns_req_1]
    for x in actuals_columns_req_1:
        try:
            actuals[x]=actuals[x].apply(int)   
            email[x]=email[x].apply(int)  
        except: 
            actuals[x]=actuals[x].apply(str)   
            email[x]=email[x].apply(str) 

    print(str(len(actuals_columns_req_1))+" after filtering with email columns")
    validation(actuals,email,actuals_columns_req_1,"Program Code","Actuals")


def forecast_validation():
    email=pd.read_excel(f1,sheet_name='email')
    email_columns=list(email.columns)
    actuals = pd.read_excel(f1,sheet_name='Forecast')
    actuals_columns=list(actuals.columns)
    print(str(len(actuals_columns))+" before filtering with email columns")
    actuals_columns_req=[]
    actuals_columns_req_1=[]
    for x in actuals_columns:
        if x in email_columns:
            actuals_columns_req.append(x) 
            actuals_columns_req_1.append(x)   
    # print(actuals_columns_req_1)
    # print(actuals_columns_req)
    try:
        actuals_columns_req.remove("Program Name")
    except:
        pass
    try:
        actuals_columns_req.remove("PPMO Program Manager")
    except:
        pass
    converterS_e = {col: str for col in email_columns}
    converterS_f = {col: str for col in actuals_columns}
    email=pd.read_excel(f1,sheet_name='email',converters=converterS_e)
    actuals = pd.read_excel(f1,sheet_name='Forecast',converters=converterS_f)
    # print(actuals_columns_req_1)
    # print(actuals_columns_req)
    email=email[actuals_columns_req_1]
    actuals=actuals[actuals_columns_req_1]
    for x in actuals_columns_req_1:
        try:
            actuals[x]=actuals[x].apply(int)   
            email[x]=email[x].apply(int)  
        except: 
            actuals[x]=actuals[x].apply(str)   
            email[x]=email[x].apply(str) 

    print(str(len(actuals_columns_req_1))+" after filtering with email columns")
    validation(actuals,email,actuals_columns_req_1,"Program Code","Forecast")

def remaining_validation():
    email=pd.read_excel(f1,sheet_name='email')
    email_columns=list(email.columns)
    actuals = pd.read_excel(f1,sheet_name='remaining')
    actuals_columns=list(actuals.columns)
    print(str(len(actuals_columns))+" before filtering with email columns")
    actuals_columns_req=[]
    actuals_columns_req_1=[]
    for x in actuals_columns:
        if x in email_columns:
            actuals_columns_req.append(x) 
            actuals_columns_req_1.append(x)   
    # print(actuals_columns_req_1)
    # print(actuals_columns_req)
    try:
        actuals_columns_req.remove("Program Name")
    except:
        pass
    try:
        actuals_columns_req.remove("PPMO Program Manager")
    except:
        pass
    converterS_e = {col: str for col in email_columns}
    converterS_f = {col: str for col in actuals_columns}
    email=pd.read_excel(f1,sheet_name='email',converters=converterS_e)
    actuals = pd.read_excel(f1,sheet_name='remaining',converters=converterS_f)
    # print(actuals_columns_req_1)
    # print(actuals_columns_req)
    email=email[actuals_columns_req_1]
    actuals=actuals[actuals_columns_req_1]
    for x in actuals_columns_req_1:
        try:
            actuals[x]=actuals[x].apply(int)   
            email[x]=email[x].apply(int)  
        except: 
            actuals[x]=actuals[x].apply(str)   
            email[x]=email[x].apply(str) 

    print(str(len(actuals_columns_req_1))+" after filtering with email columns")
    validation(actuals,email,actuals_columns_req_1,"Program Code","remaining")

actuals_validation()
forecast_validation()
remaining_validation()

# email=pd.read_excel(f1,sheet_name='email')
# email_columns=list(email.columns)
# print(email_columns)
# actuals = pd.read_excel(f1,sheet_name='Forecast')
# actuals_columns=list(actuals.columns)
# print(actuals_columns)