cur_lst=['year', 'month', 'week', 'market', 'business_segment_adj','product_desc', 'ACO_NAME', 'flu_indicator', 'Admit_Type', 'Case_Type','Treatmt_Setting', 'entity_adj', 'mkt_region','mbr_minor_mkt','mbr_state', 'Hosp_Provkey', 'outlier_flag', 'Funding_Arrangement','ip_admit', 'ip_discharge', 'SNF_admit', 'snf_discharge', 'ip_snf','snf_ip','readmit_flag', 'ad1d_flg', 'index_acute', 'ip_day','SNF_day', 'index_acute_readmit30']
crct_lst=["year","month","week","market","business_segment_adj","product_desc","ACO_NAME","flu_indicator","admit_type","Case_Type","Treatmt_Setting","entity_adj","mkt_region","mbr_minor_mkt","mbr_state","Hosp_Provkey","outlier_flag","Funding_Arrangement","ip_admit","ip_discharge","SNF_admit","snf_discharge","ip_snf","snf_ip","readmit_flag","ad1d_flg","index_acute","ip_day","SNF_day","index_acute_readmit30"]

print(str(len(crct_lst)))
print(str(len(cur_lst)))

for i in range(0,len(crct_lst)):
    if crct_lst[i]==cur_lst[i]:
        junk=1
    else:
        print("correct one="+crct_lst[i]+"]t current one="+cur_lst[i])

