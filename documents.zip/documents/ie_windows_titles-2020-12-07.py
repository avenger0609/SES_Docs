import win32gui
import subprocess
import time


def enumWindowsProc(hwnd, lParam):
    if str(win32gui.GetWindowText(hwnd)).startswith('WAT (Workforce Activity Tracker)'):
        fp.write(str(win32gui.GetWindowText(hwnd))+"\n")    

def main():   
    
    wat_check_flag=-1  
    global fp
    fp=open(r'c:\users\asrilekh\documents\ie_wat_test.txt','w')  
    win32gui.EnumWindows(enumWindowsProc, 0)
    fp.close()    
    fp1=open(r'c:\users\asrilekh\documents\ie_wat_test.txt','r')
    lines=fp1.readlines()
    for li in lines:
        if str(li).startswith('WAT (Workforce Activity Tracker)'):
            wat_check_flag=1
            print('wat window active')        
    print(wat_check_flag)

    if wat_check_flag <=0:         
        subprocess.Popen('"C:\\Program Files (x86)\\Internet Explorer\\iexplore.exe" http://lighthouse.uhc.com/')       

while(True):
    main()
    time.sleep(900)
    