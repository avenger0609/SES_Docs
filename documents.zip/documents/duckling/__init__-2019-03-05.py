from .duckling import Duckling
from .dim import Dim
from .language import Language
from .wrapper import DucklingWrapper

