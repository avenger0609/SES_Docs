import pandas as pd

# Read in the two files but call the data old and new and create columns to track
old = pd.read_excel('C:\\Users\\asrilekh\\Desktop\\work\\swing analysis\\using odbc\\July\\Citrix - Mgd_OPTUM_1907_extracted.xlsx', na_values=['N/A'])
new = pd.read_excel('C:\\Users\\asrilekh\\Desktop\\work\\swing analysis\\using odbc\\July\\Citrix - Mgd_OPTUM_1906_extracted.xlsx', na_values=['N/A'])
old['version'] = "old"
new['version'] = "new"
old_accts_all = set(old['SUI (Service Unique Identifier)'])
new_accts_all = set(new['SUI (Service Unique Identifier)'])

dropped_accts = old_accts_all - new_accts_all
added_accts = new_accts_all - old_accts_all
all_data = pd.concat([old,new],ignore_index=True)
changes = all_data.drop_duplicates(subset=["RowID","Accting Period","VolumeYearMonth","Date Of Chargeback","DivisionID","Service Group","Service Group Cost Center","Service Code Desc","Service Code","Bill Name","Billing Code","CURRENT Bill Code Status","SUI (Service Unique Identifier)","SUI Description","Service Physical","Service Virtual","Original App Name Comment","TMDB App Name - Short","TMDB Search Code","Published","Project Number","Project_Name","Project_Manager","Service Request Number","Service Delivery Date","Requestor / Contact","Segment","GL BU","GL OU","GL LOC","GL ACCT","GL DEPT","ConsumingServiceGroup","GL PROD","GL CUST","GL PID","Submitted Service Units","Adjusted Service Units","Submitted Service Storage","Adjusted Service Storage","AdjSanOrAdjStorage","San_Cost","BaseService_Cost","Prod/NonProd","Environment Code","Data Center Code","DR Mates","DR Code","Network Zone","Storage Change Reason","Service Requestor","Service Request Description","Service Requestor Email","Service Request Create Date","Service Request Type","Service Parent Request ID","Service Parent Requestor","Service Parent Requestor Email","Service Parent Description","Service Parent Create Date","Service Parent Request Type","Project Name","Project Requestor","Project Manager","Prj Prompt ID","Prj Application Name","Prj GL Code Owner","TMDB App Name - Long","ASK Global App ID","Compute Unit Pct CPU","Compute Unit Pct RAM","CPU Allocated","CPU Average Util Pct","CPU Peak Util Pct","RAM Allocated","RAM Average Util Pct","RAM Peak Util Pct","Pct Uptime","CB Feed Name","FileKey","RecordID","TransactionCycleKey","FileOutput","OutputYesNo","RateTypeID","Rate Charge/Unit","UnitCost","Adjusted Service Cost","AdjUnitCost_presplit","Storage Rate","StorageCost","Adjusted Service Storage Cost","AdjStorageCost_presplit","Rate Type","GL Source","App Source","Project Source","Unit Cap","Unit Floor","Unit Multiplier","UOM"], keep='last')
dupe_accts = changes[changes['SUI (Service Unique Identifier)'].duplicated() == True]['SUI (Service Unique Identifier)'].tolist()
dupes = changes[changes["SUI (Service Unique Identifier)"].isin(dupe_accts)]
# Pull out the old and new data into separate dataframes
change_new = dupes[(dupes["version"] == "new")]
change_old = dupes[(dupes["version"] == "old")]

# Drop the temp columns - we don't need them now
change_new = change_new.drop(['version'], axis=1)
change_old = change_old.drop(['version'], axis=1)

# Index on the account numbers
change_new.set_index('SUI (Service Unique Identifier)', inplace=True)
change_old.set_index('SUI (Service Unique Identifier)', inplace=True)

# Combine all the changes together
df_all_changes = pd.concat([change_old, change_new],
                            axis='columns',
                            keys=['old', 'new'],
                            join='outer')
# Define the diff function to show the changes in each field
def report_diff(x):
    return x[0] if x[0] == x[1] else '{} ---> {}'.format(*x)
df_all_changes = df_all_changes.swaplevel(axis='columns')[change_new.columns[0:]]
df_changed = df_all_changes.groupby(level=0, axis=1).apply(lambda frame: frame.apply(report_diff, axis=1))
df_changed = df_changed.reset_index()
df_removed = changes[changes["SUI (Service Unique Identifier)"].isin(dropped_accts)]
df_added = changes[changes["SUI (Service Unique Identifier)"].isin(added_accts)]
output_columns = ["RowID","Accting Period","VolumeYearMonth","Date Of Chargeback","DivisionID","Service Group","Service Group Cost Center","Service Code Desc","Service Code","Bill Name","Billing Code","CURRENT Bill Code Status","SUI (Service Unique Identifier)","SUI Description","Service Physical","Service Virtual","Original App Name Comment","TMDB App Name - Short","TMDB Search Code","Published","Project Number","Project_Name","Project_Manager","Service Request Number","Service Delivery Date","Requestor / Contact","Segment","GL BU","GL OU","GL LOC","GL ACCT","GL DEPT","ConsumingServiceGroup","GL PROD","GL CUST","GL PID","Submitted Service Units","Adjusted Service Units","Submitted Service Storage","Adjusted Service Storage","AdjSanOrAdjStorage","San_Cost","BaseService_Cost","Prod/NonProd","Environment Code","Data Center Code","DR Mates","DR Code","Network Zone","Storage Change Reason","Service Requestor","Service Request Description","Service Requestor Email","Service Request Create Date","Service Request Type","Service Parent Request ID","Service Parent Requestor","Service Parent Requestor Email","Service Parent Description","Service Parent Create Date","Service Parent Request Type","Project Name","Project Requestor","Project Manager","Prj Prompt ID","Prj Application Name","Prj GL Code Owner","TMDB App Name - Long","ASK Global App ID","Compute Unit Pct CPU","Compute Unit Pct RAM","CPU Allocated","CPU Average Util Pct","CPU Peak Util Pct","RAM Allocated","RAM Average Util Pct","RAM Peak Util Pct","Pct Uptime","CB Feed Name","FileKey","RecordID","TransactionCycleKey","FileOutput","OutputYesNo","RateTypeID","Rate Charge/Unit","UnitCost","Adjusted Service Cost","AdjUnitCost_presplit","Storage Rate","StorageCost","Adjusted Service Storage Cost","AdjStorageCost_presplit","Rate Type","GL Source","App Source","Project Source","Unit Cap","Unit Floor","Unit Multiplier","UOM"]
writer = pd.ExcelWriter("my-diff1.xlsx")
df_changed.to_excel(writer,"changed", index=False, columns=output_columns)
df_removed.to_excel(writer,"removed",index=False, columns=output_columns)
df_added.to_excel(writer,"added",index=False, columns=output_columns)
writer.save()
print("completed")