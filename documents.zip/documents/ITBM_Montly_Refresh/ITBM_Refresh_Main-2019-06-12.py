import datetime
import calendar
import os 
import shutil
from dateutil.relativedelta import relativedelta
from outgng_prd_recent_file import *
from MPWR_78000_DFITBM import *
from MPWR_78001_DFITBM import *
from MPWR_78002_DFITBM_PC import *
from MPWR_78002_DFITBM_SS import *
from MPWR_78008_DFITBM import *
from MPWR_78009_DFITBM import *
from MPWR_78012_DFITBM import *
from MPWR_78017_DFITBM import *
from MPWR_78022_DFITBM import *
from MPWR_78024_DFITBMLABOR import *
from MPWR_78025_DFITBM import *
from MPWR_78026_DFITBM import *
from MPWR_78027_DFITBM import *
from MPWR_78028_DFITBM import *
from MPWR_78031_DFITBM import *
from MPWR_78032_DFITBM import *
from MPWR_78033_DFITBM import *
from MPWR_78034_DFITBM import *
from MPWR_78035_DFITBM import *
from MPWR_78036_DFITBM import *
from MPWR_78045_DFITBM import *
from rate_card_file import *
from pstree_download import *
from OU_Dimension_file_gen import *
# from OU_names_file_to_csv import *
# from TRM_Utilization_File import *
from TRM_Utilization_Gen import *
from Ou_Names_Gen import *
## creating folder for current month ##
try:
    os.makedirs('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+str(calendar.month_name[datetime.datetime.now().month]))
except:
    junk=1
## creating folder for current month ##
mon_name=str(calendar.month_name[datetime.datetime.now().month])

##last month along with year

try:
    last_month = datetime.datetime.now() - relativedelta(months=1)
    text = format(last_month, '%y%m')
    print("previous month and year is "+text)
except:
    print("error: while retrieving previous month and year")
prev_mon_yr=text

##last month along with year

# mon_name='April'
# prev_mon_yr='1903'


### copy recent file from outgoing folder to required folder( this month )

Outgoing_Prod_rec_file(mon_name)

### copy recent file from outgoing folder to required folder( this month )

### MPWR Files generation ###

mpwr_78000_dfitbm(mon_name,prev_mon_yr)
mpwr_78001_dfitbm(mon_name,prev_mon_yr)
mpwr_78002_dfitbm_pc(mon_name,prev_mon_yr)
mpwr_78002_dfitbm_ss(mon_name,prev_mon_yr)
mpwr_78008_dfitbm(mon_name,prev_mon_yr)
mpwr_78009_dfitbm(mon_name,prev_mon_yr)
mpwr_78012_dfitbm(mon_name,prev_mon_yr)
mpwr_78017_dfitbm(mon_name,prev_mon_yr)
mpwr_78022_dfitbm(mon_name,prev_mon_yr)
mpwr_78024_dfitbm(mon_name,prev_mon_yr)
mpwr_78025_dfitbm(mon_name,prev_mon_yr)
mpwr_78026_dfitbm(mon_name,prev_mon_yr)
mpwr_78027_dfitbm(mon_name,prev_mon_yr)
mpwr_78028_dfitbm(mon_name,prev_mon_yr)
mpwr_78031_dfitbm(mon_name,prev_mon_yr)
mpwr_78032_dfitbm(mon_name,prev_mon_yr)
mpwr_78033_dfitbm(mon_name,prev_mon_yr)
mpwr_78034_dfitbm(mon_name,prev_mon_yr)
mpwr_78035_dfitbm(mon_name,prev_mon_yr)
mpwr_78036_dfitbm(mon_name,prev_mon_yr)
mpwr_78045_dfitbm(mon_name,prev_mon_yr)

### MPWR Files generation ###

### copy recent file from rate card folder to required folder( this month )

rate_card_rec_file(mon_name,prev_mon_yr)

### copy recent file from rate card folder to required folder( this month )

### ps tree file download

pstree_file_dwnld(mon_name)

### ps tree file download

##### ou dimension file generation
ou_dim_file(mon_name,prev_mon_yr)
##### ou dimension file generation

## ou names files generation
# ou_names(mon_name,prev_mon_yr)
OU_Names(mon_name,prev_mon_yr)
## ou names files generation

### trm utilization file generation
# trm_utilization(mon_name,prev_mon_yr)
qry_trm_utilization(mon_name,prev_mon_yr)
### trm utilization file generation

### creating rchive folder

shutil.make_archive('c:\\users\\asrilekh\\documents\\ITBM_Montly_Refresh\\'+mon_name, 'zip', 'C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name)

### creating rchive folder