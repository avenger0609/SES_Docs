import glob
import os
from shutil import copyfile

def rate_card_rec_file(mon_name,prev_mon_yr):
    try:
        list_of_files = glob.glob('\\\\NAS00038pn\\data\\Tech_Economics\\VMWare_ITBM\\Outgoing_Prod\\ratecard\\*') # * means all if need specific format then *.csv
        latest_file = max(list_of_files, key=os.path.getctime)
        print (latest_file+" is recent file from rate card folder")        
        copyfile(latest_file, 'C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+latest_file.split('\\')[len(latest_file.split('\\'))-1])
        fname=str(prev_mon_yr)+str(latest_file.split('\\')[len(latest_file.split('\\'))-1])[4:]
        os.rename('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+latest_file.split('\\')[len(latest_file.split('\\'))-1],'C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+fname)
    except Exception as e:
        print("error while retrieving recent file from rate card folder"+str(e))

# rate_card_rec_file("June","1905")