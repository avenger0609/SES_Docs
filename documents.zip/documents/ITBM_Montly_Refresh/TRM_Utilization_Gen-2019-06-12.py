import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3

def qry_trm_utilization(mon_name,prev_mon_yr):
    try:
        print("started generating files for mpwr trm utilization file")
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=TRMDB-PROD;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)        
        sql_string="SELECT concat('20' , Left('"+str(prev_mon_yr)+"',2)) AS CURRENT_YEAR, Right('"+str(prev_mon_yr)+"',2) AS CURRENT_MONTH, dbo.CB_UtilizationFeed.ServiceVirtual, dbo.CB_UtilizationFeed.ComputeUnit, dbo.CB_UtilizationFeed.CPUConsumed, dbo.CB_UtilizationFeed.RAMConsumed, dbo.CB_UtilizationFeed.PctUptime, dbo.CB_UtilizationFeed.RAMAllocated, dbo.CB_UtilizationFeed.RAMAverageUtilPct, dbo.CB_UtilizationFeed.RAMPeakUtilPct, dbo.CB_UtilizationFeed.CPUAllocated, dbo.CB_UtilizationFeed.CPUAverageUtilPct, dbo.CB_UtilizationFeed.CPUPeakUtilPct, dbo.CB_UtilizationFeed.StorageAllocated, dbo.CB_UtilizationFeed.StorageAverageUtilPct, dbo.CB_UtilizationFeed.StoragePeakUtilPct, dbo.CB_UtilizationFeed.RowInsertDate, dbo.CB_UtilizationFeed.FileKey, dbo.CB_UtilizationFeed.TransactionCycleKey, dbo.CB_UtilizationFeed.GroupID, dbo.CB_UtilizationFeed.RecordID, dbo.CB_UtilizationFeed.ComputeUnitCPU, dbo.CB_UtilizationFeed.ComputeUnitRAM, dbo.CB_UtilizationFeed.ComputeUnitPctCPU, dbo.CB_UtilizationFeed.ComputeUnitPctRAM  FROM dbo.CB_UtilizationFeed where dbo.CB_UtilizationFeed.TransactionCycleKey in (SELECT dbo.CB_UtilizationFeed.TransactionCycleKey FROM dbo.CB_UtilizationFeed where concat(Right(Year(dbo.CB_UtilizationFeed.RowInsertDate),2) , Format(Month(dbo.CB_UtilizationFeed.RowInsertDate),'00'))='"+str(prev_mon_yr)+"' GROUP BY dbo.CB_UtilizationFeed.TransactionCycleKey, concat(Right(Year(dbo.CB_UtilizationFeed.RowInsertDate),2) , Format(Month(dbo.CB_UtilizationFeed.RowInsertDate),'00')) )" 
        df = pd.read_sql_query(sql_string, engine)
        print(str(len(df)))
        print("data fetched") 
        db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
        con = sqlite3.connect(db_file)
        df.to_sql("tbl_trmcbsource", con, if_exists='replace', index=False)
        print("trmdbc source inserted")
        sql_string="SELECT * from tbl_trmcbsource ;"
        df = pd.read_sql_query(sql_string, con)
        # for col_i in df.columns:
        #     if col_i not in ['RowInsertDate']:
        #         # try:
        #         #     df[col_i]=df[col_i].apply(int) 
        #         # except:
        #         #     df[col_i]=df[col_i].apply(str) 
        #         df[col_i]=df[col_i].apply(str) 
        df['PctUptime']=df['PctUptime'].apply(int)
        df['RowInsertDate']=pd.to_datetime(df['RowInsertDate'], format='%Y-%m-%d %H:%M:%S') 
        for name, dtype in df.dtypes.iteritems():
            print(name+"--"+str(dtype))
        # pd.to_numeric       
        df.to_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_TRM_UtilizationData.csv',index=False,quoting=csv.QUOTE_NONE,date_format="%m/%d/%Y %H:%M:%S")
        
    except Exception as e:
        print("error while generating trm utilization File for 78000 DFITBM"+str(e))

# qry_trm_utilization('March','1902')


# def qry_trm_utilization(mon_name,prev_mon_yr):
#     try:
#         print("started generating files for mpwr trm utilization file")
#         params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=TRMDB-PROD;Database=TRMDB;Trusted_Connection=yes;')
#         engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
#         # sql_string="SELECT concat('20', Left('"+str(prev_mon_yr)+"',2)) AS CURRENT_YEAR, Right('"+str(prev_mon_yr)+"',2) AS CURRENT_MONTH, dbo.CB_UtilizationFeed.ServiceVirtual, dbo.CB_UtilizationFeed.ComputeUnit, dbo.CB_UtilizationFeed.CPUConsumed, dbo.CB_UtilizationFeed.RAMConsumed, dbo.CB_UtilizationFeed.PctUptime, dbo.CB_UtilizationFeed.RAMAllocated, dbo.CB_UtilizationFeed.RAMAverageUtilPct, dbo.CB_UtilizationFeed.RAMPeakUtilPct, dbo.CB_UtilizationFeed.CPUAllocated, dbo.CB_UtilizationFeed.CPUAverageUtilPct, dbo.CB_UtilizationFeed.CPUPeakUtilPct, dbo.CB_UtilizationFeed.StorageAllocated, dbo.CB_UtilizationFeed.StorageAverageUtilPct, dbo.CB_UtilizationFeed.StoragePeakUtilPct, dbo.CB_UtilizationFeed.RowInsertDate, dbo.CB_UtilizationFeed.FileKey, dbo.CB_UtilizationFeed.TransactionCycleKey, dbo.CB_UtilizationFeed.GroupID, dbo.CB_UtilizationFeed.RecordID, dbo.CB_UtilizationFeed.ComputeUnitCPU, dbo.CB_UtilizationFeed.ComputeUnitRAM, dbo.CB_UtilizationFeed.ComputeUnitPctCPU, dbo.CB_UtilizationFeed.ComputeUnitPctRAM FROM dbo.CB_UtilizationFeed where concat(Right(Year(dbo.CB_UtilizationFeed.RowInsertDate),2) ,Format(Month(dbo.CB_UtilizationFeed.RowInsertDate),'00'))='"+str(prev_mon_yr)+"' ;"
#         sql_string="SELECT concat('20' , Left('"+str(prev_mon_yr)+"',2)) AS CURRENT_YEAR, Right('"+str(prev_mon_yr)+"',2) AS CURRENT_MONTH, dbo.CB_UtilizationFeed.ServiceVirtual, dbo.CB_UtilizationFeed.ComputeUnit, dbo.CB_UtilizationFeed.CPUConsumed, dbo.CB_UtilizationFeed.RAMConsumed, dbo.CB_UtilizationFeed.PctUptime, dbo.CB_UtilizationFeed.RAMAllocated, dbo.CB_UtilizationFeed.RAMAverageUtilPct, dbo.CB_UtilizationFeed.RAMPeakUtilPct, dbo.CB_UtilizationFeed.CPUAllocated, dbo.CB_UtilizationFeed.CPUAverageUtilPct, dbo.CB_UtilizationFeed.CPUPeakUtilPct, dbo.CB_UtilizationFeed.StorageAllocated, dbo.CB_UtilizationFeed.StorageAverageUtilPct, dbo.CB_UtilizationFeed.StoragePeakUtilPct, dbo.CB_UtilizationFeed.RowInsertDate, dbo.CB_UtilizationFeed.FileKey, dbo.CB_UtilizationFeed.TransactionCycleKey, dbo.CB_UtilizationFeed.GroupID, dbo.CB_UtilizationFeed.RecordID, dbo.CB_UtilizationFeed.ComputeUnitCPU, dbo.CB_UtilizationFeed.ComputeUnitRAM, dbo.CB_UtilizationFeed.ComputeUnitPctCPU, dbo.CB_UtilizationFeed.ComputeUnitPctRAM  FROM dbo.CB_UtilizationFeed where dbo.CB_UtilizationFeed.TransactionCycleKey in (SELECT dbo.CB_UtilizationFeed.TransactionCycleKey FROM dbo.CB_UtilizationFeed where concat(Right(Year(dbo.CB_UtilizationFeed.RowInsertDate),2) , Format(Month(dbo.CB_UtilizationFeed.RowInsertDate),'00'))='"+str(prev_mon_yr)+"' GROUP BY dbo.CB_UtilizationFeed.TransactionCycleKey, concat(Right(Year(dbo.CB_UtilizationFeed.RowInsertDate),2) , Format(Month(dbo.CB_UtilizationFeed.RowInsertDate),'00')) )" 
#         df = pd.read_sql_query(sql_string, engine)
#         print(str(len(df)))
#         print("data fetched") 
#         df['RowInsertDate']=pd.to_datetime(df['RowInsertDate'], format='%Y-%m-%d %H:%M:%S') 
#         # pd.to_numeric       
#         df.to_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_TRM_UtilizationData.csv',index=False,quoting=csv.QUOTE_NONE,date_format="%#m/%#d/%Y %H:%M:%S")
        
#     except Exception as e:
#         print("error while generating trm utilization File for 78000 DFITBM"+str(e))

