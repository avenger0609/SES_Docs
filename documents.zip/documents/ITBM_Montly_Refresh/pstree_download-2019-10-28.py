## worked ###
## pre-requisite= need to get chrome driver installed from appstore
from shutil import copyfile
from selenium import webdriver
import glob
import os
import time

def pstree_file_dwnld(mon_name):
    try:
        ############# download file from URL #################
        driverpath = "C:\\ProgramData\\Chrome_driver_76.0.3809.68\\chromedriver.exe"
        chromeOptions = webdriver.ChromeOptions()
        chromeOptions.add_experimental_option('useAutomationExtension', False) ## to stop displaying error messages from chrome
        driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
        # driver = webdriver.Chrome("C:\\ProgramData\\Chrome_driver_2.46\\chromedriver.exe")
        driver.get("http://cfrservices.uhg.com/Info/TreeReport")
        driver.find_element_by_link_text('UHG_OPERATING_UNIT_GEN_PSTREE.csv').click()
        time.sleep(30)
        ############# download file from URL #################
        ############# get file name of downloaded file ###########################
        list_of_files = glob.glob('C:\\Users\\asrilekh\\Downloads\\*.csv') # * means all if need specific format then *.csv
        latest_file = max(list_of_files, key=os.path.getctime)
        print (latest_file)
        latest_fn=latest_file.split('\\')[len(latest_file.split('\\'))-1]
        if '(' in latest_fn:
            latest_fn=(latest_fn.split('(')[0].strip(' ')+".csv")
        else:
            latest_fn=latest_fn
        print(latest_fn)
        ############# get file name of downloaded file ###########################
        copyfile(latest_file, 'C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+latest_fn)
    except:
        print("error downloading pstree file")

# pstree_file_dwnld('March')