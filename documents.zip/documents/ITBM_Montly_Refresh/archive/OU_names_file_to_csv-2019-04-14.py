import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv

def ou_names(mon_name,prev_mon_yr):
    try:
        params = quote_plus(r'Driver={SQL Server};Server=TRMDB-PROD;Database=TRMDB;Trusted_Connection=yes;')

        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)

        sql_string="SELECT dbo.GL_OU_staging.GL_OU AS oper_unit, dbo.GL_OU_staging.BusinessUnitDescription AS ShortDescription, dbo.GL_OU_staging.BusinessSegmentName AS LongDescription, dbo.GL_OU_staging.EffectiveStatus, dbo.GL_OU_staging.RowInsertDate FROM dbo.GL_OU_staging;"

        final_data_fetch = pd.read_sql_query(sql_string, engine)

        final_data_fetch.to_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+' _OU_Names.csv',index=False,quoting=csv.QUOTE_ALL)
    except:
        print("error in generation ou names file")
