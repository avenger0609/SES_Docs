import pandas as pd
import xlsxwriter
import os
from datetime import datetime
import chardet

files_list=list()
for entry in os.scandir('C:\\Users\\asrilekh\\Desktop\\August-Test'):
    if entry.is_file():
        if ".csv" in str(entry.name).lower() and "VM Ware_DISPLAY_NAME_" in str(entry.name):
            files_list.append(entry.name)

flen=0
for fname in files_list:
    print(fname)
    try:        
        cdf=pd.read_csv('C:\\Users\\asrilekh\\Desktop\\August-Test\\'+fname,encoding = 'latin-1')
        flen=flen+len(cdf)
    except Exception as e:
        print(str(e))
print(str(flen))