import os
from compare_csv_files import *
for entry in os.scandir('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\June_test'):
    if entry.is_file():
        print(entry.name)
        try:
            f1='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\June\\'+entry.name
            f2='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\June_test\\'+entry.name
            compare_csv(f1,f2)
        except Exception as e:
        # else:
            print("exception "+str(e))
       