import glob
import os
from shutil import copyfile
import pandas as pd
import sqlite3
import csv
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell
import subprocess, sys

def ou_dim_file(mon_name,prev_mon_yr):

    try:

        ### retrieving ps tree file name ############
        pstree_name=""
        for entry in os.scandir('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name):
            if entry.is_file() and str(entry.name).upper().startswith('UHG_OPERATING_UNIT_GEN_PSTREE'):
                print(entry.name)
                pstree_name=entry.name

        ### retrieving ps tree file name ############
        # pstree_name='UHG_OPERATING_UNIT_GEN_PSTREE_20190412-203104.csv'
        if pstree_name=="":
            print("pstree file not downloaded")
        else:
            print('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+pstree_name)
            cdf=pd.read_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+pstree_name)
            db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\ou_dimension.db"
            con = sqlite3.connect(db_file)
            cdf.to_sql("ou_dim_tbl", con, if_exists='replace', index=False)
            stmt="select distinct LEVEL1_DESCR from ou_dim_tbl"
            # cur=con.cursor()
            # cur.execute(stmt)
            # s=cur.fetchall()
            # print(s)
            # cur.close()
            stmt="select LEVEL1_DESCR,LEVEL2_DESCR,LEVEL3_DESCR,LEVEL4_DESCR,LEVEL5_DESCR,LEVEL6_DESCR,LEVEL7_DESCR,LEVEL8_DESCR,LEVEL9_DESCR,LEVEL10_DESCR,LEVEL11_DESCR,LEVEL12_DESCR,DETAIL_NUM,DETAIL_DESCR,TREE_NAME,LOAD_DTTM from ou_dim_tbl where DETAIL_NUM NOT IN (' ','  ','   ','    ','     ','      ','       ','        ','         ') AND TRIM(DETAIL_NUM) IS NOT NULL AND UPPER(LEVEL1_DESCR) NOT IN('NON UNITEDHEALTH GROUP ROLLUP')" 
            df = pd.read_sql_query(stmt, con)
            print(str(len(df)))
            df.to_excel('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_OU_Dimension.xlsx',sheet_name='PSTREE',index=False)
            con.commit()
            con.close()
            opwb=openpyxl.load_workbook('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_OU_Dimension.xlsx')    
            opsheet_w=opwb.create_sheet(title='Step1_copyOverBlankLevels')    
            opsheet_w.cell(1,1,'L1_DESC') ## deriving first column
            for i in range(0,len(df)):
                j=i+2
                opsheet_w.cell(j,1,'=IF(PSTREE!A'+str(j)+'=0,$H'+str(j)+'&" - "&$I'+str(j)+',PSTREE!A'+str(j)+')')
            opsheet_w.cell(1,2,'L2_DESC')
            for i in range(0,len(df)): # deriving second column
                j=i+2
                opsheet_w.cell(j,2,'=IF(PSTREE!B'+str(j)+'=0,$H'+str(j)+'&" - "&$I'+str(j)+',PSTREE!B'+str(j)+')')
            opsheet_w.cell(1,3,'L3_DESC')
            for i in range(0,len(df)): # deriving third column
                j=i+2
                opsheet_w.cell(j,3,'=IF(PSTREE!C'+str(j)+'=0,$H'+str(j)+'&" - "&$I'+str(j)+',PSTREE!C'+str(j)+')')
            opsheet_w.cell(1,4,'L4_DESC') ## deriving fourth column
            for i in range(0,len(df)):
                j=i+2
                opsheet_w.cell(j,4,'=IF(PSTREE!D'+str(j)+'=0,$H'+str(j)+'&" - "&$I'+str(j)+',PSTREE!D'+str(j)+')')
            opsheet_w.cell(1,5,'L5_DESC')
            for i in range(0,len(df)): # deriving fifth column
                j=i+2
                opsheet_w.cell(j,5,'=IF(PSTREE!E'+str(j)+'=0,$H'+str(j)+'&" - "&$I'+str(j)+',PSTREE!E'+str(j)+')')
            opsheet_w.cell(1,6,'L6_DESC')
            for i in range(0,len(df)): # deriving sixth column
                j=i+2
                opsheet_w.cell(j,6,'=IF(PSTREE!F'+str(j)+'=0,$H'+str(j)+'&" - "&$I'+str(j)+',PSTREE!F'+str(j)+')')
            opsheet_w.cell(1,7,'L7_OU_CONCAT')
            for i in range(0,len(df)): # deriving seventh column
                j=i+2
                opsheet_w.cell(j,7,'=$H'+str(j)+'&" - "&$I'+str(j)+'')
            opsheet_w.cell(1,8,'DETAIL_NUM')
            for i in range(0,len(df)): # deriving eighth column
                j=i+2
                opsheet_w.cell(j,8,'=IF(TEXT(PSTREE!M'+str(j)+',"00000")="00000","",TEXT(PSTREE!M'+str(j)+',"00000"))')
            opsheet_w.cell(1,9,'DETAIL_DESCR')
            for i in range(0,len(df)): # deriving eighth column
                j=i+2
                opsheet_w.cell(j,9,'=IF(PSTREE!N'+str(j)+'=0,"",PSTREE!N'+str(j)+')')    
            opsheet_w=opwb.create_sheet(title=prev_mon_yr+'_OU_Dimension')   
            opwb.save('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_OU_Dimension.xlsx')
            opwb.close() 
            p = subprocess.Popen(["powershell.exe","C:\\Users\\asrilekh\\documents\\ITBM_Montly_Refresh\\copy_cells_excel_ps.ps1"],stdout=sys.stdout)
            p.communicate()   
            df = pd.read_excel('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_OU_Dimension.xlsx',sheet_name=2)
            converterS = {col: str for col in df.columns}
            df = pd.read_excel('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_OU_Dimension.xlsx',sheet_name=2,converters=converterS)
            print(df)
            df.to_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_OU_Dimension.csv',index=False)
    except:
        print("error in generating ou dimension file")

ou_dim_file('October','1909')