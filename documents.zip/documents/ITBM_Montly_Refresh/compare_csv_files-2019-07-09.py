import pandas as pd
import xlsxwriter
from datetime import datetime
def compare_csv(f1,f2):
    # print("entered")
    # f1='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\April\\UHG_OPERATING_UNIT_GEN_PSTREE_20190412-203104.csv'
    # f2='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\April\\UHG_OPERATING_UNIT_GEN_PSTREE_20190412-203104.csv'
       
    cdf1=pd.read_csv(f1,encoding='latin-1')
    cdf2=pd.read_csv(f2,encoding='latin-1')
    converterS = {col: str for col in cdf1.columns}
    cdf1=pd.read_csv(f1,encoding='latin-1',converters=converterS)
    converterS = {col: str for col in cdf2.columns}
    cdf2=pd.read_csv(f2,encoding='latin-1',converters=converterS)
    print(str(cdf1.columns))
    print(str(cdf2.columns))
    # cdf1.columns=cdf1.columns.str.strip()
    # cdf2.columns=cdf2.columns.str.strip()
    try:
        cdf1.sort_values(["CS_SERVICE_UNIQUE_IDENTIFIER","CS_SUI_DESCRIPTION","CS_Billing_CODE","SERVICE","SEGMENT","PROJECT_NAME","CS_CB_UNIQUE_KEY","GL_PROJECT","GL_BU","GL_OP_UNIT","GL_DEPT","GL_PROD","CS_SERVICE_UNITS","CS_BASE_SERVICE_COST","GL_BU_ORIGINAL","GL_OP_UNIT_ORIGINAL","GL_DEPT_ORIGINAL","GL_PROD_ORIGINAL","GL_LOC_ORIGINAL"], axis = 0, ascending = True,inplace = True, na_position ='last') 
    except:
        cdf1.sort_values(["CS_SERVICE_UNIQUE_IDENTIFIER","CS_SUI_DESCRIPTION","CS_BILLING_CODE","SERVICE","SEGMENT","PROJECT_NAME","CS_CB_UNIQUE_KEY","GL_PROJECT","GL_BU","GL_OP_UNIT","GL_DEPT","GL_PROD","CS_SERVICE_UNITS","CS_BASE_SERVICE_COST","GL_BU_ORIGINAL","GL_OP_UNIT_ORIGINAL","GL_DEPT_ORIGINAL","GL_PROD_ORIGINAL","GL_LOC_ORIGINAL"], axis = 0, ascending = True,inplace = True, na_position ='last') 
    
    try:
        cdf2.sort_values(["CS_SERVICE_UNIQUE_IDENTIFIER","CS_SUI_DESCRIPTION","CS_Billing_CODE","SERVICE","SEGMENT","PROJECT_NAME","CS_CB_UNIQUE_KEY","GL_PROJECT","GL_BU","GL_OP_UNIT","GL_DEPT","GL_PROD","CS_SERVICE_UNITS","CS_BASE_SERVICE_COST","GL_BU_ORIGINAL","GL_OP_UNIT_ORIGINAL","GL_DEPT_ORIGINAL","GL_PROD_ORIGINAL","GL_LOC_ORIGINAL"], axis = 0, ascending = True,inplace = True, na_position ='last') 
    except:
        cdf2.sort_values(["CS_SERVICE_UNIQUE_IDENTIFIER","CS_SUI_DESCRIPTION","CS_BILLING_CODE","SERVICE","SEGMENT","PROJECT_NAME","CS_CB_UNIQUE_KEY","GL_PROJECT","GL_BU","GL_OP_UNIT","GL_DEPT","GL_PROD","CS_SERVICE_UNITS","CS_BASE_SERVICE_COST","GL_BU_ORIGINAL","GL_OP_UNIT_ORIGINAL","GL_DEPT_ORIGINAL","GL_PROD_ORIGINAL","GL_LOC_ORIGINAL"], axis = 0, ascending = True,inplace = True, na_position ='last') 
    
    
    # # print("entered")
    junk=0
    junk1=0
    if len(cdf1)==len(cdf2):
        junk=1
        print("number of records in both files are same-"+str(len(cdf1))+"-"+str(len(cdf2)))
    else:
        print("number of records in both files are different-"+str(len(cdf1))+"-"+str(len(cdf2)))

    if len(cdf1.columns)==len(cdf2.columns):
        junk1=1
    else:
        print("number of columns in both files are different-"+str(len(cdf1.columns))+"-"+str(len(cdf2.columns)))
    col_lst=list(cdf1.columns)
    # return
    print("number of records in both files are -"+str(len(cdf1))+"-"+str(len(cdf2)))
    print("number of columns in both files are -"+str(len(cdf1.columns))+"-"+str(len(cdf2.columns)))
    # print("junk value"+str(junk))
    if junk==1 and junk1==1:
        print("entered")   
        diff_lst=list()
        diff_lst.append("row number!column number!automated file value!second file value")         
        for i in range(0,len(cdf1)):        
            for j in range(0, len(cdf1.columns)):   
                # print(str(i)+"-"+str(j)) 
                try:
                    if round(float(str(cdf1.iloc[i, j])),0)==round(float(str(cdf2.iloc[i, j])),0):
                        ok=1
                    else:
                        s1=str(i+1)+"!"+col_lst[j]+"!"+str(cdf1.iloc[i, j])+"!"+str(cdf2.iloc[i, j])
                        diff_lst.append(s1)
                except:
                    try:
                        if ' ' in cdf1.iloc[i, j] and ':' in cdf1.iloc[i, j] and '/' in cdf1.iloc[i, j]:
                            my_date=str(cdf1.iloc[i, j])
                            month, day, year = map(int, (my_date.split(' ')[0]).split('/'))
                            date_object1 = datetime(year, month, day)
                            my_date=str(cdf2.iloc[i, j])
                            month, day, year = map(int, (my_date.split(' ')[0]).split('/'))
                            date_object2 = datetime(year, month, day)
                            if date_object1==date_object2:
                                ok=1
                            else:
                                s1=str(i+1)+"!"+col_lst[j]+"!"+str(cdf1.iloc[i, j])+"!"+str(cdf2.iloc[i, j])
                                diff_lst.append(s1)
                        else:
                            if str(cdf1.iloc[i, j])==str(cdf2.iloc[i, j]):
                                ok=1
                            else:
                                if col_lst[j].strip(' ')=="HISTORY_VERSION":
                                    ok=1
                                else:
                                    s1=str(i+1)+"!"+col_lst[j]+"!"+str(cdf1.iloc[i, j])+"!"+str(cdf2.iloc[i, j])
                                    diff_lst.append(s1)
                    except:
                        if str(cdf1.iloc[i, j])==str(cdf2.iloc[i, j]):
                            ok=1
                        else:
                            if col_lst[j].strip(' ')=="HISTORY_VERSION":
                                ok=1
                            else:
                                s1=str(i+1)+"!"+col_lst[j]+"!"+str(cdf1.iloc[i, j])+"!"+str(cdf2.iloc[i, j])
                                diff_lst.append(s1)
        if len(diff_lst) > 1:
            print("found mismatch in files")
            print(str(len(diff_lst)))
            merged_x="c:\\users\\asrilekh\\documents\\ITBM_Montly_Refresh\\compare_csv\\"+(f1.split('\\')[len(f1.split('\\'))-1]).split('.')[0]+"_compare.xlsx"
            merged_x_wb = xlsxwriter.Workbook(merged_x)
            merged_sheet = merged_x_wb.add_worksheet("det_recds")
            for deli in range(0, len(diff_lst)):
                del_str = diff_lst[deli].split('!')
                # if str(del_str[1].strip(' '))=="HISTORY_VERSION":
                #     continue
                for delsi in range(0, len(del_str)):                    
                    value_w="N/A" if str(del_str[delsi].strip(' '))=='' else str(del_str[delsi].strip(' '))
                    merged_sheet.write(deli, delsi, value_w)  ##format changed
            merged_x_wb.close()
        else:
            print("no difference in files")

    
    # diff_lst=list()
    # f1=open(f1,"r")
    # a=f1.readlines()
    # f2=open(f2,"r")
    # b=f2.readlines()
    # junk=0
    # if len(a)==len(b):
    #     t=1
    # else:
    #     print("number of records are different "+str(len(a))+"-"+str(len(b)))
    #     junk=1
    # if junk==0:
    #     for i in range(0,len(a)):
    #         if a[i]==b[i]:
    #             t=1
    #         else:
    #             diff_lst.append(a[i]+"!"+b[i])
    #     print(str(len(diff_lst)))

            
            