from dateutil.relativedelta import relativedelta
from datetime import datetime
import calendar
import os
import pandas as pd
import xlsxwriter

def compare_report():
    try:
        try:
            last_month = datetime.now() - relativedelta(months=0)
            cur_text = format(last_month, '%y%m')
            print("current month and year is "+cur_text)
        except Exception as e:
            print("error: while retrieving current month and year "+str(e))
        try:
            last_month = datetime.now() - relativedelta(months=1)
            text = format(last_month, '%y%m')
            print("current month and year is "+text)
        except Exception as e:
            print("error: while retrieving current month and year "+str(e))
        cur_mon_yr=text
        try:
            last_month = datetime.now() - relativedelta(months=2)
            text = format(last_month, '%y%m')
            print("previous month and year is "+text)
        except Exception as e:
            print("error: while retrieving previous month and year "+str(e))

        cur_mon_name=str(calendar.month_name[int(str(cur_text[2:]))])
        prev_mon_name=str(calendar.month_name[int(str(cur_mon_yr[2:]))])

        print(prev_mon_name)
        print(cur_mon_name)
        prev_mon_name='May'
        cur_mon_name='June'
        cur_mon_yr='1905'
        text='1904'
        comp_lst=[]
        comp_lst.append("Filename!Current Month Count!Previous Month Count")
        for entry in os.scandir('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+cur_mon_name):
            if entry.is_file():
                print(entry.name)
                try:
                    f1='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+cur_mon_name+'\\'+entry.name
                    print(cur_mon_yr)
                    print(text)
                    fn=str(entry.name).replace(cur_mon_yr,text)
                    print(fn)
                    f2='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+prev_mon_name+"\\"+fn
                    cdf1=pd.read_csv(f1,encoding='latin-1')
                    cdf2=pd.read_csv(f2,encoding='latin-1')
                    comp_lst.append(entry.name+"!"+str(len(cdf1))+"!"+str(len(cdf2)))
                except Exception as e:
                    print("exception "+str(e))

        dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
        merged_x = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Compare_"+"_Report"+"_"+cur_mon_name+dt+".xlsx"
        merged_x_wb = xlsxwriter.Workbook(merged_x)
        merged_sheet = merged_x_wb.add_worksheet("Compare")
        x=comp_lst
        for deli in range(0, len(x)):
            del_str = x[deli].split('!')
            for delsi in range(0, len(del_str)):
                merged_sheet.write(deli, delsi, del_str[delsi])
        merged_x_wb.close()
        print("compare report generated "+merged_x)
    except Exception as e:
        print("exception in compare report "+str(e))
compare_report()