import glob
import os
from shutil import copyfile

def Outgoing_Prod_rec_file(mon_name):
    try:
        list_of_files = glob.glob('\\\\NAS00038pn\\data\\Tech_Economics\\VMWare_ITBM\\Outgoing_Prod\\*.csv') # * means all if need specific format then *.csv
        latest_file = max(list_of_files, key=os.path.getctime)
        print (latest_file+" is recent file from outgoing folder")
        copyfile(latest_file, 'C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+latest_file.split('\\')[len(latest_file.split('\\'))-1])
    except:
        print("error while retrieving recent file from outgoing prod folder")