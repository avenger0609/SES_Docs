import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3

def OU_Names(mon_name,prev_mon_yr):
    try:
        print("started generating files for ou names ")
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=TRMDB-PROD;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
        sql_string="SELECT dbo.GL_OU_staging.GL_OU AS oper_unit, dbo.GL_OU_staging.BusinessUnitDescription AS ShortDescription, dbo.GL_OU_staging.BusinessSegmentName AS LongDescription, dbo.GL_OU_staging.EffectiveStatus, dbo.GL_OU_staging.RowInsertDate FROM dbo.GL_OU_staging;"
        df = pd.read_sql_query(sql_string, engine)
        print("data fetched") 
        df['RowInsertDate']=pd.to_datetime(df['RowInsertDate'], format='%Y-%m-%d %H:%M:%S')
        # for name, dtype in df.dtypes.iteritems():
        #     print(name+"--"+str(dtype))
        df.to_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\'+prev_mon_yr+'_OU_Names.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")
        
    except Exception as e:
        print("error while generating Ou Names file "+str(e))

# OU_Names('March','1902')