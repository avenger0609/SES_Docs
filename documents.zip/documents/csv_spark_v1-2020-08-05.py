from pyspark import SparkConf
from pyspark.sql import SparkSession, Column
from pyspark.sql.functions import to_timestamp, coalesce
from pyspark.sql.types import *

from pyspark.sql import SQLContext

def init_spark():
    print("initiating spark session")
    global sparkSession, sc
    app_name = "jdbc_test.py"
    master = "local[8]"
    print("initiating spark configuration")
    
     conf 
    SparkConf().set('master','yarn-client').set('queue','bd_anltx_q1')
    conf = SparkConf().setAppName(app_name).setMaster(master).set('executor-memory','2G').set('num-executors',18).set('driver-memory','2G').set('executor-cores', 9).set('spark.serializer','org.apache.spark.serializer.KryoSerializer')
    print("completed spark session")   
    sparkSession = SparkSession.builder.config(conf=conf).getOrCreate()
    print("after spark session built")
    sc = sparkSession.sparkContext
    print("after spark context built")

def read_csv(fp):
    for line in fp.readlines():        
        yield line

def main():

    init_spark()
    fname='/mapr/datalake/optum/optuminsight/rada_anltx_prod/hive/warehouse/hsr_sas_test.db/hsr_adr_trans_comm/hsr_adr_trans_comm.txt'
    # fp=open(fname,'r')    
    # csvRDD = sc.parallelize(read_csv(fp), numSlices=16)
    # csvDF = sparkSession.read.csv(csvRDD)   
    csvDF=sparkSession.read.csv(fname,sep='|')
    print(csvDF.count())
    print(csvDF.columns)

main()
    


