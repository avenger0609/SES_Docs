import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3

def mpwr_78000_dfitbm(mon_name,prev_mon_yr):
    try:
        print("started generating files for mpwr 78000")
        df_excel = pd.read_excel('c:\\users\\asrilekh\\documents\\CB Vetting Request1.xlsx',sheet_name='Sheet1')
        print(len(df_excel))
        db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
        con = sqlite3.connect(db_file)
        df_excel.to_sql("excel_source", con, if_exists='replace', index=False)
        
        ### enhancing table
        sql_string="SELECT excel_source.BillingCode,excel_source.ServicePhysical,excel_source.ServiceVirtual,rtrim(ltrim(lower(excel_source.ServicePhysical))) as sp_lower,rtrim(ltrim(lower(excel_source.ServiceVirtual))) as sv_lower from excel_source "
        df = pd.read_sql_query(sql_string, con)
        df_excel.to_sql("excel_source", con, if_exists='replace', index=False)
        ### enhancing table

        BillingCode_lst=list(df_excel['BillingCode'])
        BillingCode_lst = list(dict.fromkeys(BillingCode_lst))
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)   
        sql_string="select dbo.uv_CB_Vetting.BillingCode,dbo.uv_CB_Vetting.AccountingYearMonth,dbo.uv_CB_Vetting.BusinessSegmentName,dbo.uv_CB_Vetting.ServicePhysical,dbo.uv_CB_Vetting.ServiceVirtual,dbo.uv_CB_Vetting.GlobalApplicationID,rtrim(ltrim(lower(dbo.uv_CB_Vetting.ServicePhysical))) as sp_lower,rtrim(ltrim(lower(dbo.uv_CB_Vetting.ServiceVirtual))) as sv_lower from dbo.uv_CB_Vetting"# where dbo.uv_CB_Vetting.AccountingYearMonth='1910'" 
        df = pd.read_sql_query(sql_string, engine)
        db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
        con = sqlite3.connect(db_file)
        df.to_sql("tbl_cbvetting_src", con, if_exists='replace', index=False)

        
        db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
        con = sqlite3.connect(db_file)        
        cur = con.cursor()
        sql_string="SELECT excel_source.BillingCode,excel_source.ServicePhysical,excel_source.ServiceVirtual,tbl_cbvetting_src.AccountingYearMonth,tbl_cbvetting_src.BusinessSegmentName,tbl_cbvetting_src.GlobalApplicationID from excel_source left join tbl_cbvetting_src on   excel_source.sp_lower= tbl_cbvetting_src.sp_lower and excel_source.sv_lower= tbl_cbvetting_src.sv_lower"
        df = pd.read_sql_query(sql_string, con)
        
        df.to_csv('C:\\Users\\asrilekh\\Documents\\Optum_CS_Variance_082019_sep_3.csv',index=False,quoting=csv.QUOTE_NONE,date_format="%m/%d/%Y %H:%M:%S")
        con.commit()
        con.close()
    except Exception as e:
        print("error while generating MPWR File for 78000 DFITBM"+str(e))


def mpwr_78000_dfitbm_citrix(mon_name,prev_mon_yr):
    try:
        print("started generating files for mpwr 78000")
        df = pd.read_excel(r'C:\Users\asrilekh\Documents\MyJabberFiles\pdheeren@corpimsvcs.com\Citrix User Assessment.xlsx',sheet_name='Unique Citrix Users')
        print(len(df))
        msid_lst=list(df['ID'])
        msid_lst = list(dict.fromkeys(msid_lst))
        print("excel source inserted")        
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)   
        sql_string="select dbo.uv_CB_Vetting.*,lower(rtrim(ltrim(dbo.uv_CB_Vetting.ServiceUniqueIdentifier))) as sui_lower from dbo.uv_CB_Vetting where dbo.uv_CB_Vetting.AccountingYearMonth in ('1910','1911','1901','1902','1903','1904','1905','1906','1907','1908','1909') and dbo.uv_CB_Vetting.ServiceCode='1005001'"
        df = pd.read_sql_query(sql_string, engine)
        print("cbvetting source inserted")
        df1 = df[df['ServiceUniqueIdentifier'].str.contains(msid_lst[0])] 
        df_final=df1[0:0]
        for mi in msid_lst:
            df1 = df[df['ServiceUniqueIdentifier'].str.contains(mi)] 
            df_final=df_final.append(df1)
        
        # df_final.to_csv('C:\\Users\\asrilekh\\Documents\\citrix_users_1901.csv',index=False,quoting=csv.QUOTE_NONE,encoding='latin-1',date_format="%m/%d/%Y %H:%M:%S")
        
        try:
            df_final.to_csv('C:\\Users\\asrilekh\\Documents\\citrix_users_1901.csv',index=False,quoting=csv.QUOTE_NONE,encoding='latin-1',date_format="%m/%d/%Y %H:%M:%S")
            print(len(df_final))
            db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
            con = sqlite3.connect(db_file)
            df_final.to_sql("citrix_final_res", con, if_exists='replace', index=False)
            print("data exported")
            con.commit()
            con.close()
        except:
            print(len(df_final))
            db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
            con = sqlite3.connect(db_file)
            df_final.to_sql("citrix_final_res", con, if_exists='replace', index=False)
            print("data exported")
            con.commit()
            con.close()
            df_final.to_excel('C:\\Users\\asrilekh\\Documents\\citrix_users_1901.xlsx',index=False,encoding='latin-1')

    except Exception as e:
        print("error while generating MPWR File for 78000 DFITBM"+str(e))

def mpwr_78000_dfitbm_citrix_1(mon_name,prev_mon_yr):
    try:
        print("started generating files for mpwr 78000")
        df = pd.read_excel(r'C:\Users\asrilekh\Documents\MyJabberFiles\pdheeren@corpimsvcs.com\Citrix User Assessment.xlsx',sheet_name='Unique Citrix Users')
        print(len(df))
        msid_lst=list(df['ID'])
        msid_lst = list(dict.fromkeys(msid_lst))
        print("excel source inserted")        
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)   
        sql_string="select dbo.uv_CB_Vetting.*,lower(rtrim(ltrim(dbo.uv_CB_Vetting.ServiceUniqueIdentifier))) as sui_lower from dbo.uv_CB_Vetting where dbo.uv_CB_Vetting.AccountingYearMonth in ('1910','1911','1901','1902','1903','1904','1905','1906','1907','1908','1909') and dbo.uv_CB_Vetting.ServiceCode='1005001'"
        df = pd.read_sql_query(sql_string, engine)
        print("cbvetting source inserted")
        # df1 = df[df['ServiceUniqueIdentifier'].str.contains(msid_lst[0])] 
        # df_final=df1[0:0]
        # for mi in msid_lst:
        #     df1 = df[df['ServiceUniqueIdentifier'].str.contains(mi)] 
        #     df_final=df_final.append(df1)
        df_final=df[df['ServiceUniqueIdentifier'].isin(msid_lst)]
        
        # df_final.to_csv('C:\\Users\\asrilekh\\Documents\\citrix_users_1901.csv',index=False,quoting=csv.QUOTE_NONE,encoding='latin-1',date_format="%m/%d/%Y %H:%M:%S")
        
        try:
            df_final.to_csv('C:\\Users\\asrilekh\\Documents\\citrix_users_1901_1.csv',index=False,quoting=csv.QUOTE_NONE,encoding='latin-1',date_format="%m/%d/%Y %H:%M:%S")
            print(len(df_final))
            db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
            con = sqlite3.connect(db_file)
            df_final.to_sql("citrix_final_res_1", con, if_exists='replace', index=False)
            print("data exported")
            con.commit()
            con.close()
        except:
            print(len(df_final))
            db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
            con = sqlite3.connect(db_file)
            df_final.to_sql("citrix_final_res_1", con, if_exists='replace', index=False)
            print("data exported")
            con.commit()
            con.close()
            df_final.to_excel('C:\\Users\\asrilekh\\Documents\\citrix_users_1901_1.xlsx',index=False,encoding='latin-1')

    except Exception as e:
        print("error while generating MPWR File for 78000 DFITBM"+str(e))

mpwr_78000_dfitbm_citrix_1('April','1903')