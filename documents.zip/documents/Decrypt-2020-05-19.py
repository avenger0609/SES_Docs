import sys, os, time, base64
import pandas
from multiprocessing import Pool
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto import Random

## Program:  cipher-file.py
## Author:   Russ Lawrence/Ray Kinsella
## Date:     2018-JUL-03
##
## Description:  Python program to decrypt an input field from Adobe analytics
##
## Parameters:   Arg1 - Input file
##               Arg2 - Output file
##.              Arg3 - key file --> '/Users/rlawr11/Documents/Provider Experience/Link/Adoption/uhc-20171026.pem'
##               Arg4 - Number of Worker threads
##               Arg5 - Error Message 
##
## Requirements:  Need to have pycrypto, RSA, and PKCS1_OAEP available
##.               Processes in parallel

def main():

    df = pandas.read_csv(csv_file,sep='\t', header=None, engine='python',names=["mcid", "inputkey"])
    
    df = df[df['inputkey'].apply(type) == str]

    # remove empty strings
    df = df[df['inputkey'] != ""]
    df['inputkey_length'] = df['inputkey'].apply(len)
    df = df[df['inputkey_length'] == 344.0]
    df = df[df['inputkey'].str[0:24] != "Encryption not supported"]
    #df = df.dropna()
    
    final_output = []
    inputkey_array = []
    
    for i, inputkey in enumerate(df.inputkey):
        inputkey_array.append(inputkey)

        if (i % 5 == 0):
            print("Record Count - Read - ...", str(i))

        if (i != 0):
            
            final_output = run_batch(inputkey_array, final_output)            
            inputkey_array = []
            print(inputkey_array)

 

    df['outputkey'] = final_output
    df.drop('inputkey_length', axis=1, inplace=True)
    df.to_csv(out_file,sep='\t',index=False,header=False)

    print(time.time() - starttime)

def decrypt_key(inputkey):
    Random.atfork()
    try:
        return(cipher.decrypt(base64.b64decode(inputkey)).decode('ISO-8859-1').strip())
    except:
        print("errored on input key:  %s" %  inputkey)
        

def run_batch(inputkey_array, final_output):
    
    for k in inputkey_array:
        final_output.append(cipher.decrypt(base64.b64decode(k)).decode('ISO-8859-1').strip())    
        print("output after encrypting")
        print(final_output)
    return final_output

if __name__ == '__main__':
    starttime = time.time()
    csv_file = "C:\\Users\\asrilekh\\Documents\\sample1.txt"
    out_file = "C:\\Users\\asrilekh\\Documents\\out.csv"
    key_file = "C:\\Users\\asrilekh\\Documents\\uhc-pub-20171026.pem"

    with open(key_file,'rb') as f: key_text = f.read()
    privkey = RSA.importKey(key_text)
    cipher = PKCS1_OAEP.new(privkey)

    main()
