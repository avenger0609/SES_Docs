from pymongo import MongoClient

from pprint import pprint


import pymongo

myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
print(myclient.list_database_names())
mydb = myclient["HandsFreeAnalytics"]

print(mydb.list_collection_names())
mycol_src = mydb["hfa_claims_1819_20190619"]
doc_i=mycol_src.find()
mycol_dest = mydb["hfa_claims_1819_MOD"]
mycol_dest.drop()
i=1
for doc in doc_i: 
    i=i+1
    if i >20:
        break
    # mycol_dest.insert(doc)
    print(str(doc))
