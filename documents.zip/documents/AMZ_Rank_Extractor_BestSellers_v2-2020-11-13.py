from selenium import webdriver
import pandas as pd
import time
# from selenium.webdriver.support.select import select
import csv
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os

driverpath = r"C:\ProgramData\chromedriver_win32\chromedriver.exe"
output_dir='\\\\APVEP78970\\Users\\sali54\\Documents\\SES POC\\Downloads\\'
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', True)
chromeOptions.add_extension(r"C:\Users\sali54\Documents\SES POC\Scripts\Amazon Quick View by AMZScout.crx")
driver = webdriver.Chrome(executable_path=driverpath,chrome_options=chromeOptions)

output_filename=output_dir+'AMZRankExtractor'+datetime.now().strftime('%d%m%Y%H%M%S')+'.csv'
df = pd.DataFrame()
df["S.No"] = []
df["Title"] = []
df["Product URL"] = []
df["Ratings URL"] = []
df["Ratings"] = []
df["Reviews"] = []
df["Reviews URL"] = []
df["Price"] = []
df["Price URL"] = []
df["Primary Rank Department"] = []
df["Primary Rank"] = []
df["weight"] = []
df["Size"] = []
df["Available From"] = []
df["Brand URL"] = []
df["Brand"] = []
df["ASIN"] = []
df["Date Extracted"] = []
df["Left Pane Dept Data"] = []
df["URL"] =[]
df.to_csv(output_filename,index=False,quoting=csv.QUOTE_ALL)

def get_rank_data(url1):
    
    sno_lst=[]
    product_title_lst=[]
    product_url_lst=[]
    ratings_url_lst=[]
    ratings_lst=[]
    reviews_lst=[]
    reviews_url_lst=[]
    price_lst=[]
    price_url_lst=[]    
    product_rank_dept_lst=[]
    product_rank_lst=[]
    product_weight_lst=[]
    product_size_lst=[]
    product_available_from_lst=[]
    product_brand_url_lst=[]
    product_brand_lst=[]
    product_asin_lst=[]
    Left_Pane_Data=url1.split("!!!!!!!!!!")[0]    
    ###########################################
    URL=url1.split("!!!!!!!!!!")[1]    
    driver.get(URL)
    ht=driver.execute_script("return document.documentElement.scrollHeight;")
    while True:
        prev_ht=driver.execute_script("return document.documentElement.scrollHeight;")
        driver.execute_script("window.scrollTo(0, document.documentElement.scrollHeight);")
        time.sleep(3)
        ht=driver.execute_script("return document.documentElement.scrollHeight;")
        if prev_ht==ht:
            break 

    time.sleep(30)
    print("waiting for page cntent")
    page_content=str(driver.page_source)
    print(len(page_content))

    ol_id_start=page_content.find('<ol id="zg-ordered-list"')
    ol_id_end=page_content.find('/ol>',ol_id_start)
    ol_data=page_content[ol_id_start:ol_id_end]
    # print(ol_data)
    li_end=0
    counter=0
    while True:
        print("counter=",counter)
        try:
            li_start=ol_data.find('<li class="zg-item-immersion"',li_end)
            if li_start==-1:
                break
            li_end=ol_data.find('/li>',li_start)
            li_data=(ol_data[li_start:li_end])
            try:
                bsr_start=li_data.find('<span class="zg-badge-text">')
                bsr_end=li_data.find('</span>',bsr_start+len('<span class="zg-badge-text">')-2)
                bsr_data=li_data[bsr_start:bsr_end].replace('<span class="zg-badge-text">','')
                # print("BSR ",bsr_data)   
                sno_lst.append(bsr_data.strip(' '))
            except Exception as e:
                print("Error while extracting bsr ",e)
                sno_lst.append('')


            ## Product URL and Product Title 

            #  Product URL
            try:
                pud_start=li_data.find('<a',bsr_end)
                pud_end=li_data.find('</a',pud_start+2)
                product_data=li_data[pud_start:pud_end]
                # print(product_data)
                prod_url_start=product_data.find('href=')
                prod_url_end=product_data.find('">',prod_url_start+5)
                prod_url=product_data[prod_url_start:prod_url_end]
                # print("product url",prod_url)
                product_url_lst.append(prod_url.strip(' '))
            except Exception as e:
                print("Error while extracting product url ",e)
                product_url_lst.append('')
            
            # Product Title
            try:
                prod_title_start=product_data.find('<div class="p13n-sc',prod_url_end)
                prod_title_end=product_data.find('</div>',prod_title_start)    
                prod_title=product_data[prod_title_start:prod_title_end]
                # print("product title",prod_title.split('>')[1])
                product_title_lst.append(prod_title.split('>')[1].strip(' '))
            except Exception as e:
                print("Error while extracting product title ",e)
                product_title_lst.append('')

            ## Ratings and Reviews
            try:
                rr_block_start=li_data.find('<div class="a-icon-row a-spacing-none">',prod_title_end)
                rr_block_end=li_data.find('</div>',rr_block_start)
                rr_data=li_data[rr_block_start:rr_block_end]
                # print(rr_data)

                # ratings
                rating_start=rr_data.find('<a class="a-link-normal"')
                rating_end=rr_data.find('</a',rating_start)

                rating_content=rr_data[rating_start:rating_end]
                rating_url_start=rating_content.find('href=')
                rating_url_end=rating_content.find('">',rating_url_start+5)
                rating_url=rating_content[rating_url_start:rating_url_end]
                # print("Rating URL=",rating_url)
                ratings_url_lst.append(rating_url.strip(' '))
            except Exception as e:
                print("Error while extracting ratings url ",e)
                ratings_url_lst.append('')

            try:
                rating_url_start=rating_content.find('title=')
                rating_url_end=rating_content.find('stars"',rating_url_start+5)
                rating_url=rating_content[rating_url_start:rating_url_end]
                # print("Rating =",rating_url.replace('title="',''))
                ratings_lst.append(rating_url.replace('title="','').strip(' '))
            except Exception as e:
                print("Error while extracting ratings  ",e)
                ratings_lst.append('')
            # reviews
            try:
                rating_start=rr_data.find('<a class="a-size-small a-link-normal"')
                rating_end=rr_data.find('</a',rating_start)
                rating_content=rr_data[rating_start:rating_end]

                rating_url_start=rating_content.find('href=')
                rating_url_end=rating_content.find('">',rating_url_start+5)
                rating_url=rating_content[rating_url_start:rating_url_end]
                # print("Reviews URL=",rating_url)
                reviews_url_lst.append(rating_url.strip(' '))
            except Exception as e:
                print("Error while extracting reviews url  ",e)
                reviews_url_lst.append('')
            try:
                # print("Reviews =",rating_content[rating_url_end:].replace('">',''))
                reviews_lst.append(rating_content[rating_url_end:].replace('">','').strip(' '))
            except Exception as e:
                print("Error while extracting reviews  ",e)
                reviews_lst.append('')
                    
            ##Price
            try:
                bsr_start=li_data.find('<span class="p13n-sc-price">')
                bsr_end=li_data.find('</span>',bsr_start+len('<span class="p13n-sc-price">')-2)
                bsr_data=li_data[bsr_start:bsr_end].replace('<span class="p13n-sc-price">','')
                # print("Price",bsr_data.replace('&nbsp;',''))  
                price_lst.append(bsr_data.replace('&nbsp;','').strip(' '))
            except Exception as e:
                print("Error while extracting price  ",e)
                price_lst.append('')


            ##price url
            try:
                rating_content=li_data[rr_block_end+4:bsr_end]
                rating_url_start=rating_content.find('href=')
                rating_url_end=rating_content.find('">',rating_url_start+5)
                rating_url=rating_content[rating_url_start:rating_url_end]
                # print("Price URL=",rating_url)
                price_url_lst.append(rating_url.strip(' '))
            except Exception as e:
                print("Error while extracting price url  ",e)
                price_url_lst.append('')
            


            ## QUICK VIEW DATA
            
            rr_block_start=li_data.find('<quick-view>',prod_title_end)
            rr_block_end=li_data.find('</quick-view>',rr_block_start)
            qv_data=li_data[rr_block_start:rr_block_end]

            #ASIN 
            try:
                asin_start=qv_data.find('ASIN:')
                asin_end=qv_data.find('</div>',asin_start)
                # print("ASIN:",qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
                product_asin_lst.append(qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
            except Exception as e:
                print("Error while extracting ASIN  ",e)
                product_asin_lst.append('')

            #Brand
            try:
                b_start=qv_data.find('Brand:')
                b_end=qv_data.find('</a>',b_start)
                rating_content=qv_data[b_start:b_end+4]

                rating_url_start=rating_content.find('href=')
                rating_url_end=rating_content.find('">',rating_url_start+5)
                rating_url=rating_content[rating_url_start:rating_url_end]
                product_brand_url_lst.append(rating_url)
                # print("Brand URL=",rating_url)
            except Exception as e:
                print("Error while extracting Brand URL  ",e)
                product_brand_url_lst.append('')

            try:
                # print("Brand=",rating_content[rating_url_end:].replace('</a>','').split('>')[-1].strip(' '))
                product_brand_lst.append(rating_content[rating_url_end:].replace('</a>','').split('>')[-1].strip(' '))
            except Exception as e:
                print("Error while extracting Brand  ",e)
                product_brand_lst.append('')
            

            #Available from  
            try:
                asin_start=qv_data.find('Available From:')
                asin_end=qv_data.find('</span>',asin_start)
                # print("Available from:",qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
                product_available_from_lst.append(qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
            except Exception as e:
                print("Error while extracting available from  ",e)
                product_available_from_lst.append('')
            #Size
            try:
                asin_start=qv_data.find('Size:')
                asin_end=qv_data.find('</span>',asin_start)
                # print("Size:",qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
                product_size_lst.append(qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
            except Exception as e:
                print("Error while extracting size  ",e)
                product_size_lst.append('')
            #Weight
            try:
                asin_start=qv_data.find('Weight:')
                asin_end=qv_data.find('</span>',asin_start)
                # print("Weight:",qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
                product_weight_lst.append(qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
            except Exception as e:
                print("Error while extracting weight  ",e)
                product_weight_lst.append('')
            #primary rank and primary department
            try:
                asin_start=qv_data.find('<span class="c0149">')
                asin_end=qv_data.find('</span>',asin_start)
                # print("Primary Rank:",qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
                product_rank_lst.append(qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
            except Exception as e:
                print("Error while extracting primary rank  ",e)
                product_rank_lst.append('')
            
            try:
                asin_start=qv_data.find('<span>',asin_end)
                asin_end=qv_data.find('</span>',asin_start)
                
                asin_start=qv_data.find('<span>',asin_end)
                asin_end=qv_data.find('</span>',asin_start)
                # print("Primary Department:",qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
                product_rank_dept_lst.append(qv_data[asin_start:asin_end].split('>')[-1].strip(' '))
            except Exception as e:
                print("Error while extracting primary rank department  ",e)
                product_rank_dept_lst.append('')

            counter=counter+1
            # if counter > 5:
            #     break
        except Exception as e:
            print('Exception in while loop ',e)
    df = pd.DataFrame()
    df["S.No"] = sno_lst
    df["Title"] = product_title_lst
    df["Product URL"] = product_url_lst
    df["Ratings URL"] = ratings_url_lst
    df["Ratings"] = ratings_lst
    df["Reviews"] = reviews_lst
    df["Reviews URL"] = reviews_url_lst
    df["Price"] = price_lst
    df["Price URL"] = price_url_lst
    df["Primary Rank Department"] = product_rank_dept_lst
    df["Primary Rank"] = product_rank_lst
    df["weight"] = product_weight_lst
    df["Size"] = product_size_lst
    df["Available From"] = product_available_from_lst
    df["Brand URL"] = product_brand_url_lst
    df["Brand"] = product_brand_lst
    df["ASIN"] = product_asin_lst
    df["Date Extracted"] = datetime.now().strftime('%d-%b-%Y %H:%M:%S')
    df["Left Pane Dept Data"] = Left_Pane_Data
    df["Left Pane URL"] = URL
    df.to_csv(output_filename,index=False,quoting=csv.QUOTE_ALL,mode='a',header=False)  

def best_seller_products_details_from_file(filename):
    print("started ",str(datetime.now().strftime('%Y%m%d%H%M%S')))
    page_urls_extracted=[]
    puef=open(output_dir+filename,mode='r',encoding='utf-8')
    puef_temp_lst=puef.readlines()
    puef.close()
    for puei in puef_temp_lst:
        page_urls_extracted.append(puei.replace('\n',''))  
    for puei in page_urls_extracted: 
        try:       
            get_rank_data(puei)
        except Exception as e:
            print(str(e))
    print("ended",str(datetime.now().strftime('%Y%m%d%H%M%S')))

best_seller_products_details_from_file('sub_dept_urls_l3_20201109045942.csv')