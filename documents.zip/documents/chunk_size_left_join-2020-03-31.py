import pandas as pd
import csv
from datetime import datetime


first_file='/app/Apache Druid POC/New Join Files/case_member_join_res.csv'
second_file='/app/Apache Druid POC/UIDXWALK_FINAL_THRU03052020.csv'
output_file='/app/Apache Druid POC/New Join Files/join_res_uidxwalk.csv'
columns_list=['uid']





######################################################################

print("started-"+str(datetime.now()))

df2=pd.read_csv(second_file,encoding = 'latin_1')
print("completed reading UIDXWALK_FINAL_THRU03052020 key data "+str(len(df2)))
df1=pd.read_csv(first_file,encoding = 'latin_1')
print("completed reading all case_member_join_res data "+str(len(df1)))

# creating a empty bucket to save result
df_result = pd.DataFrame(columns=(df1.columns.append(df2.columns)).unique())
df_result.to_csv(output_file,index_label=False)

# deleting df1 to save memory
del(df1)


file1 = open("/app/Apache Druid POC/testfile_counter.txt","w")

def preprocess(x):      
    
    df=pd.merge(x,df2,how='left',on=columns_list)
    df.to_csv(output_file,mode="a",header=False,index=False)
    file1.write(str(len(df))+"\n")

reader = pd.read_csv(first_file, chunksize=10000) # chunksize depends with you colsize

[preprocess(r) for r in reader]
file1.close()
df=pd.read_csv(output_file,encoding='latin_1')

d = {'Jan':'01', 'Feb':'02', 'Mar':'03', 'Apr':'04', 'May':'05', 'Jun':'06', 'Jul':'07', 'Aug':'08', 'Sep':'09', 'Oct':'10', 'Nov':'11', 'Dec':'12' }

df['hour']='00'
df['minute']='00'
df['second']='10'
df['month_temp']=df['month']
df['month']=df['month'].map(d)
df['day']=df['week']

print(list(dict.fromkeys(list(df['month']))))
print(list(dict.fromkeys(list(df['month_temp']))))

df['timestamp']=pd.to_datetime(df[['year', 'month', 'day','hour','minute','second']])
df['month']=df['month_temp']
df=df.drop(columns=['hour', 'minute','second','day','month_temp'])
df_check=df[0:1000]
df_check.to_csv('/app/Apache Druid POC/New Join Files/uidxwalk_mktdtlxwalktest.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')
df.to_csv(output_file,index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')

print("Completed-"+str(datetime.now()))