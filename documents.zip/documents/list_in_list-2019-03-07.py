a=['a','b','c']
b=['1','2','3']
d=['1','2','3']
c=list()
c.append(a)
c.append(b)
c.append(d)
print(str(len(c)))