import pyodbc

conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};C:\Users\asrilekh\Desktop\work\training\ITBM\Digital Fuel Data.accdb;')
cursor = conn.cursor()
cursor.execute('select * from 78026 DFITBM')
   
for row in cursor.fetchall():
    print (row)
