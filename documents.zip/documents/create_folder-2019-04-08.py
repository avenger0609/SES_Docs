import os 
try:
    os.makedirs('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\April')
except:
    junk=1