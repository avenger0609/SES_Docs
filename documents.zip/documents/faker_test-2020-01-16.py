from faker import Factory
fake=Factory.create()

fake.name()
fake.address()
fake.text()

for _ in range(0,10):
    print(fake.name())
