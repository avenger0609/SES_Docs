# from pyhive import hive
# conn = hive.Connection(host="apvrp59186", port=10021, username="mpawante", password="Jaimahasai@11", auth='CUSTOM')
# cur = conn.cursor()
# cur.execute('select * from <table>');
# print cur.fetchone()
#########################
# import pandas as pd
# from pyhive import presto
# con=presto.connect(host='apvrp59186',port=10021,username='mpawante:Jaimahasai@11')
# sqlstmt='select count(*) from hsr_1.hsr_adr_xref_fmts'
# df = pd.read_sql_query(sqlstmt, con)
# print(df)
#########################
# import jaydebeapi


# def get_hive_jdbc_con():
#     driver="org.apache.hive.jdbc.HiveDriver" 
#     conn_url="jdbc:hive2://apvrp59186:10021/default"
#     auth_lst=['mpawante','Jaimahasai@11']
#     conn = jaydebeapi.connect(driver,conn_url,auth_lst,)
#     return conn
# conn=get_hive_jdbc_con()

######################

# import pandas as pd
# from pyarrow import orc


filename=r'C:\users\asrilekh\documents\000116_0'
# with open(filename) as file:
#     data = orc.ORCFile(file)
#     df = data.read().to_pandas()

# import findspark
# from pyspark.sql import SparkSession

# findspark.init()
# spark = SparkSession.builder.getOrCreate()
# df_spark = spark.read.orc(filename)
# df_pandas = df_spark.toPandas()

import pyorc

with open(filename, "rb") as data:
    reader = pyorc.Reader(data)
    for row in reader:
        print(row)