import saspy
import pandas as pd

df=pd.read_csv(r'c:\users\asrilekh\documents\sas_test.csv')
sas = saspy.SASsession()