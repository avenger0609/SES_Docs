from selenium import webdriver
import pandas as pd
import time
# import calendar
# from datetime import datetime
# from dateutil.relativedelta import relativedelta
import csv
from selenium.webdriver.common.keys import Keys 
from selenium.common.exceptions import ElementClickInterceptedException
from datetime import datetime

state_lst=[]
county_lst=[]
test_centre_name_lst=[]
test_centre_type_lst=[]
test_centre_address_lst=[]
test_centre_add_map_lst=[]
test_centre_timing_lst=[]
test_centre_instruction_lst=[]
test_centre_source_lst=[]
test_centre_phone_lst=[]

driverpath = r"C:\ProgramData\Chrome_driver_80.0.3987.16\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://www.evive.care/")

driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[2]/i').click()
time.sleep(5)
cparent=driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[2]/div[2]')
loop_countries_lst=[]
ccs=cparent.find_elements_by_tag_name('div')
for cci in ccs:
    loop_countries_lst.append(cci.find_elements_by_tag_name('span')[0].text)
print(len(loop_countries_lst))
# loop_countries_lst=loop_countries_lst[0:1]
for lci in loop_countries_lst:
    print(lci)
    # driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[2]/input').click()
    # time.sleep(2)
    # driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[2]/input').clear()
    # time.sleep(2)
    driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[2]/input').send_keys(lci)
    time.sleep(5)    
    driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[2]/div[2]/div').click()       

    time.sleep(10)
    try:
        #print(str(driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[4]/i').is_enabled())) 
        driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[4]/i').click()
    except ElementClickInterceptedException:
        print("Element is not clickable")
        continue
    countyparent=driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[4]/div[2]')
    loop_counties_lst=[]
    cpcs=countyparent.find_elements_by_tag_name('div')
    for cci in cpcs:
        if cci.find_elements_by_tag_name('span')[0].text=='All counties':
            continue
        loop_counties_lst.append(cci.find_elements_by_tag_name('span')[0].text)
    print(len(loop_counties_lst))
    # loop_counties_lst=loop_counties_lst[2:3]
    for lcli in loop_counties_lst:        
        print(lcli)
        if lcli=='All counties':
            continue
        # driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[4]/input').click()
        # time.sleep(2)
        # driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[4]/input').clear()
        # time.sleep(2)
        driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[4]/input').send_keys(lcli)
        time.sleep(5)
        driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[1]/div/div[2]/div[4]/div[2]/div').click()
        time.sleep(10)
        tbl_id=driver.find_element_by_xpath('/html/body/div/div/main/div/div[2]/div[2]')   
        trs=tbl_id.find_elements_by_class_name('site-card-wrapper')  
        print(len(trs))
        for tri in trs:    
            # print(len(state_lst))
            # print(len(county_lst))
            # print(len(test_centre_name_lst))
            # print(len(test_centre_type_lst))
            # print(len(test_centre_address_lst))
            # print(len(test_centre_add_map_lst))
            # print(len(test_centre_timing_lst))
            # print(len(test_centre_instruction_lst))
            # print(len(test_centre_source_lst)) 
            # print(len(test_centre_phone_lst))       
            # state_lst.append(lci)
            # county_lst.append(lcli)
            tds=tri.find_elements_by_tag_name('div')            
            if len(tds)==0:
                break
            if tds[0].text=='Guidelines':
                break
            tcnls=tds[0].text
            # test_centre_name_lst.append(tcnls)  
            tctls=tds[1].text 
            # test_centre_type_lst.append(tctls)            
            tds_a=tds[2].find_elements_by_tag_name('a')            
            tds_aa=tds_a[0].find_elements_by_tag_name('a')   
            tcamls=tds_aa[0].get_attribute("href")         
            # test_centre_add_map_lst.append(tcamls)
            tcals=tds_aa[0].text
            # test_centre_address_lst.append(tcals)        
            tds_div=tds[3].find_elements_by_tag_name('div')
            tctls1=tds_div[0].text
            # test_centre_timing_lst.append(tctls1)
            tcils=tds[5].text
            # test_centre_instruction_lst.append(tcils)
            tds_a=tds[3].find_elements_by_tag_name('a')
            if len(tds_a) > 0:
                tcpls=tds_a[0].text
                # test_centre_phone_lst.append(tcpls)                
            else:
                tcpls=''
                # test_centre_phone_lst.append(tcpls)            
            tds_a=tds[5].find_elements_by_tag_name('a')
            if len(tds_a) > 0:
                tcsls=tds_a[0].get_attribute('href')
                # test_centre_source_lst.append(tcsls)                
            else:
                tcsls=''
                # test_centre_source_lst.append(tcsls)
            state_lst.append(lci)
            county_lst.append(lcli)
            test_centre_name_lst.append(tcnls)  
            test_centre_type_lst.append(tctls)
            test_centre_add_map_lst.append(tcamls)
            test_centre_address_lst.append(tcals)
            test_centre_timing_lst.append(tctls1)
            test_centre_instruction_lst.append(tcils)
            test_centre_phone_lst.append(tcpls)                
            test_centre_source_lst.append(tcsls)
        
            

print(len(state_lst))
print(len(county_lst))
print(len(test_centre_name_lst))
print(len(test_centre_type_lst))
print(len(test_centre_address_lst))
print(len(test_centre_add_map_lst))
print(len(test_centre_timing_lst))
print(len(test_centre_instruction_lst))
print(len(test_centre_source_lst))
print(len(test_centre_phone_lst))       


df=pd.DataFrame()
df['state_lst']=state_lst
df['county_lst']=county_lst
df['test_centre_name_lst']=test_centre_name_lst
df['test_centre_type_lst']=test_centre_type_lst
df['test_centre_address_lst']=test_centre_address_lst
df['test_centre_add_map_lst']=test_centre_add_map_lst
df['test_centre_timing_lst']=test_centre_timing_lst
df['test_centre_phone_lst']=test_centre_phone_lst
df['test_centre_instruction_lst']=test_centre_instruction_lst
df['test_centre_source_lst']=test_centre_source_lst
df['Date updated']=str(datetime.now()).split(' ')[0]
opfilename=r'c:\users\asrilekh\documents\evive_test_centres_data_'+str(datetime.now()).split('.')[0].replace(':','').replace(' ','').replace('-','')+'.csv'

# df.to_excel(r'c:\users\asrilekh\documents\new_cases_cnt_yesterday.xlsx',index=False)
df.to_csv(opfilename,index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')