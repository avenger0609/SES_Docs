from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.find_element_by_xpath('//*[@id="i0116"]').send_keys('rizwan.syedali@optum.com')