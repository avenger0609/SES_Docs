import pandas as pd

df=pd.DataFrame()

date_lst=["15-Feb","16-Feb","17-Feb","18-Feb","19-Feb","20-Feb","21-Feb","22-Feb","23-Feb","24-Feb","25-Feb","26-Feb","27-Feb","28-Feb","29-Feb","1-Mar","2-Mar","3-Mar","4-Mar","5-Mar","6-Mar","7-Mar","8-Mar","9-Mar","10-Mar","11-Mar","12-Mar","13-Mar","14-Mar","15-Mar","16-Mar","17-Mar","18-Mar","19-Mar","20-Mar","21-Mar","22-Mar","23-Mar","24-Mar","25-Mar","26-Mar"]
nd_lst=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,5,3,2,1,3,4,3,4,4,8,3,7,10,15,22,26,50,68,70,65,135,180,268,303,354]

print(len(date_lst))
print(len(nd_lst))

df['Date']=date_lst
df['Daily New Deaths']=nd_lst

print(df)