import os

data_recds_billed_lst=list()
data_recds_paid_lst=list()
data_recds_denied_lst=list()
data_recds_adjusted_lst=list()
data_recds_lst=list()

dir_name="C:\\Users\\asrilekh\\Desktop\\training examples\\WF2_Duration\\finalized\\claims_amount\\claims_billed_amt"
for entry in os.scandir(dir_name):
    if entry.is_file() and ".txt" in entry.name:
        en=os.path.join(dir_name,entry.name)
        file1 = open(en,"r")
        for line in file1:
            if line[-1]=="\n":
                data_recds_billed_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
                data_recds_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
            else:
                data_recds_billed_lst.append(line.strip(' ').lower())
                data_recds_lst.append(line.strip(' ').lower())

dir_name="C:\\Users\\asrilekh\\Desktop\\training examples\\WF2_Duration\\finalized\\claims_amount\\claims_adjstd_amt"
for entry in os.scandir(dir_name):
    if entry.is_file() and ".txt" in entry.name:
        en=os.path.join(dir_name,entry.name)
        file1 = open(en,"r")
        for line in file1:
            if line[-1]=="\n":
                data_recds_adjusted_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
                data_recds_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
            else:
                data_recds_adjusted_lst.append(line.strip(' ').lower())
                data_recds_lst.append(line.strip(' ').lower())

dir_name="C:\\Users\\asrilekh\\Desktop\\training examples\\WF2_Duration\\finalized\\claims_amount\\claims_dend_amt"
for entry in os.scandir(dir_name):
    if entry.is_file() and ".txt" in entry.name:
        en=os.path.join(dir_name,entry.name)
        file1 = open(en,"r")
        for line in file1:
            if line[-1]=="\n":
                data_recds_denied_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
                data_recds_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
            else:
                data_recds_denied_lst.append(line.strip(' ').lower())
                data_recds_lst.append(line.strip(' ').lower())

dir_name="C:\\Users\\asrilekh\\Desktop\\training examples\\WF2_Duration\\finalized\\claims_amount\\claims_paid_amt"
for entry in os.scandir(dir_name):
    if entry.is_file() and ".txt" in entry.name:
        en=os.path.join(dir_name,entry.name)
        file1 = open(en,"r")
        for line in file1:
            if line[-1]=="\n":
                data_recds_paid_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
                data_recds_lst.append((line.rstrip(line[-1:])).strip(' ').lower())
            else:
                data_recds_paid_lst.append(line.strip(' ').lower())
                data_recds_lst.append((line.rstrip(line[-1:])).strip(' ').lower())

                

x=list()
data_recd_hit_lst=list()
data_recd_no_hit_lst=list()
file1 = open("C:\\Users\\asrilekh\\Desktop\\training examples\\WF2_Duration\\finalized\\sample_claims_data_amt_consolidated.json","r")
for line in file1:
    if line[-1]=="\n":
        x.append((line.rstrip(line[-1:])))
    else:
        x.append(line)

c=0
for i in range(1,len(x)):
    if "\"intent\": \"claims_amount\"," in x[i]:
        if (x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()) in data_recds_billed_lst:
            c=c+1
            data_recd_hit_lst.append((x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()))
            x[i]=x[i].lower().replace('claims_amount','claims_billed_amt')
        elif (x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()) in data_recds_paid_lst:
            c=c+1
            data_recd_hit_lst.append((x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()))
            x[i]=x[i].lower().replace('claims_amount','claims_paid_amt')
        elif (x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()) in data_recds_denied_lst:
            c=c+1
            data_recd_hit_lst.append((x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()))
            x[i]=x[i].lower().replace('claims_amount','claims_dend_amt')
        elif (x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()) in data_recds_adjusted_lst:
            c=c+1
            data_recd_hit_lst.append((x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()))
            x[i]=x[i].lower().replace('claims_amount','claims_adjstd_amt')
        else:
            print((x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()))
            data_recd_no_hit_lst.append((x[i-1].split(':')[1].replace('\"','').replace(',','').strip(' ').lower()))

print("number of hits is "+str(c))
print("lenght of files is "+str(len(data_recds_adjusted_lst)+len(data_recds_billed_lst)+len(data_recds_denied_lst)+len(data_recds_paid_lst)))

file1 = open("testfile1.json","w")
for x1 in x:
    file1.write(x1+"\n")

for i in data_recds_lst:
    if i not in data_recd_hit_lst:
        print(i)