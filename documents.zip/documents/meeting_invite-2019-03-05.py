import win32com.client

for c in range(15,32):
    timings_list=list()
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')
    timings_list.append('2019-03-'+str(c)+' 16:00')

    for tl in timings_list:

        emails_lst=list()
        emails_lst.append("hyd2_conf2t@uhc.com")
        emails_lst.append("hyd2_conf2u@uhc.com")
        emails_lst.append("hyd2_conf2v@uhc.com")
        emails_lst.append("hyd2_conf2w@uhc.com")
        emails_lst.append("hyd2_conf2x@uhc.com")
        locations_lst=list()
        locations_lst.append('II519 ConfRm 2 T')
        locations_lst.append('II519 ConfRm 2 U')
        locations_lst.append('II519 ConfRm 2 V')
        locations_lst.append('II519 ConfRm 2 W')
        locations_lst.append('II519 ConfRm 2 X')
        for i in range(0,len(locations_lst)):
            # print(l)
            oOutlook = win32com.client.Dispatch("Outlook.Application")
            appt = oOutlook.CreateItem(1) # 1 - olAppointmentItem
            appt.Start = tl
            appt.Subject = 'Follow Up Meeting'
            appt.Duration = 30
            appt.Location = locations_lst[i]
            appt.MeetingStatus = 5 # 1 - olMeeting; Changing the appointment to meeting
            #only after changing the meeting status recipients can be added
            appt.Recipients.Add(emails_lst[i])
            appt.Save()
            appt.Send()
        print("Done")