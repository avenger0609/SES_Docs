import pandas as pd
import numpy as np
from sqlalchemy import *
from urllib.parse import quote_plus
import csv
import sqlite3
from sqlalchemydiff import *

params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=TRMDB-PROD;Database=TRMDB;schema=dbo;table=CB_BillingCode;Trusted_Connection=yes;')
engine = ("mssql+pyodbc:///?odbc_connect=%s" % params)

params = quote_plus(r'Driver={SQL Server};Server=DBSEP1560;Database=ITFB;Trusted_Connection=yes;') #### MPWR Server
engine1 = ("mssql+pyodbc:///?odbc_connect=%s" % params) 

params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;schema=dbo;table=CB_BO_LoadErrors;Trusted_Connection=yes;') #### TRMDB Server
engine1 = ("mssql+pyodbc:///?odbc_connect=%s" % params) 



# engine=r'jdbc:jtds:sqlserver://TRMDB-PROD'
# engine1=r'jdbc:jtds:sqlserver://DBSEP1560'

result = compare(engine, engine1)

if  result.is_match :
    print("databases are same")

else:
    print(result.errors)





Connections/TRMDBTEST/TRMDB/dbo/TABLE/AC_FilePathInfo

def mpwr_78000_dfitbm(mon_name,prev_mon_yr):
    try:
        print("started generating files for mpwr 78000")
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=TRMDB-PROD;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
        sql_string="SELECT dbo.CB_ChargebackData_UnAgg.AccountingYearMonth,dbo.CB_ChargebackData_UnAgg.ServiceUniqueIdentifier,dbo.CB_ChargebackData_UnAgg.BillingCode,dbo.CB_ChargebackData_UnAgg.ServiceName,dbo.CB_ChargebackData_UnAgg.ServiceVirtual,dbo.CB_ChargebackData_UnAgg.CustomerAcceptance,dbo.CB_ChargebackData_UnAgg.AppName,dbo.CB_ChargebackData_UnAgg.ProdNonProd,dbo.CB_ChargebackData_UnAgg.ServiceRequestNumber,dbo.CB_ChargebackData_UnAgg.ServiceDeliveryDate,dbo.CB_ChargebackData_UnAgg.ProjectManager,dbo.CB_ChargebackData_UnAgg.ParentCreateDate,dbo.CB_ChargebackData_UnAgg.ParentDescription,dbo.CB_ChargebackData_UnAgg.ParentRequestID,dbo.CB_ChargebackData_UnAgg.ParentRequestType,dbo.CB_ChargebackData_UnAgg.ParentRequestor,dbo.CB_ChargebackData_UnAgg.ParentRequestorEmail,dbo.CB_ChargebackData_UnAgg.RequestType,dbo.CB_ChargebackData_UnAgg.Requestor,dbo.CB_ChargebackData_UnAgg.RequestorEmail,dbo.CB_ChargebackData_UnAgg.Description,dbo.CB_ChargebackData_UnAgg.CreateDate,dbo.CB_ChargebackData_UnAgg.GL_CodeOwner,dbo.CB_ChargebackData_UnAgg.ProjectName,dbo.CB_ChargebackData_UnAgg.ProjectRequestor,dbo.CB_ChargebackData_UnAgg.Prompt_ID,dbo.CB_ChargebackData_UnAgg.DataCenterCode,rtrim(ltrim(lower(dbo.CB_ChargebackData_UnAgg.ServiceUniqueIdentifier))) as sui_lower FROM dbo.CB_ChargebackData_UnAgg WHERE (((dbo.CB_ChargebackData_UnAgg.AccountingYearMonth)='"+prev_mon_yr+"'));"
        print(sql_string)
        final_data_fetch = pd.read_sql_query(sql_string, engine)
        print("data fetched")
        db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
        con = sqlite3.connect(db_file)
        final_data_fetch.to_sql("tbl_trmcbsource", con, if_exists='replace', index=False)
        print("trmdbc source inserted")
        params = quote_plus(r'Driver={SQL Server};Server=DBSEP1560;Database=ITFB;Trusted_Connection=yes;') #### MPWR Server
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)        
        sql_string="SELECT dbo.history_ledger_active_ets.HISTORY_PERIOD,dbo.history_ledger_active_ets.HISTORY_VERSION,dbo.history_ledger_active_ets.SEGMENT,'' AS CURRENT_YEAR,'' AS CURRENT_MONTH,dbo.rates_active.GL_DEPT AS CS_SERVICE_GROUP_COTS_CENTER,dbo.rates_active.SERVCAT AS CS_SERVICE_GROUP,dbo.history_ledger_active_ets.SERVICE,dbo.history_ledger_active_ets.SV_DESC,dbo.history_ledger_active_ets.APPL AS CS_APPLICATION_NAME,dbo.history_ledger_active_ets.PROJECT AS CS_PROJECT_NUMBER,dbo.history_ledger_active_ets.GL_BU,dbo.history_ledger_active_ets.GL_OP_UNIT,dbo.history_ledger_active_ets.GL_LOC,dbo.history_ledger_active_ets.GL_ACCT,dbo.history_ledger_active_ets.GL_DEPT,dbo.history_ledger_active_ets.GL_PROD,dbo.history_ledger_active_ets.GL_CUSTOMER,dbo.history_ledger_active_ets.GL_PROJECT,dbo.history_ledger_active_ets.CS_SERVICE_PHYSICAL,'' AS CS_SERVICE_STORAGE,dbo.history_ledger_active_ets.CS_SERVICE_UNIQUE_IDENTIFIER,dbo.history_ledger_active_ets.QUANTITY AS CS_SERVICE_UNITS,dbo.history_ledger_active_ets.Rate AS CS_SERVICE_RATE_PER_UOM,CAST(dbo.history_ledger_active_ets.CHARGES AS Float)  AS CS_BASE_SERVICE_COST,'' AS CS_SUPP_STORAGE_COST,dbo.history_ledger_active_ets.CS_CB_UNIQUE_KEY,dbo.history_ledger_active_ets.GL_BU_ORIGINAL,dbo.history_ledger_active_ets.GL_OP_UNIT_ORIGINAL,dbo.history_ledger_active_ets.GL_LOC_ORIGINAL,dbo.history_ledger_active_ets.GL_DEPT_ORIGINAL,dbo.history_ledger_active_ets.GL_PROD_ORIGINAL,dbo.history_ledger_active_ets.GL_CUSTOMER_ORIGINAL,dbo.history_ledger_active_ets.GL_PROJECT_ORIGINAL,'' AS CS_FINANCE_DELTAS,dbo.history_ledger_active_ets.CS_SUI_DESCRIPTION,dbo.history_ledger_active_ets.PUBLISHED,'' AS CS_SERVICE,dbo.history_ledger_active_ets.ADJ_REF_ID,dbo.history_ledger_active_ets.DATASRC,'' AS BUSINESS_APP_NAME,dbo.history_ledger_active_ets.TMDB_APP_CODE,dbo.history_ledger_active_ets.GLOBAL_APP_ID,dbo.history_ledger_active_ets.LONG_APP_NAME,'' AS COMPUTE_UNIT_PCT_CPU,'' AS COMPUTE_UNIT_PCT_RAM,'' AS CPU_ALLOCATED,'' AS CPU_AVG_UTIL_PCT,'' AS CPU_PEAK_UTIL_PCT,'' AS Data_Center_NAME,'' AS PCT_UPTIME,'' AS RAM_ALLOCATED,'' AS RAM_AVG_UTIL_PCT,'' AS RAM_PEAK_UTIL_PCT,dbo.history_ledger_active_ets.EMP_ID,dbo.history_ledger_active_ets.SITE_CODE,dbo.history_ledger_active_ets.SUSPEND,dbo.history_ledger_active_ets.EMAIL_ADDRESS,dbo.history_ledger_active_ets.EMP_TYPE,dbo.history_ledger_active_ets.FIRST_NAME,dbo.history_ledger_active_ets.LAST_NAME,dbo.history_ledger_active_ets.VCC_SITE,ltrim(rtrim(lower(dbo.history_ledger_active_ets.CS_SERVICE_UNIQUE_IDENTIFIER))) as sui_lower FROM (dbo.history_ledger_active_ets LEFT JOIN dbo.rates_active ON dbo.history_ledger_active_ets.SERVICE = dbo.rates_active.SERVICE)  WHERE (((dbo.history_ledger_active_ets.HISTORY_PERIOD)='20"+prev_mon_yr+"') AND ((dbo.history_ledger_active_ets.GL_ACCT)='78000'));"
        print(sql_string)
        final_data_fetch = pd.read_sql_query(sql_string, engine)
        print("data fetched")
        db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
        final_data_fetch.to_sql("tbl_7800_dfitbm", con, if_exists='replace', index=False)
        print("another table inserted")
        cur = con.cursor()
        sql_string="SELECT TBL_7800_DFITBM.HISTORY_PERIOD, TBL_7800_DFITBM.HISTORY_VERSION, TBL_7800_DFITBM.SEGMENT, TBL_7800_DFITBM.CURRENT_YEAR AS CURRENT_YEAR, TBL_7800_DFITBM.CURRENT_MONTH AS CURRENT_MONTH, TBL_7800_DFITBM.CS_SERVICE_GROUP_COTS_CENTER AS CS_SERVICE_GROUP_COST_CENTER, TBL_7800_DFITBM.CS_SERVICE_GROUP AS CS_SERVICE_GROUP, TBL_TRMCBSOURCE.BILLINGCODE AS CS_BILLING_CODE, TBL_7800_DFITBM.SERVICE, TBL_7800_DFITBM.SV_DESC, TBL_7800_DFITBM.CS_APPLICATION_NAME AS CS_APPLICATION_NAME, TBL_7800_DFITBM.CS_PROJECT_NUMBER AS CS_PROJECT_NUMBER, TBL_TRMCBSOURCE.CUSTOMERACCEPTANCE AS CS_CUSTOMER_ACCEPTANCE, TBL_7800_DFITBM.GL_BU, TBL_7800_DFITBM.GL_OP_UNIT, TBL_7800_DFITBM.GL_LOC, TBL_7800_DFITBM.GL_ACCT, TBL_7800_DFITBM.GL_DEPT, TBL_7800_DFITBM.GL_PROD, TBL_7800_DFITBM.GL_CUSTOMER, TBL_7800_DFITBM.GL_PROJECT, TBL_7800_DFITBM.CS_SERVICE_PHYSICAL, TBL_TRMCBSOURCE.SERVICEVIRTUAL AS CS_SERVICE_VIRTUAL, TBL_7800_DFITBM.CS_SERVICE_STORAGE AS CS_SERVICE_STORAGE, TBL_7800_DFITBM.CS_SERVICE_UNIQUE_IDENTIFIER, TBL_7800_DFITBM.CS_SERVICE_UNITS AS CS_SERVICE_UNITS, TBL_7800_DFITBM.CS_SERVICE_RATE_PER_UOM AS CS_SERVICE_RATE_PER_UOM, TBL_7800_DFITBM.CS_BASE_SERVICE_COST AS CS_BASE_SERVICE_COST, '' AS CS_SUPP_STORAGE_COST, TBL_7800_DFITBM.CS_CB_UNIQUE_KEY, TBL_7800_DFITBM.GL_BU_ORIGINAL, TBL_7800_DFITBM.GL_OP_UNIT_ORIGINAL, TBL_7800_DFITBM.GL_LOC_ORIGINAL, TBL_7800_DFITBM.GL_DEPT_ORIGINAL, TBL_7800_DFITBM.GL_PROD_ORIGINAL, TBL_7800_DFITBM.GL_CUSTOMER_ORIGINAL, TBL_7800_DFITBM.GL_PROJECT_ORIGINAL, '' AS CS_FINANCE_DELTAS, TBL_TRMCBSOURCE.PRODNONPROD AS CS_PROD_NON_PROD, TBL_TRMCBSOURCE.SERVICEREQUESTNUMBER AS CS_SERVICE_REQUEST_NUMBER, TBL_TRMCBSOURCE.SERVICEDELIVERYDATE AS CS_SERVICE_DELIVERY_DATE, TBL_7800_DFITBM.CS_SUI_DESCRIPTION, TBL_7800_DFITBM.PUBLISHED, '' AS CS_SERVICE, TBL_7800_DFITBM.ADJ_REF_ID, TBL_7800_DFITBM.DATASRC, TBL_TRMCBSOURCE.PROJECTMANAGER AS PROJECT_MANAGER, '' AS BUSINESS_APP_NAME, TBL_TRMCBSOURCE.CREATEDATE AS CREATE_DATE, TBL_TRMCBSOURCE.DESCRIPTION, TBL_TRMCBSOURCE.GL_CODEOWNER AS GL_CODE_OWNER, TBL_TRMCBSOURCE.PARENTCREATEDATE AS PARENT_CREATE_DATE, TBL_TRMCBSOURCE.PARENTDESCRIPTION AS PARENT_DESCRIPTION, TBL_TRMCBSOURCE.PARENTREQUESTID AS PARENT_REQUEST_ID, TBL_TRMCBSOURCE.PARENTREQUESTTYPE AS PARENT_REQUEST_TYPE, TBL_TRMCBSOURCE.PARENTREQUESTOR AS PARENT_REQUESTOR, TBL_TRMCBSOURCE.PARENTREQUESTOREMAIL AS PARENT_REQUESTOR_EMAIL, TBL_TRMCBSOURCE.REQUESTTYPE AS REQUEST_TYPE, TBL_TRMCBSOURCE.REQUESTOR, TBL_TRMCBSOURCE.REQUESTOREMAIL AS REQUESTOR_EMAIL, TBL_TRMCBSOURCE.PROJECTNAME AS PROJECT_NAME, TBL_TRMCBSOURCE.PROJECTREQUESTOR AS PROJECT_REQUESTOR, TBL_TRMCBSOURCE.PROMPT_ID, TBL_7800_DFITBM.TMDB_APP_CODE, TBL_7800_DFITBM.GLOBAL_APP_ID, TBL_7800_DFITBM.LONG_APP_NAME, '' AS COMPUTE_UNIT_PCT_CPU, '' AS COMPUTE_UNIT_PCT_RAM, '' AS CPU_ALLOCATED, '' AS CPU_AVG_UTIL_PCT, '' AS CPU_PEAK_UTIL_PCT, TBL_TRMCBSOURCE.DATACENTERCODE AS DATA_CENTER_CODE, '' AS DATA_CENTER_NAME, '' AS PCT_UPTIME, '' AS RAM_ALLOCATED, '' AS RAM_AVG_UTIL_PCT, '' AS RAM_PEAK_UTIL_PCT, TBL_7800_DFITBM.EMP_ID, TBL_7800_DFITBM.SITE_CODE, TBL_7800_DFITBM.SUSPEND, TBL_7800_DFITBM.EMAIL_ADDRESS, TBL_7800_DFITBM.EMP_TYPE, TBL_7800_DFITBM.FIRST_NAME, TBL_7800_DFITBM.LAST_NAME, TBL_7800_DFITBM.VCC_SITE FROM TBL_7800_DFITBM LEFT JOIN TBL_TRMCBSOURCE ON TBL_7800_DFITBM.sui_lower =TBL_TRMCBSOURCE.sui_lower;"
        df = pd.read_sql_query(sql_string, con)
        # for col_i in df.columns:
        #     if col_i not in ['CS_SERVICE_DELIVERY_DATE','CREATE_DATE','PARENT_CREATE_DATE']:
        #         df[col_i]=df[col_i].apply(str)   
        # for col_i in range(0,len(df)):
        #     for col_j in range(0,len(df.columns)):
        #         df.iloc[col_i,col_j]=str(df.iloc[col_i,col_j])
        df['CS_SERVICE_DELIVERY_DATE']=pd.to_datetime(df['CS_SERVICE_DELIVERY_DATE'], format='%Y-%m-%d %H:%M:%S')
        df['CREATE_DATE']=pd.to_datetime(df['CREATE_DATE'], format='%Y-%m-%d %H:%M:%S')
        df['PARENT_CREATE_DATE']=pd.to_datetime(df['PARENT_CREATE_DATE'], format='%Y-%m-%d %H:%M:%S')
        for name, dtype in df.dtypes.iteritems():
            print(name+"--"+str(dtype))
        df.to_csv('C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\'+mon_name+'\\VM Ware_DISPLAY_NAME_78000_'+prev_mon_yr+'_MPWR_ChargebackData.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")
        con.commit()
        con.close()
    except Exception as e:
        print("error while generating MPWR File for 78000 DFITBM"+str(e))

# mpwr_78000_dfitbm('April','1903')