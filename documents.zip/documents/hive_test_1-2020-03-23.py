# from pyhive import hive
# # # hive.Conn
# conn = hive.Connection(host="dbslp0503", port='10021',database='default',auth='CUSTOM',username='mpawante',password='Jaimahasai@11')


import pyodbc
from pandas import DataFrame
from datetime import datetime
import csv
print(datetime.now())
pyodbc.autocommit = True
con = pyodbc.connect("DSN=rada_Prod", autocommit=True)
cursor = con.cursor()
cursor.execute("select * from hsr_1.hsr_adr_xref_fmts")
df = DataFrame(cursor.fetchall())
df.columns = cursor.keys()
df.to_csv('C:\\Users\\asrilekh\\Documents\\Hive_Test.csv',index=False,quoting=csv.QUOTE_ALL)
print(df[0:10])
print(list(df.columns))
print(datetime.now())

