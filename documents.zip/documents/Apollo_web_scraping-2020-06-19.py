from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://www.apollo.io/")
driver.find_element_by_xpath('/html/body/div[1]/main/div[1]/div[1]/div/div/div[2]/div/a/span').click()
time.sleep(20)
driver.find_element_by_xpath('//*[@id="identifierId"]').click()
driver.find_element_by_xpath('//*[@id="identifierId"]').send_keys('dummywebscraping')
driver.find_element_by_xpath('//*[@id="identifierNext"]/span/span').click()
time.sleep(5)
driver.find_element_by_xpath('//*[@id="password"]/div[1]/div/div[1]/input').click()
driver.find_element_by_xpath('//*[@id="password"]/div[1]/div/div[1]/input').send_keys('qwert@12345')
driver.find_element_by_xpath('//*[@id="passwordNext"]/span/span').click()
time.sleep(5)
driver.find_element_by_xpath('//*[@id="submit_approve_access"]/span/span').click()
time.sleep(30)
driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div/a/i').click()
time.sleep(30)
driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[1]/div/div[2]/div/span/a/span').click()
driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[1]/span/span[2]/div/span').click()
driver.find_element_by_xpath('/html/body/div[5]/div/div[2]/div/div/div[2]/div/div[1]/div[2]/div/div/span[2]/i').click()
time.sleep(10)
a=driver.find_element_by_xpath('/html/body/div[5]/div/div[2]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/span[1]').text
a=str(a)
a_i=a.index('(',0)
a_j=a.index(')',a_i)
a=a[a_i+1:a_j]
print(a)
a=int(a)
for i in range(0,a):
    driver.find_element_by_xpath('/html/body/div[5]/div/div[2]/div/div/div[2]/div/div[1]/div[2]/div/div[2]/div[1]').click()
# driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[1]/span/div/div/span[2]/div/div/i').click()
webdriver.ActionChains(driver).send_keys(Keys.ESCAPE).perform()
driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[1]/span/div/div/span[2]/div/div/i').click()
time.sleep(30)




first_mt_lst=[]
second_mt_lst=[]
third_mt_lst=[]
fourth_mt_lst=[]
sixth_mt_lst=[]
seventh_mt_lst=[]
eigth_mt_lst=[]
ninth_mt_lst=[]
tenth_mt_lst=[]
key_words_lst=[]
while(True):
    tbl_id=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody')             
    rows=tbl_id.find_elements_by_tag_name("tr")
    rc=1
    for tr in rows:
        tds=tr.find_elements_by_tag_name("td")
        print(len(tds))
        if len(tds) > 4:
            try:
                ## company name
                first_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody/tr['+str(rc)+']/td[1]/div/span/div[2]/a').text
                print(first_mt)
                ## company country
                second_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody/tr['+str(rc)+']/td[2]/span').text
                print(second_mt)
                ## company state
                third_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody/tr['+str(rc)+']/td[3]/span').text
                print(third_mt)
                ## company city
                fourth_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody/tr['+str(rc)+']/td[4]/span').text
                print(fourth_mt)
                ## number of employees
                sixth_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody/tr['+str(rc)+']/td[6]/span').text
                print(sixth_mt)
                
                try:
                    driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody/tr['+str(rc)+']/td[2]').click()
                    
                except:
                    pass
                time.sleep(5)
                ## Industry sector
                seventh_mt=""
                try:            
                    
                    seventh_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[1]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[3]/div/div[2]/div[2]/div').text
                    print(seventh_mt)
                except:
                    pass

                ## Annual revenue
                eigth_mt=""
                try:
                    eigth_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[1]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[3]/div/div[4]/div[2]/div/div').text
                    print(eigth_mt)
                except:
                    pass
                
                ## Address
                ninth_mt=""
                try:
                    ninth_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[1]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[3]/div/div[5]/div/div[2]').text
                    print(ninth_mt)
                except:
                    pass
                
                ## description
                tenth_mt=""
                try:
                    tenth_mt=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[1]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[3]/div/div[8]/div[2]').text
                    print(tenth_mt)
                except:
                    pass

                ## key words
                key_words=""
                try:
                    div_id=driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[1]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[3]/div/div[3]/div[2]/div')
                    print(div_id.text)
                    key_words=div_id.text
                except:
                    pass
                webdriver.ActionChains(driver).send_keys(Keys.ESCAPE).perform()
                # try:
                #     driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/table/tbody/tr['+str(rc)+']/td[2]').click()
                #     print("clicked the side bar to close")
                # except:
                #     pass
                time.sleep(5)
                first_mt_lst.append(first_mt)
                second_mt_lst.append(second_mt)
                third_mt_lst.append(third_mt)
                fourth_mt_lst.append(fourth_mt)
                sixth_mt_lst.append(sixth_mt)
                seventh_mt_lst.append(seventh_mt)
                eigth_mt_lst.append(eigth_mt)
                ninth_mt_lst.append(ninth_mt)
                tenth_mt_lst.append(tenth_mt)
                key_words_lst.append(key_words)

            except Exception as e:
                print(str(e))
        rc=rc+1
    try:
        driver.find_element_by_xpath('//*[@id="provider-mounter"]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div/div[3]/div/span/div/div[3]/div/span[1]/img').click()
        time.sleep(30)
    except:
        break



df=pd.DataFrame()
df['first_mt_lst']=first_mt_lst
df['second_mt_lst']=second_mt_lst
df['third_mt_lst']=third_mt_lst
df['fourth_mt_lst']=fourth_mt_lst
df['sixth_mt_lst']=sixth_mt_lst
df['seventh_mt_lst']=seventh_mt_lst
df['eigth_mt_lst']=eigth_mt_lst
df['ninth_mt_lst']=ninth_mt_lst
df['tenth_mt_lst']=tenth_mt_lst
df['key_words_lst']=ninth_mt_lst
# df.to_excel(r'c:\users\asrilekh\documents\new_cases_cnt_yesterday.xlsx',index=False)
df.to_csv(r'c:\users\asrilekh\documents\comapnies_info.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')


            









