def CountOccurences(S):
    d={}
    S=str(S)
    for si in S:
        if si not in d.keys():
            d[si]=S.count(si)
    op=""
    for k in d.keys():
        op=op+k+str(d[k])
    return op

T=int(input())
for _ in range(T):
    S=input()
    out_=CountOccurences(S)
    print(out_)

