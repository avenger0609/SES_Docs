
import pandas as pd
from pymongo import MongoClient
import pymongo
import time
import datetime

myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
print(myclient.list_database_names())
mydb = myclient["COE_ETL_POC"]
print(mydb.list_collection_names())
mycol = mydb["COE_WOM_US_COVID_DATA"]
# mycol.drop()

df = pd.read_excel('c:/users/asrilekh/downloads/COE_POC.xlsx',encoding = 'latin-1')

print(mycol.insert_many(df.to_dict('records')))

