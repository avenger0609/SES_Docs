import pandas as pd
import csv
from datetime import datetime

################## parameters for joining case and memeber data ######################################################################

#first_file='/app/Apache Druid POC/all_case_data_raw.csv'
#second_file='/app/Apache Druid POC/all_member_data_key.csv'
#output_file='/app/Apache Druid POC/case_member_join_res.csv'
#columns_list=['TGT_View','tmr_outlier','Funding_Arrangement','group_name','mkt_region','entity_adj','ACO_NAME','product_desc','business_segment_adj','market','week','month','year','market_detail','aco_ind','ltc_flg','span']


################## parameters for joining output of above and UIDXWALK_FINAL_THRU03052020 data ######################################################################

#first_file='/app/Apache Druid POC/case_member_join_res.csv'
#second_file='/app/Apache Druid POC/UIDXWALK_FINAL_THRU03052020.csv'
#output_file='/app/Apache Druid POC/join_res_uidxwalk.csv'
#columns_list=['uid']



################## parameters for joining output of above and zip_mktdtl_xwalk_updated data ######################################################################

first_file='/app/Apache Druid POC/New Join Files/case_member_join_res.csv'
second_file='/app/Apache Druid POC/zip_mktdtl_xwalk_updated.csv'
output_file='/app/Apache Druid POC/New Join Files/uidxwalk_mktdtl_large.csv'
columns_list=['business_segment_adj','market_detail','market']



######################################################################

print("started-"+str(datetime.now()))

df2=pd.read_csv(second_file,encoding = 'latin_1')
print("completed reading uidxwalk_mktdtl_large key data "+str(len(df2)))
df1=pd.read_csv(first_file,encoding = 'latin_1')
print("completed reading all case_member_join_res data "+str(len(df1)))
counter=0
lbound=0
rbound=100000
while True:
    if rbound >= len(df1):
        df_temp=df1[lbound:]
    else:
        df_temp=df1[lbound:rbound]
    if counter==0:
        df=pd.merge(df_temp,df2,how='left',on=columns_list)
        df.to_csv('/app/Apache Druid POC/uidxwalk_mktdtlxwalk_largetest.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')
    else:
        df_temp1=pd.merge(df_temp,df2,how='left',on=columns_list)
        df=df.append(df_temp1,ignore_index=True)
    lbound=rbound
    rbound=rbound+100000




######## only after joining zip_mktdtl_xwalk file else comment out######################
df['hour']='00'
df['minute']='00'
df['second']='10'
df['timestamp']=pd.to_datetime(df[['year', 'month', 'week','hour','minute','second']])
df=df.drop(columns=['hour', 'minute','second'])
df_check=df[0:500]
df_check.to_csv('/app/Apache Druid POC/New Join Files/uidxwalk_mktdtlxwalktest.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')
######## only after joining zip_mktdtl_xwalk file else comment out######################

print(str(len(df)))
df.to_csv(output_file,index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')

print("Completed-"+str(datetime.now()))


########################### second approach #################################

import pandas as pd
import csv
from datetime import datetime

################## parameters for joining case and memeber data ######################################################################

#first_file='/app/Apache Druid POC/all_case_data_raw.csv'
#second_file='/app/Apache Druid POC/all_member_data_key.csv'
#output_file='/app/Apache Druid POC/case_member_join_res.csv'
#columns_list=['TGT_View','tmr_outlier','Funding_Arrangement','group_name','mkt_region','entity_adj','ACO_NAME','product_desc','business_segment_adj','market','week','month','year','market_detail','aco_ind','ltc_flg','span']


################## parameters for joining output of above and UIDXWALK_FINAL_THRU03052020 data ######################################################################

#first_file='/app/Apache Druid POC/case_member_join_res.csv'
#second_file='/app/Apache Druid POC/UIDXWALK_FINAL_THRU03052020.csv'
#output_file='/app/Apache Druid POC/join_res_uidxwalk.csv'
#columns_list=['uid']



################## parameters for joining output of above and zip_mktdtl_xwalk_updated data ######################################################################

first_file='/app/Apache Druid POC/join_res_uidxwalk.csv'
second_file='/app/Apache Druid POC/zip_mktdtl_xwalk_updated.csv'
output_file='/app/Apache Druid POC/uidxwalk_mktdtlxwalk.csv'
columns_list=['business_segment_adj','market_detail','market']



######################################################################

print("started-"+str(datetime.now()))

df2=pd.read_csv(second_file,encoding = 'latin_1')
print("completed reading member key data "+str(len(df2)))
df1=pd.read_csv(first_file,encoding = 'latin_1')
print("completed reading all case data "+str(len(df1)))
df1_len=len(df1)
df1=pd.read_csv(first_file, encoding='latin_1', nrows=10000)
df=pd.merge(df1,df2,how='left',on=columns_list)
df.to_csv('/app/Apache Druid POC/uidxwalk_mktdtlxwalktop1m.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')
chunk_c=1
while True:
    if (chunk_c*10000)+1+10000 <=df1_len:
        df1=pd.read_csv(first_file, encoding='latin_1', skiprows=range(1, (chunk_c*10000)+1), nrows=10000)
        df=df.append(df1, ignore_index = True)
    else:
        df1=pd.read_csv(first_file, encoding='latin_1', skiprows=range(1, (chunk_c*10000)+1), nrows=(chunk_c*10000)+1-10000)
        df=df.append(df1, ignore_index = True)
        break
    chunk_c=chunk_c+1

######## only after joining zip_mktdtl_xwalk file else comment out######################
df['hour']='00'
df['minute']='00'
df['second']='10'
df['timestamp']=pd.to_datetime(df[['year', 'month', 'week','hour','minute','second']])
df=df.drop(columns=['hour', 'minute','second'])
df_check=df[0:500]
df_check.to_csv('/app/Apache Druid POC/uidxwalk_mktdtlxwalktest.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')
######## only after joining zip_mktdtl_xwalk file else comment out######################

print(str(len(df)))
df.to_csv(output_file,index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')

print("Completed-"+str(datetime.now()))
