file2 = open("C:\\Users\\asrilekh\\Documents\\training_examples_json\\sample_Data_Claims_revsd.json","w")
file1 = open("C:\\Users\\asrilekh\\Documents\\training_examples_json\\sample_Data_Claims.json","r")
count=0
line1=""
line1_revsd=""
x=list()
for line in file1:
    count=count+1
    line1=line.rstrip(line[-1:])
    if count > 31359 and "text" in line1 and ": " in line1:
        line1_revsd=line1.replace('in january ','')
        line1_revsd=line1.split(':')[0]+":"+line1.split(':')[1].replace('\",',' in first quarter of 2019},').replace('\"','{in first quarter of 2019 ')
        line1_revsd=line1_revsd.replace('{','\"').replace('}','\"')
        x.append(line1_revsd)
        line1=""
        line1_revsd=""
        continue
    x.append(line1)
    line1=""
    line1_revsd=""
for x1 in x:
    file2.write(x1+"\n")
file1.close()
file2.close()