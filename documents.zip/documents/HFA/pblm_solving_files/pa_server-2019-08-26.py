from flask import Flask
from flask import render_template,jsonify,request
import requests
from models import *
from pblm_solving_files.knowledge_rev import *
from pblm_solving_files.duckling_wrapper import *
from pblm_solving_files.conv_history import *
from pblm_solving_files.uid_sessid_storing import *
from pblm_solving_files.mongodb_interaction import *
from pblm_solving_files.context_history import *
from pblm_solving_files.mongodb_interaction_srch import *
from pblm_solving_files.PA_mongoAPI import *
from pblm_solving_files.PAmongoSearchAPI import *
from pblm_solving_files.PA_context_history import *
from pblm_solving_files.PA_conv_history import *
from pblm_solving_files.calls_server import *
from pblm_solving_files.claims_server import *

import random
import urllib3
from flask_cors import CORS
import json
import ast


def pa_parse(ps1):

    print("entered pa_parse")

    try:
        # print((request.url))
        # parsed=(urllib3.util.url.parse_url(request.url))
        print(str(ps1))
        s1=str(str(ps1).split('&')[0].split('=')[1].replace('+',' ')) # first query
        ## changed code after prior auth integration ##
        while True:
            a=s1.find("%")
            if a > -1:
                ss=s1[a]+s1[a+1]+s1[a+2]
                s1=s1.replace(ss," ")
            else:
                break 
        s1=s1.replace('  ',' ').replace('  ',' ').strip(' ') 
        ## changed code after prior auth integration ##
        uid_gen=1 # to check if user id was sent or not
        sessid_gen=1 # to check if session id was sent or not
        userid_ang="DEFAULT" # to store user id sent from angular
        sess_id_ang="DEFAULT"# to store session id sent from angular
        provider_lst=list() ### to store providers list
        req_from=""
        try:
            userid_ang=str(str(ps1).split('&')[1].split('=')[1].replace('+',' ')) # second query
        except:
            uid_gen=0
        try:
            sess_id_ang=str(str(ps1).split('&')[2].split('=')[1].replace('+',' ')) # second query
        except:
            sessid_gen=0
        try:            
            prov_id_ang=str(str(ps1).split('&')[3].split('=')[1].replace('+',' ')) # second query
            if '%2C' in prov_id_ang:
                provider_lst=prov_id_ang.split('%2C') 
            else:
                provider_lst=prov_id_ang.split(',') 
            print("provider_lst is "+str(provider_lst))
        except Exception as e:
            print(str(e))
            provid_gen=0
        try:
            req_from=str(str(ps1).split('&')[4].split('=')[1].replace('+',' ')) # second query
        except:
            req_from_gen=0
        ## changed code after prior auth integration ##
        try:
            req_chart_type=str(str(ps1).split('&')[5].split('=')[1].replace('+',' ')) # second query
        except:
            req_chart_type_gen=0
        try:
            req_claim_type_req=str(str(ps1).split('&')[6].split('=')[1].replace('+',' ')) # second query
        except:
            req_claim_type_req_gne=0
        ## changed code after prior auth integration ##
        if req_from.lower()=='search':
            while True:
                a=s1.find("%")
                if a > -1:
                    ss=s1[a]+s1[a+1]+s1[a+2]
                    s1=s1.replace(ss," ")
                else:
                    break 
            s1=s1.replace('  ',' ').replace('  ',' ').strip(' ') 
            ans=pa_main_func(userid_ang,sess_id_ang,s1,provider_lst,req_chart_type) ## changed code after prior auth integration ##
            kv_claims=[]
            kv_claims.append(ans)
            kv_claims.append("")
            kv_claims.append(list())
            return kv_claims
            
        if uid_gen==1 and sessid_gen==1:
            uid_sessid(userid_ang,sess_id_ang)
        # to remove unwanted characters
        print("userid="+userid_ang+"session id="+sess_id_ang)
        while True:
            a=s1.find("%")
            if a > -1:
                ss=s1[a]+s1[a+1]+s1[a+2]
                s1=s1.replace(ss," ")
            else:
                break        
        s1=s1.replace('  ',' ').replace('  ',' ').strip(' ')       
        print(s1)
        s1=str(s1)
        print(s1)
        # to remove unwanted characters
        if 'queries' in s1.lower().split(' ') and 'related' in s1.lower().split(' ') and 'to' in s1.lower().split(' ') and 'prior' in s1.lower().split(' ') and 'authorization' in s1.lower().split(' '):
            # ts=pop_conv_hist(userid_ang,sess_id_ang)
            temp_ret=pa_pop_context_hist_claim(userid_ang,sess_id_ang)
            if len(temp_ret)==0:
                ts="no conversation history found" ### just to be in tact with everything not really meant this statement
            else:
                ts="context history found"
            if ts=="no conversation history found":
                s1="status of prior auth "
            else:
                sugg_list=list()
                sugg_list.append("Yes")
                sugg_list.append("No")
                conv_uid=userid_ang
                conv_sesid=sess_id_ang
                conv_question="Queries related to prior auth"
                conv_answer="Do you want to continue with old hsc id"
                conv_intent="Double request"
                conv_int_conf="0"
                conv_like_r_dislike="default"                
                conv_obj_id=pa_conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
                kv_claims=[]
                kv_claims.append("Do you want to continue with old hsc id")
                kv_claims.append(conv_obj_id)
                kv_claims.append(sugg_list)
                return kv_claims                
         
        if s1.lower()=="yes":
            ts=pa_pop_conv_hist(userid_ang,sess_id_ang)
            if ts=="Queries related to prior auth":
                s1 = "status of PA request "+str((pa_pop_context_hist_claim(userid_ang,sess_id_ang))[5])
        elif s1.lower()=="no":
            ts=pa_pop_conv_hist(userid_ang,sess_id_ang)
            if ts=="Queries related to prior auth":
                conv_uid=userid_ang
                conv_sesid=sess_id_ang
                conv_question=ts
                conv_answer="question incomplete"
                conv_intent="request incomplete"
                conv_int_conf="0"
                conv_like_r_dislike="default"
                conv_obj_id=pa_conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
                kv_claims=[]
                kv_claims.append("Please enter hsc id")
                kv_claims.append(conv_obj_id)
                kv_claims.append(list())
                return kv_claims                
        ########## to check if intents are greet, bye or affirm ############
        s1_test=s1
        temp_cn=str(claim_num_extract(s1))
        print("returned hsc id "+temp_cn)
        s1=s1.replace(temp_cn,'')
        # s1=corrected_ip_string_1(s1,"CLAIM") # changed after integration
        print(s1)
        if len(s1.strip(' ')) > 0 and "status" not in s1.lower() and "claim" not in s1.lower() :  # changed after integration           
            
            try:
                response_g = requests.get("http://apsrp03693:8066/parse",params={"q":s1})               
                response_g = response_g.json()   
                intent_g = (response_g.get("intent"))
                res_intent_g=(intent_g['name'])
                intent_g=(intent_g)
                res_intent_g=(str(res_intent_g))
                gt_ind=0
                if res_intent_g.lower()=="greet":
                    ans_g=greeting()
                    gt_ind=1
                elif res_intent_g.lower()=="affirm" or res_intent_g.lower()=="none":
                    ans_g=affirm()
                    gt_ind=1
                elif res_intent_g.lower()=="goodbye":
                    ans_g=goodbye()
                    gt_ind=2                             
                
                if gt_ind==1 or gt_ind==2:
                    if 'how' in s1.lower() and ('are' in s1.lower() or ' r ' in s1.lower()) and (' u ' in s1.lower() or 'you' in s1.lower()):
                        ans_g="Good! Thanks for asking"
                    elif 'who' in s1.lower() and ('are' in s1.lower() or ' r ' in s1.lower()) and (' u ' in s1.lower() or 'you' in s1.lower()):
                        ans_g="I am bot, How can I help you"
                    conv_uid_g=userid_ang
                    conv_sesid_g=sess_id_ang
                    conv_question_g=s1
                    conv_answer_g=ans_g
                    conv_intent_g=res_intent_g
                    conv_int_conf_g=str(intent_g['confidence'])
                    conv_like_r_dislike_g="default"
                    conv_obj_id_g=pa_conv_hist(conv_uid_g,conv_sesid_g,conv_question_g,conv_answer_g,conv_intent_g,conv_int_conf_g,conv_like_r_dislike_g)
                    kv_claims=[]
                    kv_claims.append(ans_g)
                    kv_claims.append(conv_obj_id_g)
                    kv_claims.append(list())
                    return kv_claims                              
                print("returned intent from first request is "+res_intent_g)
            except Exception as e:
                print(str(e))
        s1=s1_test
        ########## to check if intents are greet, bye or affirm ############
        user_message = s1 # to store original user message in some variable
        um1=user_message # to store original user message in some variable

        #### context storing variables ##

        context_uid=userid_ang
        context_sessid=sess_id_ang
        context_type_of_req="default"
        context_claim_r_claims="default"
        context_context="default"
        context_claim_num="default"
        context_from="default"
        context_to="default"
        context_days=list()
        context_months=list()
        context_years=list()

        #### context storing variables ##

        
        #########   DERIVING CLAIM NUMBER AND IT'S CONTEXT IF CLAIM NUMBER IS IN REQUEST  #########

        claim_num='0'
        if True:
            print("entered if1 "+user_message)           
            claim_num=str(claim_num_extract(um1))
            if str(claim_num)=='0':
                print("entered if2 "+user_message)           
                junk=1
            else:
                print("entered else2 "+user_message)           
                context_claim_r_claims="PRIOR_AUTH"
                context_claim_num=claim_num  
                context_context=getStatusPA(str(context_claim_num))
                if context_context.split('}')[0]=='1':
                    context_context="DENIED"
                elif context_context.split('}')[0]=='2':
                    context_context="APPROVED"
                elif context_context.split('}')[0]=='3':
                    context_context="CANCELLED" 
                elif context_context.split('}')[0]=='4':
                    context_context="APPROVED"
                elif context_context.split('}')[0]=='5':
                    context_context="PARTIALLY DENIED"
                elif context_context.split('}')[0]=='6':
                    context_context="DENIED"
                elif context_context.split('}')[0]=='7':
                    # context_context="NOT FOUND
                    conv_uid=userid_ang
                    conv_sesid=sess_id_ang
                    conv_question=um1
                    conv_answer="There is no PA claim available with provided hsc ID"
                    conv_intent="PA Claim Not Found"
                    conv_int_conf="0"
                    conv_like_r_dislike="default"
                    conv_obj_id=pa_conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
                    kv_claims=[]
                    kv_claims.append("There is no PA Claim available with provided hsc ID")
                    kv_claims.append(conv_obj_id)
                    kv_claims.append(list())
                    return kv_claims 
                    
                user_message=user_message.replace(context_claim_num,'')
                if len(user_message.strip(' '))==0:
                    print("entered if length 0")
                    um=pa_pop_conv_hist(userid_ang,sess_id_ang)+" "+um1.strip(' ')
                    if um.lower().strip(' ')==("Queries related to prior auth"+" "+um1.strip(' ')).strip(' ').lower():
                        user_message="Status of PA request "
                        um1="Status of PA request "
                    else:
                        user_message=um
                        um1=um                  

        #########   DERIVING CLAIM NUMBER AND IT'S CONTEXT IF CLAIM NUMBER IS IN REQUEST  #########
        # print("user message after claim number replacement is"+user_message)
        #days,months,years extracted to be returned
        dte_text_lst=list() # to replace text which refers to duaration of time
        if str(claim_num)=='0':
            dmy_lst=time_extract(um1) # returned from duckling            
            if len(dmy_lst) > 0:
                context_claim_r_claims="PRIOR_AUTH"
                if len(dmy_lst)==3:            
                    context_from=dmy_lst[0]
                    context_to=dmy_lst[1]            
                    dte_text_lst=dmy_lst[2]         
                elif len(dmy_lst)==4:
                    context_days=(dmy_lst[0])
                    context_months=(dmy_lst[1])
                    context_years=(dmy_lst[2])
                    dte_text_lst=dmy_lst[3]            
                for dte_i in dte_text_lst:
                    user_message=user_message.replace(" "+dte_i+" "," ")
            #days,months,years extracted to be returned
            print("user message after date text replacement is "+user_message)

        # print("user_message is "+user_message)
        # user_message=user_message.replace(" - ","-")
        # user_message=corrected_ip_string_1(user_message,"CLAIM")
        # user_message=corrected_ip_string_1(user_message.replace('-',' '))           

        #### retrieving values from context collection ########

        # changed after integration of pA

        # changed after integration of pA


    
        if len(dte_text_lst)==0 and str(claim_num)=='0':
            ret_cntxt=pa_pop_context_hist(context_uid,context_sessid)
            print("returned context"+str(ret_cntxt))
            if len(ret_cntxt) > 0:  
                context_type_of_req=ret_cntxt[2]
                context_claim_r_claims=ret_cntxt[3]
                context_context=ret_cntxt[4]
                context_claim_num=ret_cntxt[5]
                context_from=ret_cntxt[6]
                context_to=ret_cntxt[7]
                context_days=ret_cntxt[8]
                context_months=ret_cntxt[9]
                context_years=ret_cntxt[10]
            else:
                conv_uid=userid_ang
                conv_sesid=sess_id_ang
                conv_question=um1
                conv_answer="question incomplete"
                conv_intent="request incomplete"
                conv_int_conf="0"
                conv_like_r_dislike="default"
                conv_obj_id=pa_conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
                kv_claims=[]
                kv_claims.append("Please enter for hsc Id for PA")
                kv_claims.append(conv_obj_id)
                kv_claims.append(list())
                return kv_claims               
        


        #### retrieving values from context collection ########

        #########   DERIVING CONTEXT IF THERE IS DURATION IS IN REQUEST  #########
        # changed after integration##
        if "denied" in user_message.lower():
            context_context="DENIED" 
        elif "approved" in user_message.lower():
            context_context="APPROVED"
        elif "cancelled" in user_message.lower():
            context_context="CANCELLED"
        elif "received" in user_message.lower():
            context_context="RECEIVED"
        else:
            ret_cntxt=pa_pop_context_hist(context_uid,context_sessid)
            if len(ret_cntxt) > 0:  
                if ret_cntxt[3].upper()=="PRIOR_AUTH":
                    context_context=ret_cntxt[4]
                else:
                    context_context="RECEIVED"             
                if context_context.lower()=="default":
                    context_context="RECEIVED"
        # changed after integration##         
        #########   DERIVING CONTEXT IF THERE IS DURATION IS IN REQUEST  #########   

        ###################################################

        # print("user_message is "+user_message)
        # user_message=user_message.replace(" - ","-")
        # user_message=corrected_ip_string_1(user_message,context_claim_r_claims)
        # user_message=corrected_ip_string_1(user_message.replace('-',' '),context_claim_r_claims) 
        # user_message=str(user_message).strip(' ').lower() 

        ####################################################

        ##### addding claim/claims accordingly #######

        user_message=user_message+" towards PA"


               
        response = requests.get("http://apsrp03693:8066/parse",params={"q":user_message})                
        response = response.json()
        
        # response text to be returned
        res_text=um1
        # response text to be returned

        # intent to be returned
        intent = response.get("intent")
        res_intent=intent['name']
        res_intent_confidence=intent['confidence']
        res_claim_num=context_claim_num
        # intent to be returned
        # entities=response.get("entities")                
        print("returned intent is "+res_intent)
        ans = "Unanswered"
        sugg_list = []
        if res_intent.lower() == "status_prior_auth":
            ans = getStatusPA(str(res_claim_num))
            sugg_list.append("When was the PA requested?")
            sugg_list.append("What's the turnaround time for the PA?")
            sugg_list.append("What's the service setting type for the PA?")
            sugg_list.append("How many line items are there?")
        elif res_intent.lower() == "pa_request_date":
            ans = getRequestSubmittedDate(str(res_claim_num))
            sugg_list.append("What's the turnaround time for the PA?")
            sugg_list.append("What's the service type of the PA?")
            sugg_list.append("What was the service category of the PA?")
        elif res_intent.lower() == "pa_decision":
            ans = getDecisionDate(str(res_claim_num))
            sugg_list.append("What's the turnaround time for the PA?")
            sugg_list.append("What are the reasons for denial?")
            sugg_list.append("What line of business does this PA belong to?")
            sugg_list.append("How many line items are there?")
        elif res_intent.lower() == "pa_service_type":
            ans = getServiceType(str(res_claim_num))
            sugg_list.append("What's the service setting type for the PA?")
            sugg_list.append("When was the decision made on the PA request?")
            sugg_list.append("What was the service category of the PA?")
        elif res_intent.lower() == "pa_service_cat":
            ans = getServiceCategory(str(res_claim_num))
            sugg_list.append("What's the service setting type for the PA?")
            sugg_list.append("What's the service type of the PA?")
            sugg_list.append("What line of business does this PA belong to?")
        elif res_intent.lower() == "pa_service_setting":
            ans = getServiceSettingType(str(res_claim_num))
            sugg_list.append("When was the PA requested?")
            sugg_list.append("When was the decision made on the PA request?")
            sugg_list.append("What's the turnaround time for the PA?")
            sugg_list.append("How many line items are there?")
        elif res_intent.lower() == "pa_lob":
            ans = getLOBPA(str(res_claim_num))
            sugg_list.append("What's the service type of the PA?")
            sugg_list.append("What was the service category of the PA?")
            sugg_list.append("What's the service setting type for the PA?")
        elif res_intent.lower() == "pa_taxid":
            ans = getTaxID(str(res_claim_num))
            sugg_list.append("When was the decision made on the PA request?")
            sugg_list.append("What line of business does this PA belong to?")
            sugg_list.append("What's the service type of the PA?")
        elif res_intent.lower() == "pa_line_items":
            ans = getLineItems(str(res_claim_num))
            sugg_list.append("What's the service type of the PA?")
            sugg_list.append("What's the turnaround time for the PA?")
            sugg_list.append("What was the service category of the PA?")
        elif res_intent.lower() == "pa_tat":
            ans = getTATPA(str(res_claim_num))
            sugg_list.append("When was the decision made on the PA request?")
            sugg_list.append("What are the reasons for denial?")
            sugg_list.append("What's the service setting type for the PA?")
        elif res_intent.lower() == "pa_denial_rsns":
            ans = getReasonsDenials(str(res_claim_num))
            sugg_list.append("What was the service category of the PA?")
            sugg_list.append("When was the decision made on the PA request?")
            sugg_list.append("What's the service setting type for the PA?")
        elif res_intent.lower() == "pa_cancel_rsns":
            ans = getCancelReasons(str(res_claim_num))
            sugg_list.append("What was the service category of the PA?")
            sugg_list.append("When was the decision made on the PA request?")
            sugg_list.append("What's the service setting type for the PA?")
        elif res_intent.lower() == "pa_approve_rsns":
            ans = getApprovalReasons(str(res_claim_num))
            sugg_list.append("What was the service category of the PA?")
            sugg_list.append("When was the decision made on the PA request?")
            sugg_list.append("What's the service setting type for the PA?")
        else:
            ans="I am not prepare for your question as of now"
            
        print(context_uid,context_sessid,context_type_of_req,context_claim_r_claims,context_context,context_claim_num,context_from,context_to,context_days,context_months,context_years)     
        pa_push_context_hist(context_uid,context_sessid,context_type_of_req,context_claim_r_claims,context_context,context_claim_num,context_from,context_to,context_days,context_months,context_years)
        ###### context history push call #######
        #####conv_history parameters and function call ########
        conv_uid=userid_ang
        conv_sesid=sess_id_ang
        conv_question=res_text
        conv_answer=ans
        conv_intent=res_intent
        conv_int_conf=res_intent_confidence
        conv_like_r_dislike="default"
        conv_obj_id=pa_conv_hist(conv_uid,conv_sesid,conv_question,conv_answer,conv_intent,conv_int_conf,conv_like_r_dislike)
        #####conv_history parameters and function call ########
        print(conv_uid)
        print(conv_sesid)
        print(conv_question)
        print(conv_answer)
        print(conv_intent)
        print(conv_int_conf)
        print(conv_like_r_dislike)
        if conv_answer == "Unanswered" or conv_answer == "Sorry, Could not fetch you results at this time" or conv_answer=="I am not prepare for your question as of now":
            conv_answer=u"Sorry I do not have an answer for that. You may reach out to us through call or email for assistance."
        kv_claims=[]
        kv_claims.append(conv_answer)
        kv_claims.append(conv_obj_id)
        kv_claims.append(sugg_list)
        return kv_claims
        # return jsonify({"response":conv_answer,"object_id":conv_obj_id,"Suggestions":sugg_list})
    except Exception as e:
    # else:
        print(e) 
        kv_claims=[]
        kv_claims.append("Sorry I do not have an answer for that. You may reach out to us through call or email for assistance.")
        kv_claims.append("")
        kv_claims.append("")
        return kv_claims
         

