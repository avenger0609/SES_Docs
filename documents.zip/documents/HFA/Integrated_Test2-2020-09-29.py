from flask import Flask
from flask import render_template,jsonify,request
import requests
from models import *
from pblm_solving_files.knowledge_rev import *
from pblm_solving_files.duckling_wrapper import *
from pblm_solving_files.conv_history import *
from pblm_solving_files.uid_sessid_storing import *
from pblm_solving_files.mongodb_interaction import *
from pblm_solving_files.context_history import *
from pblm_solving_files.mongodb_interaction_srch import *
from pblm_solving_files.PA_mongoAPI import *
from pblm_solving_files.PAmongoSearchAPI import *
from pblm_solving_files.PA_context_history import *
from pblm_solving_files.PA_conv_history import *
from pblm_solving_files.calls_server import *
from pblm_solving_files.claims_server import *
from pblm_solving_files.pa_server import *

import random
import urllib3
from flask_cors import CORS
import json
import ast

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False
app.secret_key = '12345'
CORS(app)

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route("/parse", methods=['GET', 'POST', 'OPTIONS'])
def parse():

    try:
        # print((request.url))
        parsed=(urllib3.util.url.parse_url(request.url))
        print(str(parsed.query))
        s1=str(str(parsed.query).split('&')[0].split('=')[1].replace('+',' ')) # first query
        uid_gen=1 # to check if user id was sent or not
        sessid_gen=1 # to check if session id was sent or not
        userid_ang="DEFAULT" # to store user id sent from angular
        sess_id_ang="DEFAULT"# to store session id sent from angular
        provider_lst=list() ### to store providers list
        req_from=""
        try:
            userid_ang=str(str(parsed.query).split('&')[1].split('=')[1].replace('+',' ')) # second query
        except:
            uid_gen=0
        try:
            sess_id_ang=str(str(parsed.query).split('&')[2].split('=')[1].replace('+',' ')) # second query
        except:
            sessid_gen=0
        try:            
            prov_id_ang=str(str(parsed.query).split('&')[3].split('=')[1].replace('+',' ')) # second query
            if '%2C' in prov_id_ang:
                provider_lst=prov_id_ang.split('%2C') 
            else:
                provider_lst=prov_id_ang.split(',') 
            print("provider_lst is "+str(provider_lst))
        except Exception as e:
            print(str(e))
            provid_gen=0
        try:
            req_from=str(str(parsed.query).split('&')[4].split('=')[1].replace('+',' ')) # second query
        except:
            req_from_gen=0
        try:
            req_chart_type=str(str(parsed.query).split('&')[5].split('=')[1].replace('+',' ')) # second query
        except:
            req_chart_type_gen=0
        
        try:
            req_type=str(str(parsed.query).split('&')[6].split('=')[1].replace('+',' ')) # second query
        except:
            req_type_gen=0



        if req_type.lower()=="calls" and req_from.lower()=='search':
            print("calls condition checking passed")
            ans_calls=calls_parse(str(parsed.query))
            # return jsonify(ans_calls)
            # return jsonify({"response":ans_calls[0],"object_id":ans_calls[1],"Suggestions":ans_calls[2]})
            if "'Value': []" in str(ans_calls[0]) or "'Value': []" in str(ans_calls[0]).replace(", '0'","").replace("'0'",""):
                return jsonify({"response":"Sorry, no records were found. Please adjust your search criteria and try again."})
            
            return jsonify(ans_calls[0])
        elif req_type.lower()=="calls" and req_from.lower()=='chat':
            print("calls condition checking passed")
            ans_calls=calls_parse(str(parsed.query))
            # return jsonify(ans_calls)
            return jsonify({"response":ans_calls[0],"object_id":ans_calls[1],"Suggestions":ans_calls[2]})
        else:
            print("calls condition checking failed")



        
        if req_type.lower()=="claims" and req_from.lower()=='search':
            print("pa condition checking passed")
            ans_calls=claims_parse(str(parsed.query))
            # return jsonify(ans_calls)
            # return jsonify({"response":ans_calls[0],"object_id":ans_calls[1],"Suggestions":ans_calls[2]})
            if "'Value': []" in str(ans_calls[0]) or "'Value': []" in str(ans_calls[0]).replace(", '0'","").replace("'0'",""):
                return jsonify({"response":"Sorry, no records were found. Please adjust your search criteria and try again."})
            
            return jsonify(ans_calls[0])
        elif req_type.lower()=="claims" and req_from.lower()=='chat':
            print("claims condition checking passed")
            ans_calls=claims_parse(str(parsed.query))
            # return jsonify(ans_calls)
            return jsonify({"response":ans_calls[0],"object_id":ans_calls[1],"Suggestions":ans_calls[2]})
        else:
            print("claims condition checking failed")



        
        if req_type.lower()=="prior_auth" and req_from.lower()=='search':
            print("pa condition checking passed")
            ans_calls=pa_parse(str(parsed.query))
            # return jsonify(ans_calls)
            # return jsonify({"response":ans_calls[0],"object_id":ans_calls[1],"Suggestions":ans_calls[2]})
            if "'Value': []" in str(ans_calls[0]) or "'Value': []" in str(ans_calls[0]).replace(", '0'","").replace("'0'",""):
                return jsonify({"response":"Sorry, no records were found. Please adjust your search criteria and try again."})
            
            return jsonify(ans_calls[0])
        elif req_type.lower()=="prior_auth" and req_from.lower()=='chat':
            print("claims condition checking passed")
            ans_calls=pa_parse(str(parsed.query))
            # return jsonify(ans_calls)
            return jsonify({"response":ans_calls[0],"object_id":ans_calls[1],"Suggestions":ans_calls[2]})
        else:
            return jsonify({"response":"Coming Soon.."})

        
    except Exception as e:
    # else:
        print(e) 
        return jsonify({"response":"Sorry I do not have an answer for that. You may reach out to us through call or email for assistance."})   

app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(host='apsrp03693',port=8065,debug=True)
    # app.run(host='localhost',port=8030,debug=True)
