import pandas as pd
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3

cdf1=pd.read_csv('C:\\Users\\asrilekh\\documents\\cy_case.csv',encoding='latin-1')
print(cdf1.columns)
cdf2=pd.read_csv('C:\\Users\\asrilekh\\documents\\mbr_final_cy.csv',encoding='latin-1')
print(cdf2.columns)
cdf1_temp=cdf1[0:10]
cdf2_temp=cdf2[0:10]
for cdfc in range(0,len(cdf1.columns)):
    if cdf1.columns[cdfc]=="group":
        cdf1.columns[cdfc]="group_name"

for cdfc in range(0,len(cdf2.columns)):
    if cdf2.columns[cdfc]=="group":
        cdf2.columns[cdfc]="group_name"

print(cdf1.columns)
print(cdf2.columns)
db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
con = sqlite3.connect(db_file)
cdf1_temp.to_sql("tbl_case", con, if_exists='replace', index=False)
cdf2_temp.to_sql("tbl_mf", con, if_exists='replace', index=False)


