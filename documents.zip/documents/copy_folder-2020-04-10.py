import os
import shutil

# shutil.copytree(r'C:\Program Files (x86)\Google\Chrome\Application',r'C:\Users\asrilekh\Documents\backup-chrome\Application')
# shutil.copytree(r'C:\Program Files (x86)\Google\Chrome\Temp',r'C:\Users\asrilekh\Documents\backup-chrome\Temp')
shutil.copytree(r'C:\ProgramData\Chrome_driver_80.0.3987.16',r'C:\Users\asrilekh\Documents\backup-chrome\Chrome_driver_80.0.3987.16')