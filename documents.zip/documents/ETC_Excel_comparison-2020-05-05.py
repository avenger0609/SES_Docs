import pandas as pd



hive_fname=r'c:\users\asrilekh\documents\ETC_DOMO_Report_common.xlsx' ## DOMO treating as old file
sas_fname=r'c:\users\asrilekh\documents\ETC_OSAM_Report_common_first.xlsx' ## treating as new file
compare_output=r'C:\Users\asrilekh\Documents\ETC_Comprison_dup_first.xlsx'
key_column='formattedid'    


hive_df=pd.read_excel(hive_fname, na_values=['N/A'])
# hive_df=hive_df[hive_df['Leader 2'].astype(str).str.upper().isin(['LIBRIZZI, MARC'.upper()])]
print(len(hive_df.columns))
print(len(hive_df))


sas_df=pd.read_excel(sas_fname, na_values=['N/A'])
print((sas_df.columns))
print(len(sas_df))

hive_df.columns = map(str.lower, hive_df.columns)
sas_df.columns=map(str.lower, sas_df.columns)

hive_df = hive_df.dropna(how='all')
sas_df = sas_df.dropna(how='all')

hive_df=hive_df.fillna('')
sas_df=sas_df.fillna('')

hive_df=hive_df.sort_values([key_column], ascending = (True))
sas_df=sas_df.sort_values([key_column], ascending = (True))

hive_df_columns=list(hive_df.columns)
sas_df_columns=list(sas_df.columns)


cols_in_hive_missing_in_sas=list(set(hive_df_columns) - set(sas_df_columns))
cols_in_sas_missing_in_hive=list(set(sas_df_columns) - set(hive_df_columns))

print(len(cols_in_hive_missing_in_sas))
print(len(cols_in_sas_missing_in_hive))

print((cols_in_hive_missing_in_sas))
print((cols_in_sas_missing_in_hive))


hive_df=hive_df.drop(cols_in_hive_missing_in_sas, axis = 1)
sas_df=sas_df.drop(cols_in_sas_missing_in_hive, axis = 1)


old=hive_df
new=sas_df

columns_list=list(hive_df.columns)

hive_df=hive_df[list(hive_df.columns)]
sas_df=sas_df[list(hive_df.columns)]

print(hive_df.columns)
print(sas_df.columns)

# hive_df.to_excel(r'c:\users\asrilekh\documents\ETC_DOMO_Report_Test.xlsx',index=False)
# sas_df.to_excel(r'c:\users\asrilekh\documents\ETC_OSAM_Report_Test.xlsx',index=False)  
  
hdf_key_uniq_lst=list(hive_df[key_column])
print(len(hdf_key_uniq_lst))
hdf_key_uniq_lst=list(hive_df[key_column].unique())
print(len(hdf_key_uniq_lst))

sasdf_key_uniq_lst=list(sas_df[key_column])
print(len(sasdf_key_uniq_lst))
sasdf_key_uniq_lst=list(sas_df[key_column].unique())
print(len(sasdf_key_uniq_lst))

# common_elements=list(set(sasdf_key_uniq_lst).intersection(set(hdf_key_uniq_lst)))
# print(len(common_elements))

# sas_df = sas_df.drop_duplicates(subset=key_column, keep='first')
# sas_df.to_excel(r'c:\users\asrilekh\documents\ETC_OSAM_Report_keep_first.xlsx')
# hive_df=hive_df.drop_duplicates(subset=key_column, keep='first')

# sasdf_key_uniq_lst=list(sas_df[key_column])
# print(len(sasdf_key_uniq_lst))
# sasdf_key_uniq_lst=list(sas_df[key_column].unique())
# print(len(sasdf_key_uniq_lst))


# hive_df=hive_df[hive_df[key_column].astype(str).str.upper().isin(common_elements)]
# hive_df.to_excel(r'c:\users\asrilekh\documents\ETC_DOMO_Report_common.xlsx')
# sas_df=sas_df[sas_df[key_column].astype(str).str.upper().isin(common_elements)]
# sas_df.to_excel(r'c:\users\asrilekh\documents\ETC_OSAM_Report_common_first.xlsx')

# hive_df=hive_df.reset_index(drop=True)
# sas_df=sas_df.reset_index(drop=True)


### to test for few records

# old=old[0:10]
# new=new[0:10]

# output_file='test_records.xlsx'
# with pd.ExcelWriter(output_file) as writer:  
#     old.to_excel(writer,sheet_name='Hive',index=False)
#     new.to_excel(writer,sheet_name='Sas',index=False)



### to test for few records

old['version'] = "old"
new['version'] = "new"
old_accts_all = set(old[key_column])
new_accts_all = set(new[key_column])

dropped_accts = old_accts_all - new_accts_all
added_accts = new_accts_all - old_accts_all
all_data = pd.concat([old,new],ignore_index=True)
changes = all_data.drop_duplicates(subset=columns_list, keep='last')
dupe_accts = changes[changes[key_column].duplicated() == True][key_column].tolist()
dupes = changes[changes[key_column].isin(dupe_accts)]
# Pull out the old and new data into separate dataframes
change_new = dupes[(dupes["version"] == "new")]
change_old = dupes[(dupes["version"] == "old")]

# Drop the temp columns - we don't need them now
change_new = change_new.drop(['version'], axis=1)
change_old = change_old.drop(['version'], axis=1)

# Index on the account numbers
change_new.set_index(key_column, inplace=True)
change_old.set_index(key_column, inplace=True)

# Combine all the changes together
df_all_changes = pd.concat([change_old, change_new],
                            axis='columns',
                            keys=['old', 'new'],
                            join='outer')
# Define the diff function to show the changes in each field
def report_diff(x):
    # print(x)
    return x[0] if x[0] == x[1] else '{} <> {}'.format(*x)
df_all_changes = df_all_changes.swaplevel(axis='columns')[change_new.columns[0:]]
df_changed = df_all_changes.groupby(level=0, axis=1).apply(lambda frame: frame.apply(report_diff, axis=1))
df_changed = df_changed.reset_index()
df_removed = changes[changes[key_column].isin(dropped_accts)]
df_added = changes[changes[key_column].isin(added_accts)]
output_columns = columns_list
writer = pd.ExcelWriter(compare_output)
df_changed.to_excel(writer,"changed", index=False, columns=output_columns)
df_removed.to_excel(writer,"removed",index=False, columns=output_columns)
df_added.to_excel(writer,"added",index=False, columns=output_columns)
writer.save()
print("completed")
response={}

response['no_of_rows_deleted']=str(len(df_removed))
response['no_of_rows_added']=str(len(df_added))
response['no_of_rows_changed']=str(len(df_changed))


print(response)