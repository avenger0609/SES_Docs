import pandas as pd
import sys
import gc
import threading 
# sys.setrecursionlimit(10**8)
df=pd.read_excel(r'c:\users\asrilekh\downloads\Governance+Dataset+Details.xlsx')

exec_on_update=30
input_ds_id=28
input_ds_name=29
op_ds_id=31
file_lst=[]
file_name_lst=[]
search_id_lst=[]
dsname1=""

def ip_dataset(searchid):
    # print('searchid= ' + searchid)
    try:
        df_search_ods = df[df['Output Dataset ID'] == searchid]
        # print(len(df_search_ods))
        if len(df_search_ods) <=0:
            return
        dflowid=list(df_search_ods['Dataflow ID'])[0]
        df_dataflow=df[df['Dataflow ID'] == dflowid]
        if len(df_dataflow) <=0:
            return
        # print(len(df_dataflow))
        if len(df_dataflow) > 0:
            for dataflow_i in range(0,len(df_dataflow)):
                # print(str(df_dataflow.iloc[dataflow_i,exec_on_update]))
                # print(str(df_dataflow.iloc[dataflow_i,input_ds_id]))
                # print(str(df_dataflow.iloc[dataflow_i,input_ds_name]))
                if str(df_dataflow.iloc[dataflow_i,exec_on_update]).lower()=='true':
                    ip_dataset(str(df_dataflow.iloc[dataflow_i,input_ds_id]))
                elif str(df_dataflow.iloc[dataflow_i,exec_on_update]).lower()=='false':            
                    file_lst.append(str(df_dataflow.iloc[dataflow_i,input_ds_id]))
                    file_name_lst.append(str(df_dataflow.iloc[dataflow_i,input_ds_name]))
                    search_id_lst.append(dsname1)
                else:
                    pass
        gc.collect()
        return
    except Exception as e:
        print(str(e))

def ip_dataset_1(searchid):
    # print('searchid= ' + searchid)
    try:
        df_search_ods = df[df['Output Dataset ID'] == searchid]
        # print(len(df_search_ods))
        if len(df_search_ods) <=0:
            return
        dflowid=list(df_search_ods['Dataflow ID'])[0]
        df_dataflow=df[df['Dataflow ID'] == dflowid]
        if len(df_dataflow) <=0:
            return
        # print(len(df_dataflow))
        if len(df_dataflow) > 0:
            for dataflow_i in range(0,len(df_dataflow)):
                # print(str(df_dataflow.iloc[dataflow_i,exec_on_update]))
                # print(str(df_dataflow.iloc[dataflow_i,input_ds_id]))
                # print(str(df_dataflow.iloc[dataflow_i,input_ds_name]))
                if str(df_dataflow.iloc[dataflow_i,exec_on_update]).lower()=='true':
                    ip_dataset(str(df_dataflow.iloc[dataflow_i,input_ds_id]))
                elif str(df_dataflow.iloc[dataflow_i,exec_on_update]).lower()=='false':            
                    file_lst.append(str(df_dataflow.iloc[dataflow_i,input_ds_id]))
                    file_name_lst.append(str(df_dataflow.iloc[dataflow_i,input_ds_name]))
                    search_id_lst.append(dsname1)
                else:
                    pass
        gc.collect()
        return
    except Exception as e:
        print(str(e))

op_df=pd.DataFrame(columns=['Dataset Search Id','Input Dataset Id','Input Dataset name'])
df_ods = df[df['Output Dataset ID'].apply(lambda x: len(str(x)) >= 5)]
dsname_lst=list(df_ods['Output Dataset ID'])
dsname_lst=list(dict.fromkeys(dsname_lst))
dsname_lst=["d5350e79-ff02-49e0-a409-d481fba2c2c6","f5d8fff3-544b-43be-82ed-d07634474e7d"]
c=0
for dsname_i in range(0,len(dsname_lst)):
    c=c+1
    if c%2==0:
        print(c)
        print(dsname_lst[dsname_i])
        dsname1=dsname_lst[dsname_i]
        ip_dataset(dsname_lst[dsname_i])
    else:
        
        print(c)
        print(dsname_lst[dsname_i])
        dsname1=dsname_lst[dsname_i]
        ip_dataset_1(dsname_lst[dsname_i])
    
    

print(len(file_lst))  
op_df['Input Dataset Id']=file_lst
op_df['Input Dataset name']=file_name_lst
op_df['Dataset Search Id']=search_id_lst
print(op_df)
op_df.to_excel(r'c:\users\asrilekh\downloads\gov_test_1.xlsx')
