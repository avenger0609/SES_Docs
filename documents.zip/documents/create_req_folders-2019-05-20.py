import os

fold_name_lst=['STATUS','TIME','ACTION_REASON','RESUBMIT','CLAIM_AMOUNT','CLAIM_DATE','CLAIM_LINE_ITEMS','TYPE_OF_CLAIM','PAR_R_NON_PAR_CLAIM','NPI_OF_CLAIM','LOB_OF_CLAIM','CLAIM_TAX_ID','CLAIM_DIAG_CODES','claim_submsn_mode','claim_hgh_dlr_status']

for f in fold_name_lst:
    os.makedirs('C:\\Users\\asrilekh\\Desktop\\training examples\\WF2_Duration\\finalized\\'+str(f).lower())