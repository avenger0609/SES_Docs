import keepa
from datetime import datetime
import pandas as pd

accesskey="c12t22821ud26l55gu3gj38t1a3bcsml88o57lpn9h6f63h638sskfkhu424blvt"
api=keepa.Keepa(accesskey)


def get_asin_info(search_asin):

    resp=api.query(search_asin,domain='IN',history=True,rating=True,to_datetime=True,out_of_stock_as_nan=False
    ,stock=True,product_code_is_asin=True,progress_bar=True
    ,buybox=False,stats=365,offers=21,update=0)

    products=resp
    final_result={}
    product=products[0]

    final_result['Categories']=','.join([str(i) for i in product['categories']])
    final_result['FBAStorageFee']=product['fbaFees']['storageFee']
    final_result['FBAStorageFeeTax']=product['fbaFees']['storageFeeTax']
    final_result['FBApickAndPackFee']=product['fbaFees']['pickAndPackFee']
    final_result['FBApickAndPackFeeTax']=product['fbaFees']['pickAndPackFeeTax']
    cat_tree_id=">".join(list(product['categoryTree'].keys()))
    cat_tree_names=[]
    for cti in list(product['categoryTree'].keys()):
        cat_tree_names.append(product['categoryTree'].get(cti))
    cat_tree_names=">".join(cat_tree_names)
    final_result['CategoryTreeID']=cat_tree_id
    final_result['CategoryTreeNames']=cat_tree_names


    for di in ['manufacturer','title','lastUpdate','lastPriceChange','rootCategory','productType','parentAsin','asin','domainId','type','hasReviews','trackingSince'
    ,'brand','productGroup','partNumber','model','color','size','edition','format','packageHeight','packageLength','packageWidth','packageWeight','packageQuantity','isAdultProduct','isEligibleForTradeIn','isEligibleForSuperSaverShipping'
    ,'isRedirectASIN','isSNS','author','binding','numberOfItems','numberOfPages','publicationDate','releaseDate'
    ,'lastRatingUpdate','description','newPriceIsMAP','availabilityAmazon','listedSince','itemHeight','itemLength','itemWidth','itemWeight','salesRankReference','launchpad','offersSuccessful','g'
    ]



    filename=search_asin+"_ASIN_Search_Result"+datetime.now().strftime('%d_%b_%Y_%H%M%S')+".txt"
    resf=open(output_dir+"\\ASIN Search\\"+filename,"w")
    resf.write(str(resp))

    return resp

search_asin='178472369X'
