import pandas as pd
import csv
from datetime import datetime

first_file='/app/Apache Druid POC/New Join Files/case_member_join_res.csv'
second_file='/app/Apache Druid POC/UIDXWALK_FINAL_THRU03052020.csv'
output_file='/app/Apache Druid POC/New Join Files/join_res_uidxwalk.csv'
columns_list=['uid']


df2=pd.read_csv(second_file,encoding = 'latin_1')
print("completed reading UIDXWALK_FINAL_THRU03052020 key data "+str(len(df2)))
df1=pd.read_csv(first_file,encoding = 'latin_1')
print("completed reading all case_member_join_res data "+str(len(df1)))

dfs = []
for val in df1.uid.unique():
    df = pd.merge(df1[df1.uid==val], df2, on='uid', how='left')
    #http://stackoverflow.com/a/39786538/2901002
    #df1 = df1[(df1.start <= df1.start_key) & (df1.end <= df1.end_key)]
    print(len(df))
    dfs.append(df)
df1 = df1[(df1.case_denied == 'N') & (df1.ltc_flg == 'N')& (df1.business_segment_adj == 'MnR')& (df1.admit_type != 'MHSA')& (df1.span == 'CY')& (df1.Funding_Arrangement== 'FI')& (df1.tmr_outlier == 'N')]
case_denied: N
ltc_flg: 'N"
"business_segment_adj":"MnR"
"admit_type":not in MHSA
"span":"CY"
"Funding_Arrangement":"FI"
"tmr_outlier":"N"

df = pd.concat(dfs, ignore_index=True)

print(len(df))

d = {'Jan':'01', 'Feb':'02', 'Mar':'03', 'Apr':'04', 'May':'05', 'Jun':'06', 'Jul':'07', 'Aug':'08', 'Sep':'09', 'Oct':'10', 'Nov':'11', 'Dec':'12' }

df['hour']='00'
df['minute']='00'
df['second']='10'
df['month_temp']=df['month']
df['month']=df['month'].map(d)
df['day']=df['week']

print(list(dict.fromkeys(list(df['month']))))
print(list(dict.fromkeys(list(df['month_temp']))))

df['timestamp']=pd.to_datetime(df[['year', 'month', 'day','hour','minute','second']])
df['month']=df['month_temp']
df=df.drop(columns=['hour', 'minute','second','day','month_temp'])
df_check=df[0:1000]
df_check.to_csv('/app/Apache Druid POC/New Join Files/uidxwalk_mktdtlxwalktest.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')
df.to_csv(output_file,index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d %H:%M:%S')

print("Completed-"+str(datetime.now()))