import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3
from turbodbc import connect
from pandas import DataFrame

def direct_export():
    try:
        
        params = quote_plus(r'Driver={SQL Server};Server=DBSEP1560;Database=ITFB;Trusted_Connection=yes;') #### MPWR Server
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)        
        sql_string="select * from history_ledger_active_ets where HISTORY_PERIOD='202005'"
        sql_string="WITH MyCte AS ( select history_ledger_active_ets.*,ROW_NUMBER( ) OVER(ORDER BY HISTORY_PERIOD DESC) as rn from history_ledger_active_ets where HISTORY_PERIOD='202005' ) SELECT  * FROM    MyCte WHERE   rn > 0 and rn <10 "
        df = pd.read_sql_query(sql_string, engine)
        
        df.to_csv('C:\\Users\\asrilekh\\Documents\\mpwr_data_test.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")
        return df
    except Exception as e:
        print("error in generatin mpwr 78002 dfitbm pc files "+str(e))

def using_cursor():
    try:
        df1=direct_export()
        connection = connect(dsn='MPWR')
        cursor = connection.cursor()
        rcul=651000
        rcll=650000
        while(1):
            print(rcll)
            print(rcul)
            stmt="WITH MyCte AS ( select ITFB.dbo.history_ledger_active_ets.*,ROW_NUMBER( ) OVER(ORDER BY HISTORY_PERIOD DESC) as rn from ITFB.dbo.history_ledger_active_ets where HISTORY_PERIOD='202005' ) SELECT  * FROM    MyCte WHERE   rn >"+str(rcll)+" and rn <= "+str(rcul)
            cursor.executemany(stmt)
            cur_df=DataFrame(cursor.fetchall())
            cur_df.columns=df1.columns
            if rcll==0:
                cur_df.to_csv('C:\\Users\\asrilekh\\Documents\\mpwr_data.csv',index=False,quoting=csv.QUOTE_ALL)
            else:
                cur_df.to_csv('C:\\Users\\asrilekh\\Documents\\mpwr_data.csv',mode="a",index=False,header=False,quoting=csv.QUOTE_ALL)
            print("after writing result")
            print(rcll)
            print(rcul)
            if rcul == 1511517:  ## row count
                break
            rcll=rcul
            rcul=rcul+1000
            if rcul > 1511517:
                rcul=1511517
    except Exception as e:
        print(str(e))

# direct_export()
using_cursor()