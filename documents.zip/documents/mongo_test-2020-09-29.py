import pymongo

# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["mydatabase"]
# mycol = mydb["customers"]

# #address starts with S:
# myquery = { "address": { "$regex": "^S" } }

# mydoc = mycol.find(myquery)

# for x in mydoc:
#   print(x)



print("in context history push function")
myclient = pymongo.MongoClient(u"mongodb://127.0.0.1.uhc.com:27017")
print(myclient.list_database_names())
mydb = myclient["HandsFreeAnalytics"]
print(mydb.list_collection_names())
mycol = mydb["Calls_Context_History"]
dt=str(datetime.now()).replace(' ','').replace('-','').replace(':','')
mydict = { "User_ID": 'userid', "Session_ID": 'sess_id',"Request_Type":'req_type',"Call_R_Calls":'call_r_calls',"Context":'context',"Call_id":'call_id',"From":'frm',"To":'to',"Days":'day',"Months":'mon',"Years":'yr',"creation_dt":'dt'}
x = mycol.insert_one(mydict)
print(str(x.inserted_id))