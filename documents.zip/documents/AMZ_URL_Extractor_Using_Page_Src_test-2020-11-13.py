import os
import requests
from datetime import datetime

def main_page(URL):
    response=requests.get(URL)    
    page_content=response.text    
    print(len(page_content))
    ol_id_start=page_content.find('<ul id="zg_browseRoot">')
    ol_id_end=page_content.find('/ul>',ol_id_start)
    ol_data=page_content[ol_id_start:ol_id_end]
    li_end=0    
    url_lst=[]
    name_lst=[]    
    while True:
        try:
            li_start=ol_data.find('<li',li_end)
            if li_start==-1:
                break
            li_end=ol_data.find('/li>',li_start)            
            product_data=(ol_data[li_start:li_end])
            # print(product_data)
            prod_url_start=product_data.find('href=')
            prod_url_end=product_data.find('>',prod_url_start+5)
            prod_url=product_data[prod_url_start+6:prod_url_end-1]
            print(prod_url)
            url_lst.append(prod_url)  
        except Exception as e:
            print(str(e)) 
            url_lst.append("")           
        try:
            name_end=product_data.find('</a>',prod_url_end)
            print(product_data[prod_url_end+1:name_end])
            name_lst.append(product_data[prod_url_end+1:name_end])
        except Exception as e:
            print(str(e)) 
            name_lst.append("")      
  
    print(len(url_lst))
    print(len(name_lst))
    
    return [url_lst,name_lst] 
    # return [url_lst[0:2],name_lst[0:2]]     

def get_pane_urls(URL):
    # URL='https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers'    
    response=requests.get(URL)    
    page_content=response.text    
    print(len(page_content))
    ol_id_start=page_content.find('<ul id="zg_browseRoot">')
    ol_id_end=page_content.find('/ul>',ol_id_start)
    ol_data=page_content[ol_id_start:ol_id_end]
    li_end=0    
    url_lst=[]
    name_lst=[]
    page_urls_lst=[]
    while True:
        try:
            li_start=ol_data.find('<li',li_end)
            if li_start==-1:
                break
            li_end=ol_data.find('/li>',li_start)            
            product_data=(ol_data[li_start:li_end])
            # print(product_data)
            prod_url_start=product_data.find('href=')
            prod_url_end=product_data.find('>',prod_url_start+5)
            prod_url=product_data[prod_url_start+6:prod_url_end-1]
            print(prod_url)
            url_lst.append(prod_url)  
        except Exception as e:
            print(str(e)) 
            url_lst.append("")           
        try:
            name_end=product_data.find('</a>',prod_url_end)
            print(product_data[prod_url_end+1:name_end])
            name_lst.append(product_data[prod_url_end+1:name_end])
        except Exception as e:
            print(str(e)) 
            name_lst.append("")      
    
    ol_id_start=page_content.find('<ul class="a-pagination">')
    ol_id_end=page_content.find('/ul>',ol_id_start)
    ol_data=page_content[ol_id_start:ol_id_end]
    li_end=0   
    while True:
        try:
            li_start=ol_data.find('<li',li_end)
            if li_start==-1:
                break
            li_end=ol_data.find('/li>',li_start)            
            product_data=(ol_data[li_start:li_end])
            # print(product_data)
            prod_url_start=product_data.find('href=')
            prod_url_end=product_data.find('>',prod_url_start+5)
            prod_url=product_data[prod_url_start+6:prod_url_end-1]
            print(prod_url)
            page_urls_lst.append(prod_url)  
        except Exception as e:
            print(str(e)) 
            page_urls_lst.append("")    
    print(len(url_lst))
    print(len(name_lst))
    print(len(page_urls_lst))
    return [url_lst,name_lst,page_urls_lst]     
    # return [url_lst[0:2],name_lst[0:2],page_urls_lst[0:2]]     

def get_urls(output_dir):
    final_urls_only=[]
    final_urls=[]
    dept_urls=[]
    page_urls=[]
    sub_dept_urls_l1=[]
    sub_dept_urls_l2=[]
    sub_dept_urls_l3=[]
    sub_dept_urls_l4=[]
    sub_dept_urls_l5=[]
    sub_dept_urls_l6=[]
    sub_dept_urls_l7=[]
    sub_dept_urls_l8=[]
    sub_dept_urls_l9=[]
    sub_dept_urls_l10=[]  
    # str(datetime.now().strftime('%Y%m%d%H%M%S'))
    dept_urls_file=output_dir+'dept_urls'+str("")+".csv"
    sub_dept_urls_l1_file=output_dir+'sub_dept_urls_l1'+str("")+".csv"
    sub_dept_urls_l2_file=output_dir+'sub_dept_urls_l2'+str("")+".csv"
    sub_dept_urls_l3_file=output_dir+'sub_dept_urls_l3'+str("")+".csv"
    sub_dept_urls_l4_file=output_dir+'sub_dept_urls_l4'+str("")+".csv"
    sub_dept_urls_l5_file=output_dir+'sub_dept_urls_l5'+str("")+".csv"
    sub_dept_urls_l6_file=output_dir+'sub_dept_urls_l6'+str("")+".csv"
    sub_dept_urls_l7_file=output_dir+'sub_dept_urls_l7'+str("")+".csv"
    sub_dept_urls_l8_file=output_dir+'sub_dept_urls_l8'+str("")+".csv"
    sub_dept_urls_l9_file=output_dir+'sub_dept_urls_l9'+str("")+".csv"
    sub_dept_urls_l10_file=output_dir+'sub_dept_urls_l10'+str("")+".csv"

    dept_urls_file_completed=output_dir+'dept_urls_completed'+str("")+".csv"
    sub_dept_urls_l1_file_completed=output_dir+'sub_dept_urls_l1_completed'+str("")+".csv"
    sub_dept_urls_l2_file_completed=output_dir+'sub_dept_urls_l2_completed'+str("")+".csv"
    sub_dept_urls_l3_file_completed=output_dir+'sub_dept_urls_l3_completed'+str("")+".csv"
    sub_dept_urls_l4_file_completed=output_dir+'sub_dept_urls_l4_completed'+str("")+".csv"
    sub_dept_urls_l5_file_completed=output_dir+'sub_dept_urls_l5_completed'+str("")+".csv"
    sub_dept_urls_l6_file_completed=output_dir+'sub_dept_urls_l6_completed'+str("")+".csv"
    sub_dept_urls_l7_file_completed=output_dir+'sub_dept_urls_l7_completed'+str("")+".csv"
    sub_dept_urls_l8_file_completed=output_dir+'sub_dept_urls_l8_completed'+str("")+".csv"
    sub_dept_urls_l9_file_completed=output_dir+'sub_dept_urls_l9_completed'+str("")+".csv"
    sub_dept_urls_l10_file_completed=output_dir+'sub_dept_urls_l10_completed'+str("")+".csv"

    ###-----------------
    print("Main Pane Data Extraction started")
    completed_urls=[]
    if os.path.exists(dept_urls_file_completed):
        dept_urls_tmp=open(dept_urls_file_completed,'r',encoding='utf-8').readlines()
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(dept_urls_file):
        dept_urls_tmp=open(dept_urls_file,'r',encoding='utf-8').readlines()
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                dept_urls.append(dui.replace('\n',''))    
    else:        
        main_res=main_page('https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers')
        dept_urls_tmp=main_res[0]
        dept_names_tmp=main_res[1]
        final_urls_only=main_res[0]
        duf=open(dept_urls_file,'w',encoding='utf-8')
        for duti in range(0,len(dept_urls_tmp)):
            dept_urls.append(dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
            final_urls.append(dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
            duf.write(dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
        duf.close()
        print("Main Pane Data Extraction completed=",len(dept_urls))

    ################ LEVEL 1 STARTED ##################################
    print("level 1 started ")
    
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l1_file_completed):
        dept_urls_tmp=open(sub_dept_urls_l1_file_completed,'r',encoding='utf-8').readlines()
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l1_file):
        dept_urls_tmp=open(sub_dept_urls_l1_file,'r',encoding='utf-8').readlines()
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l1.append(dui.replace('\n',''))  
    else: 
        if os.path.exists(dept_urls_file_completed):
            dufc=open(dept_urls_file_completed,'a',encoding='utf-8')
        else:        
            dufc=open(dept_urls_file_completed,'w',encoding='utf-8')
        dufw=open(sub_dept_urls_l1_file,'w',encoding='utf-8')
        for dui in dept_urls:          
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l1.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+'\n')
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 1 completed",len(sub_dept_urls_l1))

    ################ LEVEL 2 STARTED ##################################
    print("level 2 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l2_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l2_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l2_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l2_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l2.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l1_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l1_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l1_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l2_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l1:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l2.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 2 completed ",len(sub_dept_urls_l2)) ## needs to be changed

    ################ LEVEL 3 STARTED ##################################
    print("level 3 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l3_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l3_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l3_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l3_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l3.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l2_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l2_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l2_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l3_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l2:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l3.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 3 completed ",len(sub_dept_urls_l3)) ## needs to be changed
    
    ################ LEVEL 4 STARTED ##################################
    print("level 4 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l4_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l4_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l4_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l4_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l4.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l3_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l3_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l3_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l4_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l3:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l4.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 4 completed ",len(sub_dept_urls_l4)) ## needs to be changed

    ################ LEVEL 5 STARTED ##################################
    print("level 5 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l5_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l5_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l5_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l5_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l5.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l4_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l4_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l4_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l5_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l4:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l5.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 5 completed ",len(sub_dept_urls_l5)) ## needs to be changed

    ################ LEVEL 6 STARTED ##################################
    print("level 6 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l6_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l6_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l6_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l6_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l6.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l5_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l5_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l5_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l6_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l5:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l6.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 6 completed ",len(sub_dept_urls_l6)) ## needs to be changed

    ################ LEVEL 7 STARTED ##################################
    print("level 7 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l7_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l7_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l7_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l7_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l7.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l6_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l6_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l6_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l7_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l6:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l7.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 7 completed ",len(sub_dept_urls_l7)) ## needs to be changed

    ################ LEVEL 8 STARTED ##################################
    print("level 8 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l8_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l8_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l8_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l8_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l8.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l7_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l7_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l7_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l8_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l7:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l8.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 8 completed ",len(sub_dept_urls_l8)) ## needs to be changed

    ################ LEVEL 9 STARTED ##################################
    print("level 9 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l9_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l9_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l9_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l9_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l9.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l8_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l8_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l8_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l9_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l8:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l9.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 9 completed ",len(sub_dept_urls_l9)) ## needs to be changed
    ################ LEVEL 10 STARTED ##################################
    print("level 10 started")  ## needs to be changed
    completed_urls=[]
    if os.path.exists(sub_dept_urls_l10_file_completed):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l10_file_completed,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            completed_urls.append(dui.replace('\n',''))

    if os.path.exists(sub_dept_urls_l10_file):  ## needs to be changed
        dept_urls_tmp=open(sub_dept_urls_l10_file,'r',encoding='utf-8').readlines()  ## needs to be changed
        for dui in dept_urls_tmp:
            if dui.replace('\n','') not in completed_urls:
                sub_dept_urls_l10.append(dui.replace('\n',''))    ## needs to be changed
    else: 
        if os.path.exists(sub_dept_urls_l9_file_completed):  ## needs to be changed
            dufc=open(sub_dept_urls_l9_file_completed,'a',encoding='utf-8')  ## needs to be changed
        else:        
            dufc=open(sub_dept_urls_l9_file_completed,'w',encoding='utf-8')  ## needs to be changed
        dufw=open(sub_dept_urls_l10_file,'w',encoding='utf-8')
        for dui in sub_dept_urls_l9:           ## needs to be changed
            try:
                pane_res=get_pane_urls(dui.split("!!!!!!!!!!")[1])
                dept_urls_tmp=pane_res[0]
                dept_names_tmp=pane_res[1]
                page_urls_tmp=pane_res[2]
                for duti in range(0,len(dept_names_tmp)):
                    if dept_urls_tmp[duti] not in final_urls_only:
                        final_urls_only.append(dept_urls_tmp[duti])
                        sub_dept_urls_l10.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]) ## needs to be changed
                        final_urls.append(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti])
                        dufw.write(dui.split("!!!!!!!!!!")[0]+"!"+dept_names_tmp[duti]+"!!!!!!!!!!"+dept_urls_tmp[duti]+"\n")
                for puti in page_urls_tmp:
                    page_urls.append(dui.split("!!!!!!!!!!")[0]+"!!!!!!!!!!"+puti)
                dufc.write(dui+'\n')
            except Exception as e:
                print("Exception while extracting level ",str(e)," ",dui)
        dufc.close()
        dufw.close()
    print("level 10 completed ",len(sub_dept_urls_l10)) ## needs to be changed

    

    fuf=open(output_dir+'Page_urls_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv",'w')
    for fui in page_urls:
        fuf.write(fui+"\n")
    fuf.close()

    final_urls.extend(page_urls)
    fuf=open(output_dir+'consolidated_urls_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv",'w')
    for fui in final_urls:
        fuf.write(fui+"\n")
    fuf.close()



    # str(datetime.now().strftime('%Y%m%d%H%M%S'))

    os.rename(output_dir+'dept_urls'+str("")+".csv",output_dir+'dept_urls_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l1'+str("")+".csv",output_dir+'sub_dept_urls_l1_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l2'+str("")+".csv",output_dir+'sub_dept_urls_l2_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l3'+str("")+".csv",output_dir+'sub_dept_urls_l3_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l4'+str("")+".csv",output_dir+'sub_dept_urls_l4_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l5'+str("")+".csv",output_dir+'sub_dept_urls_l5_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l6'+str("")+".csv",output_dir+'sub_dept_urls_l6_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l7'+str("")+".csv",output_dir+'sub_dept_urls_l7_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l8'+str("")+".csv",output_dir+'sub_dept_urls_l8_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l9'+str("")+".csv",output_dir+'sub_dept_urls_l9_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l10'+str("")+".csv",output_dir+'sub_dept_urls_l10_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")

    os.rename(output_dir+'dept_urls_completed'+str("")+".csv",output_dir+'dept_urls_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l1_completed'+str("")+".csv",output_dir+'sub_dept_urls_l1_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l2_completed'+str("")+".csv",output_dir+'sub_dept_urls_l2_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l3_completed'+str("")+".csv",output_dir+'sub_dept_urls_l3_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l4_completed'+str("")+".csv",output_dir+'sub_dept_urls_l4_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l5_completed'+str("")+".csv",output_dir+'sub_dept_urls_l5_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l6_completed'+str("")+".csv",output_dir+'sub_dept_urls_l6_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l7_completed'+str("")+".csv",output_dir+'sub_dept_urls_l7_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l8_completed'+str("")+".csv",output_dir+'sub_dept_urls_l8_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l9_completed'+str("")+".csv",output_dir+'sub_dept_urls_l9_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")
    os.rename(output_dir+'sub_dept_urls_l10_completed'+str("")+".csv",output_dir+'sub_dept_urls_l10_completed_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv")

get_urls('\\\\APVEP78970\\Users\\sali54\\Documents\\SES POC\\Downloads\\URL_Extract_Test\\') 
# main_page('https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers')
# get_pane_urls('https://www.amazon.in/gp/bestsellers/kitchen/ref=zg_bs_nav_0')