import pandas as pd
import numpy as np
import re
from datetime import datetime


df1 = pd.DataFrame({"Person":[" John@gmail.com ", "  ", "Lewis", "Lewis", "Myla"],"Age": [24, np.nan, 22, 22, 26],"Single": [False, True, True, True, False]})
df2=pd.DataFrame({"Person":[" John@gmail.com ", "abcd", "Lewis", "John", "Myla"],"Number": [24, np.nan, 22, 33, 26],"Single": [False, True, True, True, False]})
forecast_lst = list(dict.fromkeys(list(df1['Person'])))
print(forecast_lst)
df = df1.merge(df2, how='left', on=['Person'])
print(df)
df=df.loc[df['Person'] == 'Lewis']
print(df)
# print(df['new_test']='test')
# int_no_val_lst=int_no_val_lst.append(cdf[i:i+1])
print(df1.groupby(["Person", "Age"]).size().reset_index(name='count'))
df1 = df[df['Person'].str.contains("Le")] 
print(df)
df3=df1.drop(['Person'], axis = 1)
print(df3)
df3['Person'] = 'abc'
print(df3)