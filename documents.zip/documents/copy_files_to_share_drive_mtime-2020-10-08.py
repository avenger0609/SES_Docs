import os
from shutil import copyfile
import datetime as dt
import time


# time.sleep(600)

thisdir = r'c:\users\asrilekh\desktop'
thisdir = r'c:\users\asrilekh\documents'
thisdir = r'c:\users\asrilekh\downloads'

prev_days=10

for thisdir in [r'c:\users\asrilekh\desktop',r'c:\users\asrilekh\documents',r'c:\users\asrilekh\downloads']:
    now = dt.datetime.now()
    ago = now-dt.timedelta(days=prev_days)
    print(ago)
    for r, d,f in os.walk(thisdir):  
        for file in f:
            if '.db' in file.lower():
                continue
            src_file = os.path.join(r, file)
            st = os.stat(src_file)    
            mtime = dt.datetime.fromtimestamp(st.st_mtime)
            if mtime > ago:
                print('%s modified %s'%(src_file, mtime))
                # destpath=str(r).replace("c:\\users\\asrilekh\\","\\\\nas05151pn\\ii519_homedirs\\asrilekh\\")                
                destpath=str(r).replace("c:\\users\\asrilekh\\","\\\\nas05151pn\\ii519_homedirs\\asrilekh\\asrilekh\\")                
                if not os.path.exists(destpath):
                    os.makedirs(destpath) 
                dest_file=os.path.join(destpath, file)
                copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'            
                print(copy_cmd)
                try:
                    os.system(copy_cmd)   
                except Exception as e:
                    print(e)

for thisdir in [r'C:\Users\asrilekh\Pictures',r'C:\Users\asrilekh\Music',r'C:\Users\asrilekh\MTech']:  
    now = dt.datetime.now()
    ago = now-dt.timedelta(days=prev_days)

    for r, d,f in os.walk(thisdir):  
        for file in f:
            if '.db' in file.lower():
                continue
            src_file = os.path.join(r, file)
            st = os.stat(src_file)    
            mtime = dt.datetime.fromtimestamp(st.st_mtime)
            if mtime > ago:
                print('%s modified %s'%(src_file, mtime))
                destpath=str(r).replace("C:\\Users\\asrilekh\\","\\\\nas05151pn\\ii519_homedirs\\asrilekh\\asrilekh\\")  
                print(destpath)              
                if not os.path.exists(destpath):
                    os.makedirs(destpath) 
                dest_file=os.path.join(destpath, file)                
                copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'            
                print(copy_cmd)
                try:
                    os.system(copy_cmd)   
                except Exception as e:
                    print(e)    

homedir_files=[f for f in os.listdir('c:\\users\\asrilekh') if os.path.isfile(os.path.join('c:\\users\\asrilekh', f))]
for f in homedir_files:
    now = dt.datetime.now()
    ago = now-dt.timedelta(days=prev_days)
    src_file=os.path.join('c:\\users\\asrilekh', f)
    st = os.stat(src_file)    
    mtime = dt.datetime.fromtimestamp(st.st_mtime)
    if mtime > ago:
        dest_file=src_file.replace("c:\\users\\asrilekh\\","\\\\nas05151pn\\ii519_homedirs\\asrilekh\\asrilekh\\")                
        copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'   
        print(copy_cmd)
        try:
            os.system(copy_cmd)   
        except Exception as e:
            print(e)  
src_file_1=r'C:\Users\asrilekh\AppData\Local\Google\Chrome\User Data\Default\History'
# dest_file_1="\\\\nas05151pn\\ii519_homedirs\\asrilekh\\Chrome\\History"
dest_file_1="\\\\nas05151pn\\ii519_homedirs\\asrilekh\\asrilekh\\Chrome\\History"
copy_cmd='copy "'+src_file_1+'" '+'"'+dest_file_1+'"'   
try:
    os.system(copy_cmd)   
except Exception as e:
    print(e) 

       
    