
from selenium import webdriver
import pandas as pd
import time
# from selenium.webdriver.support.select import select
import csv
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os

URL='https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers'
# driverpath = r"C:\ProgramData\chromedriver_win32\chromedriver.exe"
driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
output_dir='\\\\APVEP78970\\Users\\sali54\\Documents\\SES POC\\Downloads\\'+"Dept_Toys & Games_"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', True)

driver = webdriver.Chrome(executable_path=driverpath,chrome_options=chromeOptions)

def get_product_data(URL):
    driver.get(URL)
    details_dict={}
    details_lst=[]
    pg_src=driver.page_source
    ## Title
    try:
        title_start=pg_src.find('<span id="productTitle"')
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("Title  ",title)
        details_lst.append(title)
        details_dict["Title"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Title"]="Exception-"+str(e).replace('\n','')

    ## Ratings
    try:
        title_start=pg_src.find('<i class="a-icon a-icon-star a-star-4"><span class="a-icon-alt">')
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace('&nbsp;',' ').replace('&amp;','&').replace('ratings','').strip(' ')
        print("Ratings  ",title)
        details_lst.append(title)
        details_dict["Ratings"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Ratings"]=("Exception-"+str(e).replace('\n',''))
    
    ## Reviews
    try:
        title_start=pg_src.find('href="#customerReviews">')
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("Reviews  ",title)
        details_lst.append(title)
        details_dict["Reviews"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Reviews"]=("Exception-"+str(e).replace('\n',''))

    ## Reviews URL
    try:
        print(URL+"#customerReviews")
        details_lst.append(URL+"#customerReviews")
        details_dict["Reviews URL"]=(URL+"#customerReviews")
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Reviews URL"]=("Exception-"+str(e).replace('\n',''))

    ## Price   
    try: 
        title_start=pg_src.find('<span id="priceblock_ourprice"')
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("Price  ",title)
        details_lst.append(title)
        details_dict["Price"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Price"]="Exception-"+str(e).replace('\n','')

    ## Brand and Brand URL
    try:
        title_start=pg_src.find('<a id="bylineInfo"')
        title_end=pg_src.find('</a',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("Brand  ",title)
        details_lst.append(title)
        details_dict["Brand"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Brand"]="Exception-"+str(e).replace('\n','')
    try:
        product_data=title_content
        prod_url_start=product_data.find('href=')
        prod_url_end=product_data.find('>',prod_url_start+5)
        prod_url=product_data[prod_url_start+6:prod_url_end-1]
        print("Brand URL ",prod_url)
        details_lst.append(prod_url)
        details_dict["Brand URL"]=prod_url
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Brand URL"]=("Exception-"+str(e).replace('\n',''))

    ## Size and Weight
    try:    
        dim_start=pg_src.find('class="a-text-bold">Package Dimensions')
        title_start=pg_src.find('<span',dim_start)
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("Size  ",title.split(';')[0])
        details_lst.append(title.split(';')[0])
        details_dict["Size"]=title.split(';')[0]
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Size"]=("Exception-"+str(e).replace('\n',''))
    try:
        print("Weight  ",title.split(';')[1])
        details_lst.append(title.split(';')[1])
        details_dict["Weight"]=title.split(';')[1]
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Weight"]=("Exception-"+str(e).replace('\n',''))

    ## Available from
    try:
        dim_start=pg_src.find('class="a-text-bold">Date First Available')
        title_start=pg_src.find('<span',dim_start)
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("Available From  ",title)
        details_lst.append(title)
        details_dict["Available From"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Available From"]=("Exception-"+str(e).replace('\n',''))

    ## Manufacturer
    try:
        dim_start=pg_src.find('class="a-text-bold">Manufacturer')
        title_start=pg_src.find('<span',dim_start)
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("Manufacturer  ",title)
        details_lst.append(title)
        details_dict["Manufacturer"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Manufacturer"]=("Exception-"+str(e).replace('\n',''))

    ## ASIN
    try:
        dim_start=pg_src.find('class="a-text-bold">ASIN')
        title_start=pg_src.find('<span',dim_start)
        title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print("ASIN  ",title)
        details_lst.append(title)
        details_dict["ASIN"]=title
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["ASIN"]=("Exception-"+str(e).replace('\n',''))

    ## Primary Rank , Primary Department, Primary Dept URL
    try:
        title_start=pg_src.find('Amazon Bestsellers Rank:')
        title_end=pg_src.find('(',dim_start)
        # title_end=pg_src.find('</span',title_start)
        title_content=pg_src[title_start:title_end]
        title=title_content.split('>')[-1].replace('\n',' ').replace(',','').replace('&nbsp;',' ').replace('&amp;','&').strip(' ')
        print(title)
        print("Primary Rank  ",title.split('in')[0])
        print("Primary Department  ",title.split('in')[1])
        details_lst.append(title.split('in')[0])
        details_dict["Primary Rank"]=(title.split('in')[0])
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Primary Rank"]=("Exception-"+str(e).replace('\n',''))
    try:
        details_lst.append(title.split('in')[1])
        details_dict["Primary Department"]=(title.split('in')[1])
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Primary Department"]=("Exception-"+str(e).replace('\n',''))
        
    
    try:
        a_end=pg_src.find('>',title_end)
        product_data=pg_src[title_end:a_end]
        prod_url_start=product_data.find('href=')
        prod_url_end=product_data.find('>',prod_url_start+5)
        prod_url=product_data[prod_url_start+6:prod_url_end]
        print("Primary Department URL ",prod_url)
        details_lst.append(prod_url)
        details_dict["Primary Department URL"]=prod_url        
    except Exception as e:
        details_lst.append("Exception-"+str(e).replace('\n',''))
        details_dict["Primary Department URL"]=("Exception-"+str(e).replace('\n',''))
    
    print(details_dict)
    print((details_dict.keys()))
    print(len(details_lst))
    return details_dict   

 ## dict : ['Title', 'Ratings', 'Reviews', 'Reviews URL', 'Price', 'Brand', 'Brand URL', 'Size', 'Weight', 'Available From', 'Manufacturer', 'ASIN', 'Primary Rank', 'Primary Department', 'Primary Department URL']   

get_product_data('https://www.amazon.in/Watch-City-Color-Changing-Girls/dp/B08GM32HRW/ref=zg_bs_5518825031_1?_encoding=UTF8&psc=1&refRID=SEE7K0JP0T0FY84VAGTX')
get_product_data('https://www.amazon.in/Allen-Solly-Mens-Polo-8907587726922_AMKP317G04235_Small_Maroon/dp/B06Y2DSLL1/ref=zg_bs_apparel_1?_encoding=UTF8&psc=1&refRID=78G8VJBG6V3MZFYNGR0X')

