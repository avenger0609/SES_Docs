from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
import numpy as np
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_win32\\chromedriver.exe"
driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
sleep_time=40
def get_search_words(keyword):
    driver.get('https://www.amazon.in/')
    driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').click()
    driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').clear()
    driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').send_keys(keyword+' ')
    time.sleep(sleep_time)
    level1_keywords=[]
    for li in range(0,11):
        try:
            print(driver.find_element_by_id('issDiv'+str(li)).text)
            level1_keywords.append(driver.find_element_by_id('issDiv'+str(li)).text)
        except:
            pass

    level2_keywords=[]
    for l1i in level1_keywords:
        driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').click()
        driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').clear()
        driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').send_keys(l1i+' ')
        time.sleep(sleep_time)    
        for li in range(0,11):
            try:
                print(driver.find_element_by_id('issDiv'+str(li)).text)
                level2_keywords.append(driver.find_element_by_id('issDiv'+str(li)).text)
            except:
                pass
            

    level3_keywords=[]
    for l1i in level2_keywords:
        driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').click()
        driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').clear()
        driver.find_element_by_xpath('//*[@id="twotabsearchtextbox"]').send_keys(l1i+' ')
        time.sleep(sleep_time)    
        for li in range(0,11):
            try:
                print(driver.find_element_by_id('issDiv'+str(li)).text)
                level3_keywords.append(driver.find_element_by_id('issDiv'+str(li)).text)
            except:
                pass
get_search_words('headphones')