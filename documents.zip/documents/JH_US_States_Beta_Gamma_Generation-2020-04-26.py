

import pandas as pd 
import numpy as np

df_final=pd.DataFrame()
df_final_beta_gamma=pd.DataFrame()

dfs=pd.read_excel(r'c:\users\asrilekh\downloads\US+State+Level+download.xlsx')

states_list=list(dfs['Province/State'].unique())

for sli in states_list:
    
    df=dfs[dfs['Province/State']==sli]      
    df=df.sort_values(["Report_Date"], ascending = (True))

    ### using confirmed field values if active is not populated

    df['Active']=df['Active'].mask(pd.isnull, df['Confirmed'])

    ### using confirmed field values if active is not populated

    df['Susceptible']=df['Population']-df['Active']-df['Deaths']
    df['Susceptible_min_1']=df['Susceptible'].shift(1)
    df['Susceptible_Diff']=df['Susceptible']-df['Susceptible_min_1']

    df['Deaths_min_1']=df['Deaths'].shift(1)
    df['New Deaths']=df['Deaths']-df['Deaths_min_1']

    df['Confirmed_min_1']=df['Confirmed'].shift(1)

    df['New Cases']=df['Confirmed']-df['Confirmed_min_1']

    df['New_Cases_min_1']=df['New Cases'].shift(1)

    df['Active_Cases_min_1']=df['Active'].shift(1)

    df['Beta']=df['Susceptible_Diff']/(df['Susceptible_min_1']*-1*df['Active_Cases_min_1'])

    print(df['Beta'].mean())

    df['Recovered']=df['Active']-df['Active_Cases_min_1']-df['New Deaths']-df['New_Cases_min_1']
    df['Recovered']=df['Recovered']*-1
    df['Recovered_min_1']=df['Recovered'].shift(1)
    df['Recovered_Diff']=df['Recovered']-df['Recovered_min_1']

    df['Gamma']=df['Recovered_Diff']/df['Active_Cases_min_1']

    df['Gamma'] = df['Gamma'].replace([np.inf, -np.inf], np.nan)
    df['Beta'] = df['Beta'].replace([np.inf, -np.inf], np.nan)

    print(df['Gamma'].mean())

    df=df[0:len(df)-1]
    

    
    df_gamma=df[['Province/State','Gamma']]
    df_gamma=df_gamma.dropna(subset=['Gamma'])
    df_gamma=df_gamma[-10:]

    sf=df.groupby(['Province/State'])['Gamma'].mean()
    df_gamma=pd.DataFrame({'Province/State':sf.index, 'Gamma_Mean':sf.values})
    print(df_gamma)

    df_beta=df[['Province/State','Beta']]
    df_beta=df_beta.dropna(subset=['Beta'])
    df_beta=df_beta[-10:]

    sf=df.groupby(['Province/State'])['Beta'].mean()
    df_beta=pd.DataFrame({'Province/State':sf.index, 'Beta_Mean':sf.values})
    print(df_beta)

    df_beta_gamma=pd.merge(df_beta, df_gamma, how='inner', on=['Province/State'])

    if len(df_final_beta_gamma) > 0:
        df_final_beta_gamma=df_final_beta_gamma.append(df_beta_gamma)
    else:
        df_final_beta_gamma=df_beta_gamma

    if len(df_final) > 0:
        df_final=df_final.append(df)
    else:
        df_final=df
    
print(df_final_beta_gamma)
print(len(df_final_beta_gamma))
print(len(df_final))
df_final_beta_gamma.to_excel(r'JH_US_States_Beta_Gamma_Generation.xlsx')
df_final.to_excel(r'JH_US_States_Beta_Gamma_Value_Gen.xlsx')
