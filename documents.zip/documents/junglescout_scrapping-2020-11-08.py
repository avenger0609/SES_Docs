from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
import numpy as np

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)

driver.get('https://www.junglescout.com/estimator/')

page_source_text = str(driver.page_source)
page_source_text_ul_start = page_source_text.find('<ul')
page_source_text_ul_start = page_source_text.find('<ul',page_source_text_ul_start+100)
page_source_text_ul_end = page_source_text.find('ul>',page_source_text_ul_start)

print(page_source_text_ul_start)
print(page_source_text_ul_end)

# print(page_source_text[page_source_text_ul_start:page_source_text_ul_end])
tr_data=page_source_text[page_source_text_ul_start:page_source_text_ul_end]
cat_list_items=[]
Indian_cat_list_items=[]
categories={}
Indian_categories={}
td_start=0
c=0
market_lst=[]
category_lst=[]
sno_lst=[]
while(tr_data.find('<li',td_start) > -1):    
    c=c+1    
    td_end=tr_data.find('</li',tr_data.find('<li',td_start))
    td_data=tr_data[tr_data.find('<li',td_start):td_end+1]
    # print(td_data.split('\n'))
    li_data=td_data.split('\n')[0].split('"')[1]+"!!!!!!!!!!"+td_data.split('\n')[1].split('<')[1].replace('span>','').replace('&amp;','&').strip(' ')
    # print(li_data)
    if 'Beauty'==td_data.split('\n')[1].split('<')[1].replace('span>','').replace('&amp;','&').strip(' '):
        print(td_data.split('\n')[1].split('<')[1].replace('span>','').replace('&amp;','&').strip(' '))
        print(td_data.split('\n')[0].split('"')[1])
    market_lst.append(td_data.split('\n')[0].split('"')[1].strip(' '))
    category_lst.append(td_data.split('\n')[1].split('<')[1].replace('span>','').replace('&amp;','&').strip(' '))    
    sno_lst.append(c)
    td_start=td_end+3  
    cat_list_items.append(li_data) 
    if 'in-available' in li_data.split('!!!!!!!!!!')[0].lower():
        Indian_cat_list_items.append(li_data.split('!!!!!!!!!!')[1])

driver.ge

df=pd.DataFrame()
df['Market Place']=market_lst
df['Category']=category_lst
df.to_excel('js_cat_mkt.xlsx')

final_market_lst=[]
final_category_lst=[]
final_sno_lst=[]
category_lst_unq=list(set(category_lst))
# category_lst_unq=['Beauty']
print(len(category_lst_unq))
category_lst_unq.sort()
print(len(category_lst_unq))
c=0
for clui in category_lst_unq:
    for cli in range(0,len(category_lst)):
        if category_lst[cli]==clui:
            c=c+1
            final_market_lst.append(market_lst[cli])
            final_category_lst.append(category_lst[cli])
            final_sno_lst.append((c))
df=pd.DataFrame()
df['Market Place']=final_market_lst
df['Category']=final_category_lst
df['SNo']=final_sno_lst
df.to_excel('js_cat_mkt_after_sort.xlsx')
print(final_market_lst)
print(final_category_lst)
final_categories={}
for fcli in range(0,len(final_category_lst)):
    if 'in-available' in final_market_lst[fcli].lower():
        final_categories[final_category_lst[fcli]]=final_sno_lst[fcli]
print(final_categories)
cat_index=final_categories.get('Beauty')
print(cat_index)
time.sleep(3)

# df=pd.DataFrame()
# df['Market Place']=market_lst
# df['Category']=category_lst
# df.to_excel('js_test1.xlsx')
# print(df)
# print(len(df))
# print(df.columns)
# df=df.sort_values(['Category'])

# df['C'] = np.arange(len(df))
# df.to_excel('js_test2.xlsx')
# print(df)
# print(len(df))
# print(df.columns)
# print(df['Market Place'].unique())
# print(df[df['Market Place']=='category in-available'])

    

# for cli in range(0,len(cat_list_items)):
#     if 'in-available' in cat_list_items[cli].split('!!!!!!!!!!')[0].lower():
#         categories[cat_list_items[cli].split('!!!!!!!!!!')[1]]=cli

# for cuei in range(0,len(Indian_cat_list_items)):
#     cul_elements_text = Indian_cat_list_items[cuei]        
#     Indian_categories[cul_elements_text]=cuei

# f=open('cat_list_items.csv','w')
# for i in cat_list_items:
#     f.write(i+"\n")
# f.close()
# # print(cat_list_items)
# # print('--------------------')
# f=open('Indian_cat_list_items.csv','w')
# for i in Indian_cat_list_items:
#     f.write(i+"\n")
# f.close()
# print(Indian_cat_list_items)
# print('--------------------')
# print(Indian_categories)
# print('--------------------')
# print(categories)

driver.get('https://www.junglescout.com/estimator/')

driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[2]/td[2]/input').send_keys('496')
driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[3]/td[2]/div/span/i').click()
time.sleep(3)
driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[3]/td[2]/div/input').send_keys('India')
time.sleep(3)
driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[3]/td[2]/div/ul/li[6]').click()
## India plus 496 tested successfully

driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[4]/td[2]/div/span/i').click()
time.sleep(3)
driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[4]/td[2]/div/input').send_keys('Beauty')
# cat_index=categories.get('Beauty')
# print(cat_index)
# time.sleep(3)
cat_index=final_categories.get('Beauty')
print(cat_index)
time.sleep(3)
driver.find_element_by_xpath('/html/body/div[2]/div/main/section/div[2]/div/table/tbody/tr[4]/td[2]/div/ul/li['+str(cat_index)+']').click()



