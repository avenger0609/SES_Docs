from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.common.keys import Keys
import csv
from datetime import datetime
import os

URL='https://www.amazon.in/gp/bestsellers/?ref_=nav_cs_bestsellers'
# driverpath = r"C:\ProgramData\chromedriver_win32\chromedriver.exe"
driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
output_dir='\\\\APVEP78970\\Users\\sali54\\Documents\\SES POC\\Downloads\\'+"Dept_Toys & Games_"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', True)


sleep_time=1
def avail_alert(prod_avail_alert):
    for pi in prod_avail_alert:
        if 'of these available'.lower() in str(pi.text).strip(' ').lower():
            return(str(pi.text))

def get_num_of_product_available(ASIN):
    driver = webdriver.Chrome(executable_path=driverpath,chrome_options=chromeOptions)
    # Navigate to product
    driver.get('https://www.amazon.in/dp/'+ASIN) #B079WSYPT7
    driver.maximize_window()
    # Add to Cart
    driver.find_element_by_id('add-to-cart-button').click()
    time.sleep(sleep_time)
    # Open to Cart Page
    driver.get("https://www.amazon.in/gp/cart/view.html?ref_=nav_cart")    
    time.sleep(sleep_time)
    # Click on Quantity drop down
    driver.find_element_by_id('a-autoid-0-announce').click()
    time.sleep(sleep_time)
    # Click on 10+ in drop down
    driver.find_element_by_xpath('//*[@id="a-popover-2"]/div/div/ul/li[11]').click()
    time.sleep(sleep_time)
    # Update quantity to 999
    driver.find_element_by_name('quantityBox').click()
    driver.find_element_by_name('quantityBox').send_keys(Keys.BACKSPACE)
    driver.find_element_by_name('quantityBox').send_keys('999')
    time.sleep(sleep_time)
    # Click on Update Button
    driver.find_element_by_id('a-autoid-1-announce').click()
    time.sleep(sleep_time+3)
    # Navigate through alerts and retrieve quantity available
    prod_avail_text=avail_alert(driver.find_elements_by_class_name('a-alert-content'))    
    print(prod_avail_text)
    print(prod_avail_text.split('only')[1].strip(' ').split(' ')[0])
    driver.close()
    return prod_avail_text.split('only')[1].strip(' ').split(' ')[0]

ASIN_lst=['B07MB9N65R','B074D2P27K']
ASIN_available_lst=[]
for ali in ASIN_lst:
    try:        
        ASIN_available_lst.append(get_num_of_product_available(ali))
    except Exception as e:
        print(str(e)," -Exception for ASIN:",ali)
        ASIN_available_lst.append("")
df=pd.DataFrame()
df['ASIN']=ASIN_lst
df['Quantity Available']=ASIN_available_lst
df['Date Extracted']=str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
print(df)
df.to_csv('ASIN_Quantity_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv',index=False,quoting=csv.QUOTE_ALL)