import pandas as pd
from faker import Faker

def xlsx_to_json(filename):
    df = pd.read_excel(filename)
    print(str(len(df)))
    print(str(len(df.columns)))
    data =list(df.columns)
    print(data)
    # for row in range(0,len(df)):
    #     elm = {}
    #     for col in range(0,len(df.columns)):
    #         elm[df.columns[col]]=str(df.iloc[row,col])
    #     data.append(elm)
    # print(len(data))
    return data


def pandas_fake_python(filename):
    df = pd.read_excel(filename)
    print(str(len(df)))
    print(str(len(df.columns)))
    faker = Faker()
    df["name"] = df["name"].apply(lambda x: faker.first_name())
    print(df)

pandas_fake_python(r'C:\Users\asrilekh\Downloads\my-diff-2.xlsx')