﻿$last_month_year=(Get-Date).AddMonths(-1).ToString('MMMM-yyyy')
$last_month_year="March-2020"

$mon_name = $last_month_year.Split('-')[0].Substring(0,3)
$year_name = $last_month_year.Split('-')[1]

$files_path='C:\Users\asrilekh\Documents\NGAM Automation\'+$mon_name+' '+$year_name+'\PForms '+$mon_name+''+$year_name+'\'
$agg_file_path='C:\Users\asrilekh\Documents\NGAM Automation\'+$mon_name+' '+$year_name+'\'

#$files_path='C:\Users\asrilekh\Documents\NGAM Automation\Mar 2020\PForms Mar2020\'
#$agg_file_path='C:\Users\asrilekh\Documents\NGAM Automation\Mar 2020\'

$xlsbfiles=@("AHT Per Skill.xlsb","Transfer Report.xlsb","NPS.xlsb","PSO FCR2 Summary Report.xlsb","Release Rate.xlsb","PSO Escalation Dashboard.xlsb")
$sheet_names=@("RAW","Raw","RAW","FCR Raw","RAW","AHTRaw")
$year_month_col_nums=@(29,16,54,8,10,7)
$year_month_vals=@('2020-03','2020-03','2020-03','2020-3','2020-03','2020-03')

for($fi=0; $fi -lt $xlsbfiles.Count; $fi++)
{
    $fname=$xlsbfiles.Get($fi)
    $sheet_name= $sheet_names.Get($fi)    
    $year_month_col_num=$year_month_col_nums.Get($fi)    
    $year_month_val=$year_month_vals.Get($fi)
    $xlsbfile=$files_path + $fname
    $xlsxfile=$files_path + $fname.Split('.')[0] +'.xlsx'
    $csvfile=$files_path + $fname.Split('.')[0] +'.csv'
    

    ### to convert converted xlsx file to csv

    $xlApp = New-Object -Com Excel.Application
    $xlApp.Visible = $false
    $xlApp.DisplayAlerts = $false
    $wb = $xlApp.Workbooks.Open($xlsbfile)
	
    foreach ($ws in $wb.Worksheets) {
        if($ws.name -eq $sheet_name)
        {
            $ws.SaveAs($csvfile, 6)
        }
    }
    
    $wb.close($false)    
    #$csvfile.close($true)
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)

    ### to convert converted xlsx file to csv
    
}

#### DB file for vlookup #######

$fname="NPS.xlsb"
$sheet_name= "DB"

$xlsbfile=$files_path + $fname
$xlsxfile=$files_path + 'DB.xlsx'


$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$xlApp.DisplayAlerts = $false


$workbook_new=$xlApp.Workbooks.Add()
$workbook_new.worksheets.item("Sheet2").Delete() # Delete sheet2
$workbook_new.worksheets.item("Sheet3").Delete() # Delete Sheet3
$workbook_new.SaveAs($xlsxfile, [Microsoft.Office.Interop.Excel.xlFileFormat]::xlOpenXMLWorkbook)
$workbook_new.Save()
$workbook_new.Close(0)

$sourceWb = $xlApp.Workbooks.Open($xlsbfile,$true,$false)
$targetWB = $xlApp.Workbooks.Open($xlsxfile)

foreach($nextSheet in $sourceWb.Sheets)
{
    if($nextSheet.name -eq $sheet_name)
    {
        $nextSheet.Copy($targetWB.Sheets[1])
        break
    }

}
$sourceWb.close($false)
$targetWB.close($true)

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)


#### DB file for vlookup #######

### existing vlokup data ######

$fname="Agg file.xlsb"
$sheet_name= "Vlookup"

$xlsbfile=$agg_file_path + $fname
$xlsxfile=$files_path + 'existing_vlookup.xlsx'


$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$xlApp.DisplayAlerts = $false


$workbook_new=$xlApp.Workbooks.Add()
$workbook_new.worksheets.item("Sheet2").Delete() # Delete sheet2
$workbook_new.worksheets.item("Sheet3").Delete() # Delete Sheet3
$workbook_new.SaveAs($xlsxfile, [Microsoft.Office.Interop.Excel.xlFileFormat]::xlOpenXMLWorkbook)
$workbook_new.Save()
$workbook_new.Close(0)

$sourceWb = $xlApp.Workbooks.Open($xlsbfile,$true,$false)
$targetWB = $xlApp.Workbooks.Open($xlsxfile)

foreach($nextSheet in $sourceWb.Sheets)
{
    if($nextSheet.name -eq $sheet_name)
    {
        $nextSheet.Copy($targetWB.Sheets[1])
        break
    }

}
$sourceWb.close($false)
$targetWB.close($true)

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)

### existing vlokup data ######


### existing ms id emp name data ######

$fname="Agg file.xlsb"
$sheet_name= "ms id emp name"

$xlsbfile=$agg_file_path + $fname
$xlsxfile=$files_path + 'existing_ms id emp name.xlsx'


$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$xlApp.DisplayAlerts = $false


$workbook_new=$xlApp.Workbooks.Add()
$workbook_new.worksheets.item("Sheet2").Delete() # Delete sheet2
$workbook_new.worksheets.item("Sheet3").Delete() # Delete Sheet3
$workbook_new.SaveAs($xlsxfile, [Microsoft.Office.Interop.Excel.xlFileFormat]::xlOpenXMLWorkbook)
$workbook_new.Save()
$workbook_new.Close(0)

$sourceWb = $xlApp.Workbooks.Open($xlsbfile,$true,$false)
$targetWB = $xlApp.Workbooks.Open($xlsxfile)

foreach($nextSheet in $sourceWb.Sheets)
{
    if($nextSheet.name -eq $sheet_name)
    {
        $nextSheet.Copy($targetWB.Sheets[1])
        break
    }

}
$sourceWb.close($false)
$targetWB.close($true)

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)

### existing ms id emp name data ######