﻿$valid_files=@('asrilekh_files_valid.txt','document_files_valid.txt','download_files_valid.txt','work_files_valid.txt')
$Dest_path_files=@('H:\asrilekh\','H:\asrilekh\Documents\','H:\asrilekh\Downloads\','H:\asrilekh\Desktop\Work\')
$Src_path_files=@('C:\users\asrilekh\','C:\users\asrilekh\Documents\','C:\users\asrilekh\Downloads\','C:\users\asrilekh\Desktop\Work\')


for($vi=1; $vi -lt $valid_files.Count; $vi++)
{
    $vfn=$valid_files.Get($vi)
    $mfs = Import-Csv $vfn | select -ExpandProperty 'Name'
    for($mfi=0; $mfi -lt $mfs.Count; $mfi++)
    {    
    
        if(($mfs.Get($mfi)).ToString().Contains('.'))
        {
            # Copy-Item ($Src_path_files.Get($vi)).ToString() + ($mfs.Get($mfi)).ToString() -Destination ($Dest_path_files.Get($vi)).ToString()
            write-host "$Src_path_files.Get($vi)" + "$mfs.Get($mfi)"
            write-host ($Dest_path_files.Get($vi)).ToString()
            #Copy-Item "$Src_path_files.Get($vi)$mfs.Get($mfi)" -Destination ($Dest_path_files.Get($vi)).ToString()
            write-host "copied item"
            start-sleep 10
        }
    }

}
