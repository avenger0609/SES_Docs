﻿$csvpath = "C:\Users\asrilekh\Documents\WOM Historical Data" 
$country_name='World'
$fromurl='https://www.worldometers.info/coronavirus/worldwide-graphs/#daily-deaths'
$webclient = New-Object System.Net.WebClient
$webclient.UseDefaultCredentials = $true
$s=$webclient.DownloadString($fromurl)

############# Daily new deaths in world bar graph #################################

 
$TimeStamp = get-date -f yyyyMMddHHmmss
$FileName= $country_name+"_daily_new_deaths_$TimeStamp.csv"
$csvfile= New-Item -Path $csvpath -Name $FileName -ItemType "file" -Value ""


$junk='<script type="text/javascript">'
$script_start=$s.IndexOf("Highcharts.chart('coronavirus-deaths-daily', {",0)
write-host $script_start
$script_end=$s.IndexOf('</script',$script_start)
write-host $script_end
$script=$s.Substring($script_start-($junk.Length+5),($script_end+9-($script_start-($junk.Length+5))))
#write-host $script

$x_axis_cat_start=$script.IndexOf('categories: ',0)
$x_axis_cat_end=$script.IndexOf(']',$x_axis_cat_start)
$x_axis=$script.substring($x_axis_cat_start+11,($x_axis_cat_end+1)-($x_axis_cat_start+11))
write-host $x_axis.Trim().replace('"','')

$series_data_start=$script.IndexOf('data:')
$series_data_end=$script.IndexOf(']',$series_data_start)
$series_data=$script.Substring($series_data_start+5,($series_data_end+1)-($series_data_start+5))
write-host $series_data.Trim().replace('"','')

$date_elements=$x_axis.Trim().replace('"','').Split(',')
$tot_cases_elements=$series_data.Trim().replace('"','').Split(',')
$op_new_deaths=$tot_cases_elements

$date_elements_len=$date_elements.Count
$tot_cases_elements_len=$tot_cases_elements.Count

write-host $date_elements_len
write-host $tot_cases_elements_len

Add-content $csvfile '"Date","Daily New Deaths"'
[int]$c=0

while($true)
{
    if($c -ge $tot_cases_elements_len)
    {
        break
    }
    $dc=$date_elements[$c].replace('[','').replace(']','').trim()
    $tc=$tot_cases_elements[$c].replace('[','').replace(']','').trim()    
    $csvs='"'+$dc+'"'+',"'+$tc+'"'    
    Add-content $csvfile $csvs
    $c=$c+1
}


############# Daily new deaths in world bar graph #################################

