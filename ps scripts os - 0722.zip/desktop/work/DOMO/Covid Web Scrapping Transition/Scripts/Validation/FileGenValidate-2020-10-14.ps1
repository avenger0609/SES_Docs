﻿$yesterday_date=[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date).AddDays(-1), 'UTC') | get-date -Format 'yyyyMMdd'

$today_folder='\\nasv0602\cv19_surgemodel\Data\Raw'
$yesterday_folder=$today_folder+"_"+$yesterday_date

$today_files=get-childitem -Path $today_folder -Recurse -Name
$yesterday_files=get-childitem -Path $yesterday_folder -Recurse -Name

$today_files
$yesterday_files

$missing_files=0

$Body ='<p style="font-size:11.0pt;font-family:Calibri;">Hi,<br><br>'
$Body = $Body +'Below files are missing to the files that were generated yesterday:<br><br>'
$Body = $Body +'<ol>'

write-host "---------------------------------------------------------------------------------------------------"

$startswithfiles=@('MA\CasesByDate_probable_','CovidTrackingHistory_','CovidTrackingCurrent_','MI_region_PatientCensusasof','MI_region_PPEDaysOnHandasof','MI_region_StatewideHospitalAvailablePPETrackingforCOVID-','MI_region_StatewideHospitalCapacityReportforCOVID-')

for($yi=0; $yi -lt $yesterday_files.Count; $yi++)
{
    $yfn=$yesterday_files.Get($yi)
    $tf=0
    $swf=0

    for($swi=0; $swi -lt $startswithfiles.Count; $swi++)
    {
        if($yfn.StartsWith($startswithfiles.Get($swi)))
        {
            $swf=$startswithfiles.Get($swi)
            break
        }
    }

    if($swf -ne 0)
    {
        write-host "hit in startswith:-"+$swf
        for($ti=0; $ti -lt $today_files.Count; $ti++)
        {        
            if($today_files.Get($ti).StartsWith($swf))
            {
                $tf=1
                break
            }
        }
           
    }
    
    if($tf -ne 1)
    {
        for($ti=0; $ti -lt $today_files.Count; $ti++)
        {        
            if($today_files.Get($ti) -eq $yfn)
            {
                $tf=1
                break
            }
        }
    }

    if($tf -eq 0)
    {
        $missing_files=$missing_files+1
        $Body = $Body +'<li>'+$yfn+'</li>'        
        write-host $yfn
    }
}

$Body = $Body +'</ol></p>'

$smtpServer = "mail25.uhc.com"
$smtpFrom = "srilekha.anumula@optum.com"
$smtpTo = "srilekha.anumula@optum.com"
$smtpCc='srilekha.anumula@optum.com'
$smtpBcC='srilekha.anumula@optum.com'
$messageSubject = "Files missing in "+([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date).AddDays(0), 'UTC') | get-date -Format 'MMMM dd,yyyy')+" files from "+([System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date).AddDays(-1), 'UTC') | get-date -Format 'MMMM dd,yyyy')

if($missing_files -gt 0)
{
    Send-MailMessage -Body $Body -To $smtpTo -SmtpServer $smtpServer -From $smtpFrom -Bcc $smtpBcC -Subject $messageSubject -BodyAsHtml # -Cc $smtpCc
}