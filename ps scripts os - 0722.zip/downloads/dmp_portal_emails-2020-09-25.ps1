﻿$last_month_year=(Get-Date).ToString('MMMM-yyyy')
$mon = $last_month_year.Split('-')[0]
$year = $last_month_year.Split('-')[1]

$dmp_filename='C:\Users\vsiripu\desktop\dmp_portal.csv'
#$dmp_filename='C:\Users\asrilekh\downloads\dmp_portal.csv'

$urls = Import-Csv $dmp_filename | select -ExpandProperty 'Signoff URL'
$emails = Import-Csv $dmp_filename | select -ExpandProperty 'Service Group CB Feed Owner'
$files = Import-Csv $dmp_filename | select -ExpandProperty 'CB Feed Name'

#write-host $urls.Count
#Write-Host $emails.Count
#write-host $files.Count


for($fi=0; $fi -lt $urls.Count; $fi++)
{
    if ($urls.Count -eq 1)
    {
        #write-host $urls
        $signoff_url=$urls
        $to_email=$emails
        $chargeback_file=$files
    }
    else
    {
        $signoff_url=$urls.Get($fi)
        $to_email=$emails.Get($fi)
        $chargeback_file=$files.Get($fi)
    }
    $smtpServer = "mail25.uhc.com"
    $smtpFrom = "Siripuram, Vamshi Nath on behalf of ITCB - IT Consumption and Billing <itcb@uhc.com>"
    $smtpTo = $to_email
    $smtpCc='srilekha.anumula@optum.com'
    $smtpBcC='vamshinath_s@optum.com','itcb@uhc.com','srilekha.anumula@optum.com'
    $messageSubject = $mon+''''+$year+' - Sign Off'
 
    $message = New-Object System.Net.Mail.MailMessage $smtpfrom, $smtpto
    $message.Subject = $messageSubject
    $message.IsBodyHTML = $true
 
    $message.Body = "Click <a href=http://www.google.com>here</a> to open google <br>" 


    $message.Body ='<p style="font-size:11.0pt;font-family:Calibri;">Hi,<br><br>'
    $message.Body = $message.Body +'The '+$mon+''''+$year+' '+$chargeback_file+' feed is yet to be approved in DMP Portal.<br><br>'
    $message.Body = $message.Body +'Can you use the below link and approve the same<br><br>'
    $message.Body = $message.Body +$chargeback_file+'   - <a href='+$signoff_url+'>'+$signoff_url+'</a><br><br>Regards,<br>'
    $message.Body = $message.Body +'Vamshi Nath Siripuram | Optum<br>'
    $message.Body = $message.Body +'Sr Data Analyst, OGS (India) Private Ltd<br>'
    $message.Body = $message.Body +'Bldg. #H06, Hitech City 2, Hyderabad, <u><span style="color:blue">500081</span></u>, India <br>Tel : <u><span style="color:#0070C0">0</span><span style="color:blue">403-384-1656&nbsp;</span><br>'
    $message.Body = $message.Body +'<u><span style="color:blue"><a href="mailto:vamshinath_s@optum.com">vamshinath_s@optum.com</a></span>'
    $message.Body = $message.Body +'</p>'

    #write-host $message.Body

    $smtp = New-Object Net.Mail.SmtpClient($smtpServer)
    #$smtp.Send($message)
    try
    {
        Send-MailMessage -Body $message.Body -To $smtpTo -SmtpServer $smtpServer -From $smtpFrom -Bcc $smtpBcC -Subject $messageSubject -BodyAsHtml # -Cc $smtpCc
    }
    catch
    {
        Write-Host $message.Body  $smtpTo  $smtpServer  $smtpFrom  $smtpBcC  $messageSubject $smtpCc
        Write-Host 'Caught  '  + $_.Exception.GetType().FullName
        Write-Host 'Caught  '  + $_.Exception.Message
    }
  
    Start-Sleep -s 15
}