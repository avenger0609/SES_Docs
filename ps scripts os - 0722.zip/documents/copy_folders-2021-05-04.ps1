﻿Copy-Item -Path "Y:\Jan2021" -Destination "C:\users\asrilekh\desktop\work" -Recurse -Force
Copy-Item -Path "Y:\Feb2021" -Destination "C:\users\asrilekh\desktop\work" -Recurse -Force
Copy-Item -Path "Y:\Mar2021" -Destination "C:\users\asrilekh\desktop\work" -Recurse -Force
Copy-Item -Path "Y:\Apr2021" -Destination "C:\users\asrilekh\desktop\work" -Recurse -Force