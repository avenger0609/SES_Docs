﻿$b=Get-Process | Where-Object {$_.MainWindowTitle -ne ""} | Select-Object MainWindowTitle

foreach($b1 in $b)
{
    $c=Get-ChildItem $b1.MainWindowTitle
    Get
    write-host $c
 }