﻿$excel = New-Object -ComObject excel.application
$excel.visible = $False
$workbook = $excel.Workbooks.Add()
$diskSpacewksht= $workbook.Worksheets.Item(1)
$diskSpacewksht.Name = "Data Set"
$row_counter=0
$col_counter=0
$r = Invoke-WebRequest -Uri 'https://www.worldometers.info/coronavirus/' 
$data = $r.parsedhtml.getelementsbytagname("TR") #this part seems to work fine
$table = @()
forEach($datum in $data){
    if($datum.tagName -eq "tr"){
        $col_counter=0
        $row_counter=$row_counter+1
        write-host "ro number=" + $row_counter
        $cells = $datum.children
        forEach($cell in $cells){
            
            if($cell.tagName -eq "td"){
                $col_counter=$col_counter+1
                write-host "col number=" +  $col_counter
                $diskSpacewksht.Cells.Item($row_counter,$col_counter)=$cell.innerText
                
            }
        }
        
        
    }
}


$excel.DisplayAlerts = 'False'
$ext=".xlsx"
$path="C:\users\asrilekh\documents\DataSet1$ext"
$workbook.SaveAs($path) 
$workbook.Close
$excel.DisplayAlerts = 'False'
$excel.Quit()