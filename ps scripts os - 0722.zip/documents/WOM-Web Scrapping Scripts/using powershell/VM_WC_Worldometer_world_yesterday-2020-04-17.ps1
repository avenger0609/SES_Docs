﻿try
{

    $csvpath = "D:\DOMO\WorldOMeter\Data\World\Yesterday_Data"    
    $TimeStamp = get-date -f yyyyMMddhhmmss
    $Archive='D:\DOMO\WorldOMeter\Archive\World\Yesterday_Data'
    $FileName= "WOM_World_Covid19_YesterdayCases_$TimeStamp.txt"
    #$LogfileName= "WOM_World_Covid19_YesterdayCases_$TimeStamp logger.txt"
    $fromurl = "https://www.worldometers.info/coronavirus/"

    $csvfile= New-Item -Path $csvpath -Name $FileName -ItemType "file" -Value ""
    #$logfile= New-Item -Path $csvpath -Name $LogfileName -ItemType "file" -Value "test log"
    $yesterday_date=(Get-Date).AddDays(0).ToString('MM-dd-yyyy hh:mm:ss')

    #Archiving old files
    #Move-Item -Path $csvpath\'WOM_World_Covid19_YesterdayCases_*.txt' -Destination $Archive
    
    get-childitem -Path $csvpath -Filter WOM_World_Covid19_YesterdayCases_*.txt | move-item -destination $Archive -Force

    $row_counter=0
    $col_counter=0


    ### not needed hence stopped in middle

    
    $webclient = New-Object System.Net.WebClient
    $webclient.UseDefaultCredentials = $true
    $s=$webclient.DownloadString($fromurl)

    ### container of table data ####
    $table_start=$s.IndexOf('<table id="main_table_countries_yesterday"',0)
    $table_end=$s.IndexOf('</table>',$table_start)
    $s1=$s.Substring($table_start,($table_end-$table_start))
    #write-host $s1
    ### container of table data ####

    ### collecting table headers ###

    $th_start=$s1.IndexOf('<thead',0)
    $th_end=$s1.IndexOf('</thead>',$th_start)
    $th_s=$s1.Substring($th_start,($th_end-$th_start))
    #write-host $th_s
    $csvs=""
    
    $thte=4
    $row_counter=$row_counter+1
    write-Host 'Row number is '$row_counter
    while($true){
        $col_counter=$col_counter+1
        write-Host 'column number is ' $col_counter
        $thts_start=$th_s.IndexOf('<th',$thte)  ### index of <th    
        if($thts_start -eq -1){ break }
        $thts_end=$th_s.IndexOf('>',$thts_start)    ### index of >    
        $thte=$th_s.IndexOf('</th>',$thts_end+1)    
        $thval=$th_s.Substring($thts_end+1,($thte-$thts_end)-1)
        #Write-Host "value is  $thval"
        $csvs=$csvs+'"'+($thval).replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').Trim()+'",'
    }
    $csvs=$csvs+'"Date Updated"'
    Add-Content $csvfile "$csvs"

    ### collecting table headers ###

    ### collecting table body ###

    $tb_start=$s1.IndexOf('<tbody',0)
    $tb_end=$s1.IndexOf('</tbody>',$tb_start)
    $tb_s=$s1.Substring($tb_start,($tb_end-$tb_start+8))
    #Write-Host $tb_s
    $trte=0
    while($true){
        $csvs=""
        $row_counter=$row_counter+1
        $col_counter=0
        write-Host 'Row number is '$row_counter
        $trts_start=$tb_s.IndexOf('<tr',$trte)
        if($trts_start -eq -1){ break }
        $trts_end=$tb_s.IndexOf('>',$trts_start) 
        $trte=$tb_s.IndexOf('</tr>',$trts_end+1) 
        $trval=$tb_s.Substring($trts_end+1,($trte-$trts_end)-1)   
        #Write-Host $trval
        $tdte=0
        while($true){
            $col_counter=$col_counter+1
            write-Host 'column number is ' $col_counter
            $tdts_start=$trval.IndexOf('<td',$tdte)  ### index of <td
            if($tdts_start -eq -1){ break }
            $tdts_end=$trval.IndexOf('>',$tdts_start)    ### index of >    
            $tdte=$trval.IndexOf('</td>',$tdts_end+1)    
            $tdval=$trval.Substring($tdts_end+1,($tdte-$tdts_end)-1)
            #Write-Host "value is  $tdval"
            if($tdval.IndexOf('<') -eq -1)
            {
                $csvs=$csvs+'"'+($tdval).replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').replace("`n","").Trim()+'",'
            }
            else
            {
                $tdvalt_s=$tdval.IndexOf('>',0)
                $tdvalt_e=$tdval.IndexOf('<',$tdvalt_s)
                $tdval1=$tdval.Substring($tdvalt_s+1,($tdvalt_e)-($tdvalt_s+1))
                $csvs=$csvs+'"'+($tdval1).replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').replace("`n","").Trim()+'",'
            }
        }
        $csvs=$csvs+'"'+$yesterday_date+'"'
        Add-Content $csvfile "$csvs"
    }
    ### collecting table body ###

    $smtpServer = "mail25.uhc.com"
    $smtpFrom = "srilekha.anumula@optum.com"
    $smtpTo ="srilekha.anumula@optum.com,rizwan.syedali@optum.com"
    $messageSubject = "Success- extracting world data for yesterday powershell script from WorldoMeter"
    $messageBody =  "Number of rows extracted="+$row_counter-1
    $smtp = New-Object Net.Mail.SmtpClient($smtpServer)
    $smtp.Send($smtpFrom,$smtpTo,$messagesubject,$messagebody)

}
catch
{
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
    Write-Host 'Caught  '  + $_.Exception.Message
    $smtpServer = "mail25.uhc.com"
    $smtpFrom = "srilekha.anumula@optum.com"
    $smtpTo ="srilekha.anumula@optum.com,rizwan.syedali@optum.com"
    $messageSubject = "Error- extracting world data for yesterday powershell script from WorldoMeter"
    $messageBody =  $_.Exception.Message+""
    $smtp = New-Object Net.Mail.SmtpClient($smtpServer)
    $smtp.Send($smtpFrom,$smtpTo,$messagesubject,$messagebody)
}


