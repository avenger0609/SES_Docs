﻿[DateTime]::UtcNow.ToString('u').Replace('Z','')

$yesterday_date=(Get-Date).AddDays(0).ToString('MM-dd-yyyy hh:mm:ss')
write-host $yesterday_date

[DateTime]::Today.AddDays(0).ToString('u').Replace('Z','')

$time = [DateTime]::UtcNow | get-date -Format "yyyy-MM-ddTHH:mm:ssZ"
write-host $time

$today = [DateTime]::Today.AddDays(0).ToString('u').Replace('Z','') | get-date -Format "yyyy-MM-ddTHH:mm:ssZ"
write-host $today


## yesterday in GMT

[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date).AddDays(0), 'UTC') | get-date -Format 'MM-dd-yyyy HH:mm:ss'

#[System.TimeZoneInfo]::GetSystemTimeZones( )

