﻿Function Convert-NumberToA1 { 
  <# 
  .SYNOPSIS 
  This converts any integer into A1 format. 
  .DESCRIPTION 
  See synopsis. 
  .PARAMETER number 
  Any number between 1 and 2147483647 
  #> 
   
  Param([parameter(Mandatory=$true)] 
        [int]$number) 
 
  $a1Value = $null 
  While ($number -gt 0) { 
    $multiplier = [int][system.math]::Floor(($number / 26)) 
    $charNumber = $number - ($multiplier * 26) 
    If ($charNumber -eq 0) { $multiplier-- ; $charNumber = 26 } 
    $a1Value = [char]($charNumber + 64) + $a1Value 
    $number = $multiplier 
  } 
  Return $a1Value 
}

function Convert-XlsmToCsv {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        
    }
    process {
        
        $Excel   = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $root = Split-Path -Path $Path        
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path) ## get's file name
        $workbook = $excel.Workbooks.Open($Path)
        $src_fname=Join-Path -Path $root -ChildPath "$filename.xlsm" ## source file name with extension
        $name = Join-Path -Path $root -ChildPath "$filename.xls" # saving as output xls file
        $test = Join-Path -Path $root -ChildPath "test.xls" # intermediate file used for storing data
        $wname="" # to store name of worksheet

        # deleting unwanted sheets

        foreach ($worksheet in $workbook.Worksheets) {
            if($worksheet.Name -like "*YTD Actuals"){
                 $wname=$worksheet.Name                 
                 $workbook.worksheets.item($worksheet.Name).Visible = $true
            } 
            else{
                $workbook.worksheets.item($worksheet.Name).Delete()
            } 
        }                         
        $workbook.SaveAs($name)
        $workbook.Close()                   
        $Excel.Quit()
        $null = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Excel)

        # deleting unwanted sheets

        # deleting top 5 rows

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $sheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the first row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the second row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the third row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the fourth row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the fifth row
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        # deleting top 5 rows

        # copying sheet data to new file (test file)  deleting top 5 rows
        
        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($src_fname) # Open the file
        $workbook_new=$excel.Workbooks.Add()
        $workbook_new.worksheets.item("Sheet2").Delete()
        $workbook_new.worksheets.item("Sheet3").Delete()
        $Sheet_new = $Workbook_new.Worksheets.Item(1)
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        $ColumnCount = $WorksheetRange.Columns.Count
        $col_letter_last=Convert-NumberToA1($ColumnCount)
        [void]$workSheet.Range(“A1:$col_letter_last$RowCount").Copy()
        [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").Select()
        [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").PasteSpecial(-4163)
        [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() # Delete the first row
        [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() # Delete the second row
        [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() # Delete the third row
        [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() # Delete the fourth row
        [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() # Delete the fifth row               
        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.SaveAs($test)
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        # copying sheet data to new file (test file)  deleting top 5 rows

        # writing data to atual output file

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $test_wb = $excel.Workbooks.Open($test) # Open the file
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $test_sheet = $test_wb.Sheets.Item("Sheet1") # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        for($i=1; $i -le $WorksheetRange.Rows.Count; $i++){
            for($j=1; $j -le $WorksheetRange.Columns.Count; $j++){
                $workSheet.cells.item($i,$j).value() = $test_sheet.cells.item($i,$j).value() 
            }
        }
        $workbook.Save()
        $workbook.Close($true)
        $test_wb.Close($true)
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        # writing data to atual output file

        # adding file name to first column

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange        
        [void]$workSheet.Range(“B2:B$RowCount”).Copy()
        [void]$workSheet.Range(“A2:A$RowCount”).Select()
        [void]$workSheet.Range(“A2:A$RowCount”).PasteSpecial()    
        $workSheet.cells.item(2,1).value() = "FileName"
        for($i=3; $i -le $WorksheetRange.Rows.Count; $i++){
            $workSheet.cells.item($i,1).value() = "$filename"
        }
        [void]$workSheet.Range(“A2:A$RowCount”).EntireColumn.AutoFit() ## adjusting column width        
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        
        # adding file name to first column

        # removing intermediate file
        
        remove-item -path $test -force

        # removing intermediate file
        
    }
    end {
        
        
    }
}
Get-ChildItem -Path C:\Users\asrilekh\Documents\Domo\test2 -Filter *.xlsm |Convert-XlsmToCsv
