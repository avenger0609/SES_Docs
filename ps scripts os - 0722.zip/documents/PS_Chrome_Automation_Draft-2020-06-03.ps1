﻿Add-Type -Path "C:\ProgramData\ChromeDriver_81\Selenium.WebDriverBackedSelenium.dll"
Add-Type -Path "C:\ProgramData\ChromeDriver_81\ThoughtWorks.Selenium.Core.dll"
Add-Type -Path "C:\ProgramData\ChromeDriver_81\WebDriver.dll"
Add-Type -Path "C:\ProgramData\ChromeDriver_81\WebDriver.Support.dll"

$driver = New-Object OpenQA.Selenium.Chrome.ChromeDriver
$driver.Navigate().GoToUrl("https://www.google.com.au/")

$inputField = $driver.FindElementsById("lst-ib")
$inputField.SendKeys("spotty dog")
$inputField.Submit();

$driver.Quit();