﻿try {

    $excel = New-Object -ComObject excel.application
    $excel.visible = $False
    $workbook = $excel.Workbooks.Add()
    $diskSpacewksht= $workbook.Worksheets.Item(1)
    $diskSpacewksht.Name = "Data Set"
    $row_counter=0
    $col_counter=0
    $r = Invoke-WebRequest -Uri 'https://www.worldometers.info/coronavirus/' 
    $table_id = $r.parsedhtml.getElementById("main_table_countries_yesterday")
    $hdr_cells = $table_id.children

    forEach($hci in $hdr_cells){
        if($hci.tagName -eq "thead"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "th"){
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter
                            $diskSpacewksht.Cells.Item($row_counter,$col_counter)=$cell.innerText
                
                        }
                    }
                }
            }
        }
        if($hci.tagName -eq "tbody"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "td"){
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter
                            $diskSpacewksht.Cells.Item($row_counter,$col_counter)=$cell.innerText
                
                        }
                    }
                }
            }
        }
    }


    $excel.DisplayAlerts = 'False'
    $ext=".xlsx"
    $path="C:\users\asrilekh\documents\DataSet1_test$ext"
    $workbook.SaveAs($path) 
    $workbook.Close
    $excel.DisplayAlerts = 'False'
    $excel.Quit()
}
catch
{
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
}
