﻿#Config Variables
$SiteURL = "https://uhgazure.sharepoint.com/sites/orxtech/pfm"
$FileRelativeURL = "/Shared Documents/Portfolio Log Export 092319_with 2016 2017 and Staging.xlsx"
$DownloadPath ="C:\Users\asrilekh\Downloads\"

Try {
    #Connect to PNP Online
    Connect-PnPOnline -Url $SiteURL -SPOManagementShell -ReturnConnection
     
    #powershell download file from sharepoint online
    Get-PnPFile -Url $FileRelativeURL -Path $DownloadPath -AsFile -Force
    write-host "Success"
}
catch {
    write-host "Error: $($_.Exception.Message)" -foregroundcolor Red
}