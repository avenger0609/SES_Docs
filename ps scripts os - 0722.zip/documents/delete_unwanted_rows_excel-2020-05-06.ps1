﻿$xlsxfile = 'C:\Users\asrilekh\Documents\MyJabberFiles\ksruthi5@corpimsvcs.com\Mar 2020\PForms Mar2020\AHT Per Skill.xlsx'

$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$wb = $xlApp.Workbooks.Open($xlsxfile)
$sh1 = $wb.sheets.item('RAW')
$sh1.Select()
write-host $sh1.name
$RowCnt = $sh1.UsedRange.Rows.Count
write-host $RowCnt
for($i=2; $i -le $RowCnt; $i++){
    $cv=$sh1.cells.item($i,29).value()
    write-host $cv
    if($cv -eq '2020-03')
    {
        $ok=1
    }
    else
    {
        $currRow = $sh1.cells.item($i,29).EntireRow
        [void]$currRow.Delete()
        write-host 'deleted'
    }
}

#$sh1.ShowAllData()
#$wb.Save()
$wb.Close(0)
$xlApp.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)