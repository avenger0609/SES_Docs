﻿Function Convert-NumberToA1 { 
  <# 
  .SYNOPSIS 
  This converts any integer into A1 format in Excel. 
  .DESCRIPTION 
  See synopsis. 
  .PARAMETER number 
  Any number between 1 and 2147483647 --- range of column numbers
  #> 
   
  Param([parameter(Mandatory=$true)] 
        [int]$number) 
 
  $a1Value = $null 
  While ($number -gt 0) { 
    $multiplier = [int][system.math]::Floor(($number / 26)) 
    $charNumber = $number - ($multiplier * 26) 
    If ($charNumber -eq 0) { $multiplier-- ; $charNumber = 26 } 
    $a1Value = [char]($charNumber + 64) + $a1Value 
    $number = $multiplier 
  }
  
  Return $a1Value 
}

############################################ declarations              ###########################################################################################################

$last_month_year=(Get-Date).AddMonths(-1).ToString('MMMM-yyyy')

#$last_month_year="March-2020"

$mon_name = $last_month_year.Split('-')[0].Substring(0,3)
$year_name = $last_month_year.Split('-')[1]

$existing_gen_files_path='C:\Users\ksruthi5\Documents\DOCS\ICC  NGAM\NGAM\'+$mon_name+' '+$year_name+'\'

#$existing_gen_files_path='C:\Users\asrilekh\Documents\NGAM Automation\Mar 2020\'

############################################ aggregate file data append except 'Vlookup' and 'ms id emp name' ############################################################################################################

$existing_file=$existing_gen_files_path + 'Agg file.xlsb'
$file_frm_which_data_2b_appended= $existing_gen_files_path + 'Agg file_m.xlsx'
$sheet_names=@('AHT','Transfer Rate','NPS ','FCR 2','FCR 2 Raw','Release Rate','Esclation','Adherence','MSID List from Scorecard')

for($fi=0; $fi -lt $sheet_names.Count; $fi++)
{
    try
    {
        write-host $fi
        $excel = New-Object -ComObject Excel.Application -Property @{
                    Visible       = $false
                    DisplayAlerts = $false}
        ## existing file processing

        $workbook = $excel.Workbooks.Open($existing_file) # Open the file
        $existing_sheet = $workbook.Sheets.Item($sheet_names.Get($fi))

        ## existing file processing

        # processing file from which data to be appended

        $workbook_new=$excel.Workbooks.Open($file_frm_which_data_2b_appended)
        $new_sheet=$workbook_new.Sheets.Item($sheet_names.Get($fi))

        # processing file from which data to be appended

        # existing sheet values range

        $existingsheetRange = $existing_sheet.UsedRange
        $existingRowCount = $existingsheetRange.Rows.Count
        $existingColumnCount = $existingsheetRange.Columns.Count
        $existingcol_letter_last=Convert-NumberToA1($existingColumnCount)

        # existing sheet values range

        # file from which data needs to be appended

        $WorksheetRange = $new_sheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        if($RowCount -le 1)
        {
            continue
            $workbook.Close($true) # Close workbook and save changes
            $workbook_new.Close($false) # Close workbook and save changes


            $excel.quit() # Quit Excel
            $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        }
        $ColumnCount = $WorksheetRange.Columns.Count
        $col_letter_last=Convert-NumberToA1($ColumnCount)

        # file from which data needs to be appended


        $copy_row_count=$existingRowCount-($RowCount-1)+1

        [void]$existing_sheet.Range(“A$copy_row_count :$col_letter_last$existingRowCount").Copy()
        [void]$existing_sheet.Cells.Item($existingRowCount+1,1).PasteSpecial()

        
        [void]$new_sheet.Range(“A2:$col_letter_last$RowCount").Copy()
        [void]$existing_sheet.Cells.Item($existingRowCount+1,1).PasteSpecial(-4163)

        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.Close($false) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
    }
    catch
    {
        Write-Host 'Caught  '  + $_.Exception.GetType().FullName
        Write-Host 'Caught  '  + $_.Exception.Message
    }

}

write-host "aggregate file data append except 'Vlookup' and 'ms id emp name' completed "

############################################ aggregate file data append except 'Vlookup' and 'ms id emp name' ############################################################################################################

############################################ aggregate file data append only 'Vlookup' and 'ms id emp name' ############################################################################################################

$existing_file=$existing_gen_files_path + 'Agg file.xlsb'
$file_frm_which_data_2b_appended= $existing_gen_files_path + 'Agg file_m.xlsx'
$sheet_names=@('Vlookup','ms id emp name')

for($fi=0; $fi -lt $sheet_names.Count; $fi++)
{
    try
    {
        write-host $fi
        $excel = New-Object -ComObject Excel.Application -Property @{
                    Visible       = $false
                    DisplayAlerts = $false}
        ## existing file processing

        $workbook = $excel.Workbooks.Open($existing_file) # Open the file
        $existing_sheet = $workbook.Sheets.Item($sheet_names.Get($fi))

        ## existing file processing

        # processing file from which data to be appended

        $workbook_new=$excel.Workbooks.Open($file_frm_which_data_2b_appended)
        $new_sheet=$workbook_new.Sheets.Item($sheet_names.Get($fi))

        # processing file from which data to be appended

        # existing sheet values range

        $existingsheetRange = $existing_sheet.UsedRange
        $existingRowCount = $existingsheetRange.Rows.Count
        $existingColumnCount = $existingsheetRange.Columns.Count
        $existingcol_letter_last=Convert-NumberToA1($existingColumnCount)

        # existing sheet values range

        # file from which data needs to be appended

        $WorksheetRange = $new_sheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        if($RowCount -le 1)
        {
            continue
            $workbook.Close($true) # Close workbook and save changes
            $workbook_new.Close($false) # Close workbook and save changes


            $excel.quit() # Quit Excel
            $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        }
        $ColumnCount = $WorksheetRange.Columns.Count
        $col_letter_last=Convert-NumberToA1($ColumnCount)

        # file from which data needs to be appended


        #$copy_row_count=$existingRowCount-($RowCount-1)+1

        #[void]$existing_sheet.Range(“A$copy_row_count :$col_letter_last$existingRowCount").Copy()
        #[void]$existing_sheet.Cells.Item($existingRowCount+1,1).PasteSpecial()

        
        [void]$new_sheet.Range(“A2:$col_letter_last$RowCount").Copy()
        [void]$existing_sheet.Cells.Item(2,1).PasteSpecial(-4163)

        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.Close($false) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
    }
    catch
    {
        Write-Host 'Caught  '  + $_.Exception.GetType().FullName
        Write-Host 'Caught  '  + $_.Exception.Message
    }
}

write-host "aggregate file data append only 'Vlookup' and 'ms id emp name' completed "

############################################ aggregate file data append only  'Vlookup' and 'ms id emp name' ############################################################################################################


########################################################### AgentCountbySup, AgentScoreCard, Pfrom_Supervisor excel data append  ##########################################################################################

$existing_fnames=@('AgentCountbySup.xlsx','AgentScoreCard.xlsb','Pfrom_Supervisor.xlsx')
$fnames_frm_which_data_2b_appended=@('AgentCountbySup_m.xlsx','AgentScoreCard_m.xlsx','Pfrom_Supervisor_m.xlsx')

for($fi=0; $fi -lt $existing_fnames.Count; $fi++)
{
    try
    {
        $existing_file=$existing_gen_files_path + $existing_fnames.Get($fi)
        $file_frm_which_data_2b_appended=$existing_gen_files_path + $fnames_frm_which_data_2b_appended.Get($fi)

        $excel = New-Object -ComObject Excel.Application -Property @{
                    Visible       = $false
                    DisplayAlerts = $false}

        ## existing file processing

        $workbook = $excel.Workbooks.Open($existing_file) # Open the file
        $existing_sheet = $workbook.Sheets.Item(1)

        ## existing file processing

        # processing file from which data to be appended

        $workbook_new=$excel.Workbooks.Open($file_frm_which_data_2b_appended)
        $new_sheet=$workbook_new.Sheets.Item(1)

        # processing file from which data to be appended

        # existing sheet values range

        $existingsheetRange = $existing_sheet.UsedRange
        $existingRowCount = $existingsheetRange.Rows.Count
        $existingColumnCount = $existingsheetRange.Columns.Count
        $existingcol_letter_last=Convert-NumberToA1($existingColumnCount)

        # existing sheet values range

        # file from which data needs to be appended

        $WorksheetRange = $new_sheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        if($RowCount -le 1)
        {
            continue
            
            $workbook.Close($true) # Close workbook and save changes
            $workbook_new.Close($false) # Close workbook and save changes


            $excel.quit() # Quit Excel
            $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        }
        $ColumnCount = $WorksheetRange.Columns.Count
        $col_letter_last=Convert-NumberToA1($ColumnCount)

        # file from which data needs to be appended


        $copy_row_count=$existingRowCount-($RowCount-1)+1

        [void]$existing_sheet.Range(“A$copy_row_count :$col_letter_last$existingRowCount").Copy()
        [void]$existing_sheet.Cells.Item($existingRowCount+1,1).PasteSpecial()

        
        [void]$new_sheet.Range(“A2:$col_letter_last$RowCount").Copy()
        [void]$existing_sheet.Cells.Item($existingRowCount+1,1).PasteSpecial(-4163)

        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.Close($false) # Close workbook and save changes


        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
    }
    catch
    {
        Write-Host 'Caught  '  + $_.Exception.GetType().FullName
        Write-Host 'Caught  '  + $_.Exception.Message
    }
}

write-host "AgentCountbySup, AgentScoreCard, Pfrom_Supervisor excel data append completed "

########################################################### AgentCountbySup, AgentScoreCard, Pfrom_Supervisor excel data append  ##########################################################################################



###################################### convert xlsb to xlsx files ############################################

$existing_fnames=@('Agg file.xlsb','AgentScoreCard.xlsb')
$xlsx_fnames=@('Agg file.xlsx','AgentScoreCard.xlsx')

for($fi=0; $fi -lt $existing_fnames.Count; $fi++)
{
    try
    {
    
        $xlsbfile=$existing_gen_files_path + $existing_fnames.Get($fi)
        $xlsxfile=$existing_gen_files_path + $xlsx_fnames.Get($fi)    

        $xlApp = New-Object -Com Excel.Application
        $xlApp.Visible = $false
        $wb = $xlApp.Workbooks.Open($xlsbfile)        
        $wb.SaveAs($xlsxfile, [Microsoft.Office.Interop.Excel.xlFileFormat]::xlOpenXMLWorkbook)
        $wb.Close(0)
        $xlApp.Quit()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)
    }
    catch
    {
        Write-Host 'Caught  '  + $_.Exception.GetType().FullName
        Write-Host 'Caught  '  + $_.Exception.Message
    }
}