﻿$xlsbfile = 'C:\Users\asrilekh\Documents\MyJabberFiles\ksruthi5@corpimsvcs.com\NGAM Files Mar 2020\Mar 2020\PForms Mar2020\NPS.xlsb'   # xls, xlsx, xlsb or whatever file would be possible here.
$xlsxfile = 'C:\Users\asrilekh\Documents\MyJabberFiles\ksruthi5@corpimsvcs.com\NGAM Files Mar 2020\Mar 2020\PForms Mar2020\NPS.xlsx'

$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$wb = $xlApp.Workbooks.Open($xlsbfile)
$worksheet = $wb.worksheets.item(1).name
write-host $worksheet
#$wb.SaveAs($xlsxfile, [Microsoft.Office.Interop.Excel.xlFileFormat]::xlOpenXMLWorkbook)
$wb.Close(0)
$xlApp.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)