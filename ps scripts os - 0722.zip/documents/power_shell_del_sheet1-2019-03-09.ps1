﻿function Convert-XlsmToCsv {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        
    }
    process {
        $Excel   = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $root = Split-Path -Path $Path
        #write-host $root "Root path"
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path)
        $workbook = $excel.Workbooks.Open($Path)
        $name = Join-Path -Path $root -ChildPath "$filename.xls"                     
        $workbook.worksheets.item("Instructions").Delete()
        $workbook.worksheets.item("Current Month Actuals").Delete()
        $workbook.worksheets.item("Upload Template").Delete()        
        $workbook.worksheets.item("Sheet1").Delete()
        
        $workbook.SaveAs($name)
        $workbook.Close()                   
        $Excel.Quit()
        $null = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Excel)
            
        
    }
    end {
        
        
    }
}
Get-ChildItem -Path C:\Users\asrilekh\Documents\Domo\test -Filter *.xlsm |Convert-XlsmToCsv
