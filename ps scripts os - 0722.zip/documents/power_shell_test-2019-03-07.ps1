﻿#$import = get-content "c:\users\asrilekh\documents\domo\2018 Actuals Submission--CSG--April.csv"
#$import | Select-Object -Skip 6 | Set-Content "c:\users\asrilekh\documents\domo\2018 Actuals Submission--CSG--April.csv"
#[cultureinfo]::CurrentCulture.DateTimeFormat.GetMonthName(2)
"$([array]::indexof([cultureinfo]::CurrentCulture.DateTimeFormat.MonthNames, "April") + 1)".PadLeft(2,'0')