﻿$fromurl = "http://cfrservices.uhg.com/Info/TreeReport#"
$topath   = "C:\Users\asrilekh\Documents\Domo"
$fromfile=""
$tofile=""

$webclient = New-Object System.Net.WebClient
$webclient.UseDefaultCredentials = $true

$s=$webclient.DownloadString($fromurl) 

Write-Host $s

$startindex=0


while($true){

    $postiitonSlashA=$s.IndexOf('UHG_OPERATING_UNIT_GEN_PSTREE',$startindex)
    
    if($postiitonSlashA -ne -1){
        
        $s1=$s.Substring($postiitonSlashA,50)
        $s2=$s1.Split("'")[1]
        $fromfile=$fromurl+"/"+$s2
        write-Host $fromfile
        $tofile=$topath+"\"+$s2
        write-Host $tofile
        $webclient.DownloadFile($fromfile, $tofile)
        $startindex=$postiitonSlashA+2
        
    }
    else
    {
        break
    }

}

#$a1= $s | Select-String -Pattern "xlsm"
#write-Host $a1

#$title= [regex] '(?<=<head>)([\S\s]*?)(?=</head>)' 
#write-Host $title
#write-Host $title.Match($s).value.trim()
#$s | Select-String -Pattern 'HELLO' -CaseSensitive -SimpleMatch