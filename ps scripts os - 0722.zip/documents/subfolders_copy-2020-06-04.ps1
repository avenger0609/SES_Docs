﻿$s1=Get-ChildItem -Path "C:\users\asrilekh\downloads" -Recurse -Directory -Force -ErrorAction SilentlyContinue | Select-Object FullName
write-host type($s1)