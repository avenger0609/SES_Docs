﻿$Excel = New-Object -ComObject Excel.Application
$workbook = $Excel.workbooks.add()
#working with sheets
$workbook.worksheets.item("Sheet1").Delete()
$workbook.SaveAs("srilekha1.xlsx")
$workbook.Close()
$Excel.Quit()