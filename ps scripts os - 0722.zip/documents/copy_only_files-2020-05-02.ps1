﻿### not working

Copy-Item -Path "C:\Users\asrilekh\desktop\copy_test\*"  -Destination "H:\Desktop\" 