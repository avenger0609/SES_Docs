﻿if($true)
{    
    $fromurl='https://health.wyo.gov/publichealth/infectious-disease-epidemiology-unit/disease/novel-coronavirus/'   
    $webclient = New-Object System.Net.WebClient
    $webclient.UseDefaultCredentials = $true
    $s=$webclient.DownloadString($fromurl)
    #write-host $s
    $table_start=$s.IndexOf('<p><strong>Albany',0)    
    $table_end=$s.IndexOf('</p>',$table_start)
    $s1=$s.Substring($table_start,($table_end-$table_start))
    $data=$s1.Replace('<strong>','').Replace('<strong>','').Replace('<p>','').Replace('<br />','').Replace('</strong>',';')
    $data_lst=$data.Split(';')
    write-host $data_lst
    for($fi=0; $fi -lt $data_lst.Count; $fi++)
    {
       Write-Host $data_lst.Get($fi)
    }
}
else
{
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
    Write-Host 'Caught  '  + $_.Exception.Message
    $smtpServer = "mail25.uhc.com"
    $smtpFrom = "srilekha.anumula@optum.com"
    $smtpTo ="srilekha.anumula@optum.com,rizwan.syedali@optum.com"
    $messageSubject = "Error- extracting US data for today powershell script from WorldoMeter"
    $messageBody =  $_.Exception.Message+""
    $smtp = New-Object Net.Mail.SmtpClient($smtpServer)
    #$smtp.Send($smtpFrom,$smtpTo,$messagesubject,$messagebody)
}


