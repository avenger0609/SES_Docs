﻿$myArray = @("Hello World","Hello World","Hello World")
#foreach ($element in $myArray) {$element}
$RowCnt=$myArray.Count
for($i=0; $i -lt $RowCnt; $i++){
    write-host $myArray.Get($i)
}