﻿$x = 30

if($x -le 20){
   write-host("This is if statement")
}else {
   write-host("This is else statement")
}