try {
##task scheduler name: DOMO_ODx_Data New Script
$Source = "C:\Users\asrilekh\Downloads\splits.zip\splits\"
$Dest = "C:\Users\asrilekh\Downloads\splits.zip\splits\Consolidated"
$Archive = "C:\Users\asrilekh\Downloads\splits.zip\splits\Archive"
$Staging = "C:\Users\asrilekh\Downloads\splits.zip\splits\Staging"
$Logs = "C:\Users\asrilekh\Downloads\splits.zip\splits\Logs"
$TimeStampformatted = Get-Date -UFormat "%m-%d-%Y %T"
$TimeStamp = get-date -f yyyyMMddhhmmss
$DestFile = "combinedOptumODX_$TimeStamp.csv"
$Logfile= New-Item -Path $Logs -Name "LogTransferOptumODX-$TimeStamp.log" -ItemType "file" -Value "Consolidation of files started at $TimeStampformatted"


Add-Content $Logfile "`r`n `r`n#### Step 1: Archiving old Consolidated files ####"
Add-Content $Logfile "Archiving the previously Consolidated file`r`nFileName:"
Get-ChildItem -Path $Dest -Filter combinedOptumODX*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile
Add-Content $Logfile "Archive path: `r`n$Archive"
get-childitem -Path $Dest -Filter combinedOptumODX*.csv | move-item -destination $Archive

Add-Content $Logfile "`r`n#### Step 2: Moving all the Extract files to Staging Folder ####"
Add-Content $Logfile "Moving all the Extract files to the Staging path: $Staging"
Add-Content $Logfile "`r`nList of files being Consolidated in this Batch : "
##Move-item from source to Staging
get-childitem -Path $Source -Filter *.csv | move-item -destination $Staging
Get-ChildItem -Path $Staging -Filter *.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile

Add-Content $Logfile "`r`n#### Step 3: Creating new Consolidated files ####"

$flist=Get-ChildItem -Path $Staging -Filter *.csv
$fl=$flist.Length
if($fl -gt 0)
{
    Add-Content $Logfile "Creating a New Consolidate file `"$DestFile`" in the path: $Dest"
}
else
{
    Add-Content $Logfile "No files to consolidate"
    $opfile= New-Item -Path $Dest -Name $DestFile -ItemType "file" -Value ""
}

[int]$countoffiles = 0
$files=$flist
$encoding = [System.Text.Encoding]::UTF8
$w = New-Object System.IO.StreamWriter("$Dest\$DestFile", $true, $encoding)
$skiprow = $false
[int]$lw = 0
foreach ($file in $files)
{
    try
    {
        $fname=$file.fullname
        Add-Content $Logfile "`r`nStarted Appending - $fname"
        $r = New-Object System.IO.StreamReader($file.fullname, $encoding)
        [int]$LinesInFile = -1
        while (($line = $r.ReadLine()) -ne $null) 
        {
            $LinesInFile++
            if (!$skiprow)
            {
               if($lw -eq 0)
                {
                    $lw = $lw+1
                    #$w.WriteLine('File Name'+�,�+$line)
                    $w.WriteLine($line)
                }
                else
                {
                    #$w.WriteLine($fname +�,�+$line)
                    $w.WriteLine($line)
                }
            }
            $skiprow = $false
        }
        $r.Close()
        $r.Dispose()
        $skiprow = $true
        Add-Content $Logfile "Appending Completed $LinesInFile lines from $fname"
        Add-Content $Logfile "Started moving file - $fname from staging to archive"
        Remove-Item $fname
        Add-Content $Logfile "moved file Completed - $fname from staging to archive"        
        $countoffiles++
    }
    catch
    {
        Write-Host 'Caught  '  + $_.Exception.GetType().FullName
        Write-Host 'Caught  '  + $_.Exception.Message
        Add-Content $Logfile '`r`n Exception caught in file'+ $fname
        Add-Content $Logfile $_.Exception.GetType().FullName
        Add-Content $Logfile $_.Exception.Message
    }
}
$w.close()
$w.Dispose()


Add-Content $Logfile "`r`nCount of Extract Files that were appended successfully is $countoffiles"


## Add file names to the log
#Get-ChildItem -Path $Source -Filter extract-*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile
#Get-ChildItem -Path $Staging -Filter extract-*.csv | Select-Object -ExpandProperty FullName | Import-Csv | Export-Csv $Dest\$DestFile -NoTypeInformation -Append

Add-Content $Logfile "`r`n#### Step 4: Count of Rows ####"
Add-Content $Logfile "Count of rows in the Consolidated file : "
#Get-Content $Dest\$DestFile | Measure-Object -Line | Select-Object -Expand Lines | Add-Content $Logfile

$countfname="$Dest\$DestFile"
[int]$countLinesInFile = -1
$countreader = New-Object IO.StreamReader $countfname
while($countreader.ReadLine() -ne $null){ $countLinesInFile++ }  
$countreader.Close()
write-host $countLinesInFile
Add-Content $Logfile "Number of Lines without Header in Consolidated File are $countLinesInFile"

Add-Content $Logfile "`r`n#### Step 5: Archiving all the Extract files ####"
Add-Content $Logfile "Archiving all the above Extract*.csv(Step 2) to the path: $Archive"

##Move-item from source to Archive
#get-childitem -Path $Staging -Filter extract-*.csv | move-item -destination $Archive

$TimeStampEndTimeformatted = Get-Date -UFormat "%m-%d-%Y %T"
Add-Content $Logfile "`r`n`r`nConsolidation Script ended at $TimeStampEndTimeformatted"

### script to send email added- april 21st
$From = "srilekha.anumula@optum.com"
$To = "srilekha.anumula@optum.com"
$Cc = "srilekha.anumula@optum.com"
$Attachment = $Logfile
$Subject = "Success-ODx Consolidation"
$Body = "<div>Number of lines in cosolidated file are $countLinesInFile </div><br><br>"
$Body+="<div>Number of files consolidated $countoffiles </div>"
$SMTPServer = "mail25.uhc.com"
Send-MailMessage -From $From -to $To -Cc $Cc -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer  -Attachments $Attachment
### script to send email added- april 21st
}
catch
{
    ### script to send email added- april 21st
    $From = "srilekha.anumula@optum.com"
    $To = "srilekha.anumula@optum.com"
    $Cc = "srilekha.anumula@optum.com"
    $Attachment = $Logfile
    $Subject = "Error-ODx Consolidation"
    $Body = "<div>"+$_.Exception.Message+"</div><br><br>"
    $Body+="<div>Encountered error while consolidating files, attached log for your reference ! </div>"
    $SMTPServer = "mail25.uhc.com"
    Send-MailMessage -From $From -to $To -Cc $Cc -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer  -Attachments $Attachment
    ### script to send email added- april 21st
    Add-Content $Logfile "Exception Caught  $_.Exception.GetType().FullName"
}
