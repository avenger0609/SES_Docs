﻿try {

    $csvpath = "C:\Users\asrilekh\Documents\MyJabberFiles\sali1045@corpimsvcs.com\FilesReceived\Logs"
    $TimeStamp = get-date -f yyyyMMddhhmmss
    $csvfile= New-Item -Path $csvpath -Name "WOMUSCases-$TimeStamp.txt" -ItemType "file" -Value ""

    $excel = New-Object -ComObject excel.application
    $excel.visible = $False
    $workbook = $excel.Workbooks.Add()
    $diskSpacewksht= $workbook.Worksheets.Item(1)
    $diskSpacewksht.Name = "Data Set"
    $row_counter=0
    $col_counter=0
    $r = Invoke-WebRequest -Uri 'https://www.worldometers.info/coronavirus/country/us/'     
    write-host "test"   
    #$lines=@(100000)
    #$li=0
    
    
    $table_id = $r.parsedhtml.getElementById("usa_table_countries_yesterday")    
    #[System.Windows.Forms.SendKeys]::SendWait("{TAB}{ENTER}")
    write-host "test"
    $hdr_cells = $table_id.children
    write-host "test"
    forEach($hci in $hdr_cells){
        if($hci.tagName -eq "thead"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "th"){
                            $s=$s+($cell.innerHTML).replace('<br />','').replace('<br>',' ')+"|"
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter
                            $diskSpacewksht.Cells.Item($row_counter,$col_counter)=$cell.innerText                
                        }
                    }
                    Add-Content $csvfile "$s"
                    write-Host $s
                    #$lines[$li]=$s
                    #$li=$li+1
                }
            }
        }
        if($hci.tagName -eq "tbody"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "td"){
                            write-Host "test"
                            $s=$s+($cell.innerText)+"|"
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter
                            $diskSpacewksht.Cells.Item($row_counter,$col_counter)=$cell.innerText                
                        }
                    }
                    Add-Content $csvfile "$s"
                    write-Host $s
                    #$lines[$li]=$s
                    #$li=$li+1
                }
            }
        }
    }
    
    
    $excel.DisplayAlerts = 'False'
    $ext=".xlsx"
    $path="C:\users\asrilekh\documents\Us_coronacases$ext"
    $workbook.SaveAs($path) 
    $workbook.Close
    $excel.DisplayAlerts = 'False'
    $excel.Quit()
}
catch
{
    #write-Host "lines="+$lines
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
}
