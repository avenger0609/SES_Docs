﻿$smtpServer = "mail25.uhc.com"
$smtpFrom = "srilekha.anumula@optum.com"
$smtpTo ="srilekha.anumula@optum.com"
$messageSubject = "subject"
$messageBody = "content"
$body = "Dear <b><font color=red>$to</b></font> <br>"  
$body += "We are testing <b>HTML</b> email <br>"  
$body += "Click <a href=http://www.google.com>here</a> to open google <br>" 
 
$smtp = New-Object Net.Mail.SmtpClient($smtpServer)
$smtp.Send($smtpFrom,$smtpTo,$messagesubject,$body)