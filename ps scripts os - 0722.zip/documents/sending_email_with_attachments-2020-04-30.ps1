﻿$From = "srilekha.anumula@optum.com"
$To = "srilekha.anumula@optum.com"
$Cc = "srilekha.anumula@optum.com"
$Attachment = "C:\users\asrilekh\documents\imp.pdf","C:\users\asrilekh\documents\imp.pdf"
$Subject = "attachment-test"
$Body = "<h2>PFA</h2><br><br>"
$SMTPServer = "mail25.uhc.com"

Send-MailMessage -From $From -to $To -Cc $Cc -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer  -Attachments $Attachment