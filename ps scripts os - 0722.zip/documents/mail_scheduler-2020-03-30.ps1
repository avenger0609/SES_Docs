﻿$smtpServer = "mail25.uhc.com"
$smtpFrom = "srilekha.anumula@optum.com"
$smtpTo ="srilekha.anumula@optum.com"
$messageSubject = "task scheduler"
$messageBody =  "Content"
$smtp = New-Object Net.Mail.SmtpClient($smtpServer)
$smtp.Send($smtpFrom,$smtpTo,$messagesubject,$messagebody)