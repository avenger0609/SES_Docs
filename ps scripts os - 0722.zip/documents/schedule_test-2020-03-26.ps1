﻿$Source = "C:\Users\asrilekh\Documents\powershell-test"

#Get-ChildItem -Path $Source -Filter *.csv | Select-Object -ExpandProperty FullName | Import-Csv | Measure-Object | Select-Object -expand count
 
#Get-ChildItem -Path $Source -Filter *.csv | Select-Object -ExpandProperty FullName | Import-Csv | Measure-Object -Count

$flist=Get-ChildItem -Path $Source -Filter *.csv
ForEach ($File in $flist)
{
    $fname=$File.FullName
    write-Host $fname
    [int]$LinesInFile = 0
    $reader = New-Object IO.StreamReader $fname
    while($reader.ReadLine() -ne $null){ $LinesInFile++ }
    write-Host $LinesInFile
}