﻿Function Convert-NumberToA1 { 
  <# 
  .SYNOPSIS 
  This converts any integer into A1 format in Excel. 
  .DESCRIPTION 
  See synopsis. 
  .PARAMETER number 
  Any number between 1 and 2147483647 --- range of column numbers
  #> 
   
  Param([parameter(Mandatory=$true)] 
        [int]$number) 
 
  $a1Value = $null 
  While ($number -gt 0) { 
    $multiplier = [int][system.math]::Floor(($number / 26)) 
    $charNumber = $number - ($multiplier * 26) 
    If ($charNumber -eq 0) { $multiplier-- ; $charNumber = 26 } 
    $a1Value = [char]($charNumber + 64) + $a1Value 
    $number = $multiplier 
  }
  
  Return $a1Value 
}

$existing_file='c:\users\asrilekh\documents\Format_test1.xlsx'
$file_frm_which_data_2b_appended='c:\users\asrilekh\documents\Format_test2.xlsx'

$excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}

## existing file processing

$workbook = $excel.Workbooks.Open($existing_file) # Open the file
$existing_sheet = $workbook.Sheets.Item(1)

## existing file processing

# processing file from which data to be appended

$workbook_new=$excel.Workbooks.Open($file_frm_which_data_2b_appended)
$new_sheet=$workbook_new.Sheets.Item(1)

# processing file from which data to be appended

# existing sheet values range

$existingsheetRange = $existing_sheet.UsedRange
$existingRowCount = $existingsheetRange.Rows.Count
$existingColumnCount = $existingsheetRange.Columns.Count
$existingcol_letter_last=Convert-NumberToA1($existingColumnCount)

# existing sheet values range

# file from which data needs to be appended

$WorksheetRange = $new_sheet.UsedRange
$RowCount = $WorksheetRange.Rows.Count
$ColumnCount = $WorksheetRange.Columns.Count
$col_letter_last=Convert-NumberToA1($ColumnCount)

# file from which data needs to be appended


$copy_row_count=$existingRowCount-($RowCount-1)+1

[void]$existing_sheet.Range(“A$copy_row_count :$col_letter_last$existingRowCount").Copy()
[void]$existing_sheet.Cells.Item($existingRowCount+1,1).PasteSpecial()

        
[void]$new_sheet.Range(“A2:$col_letter_last$RowCount").Copy()
[void]$existing_sheet.Cells.Item($existingRowCount+1,1).PasteSpecial(-4163)

$workbook.Close($true) # Close workbook and save changes
$workbook_new.Close($false) # Close workbook and save changes


$excel.quit() # Quit Excel
$ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM