﻿function Convert-XlsmToCsv {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false
        }
    }
    process {
        $root = Split-Path -Path $Path
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path)
        $workbook = $excel.Workbooks.Open($Path)
        foreach ($worksheet in $workbook.Worksheets) {
            write-host $worksheet.Name
            if($worksheet.Name -like "*YTD Actuals"){
                $name1="${filename}_$($worksheet.Name)"
                $name = Join-Path -Path $root -ChildPath "$($name1.Split('_')[0]).csv"
                try {
                    $worksheet.SaveAs($name, 6)
                    
                    
                } catch {
                    Write-Error -Message "Failed to save csv! Path: '$name'. $PSItem"
                }

                ## skipping rows
                $import = get-content $name
                $name_2 = Join-Path -Path $root -ChildPath "$($name1.Split('_')[0])_1.csv"
                #remove-item -path $name -force
                $import | Select-Object -Skip 6 | Set-Content $name_2
                ## skipping rows
                $name2 = $name1.Split('_')[0].Replace("--","}")
                $name3="$([array]::indexof([cultureinfo]::CurrentCulture.DateTimeFormat.MonthNames,$name2.Split('}')[2]) + 1)".PadLeft(2,'0') # month in number
                $name4=get-date -Format yyyy ## current year
                $name5="01"## first day
                $name6="$name5-$name3-$name4".ToString() ## first day of month
                Write-host "$name6"
                Write-host "--$($name2.Split('}')[1])--"
                Write-host "$($name2.Split('}')[0])--$($name2.Split('}')[1])--$name6.csv"
                $name7="$name5$name3$name4".ToString()
                $newfile_name=Join-Path -Path $root -ChildPath "$($name2.Split('}')[0])--$($name2.Split('}')[1])--$name7.csv"
                #Wite-host "($newfile_name)1"
                #remove-item -path $name -force
                #$import | Select-Object -Skip 6 | Set-Content $name2
                ##### adding new column
                $newcolumnobj =  [ordered]@{}
                #input data into a hash table so that we can more easily reference the `.values` as an object to be inserted in the CSV
                $newcolumnobj.add("volume name", $currenttime)

                #enumerate $deltas [this will be the object that contains the volume information `$volumedeltas`)
                #  add just the new deltas to the newcolumn object
                foreach ($item in $deltas){ 
                    $newcolumnobj.add($item.volume,$item.delta)
                }

                $targetdeltacsv=$name_2
                $originalcsv = @(import-csv $targetdeltacsv)
                $obj = @()
                #thanks to pscookiemonster in #powershell on freenode
                for($i=0; $i -lt $originalcsv.count; $i++){
                    #$originalcsv[$i] | Select-Object *, @{l="$currenttime"; e={$name6}}
                    #$obj += $originalcsv[$i] | Select-Object *, @{l="$currenttime"; e={$name6}}
                    $originalcsv[$i] | Select-Object @{l="New_column"; e={$name6}},*
                    $obj += $originalcsv[$i] | Select-Object  @{l="New_column"; e={$name6}},*
                }

                $obj|Export-Csv "$newfile_name" -NoTypeInformation
                ##### adding new column
                #remove-item -path $name -force
                remove-item -path $name_2 -force
            }
            else{
                write-host "else"
            }

        }
    }
    end {
        $excel.Quit()
        $null = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
    }
}
Get-ChildItem -Path C:\Users\asrilekh\Documents\Domo -Filter *.xlsm |Convert-XlsmToCsv