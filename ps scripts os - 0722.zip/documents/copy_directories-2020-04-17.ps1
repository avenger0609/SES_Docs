﻿$src= '\\apsep02521\d$\DOMO'
$Dest='c:\users\asrilekh\downloads'
Copy-Item -Path $src -Recurse -Destination $Dest -Container