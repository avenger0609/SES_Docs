﻿function Convert-XlsmToCsv {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        
    }
    process {
        
        $Excel   = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $root = Split-Path -Path $Path
        
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path)
        $workbook = $excel.Workbooks.Open($Path)
        $name = Join-Path -Path $root -ChildPath "$filename.xls" # saving as xls file
        $test = Join-Path -Path $root -ChildPath "test.xls" # saving as xls file
        $wname="" # to store name of worksheet

        # hiding unwanted sheets

        foreach ($worksheet in $workbook.Worksheets) {
            if($worksheet.Name -like "*YTD Actuals"){
                 $wname=$worksheet.Name
                 $workbook.worksheets.item($worksheet.Name).Visible = $true
            } 
            else{
                $workbook.worksheets.item($worksheet.Name).Visible = $false
            } 
        }                         
        $workbook.SaveAs($name)
        $workbook.Close()                   
        $Excel.Quit()
        $null = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Excel)

        #hiding unwanted sheets

        # deleting top 5 rows

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $sheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the first row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the second row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the third row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the fourth row
        [void]$sheet.Cells.Item(1, 1).EntireRow.Delete() # Delete the fifth row
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        # deleting top 5 rows

        # adding file name to first column

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        $ColumnCount = $WorksheetRange.Columns.Count
        
        [void]$workSheet.Range(“B2:B$RowCount”).Copy()
        [void]$workSheet.Range(“A2:A$RowCount”).Select()
        [void]$workSheet.Range(“A2:A$RowCount”).PasteSpecial()    


        Write-Host "RowCount:" $RowCount
        Write-Host "ColumnCount" $ColumnCount
        $workSheet.cells.item(2,1).value() = "FileName"
        for($i=3; $i -lt $WorksheetRange.Rows.Count; $i++){
            $workSheet.cells.item($i,1).value() = "$filename"
        }
        [void]$workSheet.Range(“A2:A$RowCount”).EntireColumn.AutoFit() ## adjusting column width        
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        
        # adding file name to first column           

        
    }
    end {
        
        
    }
}
Get-ChildItem -Path C:\Users\asrilekh\Documents\Domo\test2 -Filter *.xlsm |Convert-XlsmToCsv
