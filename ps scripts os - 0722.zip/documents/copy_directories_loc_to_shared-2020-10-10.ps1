﻿$src= 'C:\Users\asrilekh\Documents'
$Dest='H:\asrilekh'
Copy-Item -Path $src -Recurse -Destination $Dest -Container  -Verbose