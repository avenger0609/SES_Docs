﻿## deriving respective values ###
# to get previous month name
#(Get-Culture).DateTimeFormat.GetMonthName((Get-Date).AddMonths(-1).Month).ToLower()
# get month number of previous month
#(get-date).Month-1;
## to format month to two digits
$prev_mon_num=(get-date).Month-1;
if ($prev_mon_num -eq 0){
    $prev_mon_num=12
}
if($prev_mon_num -lt 10){
 $prev_mon_num="0$prev_mon_num"
 } 
 write-Host $prev_mon_num
 ## to format month to two digits
 if($prev_mon_num -eq 12){
 $yr=(get-date).Year-1
 }
 else{
 $yr=(get-date).Year
 }
 
$yr=$yr.ToString().Substring(2,2)
$prev_mon_yr="$yr$prev_mon_num"
write-Host $prev_mon_yr
$mon_name=(Get-Culture).DateTimeFormat.GetMonthName((Get-Date).AddMonths(0).Month)
write-Host $mon_name
write-Host $prev_mon_yr

## deriving respective values ###


$src_fname="C:\Users\asrilekh\Documents\ITBM_Montly_Refresh\"+$mon_name+"\"+$prev_mon_yr+"_OU_Dimension.xlsx"


Function Convert-NumberToA1 { 
  <# 
  .SYNOPSIS 
  This converts any integer into A1 format in Excel. 
  .DESCRIPTION 
  See synopsis. 
  .PARAMETER number 
  Any number between 1 and 2147483647 --- range of column numbers
  #> 
   
  Param([parameter(Mandatory=$true)] 
        [int]$number) 
 
  $a1Value = $null 
  While ($number -gt 0) { 
    $multiplier = [int][system.math]::Floor(($number / 26)) 
    $charNumber = $number - ($multiplier * 26) 
    If ($charNumber -eq 0) { $multiplier-- ; $charNumber = 26 } 
    $a1Value = [char]($charNumber + 64) + $a1Value 
    $number = $multiplier 
  }
  
  Return $a1Value 
}


$excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
$workbook = $excel.Workbooks.Open($src_fname) # Open the file
$workSheet = $workbook.Sheets.Item('Step1_copyOverBlankLevels') # Activate the required worksheet
$worksheet1= $workbook.Sheets.Item($prev_mon_yr+'_OU_Dimension')
$WorksheetRange = $workSheet.UsedRange
$RowCount = $WorksheetRange.Rows.Count
$ColumnCount = $WorksheetRange.Columns.Count
$col_letter_last=Convert-NumberToA1($ColumnCount)        
[void]$workSheet.Range(“A1:$col_letter_last$RowCount").Copy()
#[void]$worksheet1.Range(“A1:$col_letter_last$RowCount").Select()
[void]$worksheet1.Range(“A1:$col_letter_last$RowCount").PasteSpecial(-4163)
$workbook.Close($true)