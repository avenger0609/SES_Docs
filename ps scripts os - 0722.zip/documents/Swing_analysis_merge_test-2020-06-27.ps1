﻿$tdydt=(Get-Date).ToString('yyyy-MM-dd')
write-host $tdydt

$folder_name='C:\Users\asrilekh\Desktop\work\swing analysis\using odbc\'+(Get-Date).ToString('MMMM')+"-"+(Get-Date).ToString('yyyy')
write-host $folder_name

$filter_format="*_"+$tdydt +".xlsx"
#get-childitem -Path $folder_name -Filter $filter_format 

$ExcelObject=New-Object -ComObject excel.application
$ExcelObject.visible=$false
$ExcelFiles=get-childitem -Path $folder_name -Filter $filter_format | sort ModificationTime

$Workbook=$ExcelObject.Workbooks.add()
$Worksheet=$Workbook.Sheets.Item("Sheet1")

foreach($ExcelFile in $ExcelFiles){
 
$Everyexcel=$ExcelObject.Workbooks.Open($ExcelFile.FullName)
$Everysheet=$Everyexcel.sheets.item(1)
$Everysheet.Copy($Worksheet)
$Everyexcel.Close($false)
 
}
$Workbook.SaveAs($folder_name+"\CB_Swing_Analysis _"+$tdydt+".xlsx")
$ExcelObject.Quit()