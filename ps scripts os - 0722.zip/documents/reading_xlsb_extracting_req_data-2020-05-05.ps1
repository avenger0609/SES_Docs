﻿$xlsbfile = 'C:\Users\asrilekh\Documents\ps_test_with_sheets.xlsb'

$xlsxfile = 'C:\Users\asrilekh\Documents\ps_test_with_sheets.xlsx'

$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$wb = $xlApp.Workbooks.Open($xlsbfile)
$sh1 = $wb.sheets.item('Sheet1')
$sh1.Select()
write-host $sh1.name
$RowCnt = $sh1.UsedRange.Rows.Count
write-host $RowCnt
for($i=2; $i -le $RowCnt; $i++){
    $cv=$sh1.cells.item($i,1).value()
    write-host $cv
    if($cv -eq 'a2')
    {
        $junk=1
    }
    else
    {
        $currRow = $sh1.cells.item($i,1).EntireRow
        [void]$currRow.Delete()
        write-host 'deleted'
    }
}

#$sh1.ShowAllData()
$wb.SaveAs($xlsxfile, [Microsoft.Office.Interop.Excel.xlFileFormat]::xlOpenXMLWorkbook)
$wb.Close(0)
$xlApp.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)