﻿##########################################################
# This file will transfer the files from the Sharepoint to Local Desktop
# Move them to the Archive folder on the Sharepoint
# Convert them from xlsm to xls
# Add a new column in the first position with the filename
# Create log file on the local system
# Delete the top 8 unwated rows
#
##########################################################

# set the parameters
# TimeStamp used in the log creation, Dest should be the destination where files should be transfered
# Url is the source path from where the file should be exported
# Archive is the path where files will be moved after being copied to destination
# Convert-NumberToA1 function to convert given integer to excel A1 Format
# Convert-XlsmToXls function to convert xlsm file to xls file as per requirement
#filename whcih holds individual file name without extension from Dest folder
#src_fname which holds file name with extension from dest folder
# name which holds the name of xls file generated
# test file is the file used to hold content of required sheet without any formats/formulas
# wname holds the required sheet name

$TimeStamp = get-date -f yyyyMMddhhmm
$Dest = "C:\Users\sali1045\Documents\Domo\Actuals\"
$Url = '\\it600.optum.com\sites\OAS\OptumHealth%20Finance%20Reporting\Actuals'
$Archive='\\it600.optum.com\sites\OAS\OptumHealth%20Finance%20Reporting\Archive\Actuals'
$filename="" 
$src_fname=""
$name = ""
$test = ""
$wname="Current Month Actuals"
$rowno=5 # no of rows to be deleted from Actuals files
$file_exist_src=0 # if any files exist in source folder

# Create the Logfile in the Destination and write the first line to initiate the log transfer
$Logfile= New-Item -Path $Dest -Name "LogTransfer-$TimeStamp.log" -ItemType "file" -Value "Script started at $TimeStamp"
Add-Content $Logfile ""

Write-Host "Started the script, please wait till you receive script complete message"

# Create the For loop to copy the files from Source to Destination and also Archive them
try
{
    # Get the filenames from Source path which is Url
    $Source = Get-ChildItem -Path $Url -File -ea Stop
    ForEach ($File in $Source)
    {
        $file_exist_src=1
        Add-Content $Logfile "Transfer of files Started at $TimeStamp"
        # Copy files from Source to Destination
        Copy-Item -Path $File.FullName -Destination $Dest -Force -ea Stop
        
        # Add the file name transfering to the log
        $Timestamp_log = get-date -f yyyyMMddhhmm
        Add-Content $Logfile "Transfering File -$File at-$Timestamp_log"
        
        # Copy the file to the Archive and them remove it from Destination   
        Copy-Item -Path $File.FullName -Destination $Archive -Force -ea Stop
        remove-item -path $File.FullName -force -ea Stop
        Add-Content $Logfile "Transfer of files Completed at $TimeStamp"
    }
    if($file_exist_src -eq 0)
    {  
        Add-Content $Logfile "No files to transfer"  
    }
}
catch
{    
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
    Add-Content $Logfile "Exception Caught  $_.Exception.GetType().FullName"
}
# Convert the columns from text to number like AA to 27

Function Convert-NumberToA1 { 
  <# 
  .SYNOPSIS 
  This converts any integer into A1 format in Excel. 
  .DESCRIPTION 
  See synopsis. 
  .PARAMETER number 
  Any number between 1 and 2147483647 --- range of column numbers
  #> 
   
  Param([parameter(Mandatory=$true)] 
        [int]$number) 
  try
  {
    $a1Value = $null 
    While ($number -gt 0) { 
        $multiplier = [int][system.math]::Floor(($number / 26))
        $charNumber = $number - ($multiplier * 26) 
        If ($charNumber -eq 0) { $multiplier-- ; $charNumber = 26 } 
        $a1Value = [char]($charNumber + 64) + $a1Value 
        $number = $multiplier 
    }
    Add-Content $Logfile "Inside the convert number function"
    Return $a1Value
  } 
  catch
  {
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
    Add-Content $Logfile "Exception Caught  $_.Exception.GetType().FullName"
  }
}

Function Convert-XlsmToXls {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        
    }
    process {
        
        try
        {
            
            # Split the entire path into two variables, root will contain only path and filename will have the filename without Extension
            $root = Split-Path -Path $Path -ea Stop
            $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path)  ## get's file name            
            $src_fname=Join-Path -Path $root -ChildPath "$filename.xlsm" -ea Stop ## source file name with extension
            $name = Join-Path -Path $root -ChildPath "$filename.xlsx" -ea Stop # saving as output xls file        
            

            Add-Content $Logfile "Start of Convert XLSM to XLS function for $src_fname at $TimeStamp"  

            Add-Content $Logfile "Started copying $wname data from $src_fname to new file $name at $TimeStamp"
            
            # copying sheet data to new file (xls file)  deleting top 5 rows
            
            $excel = New-Object -ComObject Excel.Application -Property @{
                Visible       = $false
                DisplayAlerts = $false}
            $workbook = $excel.Workbooks.Open($src_fname) # Open the file
            $workbook_new=$excel.Workbooks.Add()
            $workbook_new.worksheets.item("Sheet2").Delete() # Delete sheet2
            $workbook_new.worksheets.item("Sheet3").Delete() # Delete Sheet3

            $Sheet_new = $Workbook_new.Worksheets.Item(1)
            $Sheet_new.name=$wname
            $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
            $worksheet.autofiltermode=$false
            $WorksheetRange = $workSheet.UsedRange
            
            $RowCount = $WorksheetRange.Rows.Count
            $ColumnCount = $WorksheetRange.Columns.Count
            $col_letter_last=Convert-NumberToA1($ColumnCount+10)
            
            #Write-Host $RowCount
            #Write-Host $ColumnCount
            [void]$workSheet.Range(“A1:$col_letter_last$RowCount").Copy()
            [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").Select()
            [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").PasteSpecial(-4163)
            #Write-Host $Sheet_new.UsedRange.Rows.Count
            #Write-Host $Sheet_new.UsedRange.Columns.Count
            for($di=1; $di -le $rowno; $di++){
                [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() 
            } 
                        
            $workbook.Close($true) # Close workbook and save changes
            $workbook_new.SaveAs($name)
            $excel.quit() # Quit Excel
            $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

            Add-Content $Logfile "Completed copying $wname data from $src_fname to new file $name at $TimeStamp"
            
            
            # End copying sheet data to new file (xls file)  deleting top 5 rows

        
        Add-Content $Logfile "Started adding file name to first column in  $wname in $name at $TimeStamp"

        # start - insert new column

        $xl=New-Object -ComObject Excel.Application
        $wb=$xl.workbooks.open($name)
        $ws = $wb.worksheets.Item(1)
        $range = $ws.Range("A:A").EntireColumn
        $range.Insert($xlShiftToRight)
        $wb.Save()
        $xl.Quit()
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($xl) # Release COM

        # end - insert new column

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange         
        $workSheet.cells.item(1,1).value() = "FileName"
        for($i=2; $i -le $WorksheetRange.Rows.Count; $i++){
            $workSheet.cells.item($i,1).value() = "$filename"
        }
        [void]$workSheet.Range(“A2:A$RowCount”).EntireColumn.AutoFit() ## adjusting column width        
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        Add-Content $Logfile "Completed adding file name to first column in  $wname in $name at $TimeStamp"
		Write-Host "Script completed, please check the log for any details"
        # adding file name to first column

        }
        catch
        {
            Write-Host "Exception Caught, please check the below details or the log file for more information"
            Write-Host 'Caught  '  + $_.Exception.GetType().FullName
            Add-Content $Logfile "Exception Caught  $_.Exception.GetType().FullName"
        }

        
    }
    end {
        
        
    }
}

if($file_exist_src -ne 0)
{ 
    Get-ChildItem -Path $Dest -Filter *.xlsm |Convert-XlsmToXls
}


Add-Content $Logfile "Script ended at $TimeStamp"