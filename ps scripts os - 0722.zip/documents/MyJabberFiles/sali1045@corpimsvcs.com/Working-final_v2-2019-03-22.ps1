﻿# set the parameters
# TimeStamp used in the log creation, Dest should be the destination where files should be transfered
# Url is the source path from where the file should be exported
# Archive is the path where files will be moved after being copied to destination
# Convert-NumberToA1 function to convert given integer to excel A1 Format
# Convert-XlsmToXls function to convert xlsm file to xls file as per requirement
#filename whcih holds individual file name without extension from Dest folder
#src_fname which holds file name with extension from dest folder
# name which holds the name of xls file generated
# test file is the file used to hold content of required sheet without any formats/formulas
# wname holds the required sheet name

$TimeStamp = get-date -f yyyyMMddhhmm
$Dest = "C:\Users\sali1045\Documents\Domo\"
$Url = '\\it600.optum.com\sites\OAS\OptumHealth%20Finance%20Reporting\Forecast'
$Archive='\\it600.optum.com\sites\OAS\OptumHealth%20Finance%20Reporting\Archive\Forecast'
$filename="" 
$src_fname=""
$name = ""
$test = ""
$wname=""
$rowno=8 # no of rows to be deleted from
$req_sname="Roll-Up (Project)"

# Get the filenames from Source path which is Url
$Source = Get-ChildItem -Path $Url -File

# Create the Logfile in the Destination and write the first line to initiate the log transfer
$Logfile= New-Item -Path $Dest -Name "LogTransfer-$TimeStamp.log" -ItemType "file" -Value "Transfer of files started at $TimeStamp"
Add-Content $Logfile ""

# Create the For loop to copy the files from Source to Destination and also Archive them
ForEach ($File in $Source)
{
    # Copy files from Source to Destination
    Copy-Item -Path $File.FullName -Destination $Dest -Force
    
    # Add the file name transfering to the log
    $Timestamp_log = get-date -f yyyyMMddhhmm
    Add-Content $Logfile "Transfering File -$File at-$Timestamp_log"
     
    # Copy the file to the Archive and them remove it from Destination   
    Copy-Item -Path $File.FullName -Destination $Archive -Force
    remove-item -path $File.FullName -force
}

Add-Content $Logfile "Transfer of files Completed at $TimeStamp"

################################
## New Code Added
################################
Function Convert-NumberToA1 { 
  <# 
  .SYNOPSIS 
  This converts any integer into A1 format in Excel. 
  .DESCRIPTION 
  See synopsis. 
  .PARAMETER number 
  Any number between 1 and 2147483647 --- range of column numbers
  #> 
   
  Param([parameter(Mandatory=$true)] 
        [int]$number) 
 
  $a1Value = $null 
  While ($number -gt 0) { 
    $multiplier = [int][system.math]::Floor(($number / 26)) 
    $charNumber = $number - ($multiplier * 26) 
    If ($charNumber -eq 0) { $multiplier-- ; $charNumber = 26 } 
    $a1Value = [char]($charNumber + 64) + $a1Value 
    $number = $multiplier 
  }
  Add-Content $Logfile "Inside the convert number function, no of columns are $a1Value"
  Return $a1Value 
}

Function Convert-XlsmToXls {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        
    }
    process {
        
        
        $Excel   = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}

        # Split the entire path into two variables, root will contain only path and filename will have the filename without Extension
        $root = Split-Path -Path $Path
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path) ## get's file name

        #Open the workbook and go
        $workbook = $excel.Workbooks.Open($Path)
        $src_fname=Join-Path -Path $root -ChildPath "$filename.xlsm" ## source file name with extension
        $name = Join-Path -Path $root -ChildPath "$filename.xls" # saving as output xls file        
        $wname="" # to store name of worksheet

        Add-Content $Logfile "Start of Convert XLSM to XLS function for $src_fname at $TimeStamp"

        # Start - getting name of required sheet

        foreach ($worksheet in $workbook.Worksheets) {
            if($worksheet.Name -like $req_sname){
                 $wname=$worksheet.Name                                  
            } 
            
        } 
        
        Add-Content $Logfile "Collected required worksheet $wname from $src_fname at $TimeStamp"                       
        
        $workbook.Close()                   
        $Excel.Quit()
        $null = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Excel)

        # End - getting name of required sheet

        Add-Content $Logfile "Started copying $wname data from $src_fname to new file $name at $TimeStamp"
        
        # copying sheet data to new file (xls file)  deleting top 5 rows
        
        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($src_fname) # Open the file
        $workbook_new=$excel.Workbooks.Add()
        $workbook_new.worksheets.item("Sheet2").Delete() # Delete sheet2
        $workbook_new.worksheets.item("Sheet3").Delete() # Delete Sheet3

        $Sheet_new = $Workbook_new.Worksheets.Item(1)
        $Sheet_new.name=$wname
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        $ColumnCount = $WorksheetRange.Columns.Count
        $col_letter_last=Convert-NumberToA1($ColumnCount)
        
        [void]$workSheet.Range(“A1:$col_letter_last$RowCount").Copy()
        [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").Select()
        [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").PasteSpecial(-4163)

        for($di=1; $di -le $rowno; $di++){
            [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() 
        } 
                    
        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.SaveAs($name)
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        Add-Content $Logfile "Completed copying $wname data from $src_fname to new file $name at $TimeStamp"
        
        
        # End copying sheet data to new file (xls file)  deleting top 5 rows

              

        Add-Content $Logfile "Started adding file name to first column in  $wname in $name at $TimeStamp"

        # start - insert new column

        $xl=New-Object -ComObject Excel.Application
        $wb=$xl.workbooks.open($name)
        $ws = $wb.worksheets.Item(1)
        $range = $ws.Range("A:A").EntireColumn
        $range.Insert($xlShiftToRight)
        $wb.Save()
        $xl.Quit()
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($xl) # Release COM

        # end - insert new column

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange         
        $workSheet.cells.item(1,1).value() = "FileName"
        for($i=2; $i -le $WorksheetRange.Rows.Count; $i++){
            $workSheet.cells.item($i,1).value() = "$filename"
        }
        [void]$workSheet.Range(“A2:A$RowCount”).EntireColumn.AutoFit() ## adjusting column width        
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        Add-Content $Logfile "Completed adding file name to first column in  $wname in $name at $TimeStamp"

        # adding file name to first column



        
    }
    end {
        
        
    }
}


Get-ChildItem -Path $Dest -Filter *.xlsm |Convert-XlsmToXls
