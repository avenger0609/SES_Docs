﻿$csvpath = "C:\users\asrilekh\documents"    
$TimeStamp = get-date -f yyyyMMddhhmmss
$FileName= "County_Data_$TimeStamp.csv"
$csvfile= New-Item -Path $csvpath -Name $FileName -ItemType "file" -Value ""

$fromurl='https://github.optum.com/pages/mmegeria/graphsamples/COPDMap.html'
$webclient = New-Object System.Net.WebClient
$webclient.UseDefaultCredentials = $true
$s=$webclient.DownloadString($fromurl)

$script_start=$s.IndexOf('if (document.getElementById("f37cc26b-7bbe-4139-8192-80ad7af5d5b8")) {',0)
write-host $script_start
$script_end=$s.IndexOf('</script',$script_start)
write-host $script_end
$script=$s.Substring($script_start,($script_end+6-($script_start)))
#write-host $script

###### getting flips

$flips_pre_start=$script.IndexOf('<br>fips=%{location}", "locations":',0)
$flips_start=$script.IndexOf('"locations":',$flips_pre_start)
write-host $flips_start
$flips_end=$script.IndexOf(']',$flips_start)
write-host $flips_end
$flips_data=$script.Substring($flips_start+'"locations":'.Length,($flips_end+1)-($flips_start)+'"locations":'.Length)
#write-host $flips_data
write-host $flips_data.split(',').Length
$flips_data_els=$flips_data.split(',')
$flips_data_el_len=$flips_data_els.Length
$flip_counter=0
###### getting flips


$customdata_start=$script.IndexOf('customdata',0)
write-host $customdata_start
$customdata_end=$script.IndexOf(']]',$customdata_start)
write-host $customdata_end
$customdata=$script.Substring($customdata_start+14,($customdata_end+1)-($customdata_start+14))
#write-host $customdata
$el_end=0
$cdelements_count=0
Add-content $csvfile '"COPD Rate","County","State","Member Count","Dx Count","fips"'

while($true)
{
    
    $el_start=$customdata.IndexOf('[',$el_end)
    if ($el_start -eq -1)
    {
        break
    }
    $el_end=$customdata.IndexOf(']',$el_start)
    $el=$customdata.Substring($el_start,($el_end-$el_start)+1)
    $cdelements_count=$cdelements_count+1
    $csvrow_data=""
    write-host $el
    #write-host $el.split(', ')
    foreach( $eli in $el.split(','))
    {
        #write-host $eli.replace('"','').replace('[','').replace(']','').trim()
        #write-host $csvrow_data
        $junk=$eli.replace('"','').replace('[','').replace(']','').trim()
        if ( $junk.length -eq 0)
        {
            continue
        }
        #write-host $eli.replace('"','')
        $csvrow_data=$csvrow_data+'"'+($eli.replace('"','').replace('[','').replace(']','').trim()).ToString()+'",'
        
    }
    if ($flip_counter -lt $flips_data_el_len)
    {
        $csvrow_data=$csvrow_data+(($flips_data_els[$flip_counter]).replace('[','').replace(']','').trim()).ToString()
    }
    else
    {
        $csvrow_data=$csvrow_data+""
    }
    $flip_counter=$flip_counter+1
    write-host $csvrow_data
    Add-Content $csvfile $csvrow_data
 }
 write-host $flip_counter
 write-host($flips_data_els[$flip_counter])
 $flip_counter=$flip_counter+1
 write-host($flips_data_els[$flip_counter])

 write-host $cdelements_count
