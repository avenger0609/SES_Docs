﻿$cfname=$Dest\$DestFile
[int]$LinesInFile = -1
$reader = New-Object IO.StreamReader $fname
while($reader.ReadLine() -ne $null){ $LinesInFile++ }  
$reader.Close()
write-host $LinesInFile
Add-Content $Logfile "Number of Lines in Consolidated File are $LinesInFile"