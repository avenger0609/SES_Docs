﻿$Dest = "C:\Users\asrilekh\Documents\Domo\test.xlsx"
$xl=New-Object -ComObject Excel.Application
$wb=$xl.workbooks.open($Dest)
$ws = $wb.worksheets.Item(1)
$range = $ws.Range("A:A").EntireColumn ### column to before we need to insert columns
$range.Insert($xlShiftToRight) ### shift columns to right
$wb.Save()
$xl.Quit()