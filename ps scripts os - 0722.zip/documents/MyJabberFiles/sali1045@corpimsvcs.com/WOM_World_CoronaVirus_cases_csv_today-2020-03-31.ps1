﻿try {

    #$csvpath = "C:\Users\sali1045\Desktop\Covid-OCIO\Testing_Webscraping"
    $csvpath = "C:\users\asrilekh\documents"
    $TimeStamp = get-date -f yyyyMMddhhmmss
    $Archive='C:\Users\sali1045\Desktop\Covid-OCIO\Testing_Webscraping\Archive'
    $csvfile= New-Item -Path $csvpath -Name "WOM_World_Covid19_cur_day_$TimeStamp.csv" -ItemType "file" -Value ""
    $yesterday_date=(Get-Date).AddDays(0).ToString('MM-dd-yyyy hh:mm:ss')

    #Archiving old files
    #get-childitem -Path $csvpath -Filter WOM_World_Covid19_cur_day_*.csv | move-item -destination $Archive

    $row_counter=0
    $col_counter=0
    #$r = Invoke-WebRequest -Uri 'https://www.worldometers.info/coronavirus/'  
    #write-host $r.GetType()
    ##############################################   
    $webclient = New-Object System.Net.WebClient
    $webclient.UseDefaultCredentials = $true
    $source_code=$webclient.DownloadString('https://www.worldometers.info/coronavirus/')
    #$source_code | Out-File 'c:\users\asrilekh\documents\File.html'
    $r = New-Object -Com "HTMLFile"
    write-Host $r
    write-host $r.GetType()
    $r=$r.IHTMLDocument2_write($source_code)
    write-Host $r
    write-host $r.GetType()
    ##############################################
    $table_id = $r.parsedhtml.getElementById("main_table_countries_today")    
    $hdr_cells = $table_id.children
    write-Host "Test "
    forEach($hci in $hdr_cells){
        if($hci.tagName -eq "thead"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "th"){
                            $s=$s+'"'+($cell.innerHTML).replace('<br />','').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ')+'",'
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter                
                        }
                    }
                    $s=$s+'"Date Updated"'
                    Add-Content $csvfile "$s"
                    write-Host $s

                }
            }
        }
        if($hci.tagName -eq "tbody"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "td"){
                            write-Host "test"
                            $s=$s+'"'+($cell.innerText)+'",'
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter
                        }
                    }
                    $s=$s+'"'+$yesterday_date+'"'
                    Add-Content $csvfile "$s"
                    write-Host $s

                }
            }
        }
    }   
    
    
}
catch
{
    Write-Host 'Caught  '  +  $_.Exception.Message    
}
