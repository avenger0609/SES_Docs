﻿try {

    $csvpath = "D:\DOMO\WorldOMeter\Data\World\Today_Data"
    $TimeStamp = get-date -f yyyyMMddhhmmss
    $Archive='D:\DOMO\WorldOMeter\Archive\World\Today_Data'
    $FileName= "WOM_World_Covid19_TodayCases_$TimeStamp.txt"
    $LogfileName= "WOM_World_Covid19_TodayCases_$TimeStamp logger.txt"
    $URL = 'https://www.worldometers.info/coronavirus/'

    $csvfile= New-Item -Path $csvpath -Name $FileName -ItemType "file" -Value ""
    $logfile= New-Item -Path $csvpath -Name $LogfileName -ItemType "file" -Value "test log"
    $yesterday_date=(Get-Date).AddDays(0).ToString('MM-dd-yyyy hh:mm:ss')

    #Archiving old files
    #Move-Item -Path $csvpath\'WOM_World_Covid19_TodayCases_*.txt' -Destination $Archive
    get-childitem -Path $csvpath -Filter WOM_World_Covid19_TodayCases_*.txt | move-item -destination $Archive -Force

    $row_counter=0
    $col_counter=0
    
    #$r = Invoke-WebRequest -Uri $URL
    ##### new code
    $webclient = New-Object System.Net.WebClient
    $webclient.UseDefaultCredentials = $true
    $r=$webclient.DownloadString($URL)
    ##### new-code
    write-host "Line 21"
    write-host $r 
    #write-host $r.Value.GetType().Name
    Add-Content $logfile "After Invoke"

    $table_id = $r.parsedhtml.getElementById("main_table_countries_today")    
    Add-Content $logfile "After Parsing"
    $hdr_cells = $table_id.children
    write-Host "Test "
    Add-Content $logfile "Before ForEach"
    forEach($hci in $hdr_cells){
        if($hci.tagName -eq "thead"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    Add-Content $logfile "Before ro Number $row_counter"
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "th"){
                            $s=$s+'"'+($cell.innerHTML).replace('<br />','').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ')+'",'
                            $col_counter=$col_counter+1
                            Add-Content $logfile "Before Col Number $col_counter"
                            write-host "col number=" +  $col_counter                
                        }
                    }
                    $s=$s+'"Date Updated"'
                    Add-Content $logfile "Before adding data to file"
                    Add-Content $csvfile "$s"
                    Add-Content $logfile "After adding data to file"
                    write-Host $s

                }
            }
        }
        if($hci.tagName -eq "tbody"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    Add-Content $logfile "Before ro Number in tbody $row_counter"
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "td"){
                            write-Host "test"
                            $s=$s+'"'+($cell.innerText)+'",'
                            $col_counter=$col_counter+1
                            Add-Content $logfile "Before Col Number $col_counter"
                            write-host "col number=" +  $col_counter
                        }
                    }
                    $s=$s+'"'+$yesterday_date+'"'
                    Add-Content $csvfile "$s"

                    write-Host $s

                }
            }
        }
    }   
    
    
}
catch
{
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
    Write-Host 'Caught  '  + $_.Exception.Message
    $smtpServer = "mail25.uhc.com"
    $smtpFrom = "srilekha.anumula@optum.com"
    $smtpTo ="srilekha.anumula@optum.com,rizwan.syedali@optum.com"
    $messageSubject = "Exception while extracting world data for today powershell script from WorldoMeter"
    $messageBody =  $_.Exception.Message+""
    $smtp = New-Object Net.Mail.SmtpClient($smtpServer)
    $smtp.Send($smtpFrom,$smtpTo,$messagesubject,$messagebody)
}
