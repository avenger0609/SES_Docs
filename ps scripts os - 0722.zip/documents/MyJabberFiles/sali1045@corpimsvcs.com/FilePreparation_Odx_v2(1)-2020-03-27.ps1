try {
##task scheduler name: DOMO_ODx_Data
$Source = "\\nasv0512\domo_odx\"
$Dest = "\\nasv0512\domo_odx\Consolidated"
$Archive = "\\nasv0512\domo_odx\Archive"
$Staging = "\\nasv0512\domo_odx\Staging"
$Logs = "\\nasv0512\domo_odx\Logs"


#$Source='C:\Users\asrilekh\Documents\MyJabberFiles\sali1045@corpimsvcs.com\FilesReceived\'
#$Dest = "C:\Users\asrilekh\Documents\MyJabberFiles\sali1045@corpimsvcs.com\FilesReceived\Consolidated"
#$Archive = "C:\Users\asrilekh\Documents\MyJabberFiles\sali1045@corpimsvcs.com\FilesReceived\Archive"
#$Staging = "C:\Users\asrilekh\Documents\MyJabberFiles\sali1045@corpimsvcs.com\FilesReceived\Staging"
#$Logs = "C:\Users\asrilekh\Documents\MyJabberFiles\sali1045@corpimsvcs.com\FilesReceived\Logs"



$TimeStampformatted = Get-Date -UFormat "%m-%d-%Y %T"
$TimeStamp = get-date -f yyyyMMddhhmmss
$DestFile = "combinedOptumODX_$TimeStamp.csv"
$Logfile= New-Item -Path $Logs -Name "LogTransferOptumODX-$TimeStamp.log" -ItemType "file" -Value "Consolidation of files started at $TimeStampformatted"


Add-Content $Logfile "`r`n `r`n#### Step 1: Archiving old Consolidated files ####"
Add-Content $Logfile "Archiving the previously Consolidated file`r`nFileName:"
Get-ChildItem -Path $Dest -Filter combinedOptumODX*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile
Add-Content $Logfile "Archive path: `r`n$Archive"
get-childitem -Path $Dest -Filter combinedOptumODX*.csv | move-item -destination $Archive

Add-Content $Logfile "`r`n#### Step 2: Moving all the Extract files to Staging Folder ####"
Add-Content $Logfile "Moving all the Extract files to the Staging path: $Staging"
Add-Content $Logfile "`r`nList of files being Consolidated in this Batch : "
##Move-item from source to Staging
get-childitem -Path $Source -Filter extract-*.csv | move-item -destination $Staging
Get-ChildItem -Path $Staging -Filter extract-*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile

Add-Content $Logfile "`r`n#### Step 3: Creating new Consolidated files ####"
Add-Content $Logfile "Creating a New Consolidate file `"$DestFile`" in the path: $Dest"

$flist=Get-ChildItem -Path $Staging -Filter extract-*.csv
[int]$countoffiles = 0
ForEach ($File in $flist)
{
    $fname=$File.FullName

    Add-Content $Logfile "`r`nstarted Appending - $fname"

    [int]$LinesInFile = -1

    $reader = New-Object IO.StreamReader $fname
    

    while($reader.ReadLine() -ne $null){ $LinesInFile++ }    

    $reader.Close()

    try{
    
        Import-Csv $fname | Export-Csv $Dest\$DestFile -NoTypeInformation -Append 
        Add-Content $Logfile "`r`nAppended  $LinesInFile lines from $fname"
        Add-Content $Logfile "`r`nmoving file - $fname from staging to archive"
        move-item $fname $Archive
        Add-Content $Logfile "`r`nmoved file - $fname from staging to archive"        
        $countoffiles++
    }
    catch
    {
        Add-Content $Logfile "`r`nError while appending content of $fname"
        Add-Content $Logfile "`r`nPlease try reloading the file again"
    }

}


Add-Content $Logfile "`r`nCount of Extract Files that were appended successfully is $countoffiles"


## Add file names to the log
#Get-ChildItem -Path $Source -Filter extract-*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile
#Get-ChildItem -Path $Staging -Filter extract-*.csv | Select-Object -ExpandProperty FullName | Import-Csv | Export-Csv $Dest\$DestFile -NoTypeInformation -Append

Add-Content $Logfile "`r`n#### Step 4: Count of Rows ####"
Add-Content $Logfile "Count of rows in the Consolidated file : "
Get-Content $Dest\$DestFile | Measure-Object -Line | Select-Object -Expand Lines | Add-Content $Logfile

Add-Content $Logfile "`r`n#### Step 5: Archiving all the Extract files ####"
Add-Content $Logfile "Archiving all the above Extract*.csv(Step 2) to the path: $Archive"

##Move-item from source to Archive
#get-childitem -Path $Staging -Filter extract-*.csv | move-item -destination $Archive

Add-Content $Logfile "`r`n`r`nConsolidation Script ended at $TimeStampformatted"
}
catch
  {
    Add-Content $Logfile "Exception Caught  $_.Exception.GetType().FullName"
  }
