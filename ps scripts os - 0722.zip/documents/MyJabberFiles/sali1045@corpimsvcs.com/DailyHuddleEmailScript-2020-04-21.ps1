﻿### script to send email added- april 21st
$From = "rizwan.syedali@optum.com"
$To = "rizwan.syedali@optum.com","srilekha.anumula@optum.com"
$fileExtn=[System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId((Get-Date).AddDays(1), 'UTC') | Get-Date -UFormat %d%b
$filename ='Daily Huddle Template_'+$fileExtn+'.doc'
#$Attachment='C:\Users\sali1045\Desktop\Covid-OCIO\Daily Huddle Template\' +$filename
$Attachment='C:\Users\asrilekh\Documents\MyJabberFiles\sali1045@corpimsvcs.com\' +$filename
$Subject = "COVID-19 Daily Huddle Template"
$Body = "<div>Please find attached the daily Huddle Document </div><br><br> Regards Syed"
$SMTPServer = "mail25.uhc.com"
Send-MailMessage -From $From -to $To -Subject $Subject -Body $Body -BodyAsHtml -SmtpServer $SMTPServer  -Attachments $Attachment
### script to send email added- april 21st