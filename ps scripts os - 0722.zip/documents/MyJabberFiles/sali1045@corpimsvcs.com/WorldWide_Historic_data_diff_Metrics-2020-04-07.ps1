﻿$csvpath = "C:\Users\asrilekh\Documents\WOM Historical Data" 
$country_name='WorldWide'


$x_axis='["Jan 22","Jan 23","Jan 24","Jan 25","Jan 26","Jan 27","Jan 28","Jan 29","Jan 30","Jan 31","Feb 01","Feb 02","Feb 03","Feb 04","Feb 05","Feb 06","Feb 07","Feb 08","Feb 09","Feb 10","Feb 11","Feb 12","Feb 13","Feb 14","Feb 15","Feb 16","Feb 17","Feb 18","Feb 19","Feb 20","Feb 21","Feb 22","Feb 23","Feb 24","Feb 25","Feb 26","Feb 27","Feb 28","Feb 29","Mar 01","Mar 02","Mar 03","Mar 04","Mar 05","Mar 06","Mar 07","Mar 08","Mar 09","Mar 10","Mar 11","Mar 12","Mar 13","Mar 14","Mar 15","Mar 16","Mar 17","Mar 18","Mar 19","Mar 20","Mar 21","Mar 22","Mar 23","Mar 24","Mar 25","Mar 26","Mar 27","Mar 28","Mar 29","Mar 30","Mar 31","Apr 01","Apr 02","Apr 03","Apr 04","Apr 05","Apr 06"]'
$date_elements=$x_axis.Trim().replace('"','').Split(',')

$series_data='[580,845,1317,2015,2800,4581,6058,7813,9823,11950,14553,17391,20630,24545,28266,31439,34876,37552,40553,43099,45134,59287,64438,67100,69197,71329,73332,75184,75700,76677,77673,78651,79205,80087,80828,81820,83112,84615,86604,88585,90443,93016,95314,98425,102050,106099,109991,114381,118948,126214,134509,145416,156475,169511,182431,198159,218744,244902,275550,304979,337459,378830,422574,471035,531865,596366,663127,723390,784741,858361,935232,1015096,1116662,1201483,1272901,1346036]'
$tot_cases_elements=$series_data.Trim().replace('"','').Split(',')

$op_total_cases_elements=$tot_cases_elements

$series_data='[null,265,472,698,785,1781,1477,1755,2010,2127,2603,2838,3239,3915,3721,3173,3437,2676,3001,2546,2035,14153,5151,2662,2097,2132,2003,1852,516,977,996,978,554,882,741,992,1292,1503,1989,1981,1858,2573,2298,3111,3625,4049,3892,4390,4567,7266,8295,10907,11059,13036,12920,15728,20585,26158,30648,29429,32480,41371,43744,48461,60830,64501,66761,60263,61351,73620,76871,79864,101566,84821,71418,73135]'
$tot_cases_elements=$series_data.Trim().replace('"','').Split(',')

$op_daily_new_cases=$tot_cases_elements

$series_data='[563,786,1238,1910,2669,4415,5823,7519,9439,11448,13921,16525,19561,23146,26528,29239,32069,34055,36320,38038,39216,52039,56247,57378,57990,58581,58747,58622,57217,55906,54418,53541,51596,49922,48014,46215,43734,42262,41297,40413,39218,38870,38505,39433,40947,42328,43886,46300,48031,53279,59168,67413,74717,85538,95640,107556,124459,146709,172591,196473,224192,260248,294801,335525,383850,435964,490313,538013,581580,637935,693875,749738,829184,890328,940105,992848] '
$tot_cases_elements=$series_data.Trim().replace('"','').Split(',')

$op_daily_active_cases=$tot_cases_elements



############# Daily new deaths in US bar graph #################################

$TimeStamp = get-date -f yyyyMMddhhmmss
$FileName= $country_name+"_collated_$TimeStamp.csv"
$csvfile= New-Item -Path $csvpath -Name $FileName -ItemType "file" -Value ""

Add-content $csvfile '"Date","Total Cases","New Cases","Active Cases"'
[int]$c=0

while($true)
{
    if($c -ge $tot_cases_elements_len)
    {
        break
    }
    
    $dc=$date_elements[$c].replace('[','').replace(']','').trim()
    $tc=$op_total_cases_elements[$c].replace('[','').replace(']','').trim()    
    $dnc=$op_daily_new_cases[$c].replace('[','').replace(']','').trim()
    $dac=$op_daily_active_cases[$c].replace('[','').replace(']','').trim()
    
    $csvs='"'+$dc+'"'+',"'+$tc+'"'+',"'+$dnc+'"'+',"'+$dac+'"'
    Add-content $csvfile $csvs
    $c=$c+1
}

