try {
##task scheduler name: DOMO_Biosticker_Data New Script
$Source = "\\msp06fil03\data\ITIRD_KM_Folder\BioSticker\BioSticker ECG Files\"
$Dest = "\\msp06fil03\data\ITIRD_KM_Folder\BioSticker\BioSticker ECG Files\Consolidated"
$Archive = "\\msp06fil03\data\ITIRD_KM_Folder\BioSticker\BioSticker ECG Files\Archive"
$Staging = "\\msp06fil03\data\ITIRD_KM_Folder\BioSticker\BioSticker ECG Files\Staging"
$Logs = "\\msp06fil03\data\ITIRD_KM_Folder\BioSticker\BioSticker ECG Files\Logs"
$TimeStampformatted = Get-Date -UFormat "%m-%d-%Y %T"
$TimeStamp = get-date -f yyyyMMddhhmmss
$DestFile = "combinedBiosticker_$TimeStamp.csv"
$Logfile= New-Item -Path $Logs -Name "LogTransferBiosticker-$TimeStamp.log" -ItemType "file" -Value "Consolidation of files started at $TimeStampformatted"


Add-Content $Logfile "`r`n `r`n#### Step 1: Archiving old Consolidated files ####"
Add-Content $Logfile "Archiving the previously Consolidated file`r`nFileName:"
Get-ChildItem -Path $Dest -Filter combinedBiosticker*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile
Add-Content $Logfile "Archive path: `r`n$Archive"
get-childitem -Path $Dest -Filter combinedBiosticker*.csv | move-item -destination $Archive

Add-Content $Logfile "`r`n#### Step 2: Moving all the Extract files to Staging Folder ####"
Add-Content $Logfile "Moving all the Extract files to the Staging path: $Staging"
Add-Content $Logfile "`r`nList of files being Consolidated in this Batch : "
##Move-item from source to Staging
get-childitem -Path $Source -Filter BioIntelliSense-*.csv | move-item -destination $Staging
Get-ChildItem -Path $Staging -Filter BioIntelliSense-*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile

Add-Content $Logfile "`r`n#### Step 3: Creating new Consolidated files ####"

$flist=Get-ChildItem -Path $Staging -Filter BioIntelliSense-*.csv
$fl=$flist.Length
if($fl -gt 0)
{
    Add-Content $Logfile "Creating a New Consolidate file `"$DestFile`" in the path: $Dest"
}
else
{
    Add-Content $Logfile "No files to consolidate"
    $opfile= New-Item -Path $Dest -Name $DestFile -ItemType "file" -Value ""
}

[int]$countoffiles = 0
$files=$flist
$encoding = [System.Text.Encoding]::UTF8
$w = New-Object System.IO.StreamWriter("$Dest\$DestFile", $true, $encoding)
$skiprow = $false
foreach ($file in $files)
{
    try
    {
        $fname=$file.fullname
        Add-Content $Logfile "`r`nStarted Appending - $fname"
        $r = New-Object System.IO.StreamReader($file.fullname, $encoding)
        [int]$LinesInFile = -1
        while (($line = $r.ReadLine()) -ne $null) 
        {
            $LinesInFile++
            if (!$skiprow)
            {
                $w.WriteLine($line)
            }
            $skiprow = $false
        }
        $r.Close()
        $r.Dispose()
        $skiprow = $true
        Add-Content $Logfile "Appending Completed $LinesInFile lines from $fname"
        Add-Content $Logfile "Started moving file - $fname from staging to archive"
        move-item $fname $Archive
        Add-Content $Logfile "moved file Completed - $fname from staging to archive"        
        $countoffiles++
    }
    catch
    {
        Write-Host 'Caught  '  + $_.Exception.GetType().FullName
        Write-Host 'Caught  '  + $_.Exception.Message
        Add-Content $Logfile '`r`nCaught  '+ $_.Exception.GetType().FullName +'in'+ $fname
        Add-Content $Logfile '`r`nCaught  '+ $_.Exception.Message +'in'+ $fname
    }
}
$w.close()
$w.Dispose()


Add-Content $Logfile "`r`nCount of Extract Files that were appended successfully is $countoffiles"


## Add file names to the log
#Get-ChildItem -Path $Source -Filter BioIntelliSense-*.csv | Select-Object -ExpandProperty Name | Add-Content $Logfile
#Get-ChildItem -Path $Staging -Filter BioIntelliSense-*.csv | Select-Object -ExpandProperty FullName | Import-Csv | Export-Csv $Dest\$DestFile -NoTypeInformation -Append

Add-Content $Logfile "`r`n#### Step 4: Count of Rows ####"
Add-Content $Logfile "Count of rows in the Consolidated file : "
#Get-Content $Dest\$DestFile | Measure-Object -Line | Select-Object -Expand Lines | Add-Content $Logfile

$countfname="$Dest\$DestFile"
[int]$countLinesInFile = -1
$countreader = New-Object IO.StreamReader $countfname
while($countreader.ReadLine() -ne $null){ $countLinesInFile++ }  
$countreader.Close()
write-host $countLinesInFile
Add-Content $Logfile "Number of Lines without Header in Consolidated File are $countLinesInFile"

Add-Content $Logfile "`r`n#### Step 5: Archiving all the Extract files ####"
Add-Content $Logfile "Archiving all the above BioIntelliSense*.csv(Step 2) to the path: $Archive"

##Move-item from source to Archive
#get-childitem -Path $Staging -Filter BioIntelliSense-*.csv | move-item -destination $Archive

$TimeStampEndTimeformatted = Get-Date -UFormat "%m-%d-%Y %T"
Add-Content $Logfile "`r`n`r`nConsolidation Script ended at $TimeStampEndTimeformatted"
}
catch
  {
    Add-Content $Logfile "Exception Caught  $_.Exception.GetType().FullName"
  }
