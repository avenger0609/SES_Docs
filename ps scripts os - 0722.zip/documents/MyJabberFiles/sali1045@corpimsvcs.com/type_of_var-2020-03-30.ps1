﻿$var1 = (get-Date)
$gottenVar = (get-variable -name var1)
$gottenVar.Value.GetType().Name