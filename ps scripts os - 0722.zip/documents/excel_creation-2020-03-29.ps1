﻿$excel = New-Object -ComObject excel.application
$excel.visible = $False
$workbook = $excel.Workbooks.Add()
$diskSpacewksht= $workbook.Worksheets.Item(1)
$diskSpacewksht.Name = "Data Set"


$diskSpacewksht.Cells.Item(1,1)="test"
$diskSpacewksht.Cells.Item(1,2)="test"
$diskSpacewksht.Cells.Item(1,3)="test"
$diskSpacewksht.Cells.Item(1,4)="test"


$diskSpacewksht.Cells.Item(2,1)="test"
$diskSpacewksht.Cells.Item(2,2)="test"
$diskSpacewksht.Cells.Item(2,3)="test"
$diskSpacewksht.Cells.Item(2,4)="test"

$excel.DisplayAlerts = 'False'
$ext=".xlsx"
$path="C:\users\asrilekh\documents\DataSetE$ext"
$workbook.SaveAs($path) 
$workbook.Close
$excel.DisplayAlerts = 'False'
$excel.Quit()
