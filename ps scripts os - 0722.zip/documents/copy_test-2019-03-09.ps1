﻿        # copying sheet data

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $workbook_new=$excel.Workbooks.Add()
        $workbook_new.worksheets.item("Sheet2").Delete()
        $workbook_new.worksheets.item("Sheet3").Delete()
        $Sheet_new = $Workbook_new.Worksheets.Item(1)
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        $ColumnCount = $WorksheetRange.Columns.Count
        
        for($i=1; $i -lt $WorksheetRange.Rows.Count; $i++){
            for($j=1;$j -lt $WorksheetRange.Columns.Count; $j++){
                Write-host $j
                [void]$workSheet.cells.item($i,$j).copy()
                [void]$Sheet_new.cells.item($i,$j).Select()
                [void]$Sheet_new.cells.item($i,$j).PasteSpecial() 
            }   
        }
        
        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.SaveAs($test)
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        
        # copying sheet data




        
         $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $workbook_new=$excel.Workbooks.Add()
        $workbook_new.worksheets.item("Sheet2").Delete()
        $workbook_new.worksheets.item("Sheet3").Delete()
        $Sheet_new = $Workbook_new.Worksheets.Item(1)
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        $ColumnCount = $WorksheetRange.Columns.Count
        [void]$workSheet.Range(“A1:AB$RowCount").Copy()
        [void]$Sheet_new.Range(“A1:AB$RowCount").Select()
        [void]$Sheet_new.Range(“A1:AB$RowCount").PasteSpecial(-4163)
        
        
        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.SaveAs($test)
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM