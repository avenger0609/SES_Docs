﻿$tdydt=(Get-Date).ToString('yyyy-MM-dd')
$tdydt=(Get-Date).ToString('yyyy-MM-')
write-host $tdydt

$folder_name='C:\Users\asrilekh\Desktop\work\swing analysis\using odbc\'+(Get-Date).ToString('MMMM')+"-"+(Get-Date).ToString('yyyy')
#$folder_name='C:\Users\asrilekh\Desktop\work\swing analysis\using odbc\Test'
write-host $folder_name

$filter_format="*_"+$tdydt +"*.xlsx"
#$filter_format="*_2021-02-02.xlsx"
#get-childitem -Path $folder_name -Filter $filter_format 

$ExcelObject=New-Object -ComObject excel.application
$ExcelObject.visible=$false
$ExcelFiles=get-childitem -Path $folder_name -Filter $filter_format | sort ModificationTime

$Workbook=$ExcelObject.Workbooks.add()
$Worksheet=$Workbook.Sheets.Item("Sheet1")
$c=1
foreach($ExcelFile in $ExcelFiles){
write-host $c+"-"+$ExcelFile.FullName
$c=$c+1
$Everyexcel=$ExcelObject.Workbooks.Open($ExcelFile.FullName)
$Everysheet=$Everyexcel.sheets.item(1)
$Everysheet.Copy($Worksheet)
$Everyexcel.Close($false)
 
}
$tdydt=(Get-Date).ToString('yyyy-MM-dd')
$Workbook.SaveAs($folder_name+"\CB_Swing_Analysis _"+$tdydt+".xlsx")
$ExcelObject.Quit()

#8,,