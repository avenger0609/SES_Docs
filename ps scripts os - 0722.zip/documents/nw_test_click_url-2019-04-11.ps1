﻿$ie = new-object -com internetexplorer.application
$ie.visible=$true
$ie.navigate("http://cfrservices.uhg.com/Info/TreeReport#")
write-Host $ie.ToString()
#while($ie.busy) {sleep 1}
Write-Host $ie.Document.getElementsByTagName('table')
$link = $ie.Document.getElementsByTagName('table') | where-object {write-Host $_.innerText }
$link.click()