﻿$folder_name='C:\Users\asrilekh\Documents\onpremisefiles'
write-host $folder_name

$filter_format="*.xlsx"


$ExcelObject=New-Object -ComObject excel.application
$ExcelObject.visible=$false
$ExcelFiles=get-childitem -Path $folder_name -Filter $filter_format | sort ModificationTime

$Workbook=$ExcelObject.Workbooks.add()
$Worksheet=$Workbook.Sheets.Item("Sheet1")

foreach($ExcelFile in $ExcelFiles){
write-host $ExcelFile  
$Everyexcel=$ExcelObject.Workbooks.Open($ExcelFile.FullName)
$Everysheet=$Everyexcel.sheets.item(1)
$Everysheet.Copy($Worksheet)
$Everyexcel.Close($false)
 
}
$Workbook.SaveAs($folder_name+"\CB_Swing_Analysis _"+$tdydt+".xlsx")
$ExcelObject.Quit()