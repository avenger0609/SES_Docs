﻿$csvpath = "c:\users\asrilekh\downloads\DOMO\WorldOMeter\Data\US\Yesterday_Data"   ## testing in local
    
$FileName='test_file.csv' 

$TimeStamp = get-date -f yyyyMMddHHmmss

$FileName='test_file_'+$TimeStamp+'.csv' 

$csvfile= New-Item -Path $csvpath -Name $FileName -ItemType "file" -Value ""

for($i=0; $i -lt 224; $i++)
{    
    $webclient = New-Object System.Net.WebClient

    $webclient.UseDefaultCredentials = $true

    $fromurl="https://healthcare.ascension.org/Locations?page="+$i

    $s1=$webclient.DownloadString($fromurl)

    $div_start=$s1.IndexOf('<div class="location-listings">',0)

    $sub_div_end=$div_start

    while($true)
    {
        $title=""
        $services=""
        $address=""
        $zip=""
        $phone=""
       
        $div_loop_start=$s1.IndexOf('<div class="location-info">',$sub_div_end)

        if($div_loop_start -eq -1)
        {
            break
        }

        # title

        try
        {
            $h3_start=$s1.IndexOf('<h3 class="heading-sub">',$div_loop_start)
            $h3_a_end=$s1.IndexOf('>',$h3_start+'<h3 class="heading-sub">'.Length+4)
            $title_end=$s1.IndexOf('</a>',$h3_a_end)
            write-host $s1.Substring($h3_a_end+1,$title_end-$h3_a_end-1)
            $title=$s1.Substring($h3_a_end+1,$title_end-$h3_a_end-1)
        }
        catch
        {
            Write-Host 'Caught  '  + $_.Exception.GetType().FullName
            Write-Host 'Caught  '  + $_.Exception.Message
        }

        # title

        # services
        try
        {
            $ul_start=$s1.IndexOf('<ul class="location-type">',$title_end)
            $ul_end=$s1.IndexOf('</ul>',$ul_start)
            $ul_str=$s1.Substring($ul_start,$ul_end-$ul_start)
            $li_end=0
            while($true)
            {
                $li_start=$ul_str.IndexOf('<li>',$li_end)
                if($li_start -eq -1)
                {
                    break
                }
                $li_end=$ul_str.IndexOf('</li>',$li_start)
                write-host $ul_str.Substring($li_start+4,$li_end-$li_start-4)
                $services=$services+$ul_str.Substring($li_start+4,$li_end-$li_start-4)+","
            }
            $services=$services.Substring(0,$services.Length-1)
        }
        catch
        {
            Write-Host 'Caught  '  + $_.Exception.GetType().FullName
            Write-Host 'Caught  '  + $_.Exception.Message
        }

        # services

        # Address
        try
        {
            $address_start=$s1.IndexOf('<address role="presentation">',$ul_end)
            $address_end=$s1.IndexOf('</address>',$address_start)
            $address_str=$s1.Substring($address_start,$address_end-$address_start)
            $address_str_a_start=$address_str.IndexOf('<a href=',0)
            $address_str_a_start_tag_end = $address_str.IndexOf('>',$address_str_a_start)
            $address_str_a_end=$address_str.IndexOf('</a>',$address_str_a_start_tag_end)
            write-host $address_str.Substring($address_str_a_start_tag_end+1,$address_str_a_end-$address_str_a_start_tag_end-1).Replace('<br>',' ')
            $zip_start= ($address_str.Substring($address_str_a_start_tag_end+1,$address_str_a_end-$address_str_a_start_tag_end-1)).LastIndexOf(' ')
            write-host ($address_str.Substring($address_str_a_start_tag_end+1,$address_str_a_end-$address_str_a_start_tag_end-1)).substring($zip_start+1,5)
            $address=$address_str.Substring($address_str_a_start_tag_end+1,$address_str_a_end-$address_str_a_start_tag_end-1).Replace('<br>',' ')
            $zip=($address_str.Substring($address_str_a_start_tag_end+1,$address_str_a_end-$address_str_a_start_tag_end-1)).substring($zip_start+1,5)
        }
    
        catch
        {
            Write-Host 'Caught  '  + $_.Exception.GetType().FullName
            Write-Host 'Caught  '  + $_.Exception.Message
        }

        # Address

        # phone
        try
        {
            $phone_start=$s1.IndexOf('<strong>Phone</strong>',$address_end)
            $phone_str_a_start=$s1.IndexOf('<a href=',$phone_start)
            $phone_str_a_start_tag_end = $s1.IndexOf('>',$phone_str_a_start)
            $phone_str_a_end=$s1.IndexOf('</a>',$phone_str_a_start_tag_end)
            write-host $s1.Substring($phone_str_a_start_tag_end+1,$phone_str_a_end-$phone_str_a_start_tag_end-1)
            $phone=$s1.Substring($phone_str_a_start_tag_end+1,$phone_str_a_end-$phone_str_a_start_tag_end-1)
        }
        catch
        {
            Write-Host 'Caught  '  + $_.Exception.GetType().FullName
            Write-Host 'Caught  '  + $_.Exception.Message
        }

        # phone

        $sub_div_end=$s1.IndexOf('<!-- END ~/UI/Healthcare/Views/HealthcareSearch/../Component/LocationDetails/LocationAppointments.cshtml -->',$phone_str_a_end)

        $title=$title.replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').replace("`n","").Trim().replace('  ',' ').replace("`t","")
        $services=$services.replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').replace("`n","").Trim().replace('  ',' ').replace("`t","")
        $address=$address.replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').replace("`n","").Trim().replace('  ',' ').replace("`t","")
        $zip=$zip.replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').replace("`n","").Trim().replace('  ',' ').replace("`t","")
        $phone=$phone.replace('<br />',' ').replace('<br>',' ').replace('<sup>','').replace('</sup>','').replace('&nbsp;',' ').replace("`n","").Trim().replace('  ',' ').replace("`t","")

        $csvline='"'+$title+'","'+$services+'","'+$address+'","'+$zip+'","'+$phone+'"'

        write-host $csvline

        write-host $title
        write-host $services
        write-host $address
        write-host $zip
        write-host $phone

        Add-Content $csvfile "$csvline"
    }
}