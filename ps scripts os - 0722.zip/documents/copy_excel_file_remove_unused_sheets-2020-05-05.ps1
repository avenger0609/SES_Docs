﻿$xlsbfile = 'C:\Users\asrilekh\Documents\MyJabberFiles\ksruthi5@corpimsvcs.com\NGAM Files Mar 2020\Mar 2020\PForms Mar2020\PSO FCR2 Summary Report.xlsb'

$xlsxfile = 'C:\Users\asrilekh\Documents\MyJabberFiles\ksruthi5@corpimsvcs.com\NGAM Files Mar 2020\Mar 2020\PForms Mar2020\VLookup.xlsx'



## to save as xlsx file

$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$xlApp.DisplayAlerts = $false
$wb = $xlApp.Workbooks.Open($xlsbfile)
$wb.SaveAs($xlsxfile, [Microsoft.Office.Interop.Excel.xlFileFormat]::xlOpenXMLWorkbook)
$wb.Close(0)
$xlApp.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)

## to save as xlsx file

write-host 'Converted to xlsx file'

## removing unwanted sheets other than DB

$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$xlApp.DisplayAlerts = $false
$wb = $xlApp.Workbooks.Open($xlsxfile)
foreach( $w in $wb.Worksheets)
{
    if($w.name -ne 'DB')
    {
        $wb.worksheets.item($w.name).Delete()
        write-host $w.name + " Deleted"
    }
}
$wb.Save()
$wb.Close(0)
$xlApp.Quit()

## removing unwanted sheets other than DB

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)
