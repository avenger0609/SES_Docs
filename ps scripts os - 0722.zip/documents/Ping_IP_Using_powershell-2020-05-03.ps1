﻿Write-Host "Started Pinging.."

if (test-connection  "10.129.71.242" -count 1 -quiet)
{
    write-host  "Ping succeeded." -foreground green

}
else
{
        write-host  "Ping failed." -foreground red
}
    


Write-Host "Pinging Completed."

