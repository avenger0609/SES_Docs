﻿# reference: https://community.idera.com/database-tools/powershell/ask_the_experts/f/learn_powershell_from_don_jones-24/21097/new-to-powershell-find-url
# last but one answer

 Param([switch]$Full, [switch]$Location, [switch]$Content)
 while($true){
    sleep 60
    #Write-Host "entered"
    $urls = (New-Object -ComObject Shell.Application).Windows() |
    Where-Object {$_.LocationUrl -match "(^https?://.+)|(^ftp://)"} |
    Where-Object {$_.LocationUrl}
    if($Full)
    {
        Write-Host "if1"
        $urls
    }
    elseif($Location)
    {
        Write-Host "if2"
        $urls | select Location*
    }
    elseif($Content)
    {
        Write-Host "if3"
        $urls | ForEach-Object {
            $ie.LocationName;
            $ie.LocationUrl;
            $_.Document.building.innerText
        }
    }
    else
    {
        #Write-Host "if4"
        $hit=0
        $urls | ForEach-Object {
            #$_.LocationUrl
            if($_.LocationUrl -eq "http://lighthouse.uhc.com/WebActivityTracker/ActivityTracker.htm?v=3.0"){
                $hit=1
            }

        }
        if($hit -eq 0){
            $ie = Start-Process -file iexplore -arg 'http://lighthouse.uhc.com/' -PassThru
        }
    
    }
}