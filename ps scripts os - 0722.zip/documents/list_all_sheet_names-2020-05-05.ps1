﻿$xlsbfile = 'C:\Users\asrilekh\Documents\MyJabberFiles\ksruthi5@corpimsvcs.com\Mar 2020\PForms Mar2020\DB.xlsx'
$xlApp = New-Object -Com Excel.Application
$xlApp.Visible = $false
$wb = $xlApp.Workbooks.Open($xlsbfile)
foreach( $w in $wb.Worksheets)
{
    
    write-host $w.name
}

$wb.Close(0)
$xlApp.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xlApp)