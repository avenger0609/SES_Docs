﻿# add new column at beginning with column name tet_col and value as test

$newcolumnobj =  [ordered]@{}
#input data into a hash table so that we can more easily reference the `.values` as an object to be inserted in the CSV
$newcolumnobj.add("volume name", $currenttime)

#enumerate $deltas [this will be the object that contains the volume information `$volumedeltas`)
#  add just the new deltas to the newcolumn object
foreach ($item in $deltas){ 
  $newcolumnobj.add($item.volume,$item.delta)
}

$targetdeltacsv="C:\users\asrilekh\documents\domo\2018 Actuals Submission--CSG--April.csv"
$originalcsv = @(import-csv $targetdeltacsv)
$obj = @()
#thanks to pscookiemonster in #powershell on freenode
for($i=6; $i -lt $originalcsv.count; $i++){
  $originalcsv[$i] | Select-Object @{l="tet_col"; e={"test"}},*
  $obj += $originalcsv[$i] | Select-Object @{l="tet_col"; e={"test"}},*
}

$obj|Export-Csv "C:\users\asrilekh\documents\domo\2018 Actuals Submission--CSG--April_test2.csv" -NoTypeInformation