﻿$employees = @(

  [pscustomobject]@{

  FirstName = 'Adam'

  LastName  = 'Bertram'

  Username  = 'abertram'

  }

  [pscustomobject]@{

  FirstName = 'Joe'

  LastName  = 'Jones'

  Username  = 'jjones'

  }

  [pscustomobject]@{

  FirstName = 'Mary'

  LastName  = 'Baker'

  Username  = 'mbaker'

  }

  )
  
  $employees | Export-Csv -Path C:\users\asrilekh\documents\Employees2.csv