﻿function Convert-XlsmToCsv {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false
        }
    }
    process {
        $root = Split-Path -Path $Path
        #write-host $root "Root path"
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path)
        $workbook = $excel.Workbooks.Open($Path)
        
        foreach ($worksheet in $workbook.Worksheets) {
            #write-host $worksheet.Name
            if($worksheet.Name -like "*YTD Actuals"){
                
                $name = Join-Path -Path $root -ChildPath "$filename.csv"
                
                
                try {
                    $worksheet.SaveAs($name, 6)
                    
                    
                } catch {
                    Write-Error -Message "Failed to save csv! Path: '$name'. $PSItem"
                }

                ## skipping rows

                $import = get-content $name
                $name_2 = Join-Path -Path $root -ChildPath "$($filename)_1.csv" 
                #remove-item -path $name -force
                $import | Select-Object -Skip 6 | Set-Content $name_2  # skipping top 6 rows from file
               
                ## skipping rows

                $originalcsv = @(import-csv $name_2)
                
                $obj = @()
                
                for($i=0; $i -lt $originalcsv.count; $i++){
                   
                    $originalcsv[$i] | Select-Object @{l="File_Name"; e={${filename}}},*
                    $obj += $originalcsv[$i] | Select-Object  @{l="File_Name"; e={${filename}}},*
                    
                }
                
                $name_2 = Join-Path -Path $root -ChildPath "$($filename)_2.csv" 
                $obj | Export-Csv $name_2 -NoTypeInformation
                
                #$obj|Export-Csv "$($filename)_2" -NoTypeInformation
                
                ##### adding new column
                #remove-item -path $name -force
                #remove-item -path $name_2 -force
            }
            else{
                write-host "else"
            }

        }
    }
    end {
        $excel.Quit()
        $null = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
    }
}
Get-ChildItem -Path C:\Users\asrilekh\Documents\Domo\test -Filter *.xlsm |Convert-XlsmToCsv
