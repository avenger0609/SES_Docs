﻿
    
    $excelFile = 'C:\Users\asrilekh\Documents\ps_test_with_sheets.xlsx'
    $Excel = New-Object -ComObject Excel.Application
    $wb = $Excel.Workbooks.Open($excelFile)
	
    foreach ($ws in $wb.Worksheets) {
        $ws.SaveAs("c:\users\asrilekh\documents" + $ws.name + ".csv", 6)
    }
    $Excel.Quit()
