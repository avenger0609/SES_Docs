﻿        $excel = new-object -com Excel.Application -Property @{Visible = $false} 
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $ws = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $lastCell = $ws.usedRange        
        $R = $lastCell.row
        [void]$ws.Range(“B2:B$R”).Copy()
        [void]$ws.Range(“A2:A$R”).Select()
        [void]$ws.Range(“A2:A$R”).PasteSpecial(-4163)
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
