﻿# set the parameters
# TimeStamp used in the log creation, Dest should be the destination where files should be transfered
# Url is the source path from where the file should be exported
# Archive is the path where files will be moved after being copied to destination
# Convert-NumberToA1 function to convert given integer to excel A1 Format
# Convert-XlsmToXls function to convert xlsm file to xls file as per requirement
#filename whcih holds individual file name without extension from Dest folder
#src_fname which holds file name with extension from dest folder
# name which holds the name of xls file generated
# test file is the file used to hold content of required sheet without any formats/formulas
# wname holds the required sheet name
$TimeStamp = get-date -f yyyyMMddhhmm
$Dest = "C:\Users\sali1045\Documents\Domo\"
$Url = '\\it600.optum.com\sites\OAS\OptumHealth%20Finance%20Reporting\2018 CSG Actuals'
$Archive='\\it600.optum.com\sites\OAS\OptumHealth%20Finance%20Reporting\Archive\'
$filename="" 
$src_fname=""
$name = ""
$test = ""
$wname=""

# Get the filenames from Source path which is Url
$Source = Get-ChildItem -Path $Url -File

# Create the Logfile in the Destination and write the first line to initiate the log transfer
$Logfile= New-Item -Path $Dest -Name "LogTransfer-$TimeStamp.log" -ItemType "file" -Value "Transfer of files started at $TimeStamp"
Add-Content $Logfile ""

# Create the For loop to copy the files from Source to Destination and also Archive them
ForEach ($File in $Source)
{
    # Copy files from Source to Destination
    Copy-Item -Path $File.FullName -Destination $Dest -Force
    
    # Add the file name transfering to the log
    $Timestamp_log = get-date -f yyyyMMddhhmm
    Add-Content $Logfile "Transfering File -$File at-$Timestamp_log"
     
    # Copy the file to the Archive and them remove it from Destination   
    Copy-Item -Path $File.FullName -Destination $Archive -Force
    remove-item -path $File.FullName -force
}

Add-Content $Logfile "Transfer of files Completed at $TimeStamp"

################################
## New Code Added
################################
Function Convert-NumberToA1 { 
  <# 
  .SYNOPSIS 
  This converts any integer into A1 format. 
  .DESCRIPTION 
  See synopsis. 
  .PARAMETER number 
  Any number between 1 and 2147483647 --- range of column numbers
  #> 
   
  Param([parameter(Mandatory=$true)] 
        [int]$number) 
 
  $a1Value = $null 
  While ($number -gt 0) { 
    $multiplier = [int][system.math]::Floor(($number / 26)) 
    $charNumber = $number - ($multiplier * 26) 
    If ($charNumber -eq 0) { $multiplier-- ; $charNumber = 26 } 
    $a1Value = [char]($charNumber + 64) + $a1Value 
    $number = $multiplier 
  } 
  Return $a1Value 
}

function Convert-XlsmToXls {
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [ValidateNotNullOrEmpty()]
        [Alias('FullName')]
        [string] $Path
    )
    begin {
        
    }
    process {
        
        $Excel   = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}

        # Split the entire path into two variables, root will contain only path and filename will have the filename without Extension
        $root = Split-Path -Path $Path        
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path) ## get's file name

        #Open the workbook and go
        $workbook = $excel.Workbooks.Open($Path)
        $src_fname=Join-Path -Path $root -ChildPath "$filename.xlsm" ## source file name with extension
        $name = Join-Path -Path $root -ChildPath "$filename.xls" # saving as output xls file
        $test = Join-Path -Path $root -ChildPath "test.xls" # intermediate file used for storing data
        $wname="" # to store name of worksheet

        # deleting unwanted sheets

        foreach ($worksheet in $workbook.Worksheets) {
            if($worksheet.Name -like "*YTD Actuals"){
                 $wname=$worksheet.Name                 
                 $workbook.worksheets.item($worksheet.Name).Visible = $true
            } 
            else{
                $workbook.worksheets.item($worksheet.Name).Delete()
            } 
        }                         
        $workbook.SaveAs($name)
        $workbook.Close()                   
        $Excel.Quit()
        $null = [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Excel)

        # deleting unwanted sheets

        # deleting top 5 rows

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $sheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        for($di=1; $di -le 5; $di++){
            [void]$sheet.Cells.Item(1, 1).EntireRow.Delete()
        }         
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        # deleting top 5 rows

        # copying sheet data to new file (test file)  deleting top 5 rows
        
        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($src_fname) # Open the file
        $workbook_new=$excel.Workbooks.Add()
        $workbook_new.worksheets.item("Sheet2").Delete() # Delete sheet2
        $workbook_new.worksheets.item("Sheet3").Delete() # Delete Sheet3
        $Sheet_new = $Workbook_new.Worksheets.Item(1)
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        $RowCount = $WorksheetRange.Rows.Count
        $ColumnCount = $WorksheetRange.Columns.Count
        $col_letter_last=Convert-NumberToA1($ColumnCount)
        [void]$workSheet.Range(“A1:$col_letter_last$RowCount").Copy()
        [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").Select()
        [void]$Sheet_new.Range(“A1:$col_letter_last$RowCount").PasteSpecial(-4163)
        for($di=1; $di -le 5; $di++){
            [void]$Sheet_new.Cells.Item(1, 1).EntireRow.Delete() 
        }             
        $workbook.Close($true) # Close workbook and save changes
        $workbook_new.SaveAs($test)
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM

        # copying sheet data to new file (test file)  deleting top 5 rows

        # writing data to atual output file

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $test_wb = $excel.Workbooks.Open($test) # Open the file
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $test_sheet = $test_wb.Sheets.Item("Sheet1") # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange
        for($i=1; $i -le $WorksheetRange.Rows.Count; $i++){
            for($j=1; $j -le $WorksheetRange.Columns.Count; $j++){
                $workSheet.cells.item($i,$j).value() = $test_sheet.cells.item($i,$j).value() 
            }
        }
        $workbook.Save()
        $workbook.Close($true)
        $test_wb.Close($true)
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        # writing data to atual output file

        # adding file name to first column

        $excel = New-Object -ComObject Excel.Application -Property @{
            Visible       = $false
            DisplayAlerts = $false}
        $workbook = $excel.Workbooks.Open($name) # Open the file
        $workSheet = $workbook.Sheets.Item($wname) # Activate the required worksheet
        $WorksheetRange = $workSheet.UsedRange        
        [void]$workSheet.Range(“B2:B$RowCount”).Copy()
        [void]$workSheet.Range(“A2:A$RowCount”).Select()
        [void]$workSheet.Range(“A2:A$RowCount”).PasteSpecial()    
        $workSheet.cells.item(2,1).value() = "FileName"
        for($i=3; $i -le $WorksheetRange.Rows.Count; $i++){
            $workSheet.cells.item($i,1).value() = "$filename"
        }
        [void]$workSheet.Range(“A2:A$RowCount”).EntireColumn.AutoFit() ## adjusting column width        
        $workbook.Close($true) # Close workbook and save changes
        $excel.quit() # Quit Excel
        $ec=[Runtime.Interopservices.Marshal]::ReleaseComObject($excel) # Release COM
        
        # adding file name to first column

        # removing intermediate file
        
        remove-item -path $test -force

        # removing intermediate file
        
    }
    end {
        
        
    }
}
Get-ChildItem -Path $Dest -Filter *.xlsm |Convert-XlsmToXls
