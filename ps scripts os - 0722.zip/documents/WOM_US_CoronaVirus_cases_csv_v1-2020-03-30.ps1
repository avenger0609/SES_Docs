﻿try {

    $csvpath = "D:\DOMO\WorldOMeter\Data"
    $TimeStamp = get-date -f yyyyMMddhhmmss
    $Archive='D:\DOMO\WorldOMeter\Archive'
    $csvfile= New-Item -Path $csvpath -Name "WOM_US_Covid19_$TimeStamp.txt" -ItemType "file" -Value ""

    #Archiving old files
    get-childitem -Path $csvpath -Filter WOM_US_Covid19_*.txt | move-item -destination $Archive

    $row_counter=0
    $col_counter=0
    $r = Invoke-WebRequest -Uri 'https://www.worldometers.info/coronavirus/country/us/'     
    write-host "test"   
    #$lines=@(100000)
    #$li=0
    
    
    $table_id = $r.parsedhtml.getElementById("usa_table_countries_yesterday")    
    #[System.Windows.Forms.SendKeys]::SendWait("{TAB}{ENTER}")
    write-host "test"
    $hdr_cells = $table_id.children
    write-host "test"
    forEach($hci in $hdr_cells){
        if($hci.tagName -eq "thead"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "th"){
                            $s=$s+($cell.innerHTML).replace('<br />','').replace('<br>',' ')+"|"
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter
                            $diskSpacewksht.Cells.Item($row_counter,$col_counter)=$cell.innerText                
                        }
                    }
                    Add-Content $csvfile "$s"
                    write-Host $s
                    #$lines[$li]=$s
                    #$li=$li+1
                }
            }
        }
        if($hci.tagName -eq "tbody"){
            $header_cells = $hci.children
            forEach($datum in $header_cells){
                if($datum.tagName -eq "tr"){
                    $s=""
                    $col_counter=0
                    $row_counter=$row_counter+1
                    write-host "ro number=" + $row_counter
                    $cells = $datum.children
                    forEach($cell in $cells){            
                        if($cell.tagName -eq "td"){
                            write-Host "test"
                            $s=$s+($cell.innerText)+"|"
                            $col_counter=$col_counter+1
                            write-host "col number=" +  $col_counter
                            $diskSpacewksht.Cells.Item($row_counter,$col_counter)=$cell.innerText                
                        }
                    }
                    Add-Content $csvfile "$s"
                    write-Host $s
                    #$lines[$li]=$s
                    #$li=$li+1
                }
            }
        }
    }   
    
    
}
catch
{
    #write-Host "lines="+$lines
    Write-Host 'Caught  '  + $_.Exception.GetType().FullName
}
