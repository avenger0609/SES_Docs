from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
import numpy as np
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_win32\\chromedriver.exe"
# driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
output_filename=r'\\APVEP78970\Users\sali54\Documents\SES POC\Downloads\AMZScout_Sales_Estimates_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv"
df=pd.DataFrame()
df['ASIN']=[]
df["Category"]=[]
df['Category Rank']=[]
df['Estimated Monthly Sales']=[]
df['Estimated Daily Sales']=[]
df['Extracted Date']=[]  #str(datetime.now().strftime('%Y%m%d%H%M%S'))
df.to_csv(output_filename,index=False,quoting=csv.QUOTE_ALL)
Categories={}

def get_categories():
    driver.get('https://amzscout.net/sales-estimator/')
    driver.find_element_by_xpath('//*[@id="salesEstimator-currentMarketplace"]').click()
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="salesEstimator-marketplace"]/li[8]').click()
    driver.find_element_by_xpath('//*[@id="salesEstimator-currentCtegory"]').click()
    time.sleep(2)
    ul=driver.find_element_by_xpath('//*[@id="salesEstimator-category"]')
    lis=ul.find_elements_by_tag_name('li')
    for i in range(0,len(lis)):
        print(lis[i].text)
        Categories[lis[i].text]=i
    print(Categories)


def get_estimates(cat_value,cat_rank,asn_value):
    driver.get('https://amzscout.net/sales-estimator/')
    driver.find_element_by_xpath('//*[@id="salesEstimator-currentMarketplace"]').click()
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="salesEstimator-marketplace"]/li[8]').click()
    driver.find_element_by_xpath('//*[@id="salesEstimator-currentCtegory"]').click()
    time.sleep(2)
    # get_categories()
    cat_index=Categories.get(cat_value)
    ul=driver.find_element_by_xpath('//*[@id="salesEstimator-category"]')
    ul.find_elements_by_tag_name('li')[cat_index].click()
    print(cat_index,cat_value,cat_rank)
    
    time.sleep(2)
    
    # # driver.execute_script('document.getElementById("salesEstimator-value").value = "16";')
    
    driver.find_element_by_xpath('//*[@id="salesEstimator-value"]').click()
    action = ActionChains(driver)
    for _ in range(0,int(cat_rank)):
        action = ActionChains(driver)
        action.send_keys(Keys.ARROW_UP).perform()

    
    time.sleep(5)
    driver.find_element_by_xpath('//*[@id="salesEstimator-behavior"]/div[2]/button').click()    
    time.sleep(5)
    Estimates=driver.find_element_by_xpath('//*[@id="salesEstimator-behavior_data"]/p').text
    print(Estimates)
    
    df=pd.DataFrame()
    df['ASIN']=[asn_value]
    df["Category"]=[cat_value]
    df['Category Rank']=[cat_rank]    
    df['Estimated Monthly Sales']=[Estimates]
    df['Estimated Daily Sales']=[str(round(int(Estimates)/30,2))]
    
    df['Extracted Date']=str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    df.to_csv(output_filename,index=False,quoting=csv.QUOTE_ALL,mode='a',header=False)    
    
    time.sleep(5)

# get_estimates("Baby","496","TEST")
def main():
    df_ip=pd.read_csv(r'\\APVEP78970\Users\sali54\Documents\SES POC\Scripts\AMZRankExtractor10112020083605_Est.csv')
    rank_dept=list(df_ip['Primary Rank Department'])    
    asn_lst=list(df_ip['ASIN'])  
    rank=list(df_ip['Primary Rank'])
    get_categories()
    # for rdi in range(0,5):
    for rdi in range(0,len(rank_dept)):
        # get_estimates(rank_dept[rdi],rank[rdi].replace('#','').replace(',',''),asn_lst[rdi])
        try:
            get_estimates(rank_dept[rdi],rank[rdi].replace('#','').replace(',',''),asn_lst[rdi])
        except Exception as e:
            print(str(e))
main()