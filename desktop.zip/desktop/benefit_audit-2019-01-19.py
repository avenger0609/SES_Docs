from datetime import datetime
import os
import csv
import openpyxl
import paandas as pd
import numpy as np
import datetime
import time
from dateutil import parser
import redis
import re
import xlrd
import xlwt
import xlwings




def floatHT(fh):
    h, r = divmod(fh, 1)
    m, r = divmod(r * 60, 1)
    return (int(h), int(m), int(r * 60))


def rdate(fh1):

    excel_date = round(float(str(fh1)),1)

    dt = datetime.date.fromordinal(datetime(1900, 1, 1).date.toordinal() + int(excel_date) - 2)
    print("test")
    hour, minute, second = floatHT(excel_date % 1)
    dt = dt.replace(hour=hour, minute=minute, second=second)
    return dt


try:
    align_ssn_index = 0
    align_emp_index = 1
    align_pr_schedule_index = 5
    align_ded_begdt_index = 12
    align_ded_enddt_index = 13
    align_ded_amt_index = 11
    align_retro_index = 14
    align_ded_cd_index = 10
    valid="-1234567890."

    print("extraction started of alight source")
    #align_source = input("please provide name of align source file along with extension")
    align_source = "Henkel Payroll Audit 10-4-18.xlsx"
   # adp_source = input("please provide name of adp source file along with extension")
    adp_source = "Org_HENKEL_ACCUM_DED_REPORT_09282018.xlsx"
    align_al = list()
    adp_al = list()
    align_wb = xlrd.open_workbook(align_source)
    align_sheet=align_wb.sheet_by_index(0)
    #print(str(align_sheet.cell_value(1, align_ded_enddt_index)))
   # print(str(align_sheet.nrows))
    #print(str(align_sheet.ncols))
    for aligni in range(0,align_sheet.nrows):
        #print("aligni"+str(aligni))
        v1=str(align_sheet.cell_value(aligni, align_ded_amt_index))
        v2=""
        #print(v1)
        valid_test=10
        invalid_test=10
        for v1i in range(0,len(v1)):
            if v1[v1i] in "0.":
                #print ("entered invalid")
                invalid_test=0
            else:
                #print ("entered valid")
                valid_test=1
        if valid_test==10:
            continue
        align_recd=""
        for alignj in range(0,align_sheet.ncols):
            #print("alignj" + str(alignj))
            if alignj==align_ssn_index:
                v1=str(align_sheet.cell_value(aligni, alignj))
                v2=""
                for v1i in range(0,len(v1)):
                    if v1[v1i] in valid:
                        v2=v2+v1[v1i]
                    else:
                        j=""
                align_recd=align_recd+"!"+str(v2)
            elif alignj==align_ded_amt_index:
                v1 = str(align_sheet.cell_value(aligni, alignj))
                v2 = ""
                for v1i in range(0, len(v1)):
                    if v1[v1i] in valid:
                        v2 = v2 + v1[v1i]
                    else:
                        j = ""
                align_recd = align_recd + "!" + str(v2)
            elif alignj==align_emp_index:
                v1 = str(align_sheet.cell_value(aligni, alignj))
                v2 = ""
                for v1i in range(0, len(v1)):
                    if v1[v1i] in valid:
                        v2 = v2 + v1[v1i]
                    else:
                        j = ""
                align_recd = align_recd + "!" + str(v2)

            else:
                align_recd=align_recd+"!"+str(align_sheet.cell_value(aligni, alignj))
       # print(align_recd[1:])
        align_al.append(align_recd[1:])
    print("extraction completed of alight source")
    print(len(align_al))
    print("extraction started of adp source")
    adp_wb = xlrd.open_workbook(adp_source)
    adp_sheet = adp_wb.sheet_by_index(0)
   # print(str(adp_sheet.nrows))
    #print(str(adp_sheet.ncols))
    for adpi in range(0, adp_sheet.nrows):
        #print("adpi" + str(adpi))
        adp_recd = ""
        for adpj in range(0, adp_sheet.ncols):
           # print("adpj" + str(adpj))
            if "SPECIAL" in str(adp_sheet.cell_value(0,adpj)).upper() and "ACCUM" in str(adp_sheet.cell_value(0,adpj)).upper():

                v1 = str(adp_sheet.cell_value(adpi, adpj))
                v2 = ""
                for v1i in range(0, len(v1)):
                    if v1[v1i] in valid:
                        v2 = v2 + v1[v1i]
                    else:
                        j = ""
                adp_recd = adp_recd + "!" + str(v2)
            else:
                adp_recd = adp_recd + "!" + str(adp_sheet.cell_value(adpi, adpj))
        #print(adp_recd[1:])
        adp_al.append(adp_recd[1:])
    print("extraction completed of adp source")
except Exception as  e2:
    print("error while reading contents from excel file:"+str(e2))
try:

    new_align_al=list()
    #print("new aling is empty")



    align_std_dt="43372.0"
    #print(str(len(align_al)))
    for aligni in range(1,len(align_al)):

        align_recd=str(align_al[aligni])

        align_cal_begdt=str(align_recd).split('!')[align_ded_begdt_index]
        #print(str(align_cal_begdt))
        align_cal_begdt=str(float(str(align_cal_begdt))-1)
        #print("test1")
        #print(str(align_cal_begdt) + "cal_beg_dt")
        align_difference=float(align_std_dt)-float(str(align_recd).split('!')[align_ded_enddt_index])
        if align_difference < 0 :
            align_cal_enddt=align_std_dt
        else:
            align_cal_enddt=float(str(align_recd).split('!')[align_ded_enddt_index])
        #print(str(align_cal_enddt) + "cal_end_dt")
        if (str(align_recd).split('!')[align_pr_schedule_index].upper().find("WEEKLY")) > -1 and (str(align_recd).split('!')[align_pr_schedule_index].upper().find("BI")) > -1:
            cal_no_of_pc=(float(align_cal_enddt)-float(align_cal_begdt))/14
        else:
            cal_no_of_pc = (float(align_cal_enddt) - float(align_cal_begdt)) / 7
        if ".5" in str(cal_no_of_pc):
            if int(str(cal_no_of_pc).split('.')[0]) % 2==0:
                #print("entered condition"+str(round(cal_no_of_pc)))
                cal_round_pc=round(cal_no_of_pc)+1
                #print("after condition"+str(round(cal_round_pc)))
            else:
                cal_round_pc=round(cal_no_of_pc)
        else:
            cal_round_pc=round(cal_no_of_pc)


     #   print(str(cal_no_of_pc) + "cal_no_of_pc")
        #cal_round_pc=round(cal_no_of_pc)
      #  print(str(cal_round_pc) + "cal_round_pc")
        if (str(align_recd).split('!')[align_pr_schedule_index].upper().find("WEEKLY")) > -1 and (str(align_recd).split('!')[align_pr_schedule_index].upper().find("48")) > -1:
            if(cal_round_pc > 34):
                cal_48_week=cal_round_pc-3
            elif( cal_round_pc >21 and cal_round_pc <35):
                cal_48_week=cal_round_pc-2
            elif (cal_round_pc > 4 and cal_round_pc < 21):
                cal_48_week = cal_round_pc - 1
            else:
                cal_48_week=cal_round_pc
        else:
            cal_48_week=cal_round_pc
       # print(str(cal_48_week) + "cak_48_week")
        cal_ytd_amt=cal_48_week*float(str(align_recd).split('!')[align_ded_amt_index])
       # print(str(cal_ytd_amt) + "cal_ytd_amt")
        if len(str(align_recd).split('!')[align_retro_index].strip(' '))>0:
             cal_ytd_amt=0.0
             retro_amt=float(str(align_recd).split('!')[align_ded_amt_index])
             print(str(align_recd).split('!')[align_ded_amt_index]+"retro amount")
        else:
            retro_amt=0.0
            cal_ytd_amt=cal_ytd_amt
       # print(str(retro_amt) + "cal_retro_amt")
        new_align_recd=align_recd+"!"+str(align_cal_begdt)+"!"+str(str(align_cal_enddt))+"!"+str(cal_no_of_pc)+"!"+str(cal_round_pc)+"!"+str(cal_48_week)+"!"+str(cal_ytd_amt)+"!"+str(retro_amt)
        new_align_al.append(new_align_recd)
    #print(new_align_al)
    print("completed deriving calculated fields")
except Exception as  e2:
    print("error while reading contents from excel file:"+str(e2))

try:
    new_ded_align_list=list()
    for newaligni in range(0,len(new_align_al)):
        dedcd = str(new_align_al[newaligni]).split('!')[align_ded_cd_index]
        try:
            junk=new_ded_align_list.index(dedcd)
        except:
            new_ded_align_list.append((dedcd))
   # print(new_ded_align_list)
    print("completed collecting unique deduction codes")
except:
    print("error while populating unique ded codes")

try:
    cal_ytd_index=int(align_sheet.ncols)+5
    retro_index=int(align_sheet.ncols)+6
    cal_48_index=int(align_sheet.ncols)+4
    cal_round_pc_index=int(align_sheet.ncols)+3
    cal_no_of_pc_index=int(align_sheet.ncols)+2
    cal_end_dt_index=int(align_sheet.ncols)+1
    cal_beg_dt_index=int(align_sheet.ncols)
    for dedi in range(0,len(new_ded_align_list)):
        new_align_ded_spec_recds=list()
        new_align_ded_emp_qunique=list()
        for newaligni in range(0,len(new_align_al)):
            dedcd=str(new_align_al[newaligni]).split('!')[align_ded_cd_index]
            if dedcd.strip(' ').upper()==new_ded_align_list[dedi].strip(' ').upper():
                new_align_ded_spec_recds.append(new_align_al[newaligni])
                empssn=new_align_al[newaligni].split('!')[align_ssn_index]
                try:
                    junk=new_align_ded_emp_qunique.index(empssn)
                except:
                    new_align_ded_emp_qunique.append(empssn)
       # print(new_align_ded_emp_qunique)
        print("completed collecting deduction code specific records for dedcd="+str(new_ded_align_list[dedi]))
        new_align_ded_emp_ytd=list()
        for dedempi in range(0,len(new_align_ded_emp_qunique)):
            dedsum=0.0

            for dedempreci in range(0,len(new_align_ded_spec_recds)):
                if new_align_ded_emp_qunique[dedempi].strip(' ').upper()==new_align_ded_spec_recds[dedempreci].strip(' ').upper().split('!')[align_ssn_index]:
                    #print("entered ")
                   # print("dedsum="+str(dedsum))
                   # print("new_align_ded_spec_recds_ytd"+str(float(str(new_align_ded_spec_recds[dedempreci]).split('!')[cal_ytd_index])))
                    dedsum=dedsum+float(str(new_align_ded_spec_recds[dedempreci]).split('!')[cal_ytd_index])+float(str(new_align_ded_spec_recds[dedempreci]).split('!')[retro_index])

                   # print("after dedsum="+str(round(dedsum,2)))
                   # print(str(dedsum))
            new_align_ded_emp_ytd.append(str(dedsum))
            if dedempi%1000==0:
                print("commpleted calculating utd amounts for " +str(dedempi)+" number of records")

        print("completed calculating ytd amounts for dedcd=" + str(new_ded_align_list[dedi]))

        adp_header=adp_al[0].split('!')

        acci=0
        dedcdacc=new_ded_align_list[dedi].strip(' ').upper()
        for adpj in range(0, adp_sheet.ncols):

            if str(adp_sheet.cell_value(0, adpj)).upper().find("DED")>-1 and str(adp_sheet.cell_value(0, adpj)).upper().find("CD")>-1 and str(adp_sheet.cell_value(0, adpj)).upper().find(dedcdacc)>-1:
                acci=adpj+1
                break

       # print(str(acci))
        fp=open('error_report.csv', 'w', newline='', encoding="utf-8")
        w=csv.writer(fp,delimiter=",")
		#w = csv.writer(fp, delimiter=',')
        if acci==0:
            w.writerow("could not find accumulator values for deduction code"+str(new_ded_align_list[dedi]))
            continue

        adp_ssn_index=2
        adp_emp_name_index=1
        adp_emp_status_index=5
        adp_emp_date_index=6
        adp_acc_index=acci

        adp_emp_unique=list()
        adp_emp_det=list()

        for adpi in range(1,len(adp_al)):

            if float(adp_al[adpi].split('!')[adp_acc_index]) >0:
                empssn = adp_al[adpi].split('!')[adp_ssn_index]
                try:
                    junk = adp_emp_unique.index(empssn)
                except:
                    adp_emp_unique.append(empssn)




        for adpeui in range(0,len(adp_emp_unique)):

            for adpi in range(1,len(adp_al)):

                if adp_al[adpi].split('!')[adp_ssn_index]==adp_emp_unique[adpeui]:
                    e_ssn=adp_al[adpi].split('!')[adp_ssn_index]
                    e_name=adp_al[adpi].split('!')[adp_emp_name_index]
                    e_status=adp_al[adpi].split('!')[adp_emp_status_index]
                    e_date=adp_al[adpi].split('!')[adp_emp_date_index]
                    empdet=e_ssn+"!"+e_name+"!"+e_status+"!"+e_date
                    adp_emp_det.append(empdet)
                    break
        print("completed collecting emp details from adp source for dedcd=" + str(new_ded_align_list[dedi]))
       # print(str(len(adp_emp_unique)))
      #  print(str(len(adp_emp_det)))
        adp_acc_amt=list()
        for adpeui in range(0,len(adp_emp_unique)):
            esum=0.0
            for adpi in range(1,len(adp_al)):

                if adp_al[adpi].split('!')[adp_ssn_index]==adp_emp_unique[adpeui]:
                    esum=esum+float(adp_al[adpi].split('!')[adp_acc_index])

            adp_acc_amt.append(str(round(esum,2)))
        print("completed calculating adp total amounts for dedcd=" + str(new_ded_align_list[dedi]))
      #  print(str(len(adp_acc_amt)))
        adp_final_emp=list()
        adp_final_emp_det=list()
        adp_final_acc_amt=list()
        for adpacci in range(0,len(adp_acc_amt)):
            if float(str(adp_acc_amt[adpacci])) > 0:
                adp_final_emp.append(adp_emp_unique[adpacci])
                adp_final_emp_det.append(adp_emp_det[adpacci])
                adp_final_acc_amt.append(adp_acc_amt[adpacci])

      #  print(adp_final_acc_amt)
       # print(adp_final_emp_det)
       # print(adp_final_emp)
        print("finalized lists related to adp source")
        adp2aligncmp=list()

        for afe in range(0,len(adp_final_emp)):
            align_amt=""
            diff=""
            adp_amt=str(round(float(str(adp_final_acc_amt[afe])),2))
            for aligni in range(0,len(new_align_ded_emp_qunique)):
                if str(int(float(str(new_align_ded_emp_qunique[aligni])))).strip(' ').zfill(9)==str(int(float(str(adp_final_emp[afe])))).strip(' ').zfill(9):

                    align_amt=str(round(float(str(new_align_ded_emp_ytd[aligni])),2))
                    diff=str(round(float(str(new_align_ded_emp_ytd[aligni]))-float(str(adp_final_acc_amt[afe])),2))
                    adp_amt=str(round(float(str(adp_final_acc_amt[afe])),2))

            adp2aligncmp.append(adp_final_emp_det[afe]+"!"+adp_amt+"!"+align_amt+"!"+diff)

       # print(adp2aligncmp)
        print("completed comparing adp total amounts for dedcd=" + str(new_ded_align_list[dedi])+"with alight source")
        align2adpcmp=list()

        for aligni in range(0, len(new_align_ded_emp_qunique)):
            adp_amt=""
            diff=""
            align_amt=str(round(float(str(new_align_ded_emp_ytd[aligni])),2))
            for afe in range(0, len(adp_final_emp)):
                if str(int(float(str(new_align_ded_emp_qunique[aligni])))).strip(' ').zfill(9) == str(int(float(str(adp_final_emp[afe])))).strip(' ').zfill(9):
                    adp_amt=str(adp_final_acc_amt[afe])
                    diff = str(round(float(str(new_align_ded_emp_ytd[aligni])) - float(str(adp_final_acc_amt[afe])),2))
                    align_amt=str(round(float(str(new_align_ded_emp_ytd[aligni])),2))
            align2adpcmp.append(str(int(float(str(new_align_ded_emp_qunique[aligni])))).strip(' ').zfill(9)+"!"+align_amt+"!"+adp_amt+"!"+diff)

        #print(align2adpcmp)
        print("completed comparing ytd amounts for dedcd=" + str(new_ded_align_list[dedi]) + "with adp source")
        wb_name="compare"+str(new_ded_align_list[dedi])+".xls"
        wb=xlwt.Workbook()
        sheet1=wb.add_sheet('alight merged')
        sheet1.write(0,0,"alight_emp_ssn")
        sheet1.write(0, 1, "alight_emp_id")
        sheet1.write(0, 2, "alight_emp_last_name")
        sheet1.write(0, 3, "alight_emp_first_name")
        sheet1.write(0, 4, "company_code")
        sheet1.write(0, 5, "payroll_schedule")
        sheet1.write(0, 6, "plan")
        sheet1.write(0, 7, "option")
        sheet1.write(0, 8, "COVAT")
        sheet1.write(0, 9, "coverage")
        sheet1.write(0, 10, "DED_LBL_CD")
        sheet1.write(0, 11, "DED_AT")
        sheet1.write(0, 12, "DED_BEGDT")
        sheet1.write(0, 13, "DED_ENDDT")
        sheet1.write(0, 14, "RETROS")
        sheet1.write(0, 15, "CAL_DED_BEGDT")
        sheet1.write(0, 16, "CAL_DED_ENDDT")
        sheet1.write(0, 17, "NO_OF_PAYCYCLES")
        sheet1.write(0, 18, "ROUNDED_NO_OF_PAYCYCLES")
        sheet1.write(0, 19, "CAL_48_WEEK")
        sheet1.write(0, 20, "CAL_YTD_AMOUNT")
        sheet1.write(0, 21, "RETRO_AMOUNT")

        for nadsri in range(0,len(new_align_ded_spec_recds)):
            for nadsrj in range(0,22):
                if nadsrj==0:
                    sheet1.write(nadsri+1, nadsrj, str(int(float(str(str(new_align_ded_spec_recds[nadsri]).split('!')[nadsrj])))).strip(' ').zfill(9))
                else:
                    sheet1.write(nadsri+1, nadsrj, str(new_align_ded_spec_recds[nadsri]).split('!')[nadsrj])

               # elif nadsrj==align_ded_begdt_index:
                #    sheet1.write(nadsri, nadsrj, str(rdate(str(new_align_ded_spec_recds[nadsri]).split('!')[nadsrj])))
                #elif nadsrj==align_ded_enddt_index:
#                    sheet1.write(nadsri, nadsrj, str(rdate(str(new_align_ded_spec_recds[nadsri]).split('!')[nadsrj])))
#                elif nadsrj==cal_beg_dt_index:
 #                   sheet1.write(nadsri, nadsrj, str(rdate(str(new_align_ded_spec_recds[nadsri]).split('!')[nadsrj])))
  #              elif nadsrj==cal_end_dt_index:
   #                 sheet1.write(nadsri, nadsrj, str(rdate(str(new_align_ded_spec_recds[nadsri]).split('!')[nadsrj])))
    #            else:
     #               sheet1.write(nadsri,nadsrj,str(new_align_ded_spec_recds[nadsri]).split('!')[nadsrj])
        print("completed writing into alight merged sheet")
        sheet2 = wb.add_sheet('adp merged')
        sheet2.write(0,0,"adp_emp_ssn")
        sheet2.write(0, 1, "adp_emp_name")
        sheet2.write(0, 2, "adp_emp_status")
        sheet2.write(0, 3, "adp_emp_date")
        sheet2.write(0, 4, "adp_acc_amount")
        for afedi in range(0,len(adp_final_emp_det)):
            sheet2.write(afedi+1,0,str(adp_final_emp_det[afedi]).split('!')[0])
            sheet2.write(afedi+1, 1, str(adp_final_emp_det[afedi]).split('!')[1])
            sheet2.write(afedi+1, 2, str(adp_final_emp_det[afedi]).split('!')[2])
            sheet2.write(afedi+1, 3, str(adp_final_emp_det[afedi]).split('!')[3])
            sheet2.write(afedi+1, 4, str(adp_final_acc_amt[afedi]))
        print("completed writing into adp merged sheet")
        sheet3=wb.add_sheet('adp compare')
        sheet3.write(0,0,"adp_emp_ssn")
        sheet3.write(0, 1, "adp_emp_name")
        sheet3.write(0, 2, "adp_emp_status")
        sheet3.write(0, 3, "adp_emp_date")
        sheet3.write(0, 4, "adp_acc_amount")
        sheet3.write(0, 5, "adp_alight amount")
        sheet3.write(0, 6, "difference(alight-adp)")
        for ad2ali in range(0,len(adp2aligncmp)):
            sheet3.write(ad2ali+1,0,str(adp2aligncmp[ad2ali]).split('!')[0])
            sheet3.write(ad2ali+1, 1, str(adp2aligncmp[ad2ali]).split('!')[1])
            sheet3.write(ad2ali+1, 2,str(adp2aligncmp[ad2ali]).split('!')[2])
            sheet3.write(ad2ali+1, 3,str(adp2aligncmp[ad2ali]).split('!')[3])
            sheet3.write(ad2ali+1, 4, str(adp2aligncmp[ad2ali]).split('!')[4])
            sheet3.write(ad2ali+1, 5, str(adp2aligncmp[ad2ali]).split('!')[5])
            sheet3.write(ad2ali+1, 6, str(adp2aligncmp[ad2ali]).split('!')[6])
        print("completed writing into adp compare sheet")
        sheet4 = wb.add_sheet('alight compare')
        sheet4.write(0,0,"alight_emp_ssn")
        sheet4.write(0, 1, "alight_ytd_amount")
        sheet4.write(0, 2, "adp_acc_amount")
        sheet4.write(0, 3, "difference(alight-adp)")
        for ali2adp in range(0,len(align2adpcmp)):
            sheet4.write(ali2adp+1, 0, str(align2adpcmp[ali2adp]).split('!')[0])
            sheet4.write(ali2adp+1, 1, str(align2adpcmp[ali2adp]).split('!')[1])
            sheet4.write(ali2adp+1, 2, str(align2adpcmp[ali2adp]).split('!')[2])
            sheet4.write(ali2adp+1, 3, str(align2adpcmp[ali2adp]).split('!')[3])
        print("completed writing into alight compare sheet")
        wb.save(wb_name)

        print("completed for dedcode"+str(new_ded_align_list[dedi].strip(' ').upper()))

except Exception as  e1:

    print("error while populating employee and unique employees according to ded codes"+str(e1))
