import os
import time

time.sleep(3600)
os.system("shutdown.exe /h")