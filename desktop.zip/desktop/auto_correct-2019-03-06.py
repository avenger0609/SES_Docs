from autocorrect import spell

print (spell(u'caaaar'))
print (spell(u'twelVEth'))
print (spell(u'survice'))
print (spell(u'hte'))