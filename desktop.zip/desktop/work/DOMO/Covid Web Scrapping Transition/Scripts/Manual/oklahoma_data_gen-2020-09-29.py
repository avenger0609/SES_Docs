# Rference for reading pdf - https://stackoverflow.com/questions/44982406/reading-pdf-files-line-by-line-using-python
import PyPDF2
from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import requests
from pathlib import Path

chrome_driver_url="c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
URL = "https://coronavirus.health.ok.gov/executive-order-reports"
pdf_file_name=Path(r'c:\users\asrilekh\downloads\metadata.pdf')

def data_gen():
    driverpath = chrome_driver_url
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)    
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL)
    time.sleep(60)
    action = ActionChains(driver)
    action.send_keys(Keys.ESCAPE).perform()
    driver.maximize_window()
    dt_str=(driver.find_element_by_xpath('/html/body/div[2]/main/div/div/div[1]/div/div/div[7]/div/div/div[1]/div[1]/div[1]/h3/a').text).replace('Executive Order Report ','')
    pdf_url=driver.find_element_by_xpath('/html/body/div[2]/main/div/div/div[1]/div/div/div[7]/div/div/div[1]/div[1]/div[2]/div/ul/li/div/span/a').get_attribute('href')
    print(pdf_url)
    driver.close()
    response=requests.get(pdf_url)    
    pdf_file_name.write_bytes(response.content)    
    pdfFileObj = open(pdf_file_name, 'rb')
    pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
    print("Number of pages:-"+str(pdfReader.numPages))
    num = pdfReader.numPages
    i =0
    c=""
    while(i<num):    
        pageObj = pdfReader.getPage(i)
        text=pageObj.extractText()
        text1 = text.lower()
        for line in text1:            		
            c=c+line    
        i= i+1

    data=c.split('\n')
    for d in data:
        print(d)
    for di in range(0,len(data)):
        if 'Total Number of Specimens Tested to Date:'.lower() in data[di]:
            print('Total Number of Specimens Tested to Date:')
            pcr_tests=data[di+1].replace(',','')
            print(pcr_tests)
        if 'Total Positive Specimen:'.lower() in data[di]:
            print('Total Positive Specimen:')
            positive_pcr_tests=data[di+1].replace(',','')
            print(positive_pcr_tests)
        if 'Percent Positive:'.lower() in data[di]:
            print('Percent Positive')
            tests_positivity=data[di+1].replace(',','')
            print(tests_positivity)
        if 'Total Deaths:'.lower() in data[di]:
            print('Total Deaths:')
            deaths=data[di+1].replace(',','')
            print(deaths)
        if 'COVID-19 Cases Currently Hospitalized:'.lower() in data[di]:
            print('COVID-19 Cases Currently Hospitalized:')
            # 496 (206 in icu)
            temp=data[di+1]
            covid_hospitalizations=temp.split('(')[0].strip(' ').replace(',','')
            icu_hospitalization=(temp.split('(')[1]).split(' ')[0].replace(',','')
            print(covid_hospitalizations)
            print(icu_hospitalization)
        if 'Ventilators Available:'.lower() in data[di]:
            print('Ventilators Available:')
            vent_available=data[di+1].split(' ')[0].replace(',','')
            print(vent_available)
        if '(active cases):'.lower() in data[di]:
            print('(active cases):')
            print(data[di+1]) ## total-cases
            tc=int(data[di+1].replace(',','').strip(' '))

    df=pd.DataFrame()
    df['Number of COVID-19 Tests (PCR)']=[pcr_tests]
    df['Positive COVID-19 Tests (PCR)']=[positive_pcr_tests]
    df['COVID-19 Test Positivity %']=[tests_positivity]
    df['Deaths']=[deaths]
    df['Current COVID Hospitalizations']=[covid_hospitalizations]
    df['Current COVID ICU patients']=[icu_hospitalization]
    df['Hospital Vent capacity']=vent_available
    df['State']='Oklahoma'
    # dt_str='9/25/2020'
    df['Date']=dt_str

    for c in ['County','State_County_Id','FIPS Code','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
        if c not in ['Date','State','Hospital Vent capacity','Current COVID ICU patients','Current COVID Hospitalizations','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths']:
            df[c]=""

    df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]

    df.to_csv(r'Oklahoma_State_File.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')

    age_group=[]
    cases_by_age_group=[]
    deaths_by_age_group=[]
    age_start_line=data.index('00-04')
    ## 1
    age_group.append('00-04')
    temp=data[age_start_line+1].strip(' ').replace(',','')
    cases_by_age_group.append(temp)
    temp=data[age_start_line+2].replace('05-17','').strip(' ').replace(',','')
    deaths_by_age_group.append(temp)
    ## 1

    ## 2
    age_group.append('05-17')
    temp=data[age_start_line+3].strip(' ').replace(',','')
    cases_by_age_group.append(temp)
    temp=data[age_start_line+4].replace('18-35','').strip(' ').replace(',','')
    deaths_by_age_group.append(temp)
    ## 2

    ## 3
    age_group.append('18-35')
    temp=data[age_start_line+5].strip(' ').replace(',','')
    cases_by_age_group.append(temp)
    temp=data[age_start_line+6].replace('36-49','').strip(' ').replace(',','')
    deaths_by_age_group.append(temp)
    ## 3

    ## 4
    age_group.append('36-49')
    temp=data[age_start_line+7].strip(' ').replace(',','')
    cases_by_age_group.append(temp)
    temp=data[age_start_line+8].replace('50-64','').strip(' ').replace(',','')
    deaths_by_age_group.append(temp)
    ## 4

    ## 5
    age_group.append('50-64')
    temp=data[age_start_line+9].strip(' ').replace(',','')
    cases_by_age_group.append(temp)
    temp=data[age_start_line+10].replace('65+','').strip(' ').replace(',','')
    deaths_by_age_group.append(temp)
    ## 5

    ## 6
    age_group.append('65+')
    temp=data[age_start_line+11].strip(' ').replace('65+','').replace(',','')
    cases_by_age_group.append(temp)
    temp=data[age_start_line+12].replace('unknown','').strip(' ').replace(',','')
    deaths_by_age_group.append(temp)
    ## 6

    ## 7
    age_group.append('Unknown')
    # temp=data[age_start_line+13].strip(' ').replace(',','')
    # cases_by_age_group.append(temp)
    temp=data[age_start_line+13].replace('mean','').strip(' ').replace(',','')
    tc_temp=0
    for ti in cases_by_age_group:
        tc_temp=int(ti)+tc_temp
    tc_temp=str(tc-tc_temp)
    cases_by_age_group.append(tc_temp)
    deaths_by_age_group.append(str(temp.replace(tc_temp,'')))
    # deaths_by_age_group.append(temp)
    ## 7

    print(age_group)
    print(cases_by_age_group)
    print(deaths_by_age_group)

    df=pd.DataFrame()
    df['Age Group']=age_group
    df['Positive COVID-19 Tests (PCR)']=cases_by_age_group
    df['Deaths']=deaths_by_age_group
    df['State']='Oklahoma'

    for c in ['State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']:
        if c not in ['Age Group','Positive COVID-19 Tests (PCR)','Deaths','State']:
            df[c]=""

    df['Date']=dt_str

    df=df[['State','Age Group','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']]

    df.to_csv(r'Oklahoma_Age_Group_File.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')

data_gen()
