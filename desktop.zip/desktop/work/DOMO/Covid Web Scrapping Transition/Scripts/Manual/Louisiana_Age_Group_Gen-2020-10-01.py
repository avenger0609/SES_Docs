import pandas as pd
import time
from selenium import webdriver
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os
from datetime import datetime
import csv
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select

driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
download_dir=r'C:\users\asrilekh\downloads'

def data_gen():    

    # try:
    #     os.unlink(download_dir+"\\age group.xlsx")
    # except:
    #     pass

    URL='https://www.arcgis.com/apps/opsdashboard/index.html#/4a6de226701e45bdb542f09b73ee79e1'
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    
    driver = webdriver.Chrome(executable_path=driverpath,
                            chrome_options=chromeOptions)
    ## needed     

    # driver.get(URL)
    # timeout = 60
    # time.sleep(timeout)
    # driver.maximize_window()
    # els=driver.find_elements_by_class_name('responsive-text-label')
    
    # print(els[7].text)
    # print(els[9].text)
    # print(els[11].text)
    # print(els[20].text)
    # print(els[23].text)

    ## needed 


    # time.sleep(timeout)
    # # driver.switch_to_frame('//*[@id="ember219"')
    # driver.find_element_by_class_name('nav-btn').click()
    # print("clicked")
    # time.sleep(30)
    # driver.find_element_by_class_name('nav-btn').click()
    # print("clicked")
    # time.sleep(180)

    # action = ActionChains(driver)
    # action.send_keys(Keys.TAB).perform()
    # time.sleep(10)

    driver.get('https://ladhh.maps.arcgis.com/apps/webappviewer/index.html?id=3b9b6f22d92f4d688f1c21e9d154cae2')
    time.sleep(120)

    print(1)

    action = ActionChains(driver)
    action.send_keys(Keys.TAB).perform()
    time.sleep(10)

    print(2)

    action = ActionChains(driver)
    action.send_keys(Keys.TAB).perform()
    time.sleep(10)

    print(3)

    action = ActionChains(driver)
    action.send_keys(Keys.TAB).perform()
    time.sleep(10)

    print(4)

    action = ActionChains(driver)
    action.send_keys(Keys.TAB).perform()
    time.sleep(10)

    print(5)

    # action = ActionChains(driver)
    # action.send_keys(Keys.TAB).perform()
    # time.sleep(10)

    # print(6)

    # action = ActionChains(driver)
    # action.send_keys(Keys.TAB).perform()
    # time.sleep(10)

    # print(7)

    # action = ActionChains(driver)
    # action.send_keys(Keys.TAB).perform()
    # time.sleep(10)

    # print(8)

    # action = ActionChains(driver)
    # action.send_keys(Keys.TAB).perform()
    # time.sleep(10)

    # print(9)

    # for i in range(0,9):
    #     action = ActionChains(driver)
    #     action.send_keys(Keys.TAB).perform()
    #     time.sleep(10)
    action = ActionChains(driver)
    action.send_keys(Keys.ENTER).perform() 
    print('clicked on enter')

    time.sleep(30)

    



    # tabs = class tabLabel
    # options = id dijit_form_DropDownButton_0_label and 2nd element in result
    # export to csv = id dijit_MenuItem_4_text only single element in result

    tab_els=driver.find_elements_by_class_name('tabLabel')
    for tei in range(0,len(tab_els)):
        tab_els[tei].click()
        time.sleep(20)
        # option_el=
        (driver.find_elements_by_id('dijit_form_DropDownButton_0_label'))[0].click()
        time.sleep(10)
        # export_el=
        driver.find_element_by_id('dijit_MenuItem_4_text').click()
        time.sleep(10)
        action = ActionChains(driver)
        action.send_keys(Keys.TAB).perform() 
        print('clicked tab')
        time.sleep(5)
        action = ActionChains(driver)
        action.send_keys(Keys.ENTER).perform() 
        print('clicked on enter')

        time.sleep(30)

        driver.get('https://ladhh.maps.arcgis.com/apps/webappviewer/index.html?id=3b9b6f22d92f4d688f1c21e9d154cae2')
        time.sleep(120)

        print(1)

        action = ActionChains(driver)
        action.send_keys(Keys.TAB).perform()
        time.sleep(10)

        print(2)

        action = ActionChains(driver)
        action.send_keys(Keys.TAB).perform()
        time.sleep(10)

        print(3)

        action = ActionChains(driver)
        action.send_keys(Keys.TAB).perform()
        time.sleep(10)

        print(4)

        action = ActionChains(driver)
        action.send_keys(Keys.TAB).perform()
        time.sleep(10)

        print(5)

        action = ActionChains(driver)
        action.send_keys(Keys.ENTER).perform() 
        print('clicked on enter')

        time.sleep(30)



    # hospitalized ccovid patients on vents by day
    # driver.find_element_by_xpath('//*[@id="dijit_layout_TabContainer_0_tablist_dijit_layout_ContentPane_0"]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_form_DropDownButton_0"]/span[3]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_MenuItem_4_text"]').click()
    # time.sleep(30)

    # #bed availability by region
    # driver.find_element_by_xpath('//*[@id="dijit_layout_TabContainer_0_tablist_dijit_layout_ContentPane_2"]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_form_DropDownButton_2"]/span[3]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_MenuItem_12_text"]').click()
    # time.sleep(30)

    # # icu bed availability by region
    # driver.find_element_by_xpath('//*[@id="dijit_layout_TabContainer_0_tablist_dijit_layout_ContentPane_3"]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_form_DropDownButton_3"]/span[3]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_MenuItem_16_text"]').click()
    # time.sleep(30)

    # # hospital bed availabilty by region
    # driver.find_element_by_xpath('//*[@id="dijit_layout_TabContainer_0_tablist_dijit_layout_ContentPane_4"]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_form_DropDownButton_4"]/span[3]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_MenuItem_20_text"]').click()
    # time.sleep(30)

    # # cases and deaths by age
    # driver.find_element_by_xpath('//*[@id="dijit_layout_TabContainer_0_tablist_dijit_layout_ContentPane_6"]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_form_DropDownButton_6"]/span[3]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_MenuItem_28_text"]').click()
    # time.sleep(30)

    # # by parish
    # driver.find_element_by_xpath('//*[@id="dijit_layout_TabContainer_0_tablist_dijit_layout_ContentPane_10"]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_form_DropDownButton_10"]/span[3]').click()
    # time.sleep(10)
    # driver.find_element_by_xpath('//*[@id="dijit_MenuItem_44_text"]').click()
    # time.sleep(30)




    # tab_pane=driver.find_element_by_xpath('//*[@id="dijit_layout_TabContainer_0_tablist"]')

    time.sleep(1800)
    # pane=driver.find_element_by_class_name('nowrapTabStrip dijitTabContainerTop-tabs')
    # driver.switch_to_frame('//*[@id="ember219"')
    # driver.find_element_by_xpath('//*[@id="ember389"]').click()
    # driver.find_element_by_xpath('//*[@id="ember389"]').click()
    # driver.find_element_by_xpath('//*[@id="widgets_Splash_Widget_14"]/div[2]/div[2]/div[2]/button').click()

    # // https://www.arcgis.com/apps/opsdashboard/index.html#/4a6de226701e45bdb542f09b73ee79e1
        # iframe xpath //*[@id="ember219"]
        #  //*[@id="ember389"] left arrow - 2times click
        # //*[@id="widgets_Splash_Widget_14"]/div[2]/div[2]/div[2]/button - ok click
        # parent div : //*[@id="dijit_layout_TabContainer_0_tablist"]/div[4]/div/div[1]
        # child div : 
   

    # driver.switch_to_frame(driver.find_element_by_xpath('//*[@id="covid-dashboard"]/iframe'))
    # print(driver.find_element_by_xpath('//*[@id="ember1070"]/svg/g[2]/svg/text').text) # confirmed
    # print(driver.find_elements_by_xpath('//*[@id="ember1259"]/svg/g[2]/svg/text').text) # deaths
    # print(driver.find_elements_by_xpath('//*[@id="ember1257"]/svg/g[2]/svg/text').text) # tests
    # print(driver.find_elements_by_xpath('//*[@id="ember1066"]/svg/g[2]/svg/text').text) # covid hospitalizations
    # print(driver.find_elements_by_xpath('//*[@id="ember932"]/svg/g[2]/svg/text').text) # vents
    
    # tbody_xpath='//*[@id="download-ToolbarButton"]'
    # try:
    #     time.sleep(timeout)        
    #     driver.switch_to_frame(driver.find_element_by_xpath('//*[@id="ng-app"]/body/div[1]/div[2]/section/div/div[2]/section[2]/figure/js-api-viz/div/iframe'))
    #     element_present = EC.presence_of_element_located(
    #         (By.XPATH, tbody_xpath))
    #     WebDriverWait(driver, timeout).until(element_present)
    #     (driver.find_element_by_xpath(tbody_xpath).click())
    #     time.sleep(30)
    #     driver.find_element_by_xpath('//*[@id="DownloadDialog-Dialog-Body-Id"]/div/button[3]').click()
    #     # time.sleep(30)
    #     # driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[1]/div[2]/div/div/div[3]/div/div/div').click()
    #     # time.sleep(30)
    #     # driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[1]/button').click()
    #     action = ActionChains(driver)
    #     action.send_keys(Keys.ENTER).perform()
    #     time.sleep(60)
    #     driver.close()

    # except Exception as e:
    #     print(str(e))
    #     print('[loop]: Uncaught - '+(type(e).__name__))
    #     # page_lang.append('')
    # finally:
        
        # df=pd.read_excel(download_dir+"\\age group.xlsx", header=None)
        # df.columns=['Age Group','COVID-19 Test Positivity %']
        # print(df.columns)
        # # df=pd.DataFrame()
        # # df['Age Group']=age_group
        # # df['Positive COVID-19 Tests (PCR)']=cases_by_age_group
        # # df['Deaths']=deaths_by_age_group
        # df['State']='Wyomhing'

        # for c in ['Age Group','Positive COVID-19 Tests (PCR)','Deaths','State','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']:
        #     if c not in ['Age Group','COVID-19 Test Positivity %','Date','State']:
        #         df[c]=""

        # dt_str='9/30/2020'
        # df['Date']=dt_str

        # df=df[['State','Age Group','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']]

        
        # df.to_csv(r'WY_Age_Group.csv',index=False,quoting=csv.QUOTE_ALL)
        # driver.close()
        # pass

        # // https://www.arcgis.com/apps/opsdashboard/index.html#/4a6de226701e45bdb542f09b73ee79e1
        # iframe xpath //*[@id="ember219"]
        #  //*[@id="ember389"] left arrow - 2times click
        # //*[@id="widgets_Splash_Widget_14"]/div[2]/div[2]/div[2]/button - ok click
        # parent div : //*[@id="dijit_layout_TabContainer_0_tablist"]/div[4]/div/div[1]
        # child div : 


data_gen()