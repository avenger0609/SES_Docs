from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
URL = "https://msdh.ms.gov/msdhsite/_static/14,0,420.html"
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get(URL)
time.sleep(120)
county_name=[]
cases=[]
deaths=[]
def month_string_to_number(string):
    m = {
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr':4,
         'may':5,
         'jun':6,
         'jul':7,
         'aug':8,
         'sep':9,
         'oct':10,
         'nov':11,
         'dec':12
        }
    s = string.strip()[:3].lower()

    try:
        out = m[s]
        return out
    except:
        raise ValueError('Not a month')

try:

    dt_str=(driver.find_element_by_xpath('//*[@id="article"]/div/h3[1]').text).replace('New Cases and Deaths as of ','').strip(' ')
    mon=month_string_to_number(dt_str.split(' ')[0])
    dt=dt_str.split(' ')[1]
    yr=datetime.now().strftime('%Y')
    dt_str=str(mon)+'/'+str(dt)+"/"+str(yr)
    table_id=driver.find_element_by_xpath('//*[@id="msdhTotalCovid-19Cases"]')
    # print("entered-1")
    table_data_id=driver.find_element_by_xpath('//*[@id="msdhTotalCovid-19Cases"]/tbody')
    parent_rows=table_data_id.find_elements_by_tag_name('tr')
    # print("entered-2"+str(len(parent_rows)))
    
    for pr in parent_rows:
        time.sleep(2)
        # print("entered-3")
        try:
            tdr=pr.find_elements_by_tag_name('td')
            # print("entered-4"+str(len(tdr)))
            county_name.append(pr.find_elements_by_tag_name('td')[0].text)
            cases.append(pr.find_elements_by_tag_name('td')[1].text)
            deaths.append(pr.find_elements_by_tag_name('td')[2].text)    
        except Exception as e:
            print(str(e))
            
except Exception as e:
    print(str(e))
finally:
    driver.close()
    print(len(county_name))
    print(len(cases))
    print(len(deaths))
    df=pd.DataFrame()
    df['County']=county_name
    df['Positive COVID-19 Tests']=cases
    df['Deaths']=cases
    df['Date']=dt_str
    df['State']='Mississippi'

    for c in ['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests ','Positive COVID-19 Tests','COVID-19 Test Positivity %','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
        if c not in ['Date','State','County','Deaths','Positive COVID-19 Tests']:
            df[c]=""

    df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests ','Positive COVID-19 Tests','COVID-19 Test Positivity %','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]

    df.to_csv(r'Mississippi_County_Data.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')
