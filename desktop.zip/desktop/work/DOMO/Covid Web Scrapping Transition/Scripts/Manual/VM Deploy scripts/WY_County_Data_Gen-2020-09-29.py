import pandas as pd
import time
from selenium import webdriver
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os
from datetime import datetime
import csv

driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
download_dir=r'C:\users\asrilekh\downloads'


def cumulative_cases_gen():

    URL1="https://health.wyo.gov/publichealth/infectious-disease-epidemiology-unit/disease/novel-coronavirus/"

    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL1)
    html = driver.page_source
    time.sleep(2)
    # print(html)
    html=str(html)
    content_start=str(html).index('<p><strong>Albany',0)
    content_end=str(html).index('</p>',content_start)
    data=html[content_start:content_end]
    data=str(data).replace('<strong>','').replace('<strong>','').replace('<p>','').replace('<br />','').replace('</strong>',';').replace('<br>','')
    data_lst=str(data).split(';')
    county_lst=[]
    value_lst=[]
    for i in data_lst:
        if len(i.strip(' '))==0:
            continue
        county_lst.append(i.split(':')[0].strip(' '))
        value_lst.append((i.split(':')[1]).split('(')[0].strip(' '))
    print(len(county_lst))
    print(len(value_lst))
    df=pd.DataFrame()
    df['county']=county_lst
    df['Positive COVID-19 Tests']=value_lst    
    # df.to_csv(r'WY_County_Cumulative_cases.csv',index=False,quoting=csv.QUOTE_ALL)
    driver.close()
    return df


def WY_data_gen():

    cum_county_df=cumulative_cases_gen()

    try:
        os.unlink(download_dir+"\\map.xlsx")
    except:
        pass

    URL='https://public.tableau.com/profile/melissa.taylor#!/vizhome/shared/8BBTPD39D'
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    
    driver = webdriver.Chrome(executable_path=driverpath,
                            chrome_options=chromeOptions)
    driver.get(URL)
    timeout = 60
    driver.maximize_window()
    tbody_xpath='//*[@id="download-ToolbarButton"]'
    try:
        time.sleep(timeout)        
        driver.switch_to_frame(driver.find_element_by_xpath('//*[@id="ng-app"]/body/div[1]/div[2]/section/div/div[2]/section[2]/figure/js-api-viz/div/iframe'))
        element_present = EC.presence_of_element_located(
            (By.XPATH, tbody_xpath))
        WebDriverWait(driver, timeout).until(element_present)
        (driver.find_element_by_xpath(tbody_xpath).click())
        time.sleep(30)
        driver.find_element_by_xpath('//*[@id="DownloadDialog-Dialog-Body-Id"]/div/button[3]').click()
        time.sleep(30)
        driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[1]/div[2]/div/div/div[3]/div/div/div').click()
        time.sleep(30)
        driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[3]/button').click()
        print(download_dir+"\\map.xlsx")
        df=pd.read_excel(download_dir+"\\map.xlsx")
        df=df.merge(cum_county_df,how="inner",on=['county'])
        print(df.columns)
        df.to_csv(r'WY_County_Test.csv',index=False,quoting=csv.QUOTE_ALL)


    except TimeoutException:    
        print("[loop]: Timed out waiting for page load")
    except KeyboardInterrupt:
        print("[loop]: Keyboard Interrupt")
    except Exception as e:
        print('[loop]: Uncaught - '+(type(e).__name__))
        # page_lang.append('')
    finally:
        # driver.close()
        pass

WY_data_gen()