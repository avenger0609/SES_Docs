import pandas as pd
import time
from selenium import webdriver
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os
from datetime import datetime
import csv
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select

driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
download_dir=r'C:\users\asrilekh\downloads'

def WY_data_gen():

    

    # try:
    #     os.unlink(download_dir+"\\age group.xlsx")
    # except:
    #     pass

    URL='https://public.tableau.com/profile/melissa.taylor#!/vizhome/shared/8BBTPD39D'
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    
    driver = webdriver.Chrome(executable_path=driverpath,
                            chrome_options=chromeOptions)
    driver.get(URL)
    timeout = 60
    driver.maximize_window()
    tbody_xpath='//*[@id="download-ToolbarButton"]'
    try:
        time.sleep(timeout)        
        driver.switch_to_frame(driver.find_element_by_xpath('//*[@id="ng-app"]/body/div[1]/div[2]/section/div/div[2]/section[2]/figure/js-api-viz/div/iframe'))
        element_present = EC.presence_of_element_located(
            (By.XPATH, tbody_xpath))
        WebDriverWait(driver, timeout).until(element_present)
        (driver.find_element_by_xpath(tbody_xpath).click())
        time.sleep(30)
        driver.find_element_by_xpath('//*[@id="DownloadDialog-Dialog-Body-Id"]/div/button[3]').click()
        # time.sleep(30)
        # driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[1]/div[2]/div/div/div[3]/div/div/div').click()
        # time.sleep(30)
        # driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[1]/button').click()
        action = ActionChains(driver)
        action.send_keys(Keys.ENTER).perform()
        time.sleep(60)
        driver.close()

    except Exception as e:
        print(str(e))
        print('[loop]: Uncaught - '+(type(e).__name__))
        # page_lang.append('')
    finally:
        
        df=pd.read_excel(download_dir+"\\age group.xlsx", header=None)
        df.columns=['Age Group','COVID-19 Test Positivity %']
        print(df.columns)
        # df=pd.DataFrame()
        # df['Age Group']=age_group
        # df['Positive COVID-19 Tests (PCR)']=cases_by_age_group
        # df['Deaths']=deaths_by_age_group
        df['State']='Wyomhing'

        for c in ['Age Group','Positive COVID-19 Tests (PCR)','Deaths','State','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']:
            if c not in ['Age Group','COVID-19 Test Positivity %','Date','State']:
                df[c]=""

        dt_str='9/30/2020'
        df['Date']=dt_str

        df=df[['State','Age Group','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']]

        
        df.to_csv(r'WY_Age_Group.csv',index=False,quoting=csv.QUOTE_ALL)
        driver.close()
        pass

WY_data_gen()