import pandas as pd
import time
from selenium import webdriver
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os
from datetime import datetime
import csv

driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
download_dir=r'C:\users\asrilekh\downloads'

def WY_map_xlsx_file():

    URL='https://public.tableau.com/profile/melissa.taylor#!/vizhome/shared/8BBTPD39D'
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    
    driver = webdriver.Chrome(executable_path=driverpath,
                            chrome_options=chromeOptions)
    driver.get(URL)
    timeout = 60
    driver.maximize_window()
    tbody_xpath='//*[@id="download-ToolbarButton"]'
    try:
        time.sleep(timeout)        
        driver.switch_to_frame(driver.find_element_by_xpath('//*[@id="ng-app"]/body/div[1]/div[2]/section/div/div[2]/section[2]/figure/js-api-viz/div/iframe'))
        element_present = EC.presence_of_element_located(
            (By.XPATH, tbody_xpath))
        WebDriverWait(driver, timeout).until(element_present)
        (driver.find_element_by_xpath(tbody_xpath).click())
        time.sleep(30)
        driver.find_element_by_xpath('//*[@id="DownloadDialog-Dialog-Body-Id"]/div/button[3]').click()
        time.sleep(30)
        driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[1]/div[2]/div/div/div[3]/div/div/div').click()
        time.sleep(30)
        driver.find_element_by_xpath('//*[@id="export-crosstab-options-dialog-Dialog-BodyWrapper-Dialog-Body-Id"]/div/div[3]/button').click()
 
    except Exception as e:
        print(str(e))
    finally:
        driver.close()



