import PyPDF2
from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import requests
from pathlib import Path
import pandas as pd
import time
from selenium import webdriver
from datetime import datetime
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os
from datetime import datetime
import csv
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select

driverpath =  "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
download_dir=r'C:\users\asrilekh\downloads'
Manual_output_dir='C:\\Users\\asrilekh\\Desktop\\work\\DOMO\\Covid Web Scrapping Transition\\Scripts\\Manual\\VM Deploy scripts\\'

def month_string_to_number(string):
    m = {
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr':4,
         'may':5,
         'jun':6,
         'jul':7,
         'aug':8,
         'sep':9,
         'oct':10,
         'nov':11,
         'dec':12
        }
    s = string.strip()[:3].lower()

    try:
        out = m[s]
        return out
    except:
        raise ValueError('Not a month')

def WY_cumulative_cases_gen():

    URL1="https://health.wyo.gov/publichealth/infectious-disease-epidemiology-unit/disease/novel-coronavirus/"

    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL1)
    html = driver.page_source
    time.sleep(2)
    # print(html)
    html=str(html)
    content_start=str(html).index('<p><strong>Albany',0)
    content_end=str(html).index('</p>',content_start)
    data=html[content_start:content_end]
    data=str(data).replace('<strong>','').replace('<strong>','').replace('<p>','').replace('<br />','').replace('</strong>',';').replace('<br>','')
    data_lst=str(data).split(';')
    county_lst=[]
    value_lst=[]
    for i in data_lst:
        if len(i.strip(' '))==0:
            continue
        county_lst.append(i.split(':')[0].strip(' '))
        value_lst.append((i.split(':')[1]).split('(')[0].strip(' '))
    print(len(county_lst))
    print(len(value_lst))
    df=pd.DataFrame()
    df['county']=county_lst
    df['Positive COVID-19 Tests']=value_lst    
    # df.to_csv(r'WY_County_Cumulative_cases.csv',index=False,quoting=csv.QUOTE_ALL)
    driver.close()
    return df

def WY_county_test_gen():

    cum_county_df=WY_cumulative_cases_gen()    
    try:     
        
        df=pd.read_excel(download_dir+"\\map.xlsx")
        df=df.merge(cum_county_df,how="inner",on=['county'])
        print(df.columns)
        df.to_csv(Manual_output_dir+r'WY_County_Test.csv',index=False,quoting=csv.QUOTE_ALL)

    except Exception as e:
        print(str(e))
    
def WY_age_group_gen():

    URL1="https://health.wyo.gov/publichealth/infectious-disease-epidemiology-unit/disease/novel-coronavirus/"

    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL1)
    time.sleep(60)
    #to extract updated date 
    dt_str=driver.find_element_by_xpath('//*[@id="et-boc"]/div/div/div/div[4]/div[1]/div[1]/div/p/strong').text
    time.sleep(10)
    driver.close()            
    df=pd.read_excel(download_dir+"\\age group.xlsx", header=None)
    df.columns=['Age Group','COVID-19 Test Positivity %']
    print(df.columns)
    df['State']='Wyoming'

    for c in ['Age Group','Positive COVID-19 Tests (PCR)','Deaths','State','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']:
        if c not in ['Age Group','COVID-19 Test Positivity %','Date','State']:
            df[c]=""
    
    df['Date']=dt_str
    df=df[['State','Age Group','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']]
    
    df.to_csv(Manual_output_dir+'WY_Age_Group.csv',index=False,quoting=csv.QUOTE_ALL)
    
def Mississippi_county_data_gen():

    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    URL = "https://msdh.ms.gov/msdhsite/_static/14,0,420.html"
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL)
    time.sleep(120)
    county_name=[]
    cases=[]
    deaths=[]

    try:

        dt_str=(driver.find_element_by_xpath('//*[@id="article"]/div/h3[1]').text).replace('New Cases and Deaths as of ','').strip(' ')
        mon=month_string_to_number(dt_str.split(' ')[0])
        dt=dt_str.split(' ')[1]
        yr=datetime.now().strftime('%Y')
        dt_str=str(mon)+'/'+str(dt)+"/"+str(yr)
        table_id=driver.find_element_by_xpath('//*[@id="msdhTotalCovid-19Cases"]')        
        table_data_id=driver.find_element_by_xpath('//*[@id="msdhTotalCovid-19Cases"]/tbody')
        parent_rows=table_data_id.find_elements_by_tag_name('tr')
        
        for pr in parent_rows:
            time.sleep(2)
            try:
                tdr=pr.find_elements_by_tag_name('td')
                county_name.append(pr.find_elements_by_tag_name('td')[0].text)
                cases.append(pr.find_elements_by_tag_name('td')[1].text)
                deaths.append(pr.find_elements_by_tag_name('td')[2].text)    
            except Exception as e:
                print(str(e))
                
    except Exception as e:
        print(str(e))
    finally:
        driver.close()
        df=pd.DataFrame()
        df['County']=county_name
        df['Positive COVID-19 Tests']=cases
        df['Deaths']=cases
        df['Date']=dt_str
        df['State']='Mississippi'

        for c in ['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests','Positive COVID-19 Tests','COVID-19 Test Positivity %','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
            if c not in ['Date','State','County','Deaths','Positive COVID-19 Tests']:
                df[c]=""

        df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests','Positive COVID-19 Tests','COVID-19 Test Positivity %','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]

        df.to_csv(Manual_output_dir+'Mississippi_County_Data.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')       

def Louisiana_parish_data_gen():

    URL1=r"https://public.tableau.com/views/COVID19demog/DataonCOVIN-19RelatedDeathsToDate?:embed=y&:showVizHome=no&:host_url=https%3A%2F%2Fpublic.tableau.com%2F&:embed_code_version=3&:device=phone&:tabs=no&:toolbar=no&:showAppBanner=false&:display_spinner=no&:loadOrderID=1"

    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL1)
    time.sleep(60)
    #to extract updated date 
    dt_temp=driver.find_element_by_xpath('//*[@id="tabZoneId12"]/div/div/div/div[1]/div/span/div/span').text
    dt_str=dt_temp.split(' ')[-1].replace('.','')
    print(dt_str)    
    time.sleep(10)
    driver.close()   

    df=pd.read_csv(download_dir+"\\Parish Level Data.csv")
    for c in ['Count']:
        df[c]=pd.to_numeric(df[c], errors='coerce', downcast='unsigned')
        df[c]=df[c].fillna(0)
    
    df_cases=df[df['Measure']=='Case Count']
    df_deaths=df[df['Measure']=='Deaths']
    df_comm_tests=df[df['Measure']=='Commercial Tests']
    df_state_tests=df[df['Measure']=='State Tests']

    df_cases=df_cases[['Parish','Count']]
    df_cases['Positive COVID-19 Tests']=df_cases['Count']
    df_cases=df_cases[['Parish','Positive COVID-19 Tests']]

    df_deaths=df_deaths[['Parish','Count']]
    df_deaths['Deaths']=df_deaths['Count']
    df_deaths=df_deaths[['Parish','Deaths']]

    df_comm_tests=df_comm_tests[['Parish','Count']]
    df_comm_tests['Comm Tests']=df_comm_tests['Count']
    df_comm_tests=df_comm_tests[['Parish','Comm Tests']]

    df_state_tests=df_state_tests[['Parish','Count']]
    df_state_tests['State Tests']=df_state_tests['Count']
    df_state_tests=df_state_tests[['Parish','State Tests']]

    df_tests=pd.merge(df_state_tests,df_comm_tests,how='outer',on=['Parish'])
    df_tests['Number of COVID-19 Tests']=df_tests['State Tests']+df_tests['Comm Tests']
    df_tests=df_tests[['Parish','Number of COVID-19 Tests']]

    df_final=pd.merge(df_cases,df_deaths,how='outer',on=['Parish'])
    df_final=pd.merge(df_final,df_tests,how='outer',on=['Parish'])
    df_final['State']='Louisiana'
    df_final['Date']=dt_str
    df_final['County']=df_final['Parish']
    df=df_final

    for c in ['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests','Positive COVID-19 Tests','COVID-19 Test Positivity %','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
        if c not in ['Date','State','County','Deaths','Positive COVID-19 Tests','Number of COVID-19 Tests']:
            df[c]=""

    df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests','Positive COVID-19 Tests','COVID-19 Test Positivity %','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]
    df.to_csv(Manual_output_dir+'Louisiana_County_Data.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')    
    
def Louisiana_age_group_data_gen():

    URL1=r"https://public.tableau.com/views/COVID19demog/DataonCOVIN-19RelatedDeathsToDate?:embed=y&:showVizHome=no&:host_url=https%3A%2F%2Fpublic.tableau.com%2F&:embed_code_version=3&:device=phone&:tabs=no&:toolbar=no&:showAppBanner=false&:display_spinner=no&:loadOrderID=1"

    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL1)
    time.sleep(60)
    #to extract updated date 
    dt_temp=driver.find_element_by_xpath('//*[@id="tabZoneId12"]/div/div/div/div[1]/div/span/div/span').text
    dt_str=dt_temp.split(' ')[-1].replace('.','')
    print(dt_str)    
    time.sleep(10)
    driver.close()   

    df=pd.read_csv(download_dir+"\\Cases and Deaths by age.csv")
    for c in ['Cumulative Count']:
        df[c]=pd.to_numeric(df[c], errors='coerce', downcast='unsigned')
        df[c]=df[c].fillna(0)
    
    df_cases=df[df['Count Type']=='case']
    df_deaths=df[df['Count Type']=='death']

    df_cases=df_cases[['Age Group','Cumulative Count']]
    df_cases['Positive COVID-19 Tests (PCR)']=df_cases['Cumulative Count']
    df_cases=df_cases[['Age Group','Positive COVID-19 Tests (PCR)']]

    df_deaths=df_deaths[['Age Group','Cumulative Count']]
    df_deaths['Deaths']=df_deaths['Cumulative Count']
    df_deaths=df_deaths[['Age Group','Deaths']]

    

    df_final=pd.merge(df_cases,df_deaths,how='outer',on=['Age Group'])
    # df_final=pd.merge(df_final,df_tests,how='outer',on=['Age Group'])
    df_final['State']='Louisiana'
    df_final['Date']=dt_str


    df=df_final

    for c in ['State','Age Group','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']:
        if c not in ['Date','State','Deaths','Positive COVID-19 Tests (PCR)']:
            df[c]=""

    df=df[['State','Age Group','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Deaths','Last Updated date from API']]
    df.to_csv(Manual_output_dir+'Louisiana_Age_Group.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')    

def Mississippi_icu_vents_hospitalizations():
    # driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    URL = "https://app.powerbigov.us/view?r=eyJrIjoiNzhkM2M5YzItMWM4OC00YmI1LWEyMTktNDUxNjQ5YjVkM2U1IiwidCI6IjU1OTA0MmRjLThiZjAtNGQ4Ni05ZmMwLWZiZjRjNzUwM2M3OSJ9"
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL)

    time.sleep(60)
    driver.maximize_window()

    time.sleep(10)

    source=driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/div/div/div')
    source=driver.find_element_by_class_name('preTextWithEllipsis')
    # source.click()
    action = ActionChains(driver)
    action.context_click(source).perform()
    time.sleep(10)
    action = ActionChains(driver)
    action.send_keys(Keys.ENTER).perform()

    time.sleep(60)
    # driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/visual-modern/div/svg/svg/g[1]/svg[1]/rect').click()
    # action.context_click()

    # driver.find_element_by_xpath('//*[@id="contextmenu-label-text5"]').click()
    # try:
    #     driver.find_element_by_class_name('itemLabel trimmedTextWithEllipsis').click()
    # except Exception as e:
    #     print(str(e)+"-1")

    # try:
    #     driver.find_element_by_xpath('/html/body/div[5]/drop-down-list/ng-transclude/ng-repeat/drop-down-list-item/ng-transclude/ng-switch/div').click()
    # except Exception as e:
    #     print(str(e)+"-2")

    # time.sleep(60)

    date_lst=[]
    patients_with_confirmed_infection=[]
    patients_with_suspected_infection=[]
    patients_in_ICU=[]
    patients_on_ventilators=[]

    driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/visual-container-header-modern/div/div[1]/div/visual-header-item-container[2]/div/button').click()

    for i in range(1,22):
        date_lst.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[3]/div/div['+str(i)+']').text)

    for i in range(1,21):
        patients_with_confirmed_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[1]/div['+str(i)+']').text)

    patients_with_confirmed_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[1]/div').text)


    for i in range(1,21):
        patients_with_suspected_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[2]/div['+str(i)+']').text)

    patients_with_suspected_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[2]/div').text)

    for i in range(1,21):
        patients_in_ICU.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[3]/div['+str(i)+']').text)

    patients_in_ICU.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[3]/div').text)

    for i in range(1,21):
        patients_on_ventilators.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[4]/div['+str(i)+']').text)

    patients_on_ventilators.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[4]/div').text)

    df=pd.DataFrame()
    df['date_lst']=date_lst
    df['patients_with_confirmed_infection']=patients_with_confirmed_infection
    df['patients_with_suspected_infection']=patients_with_suspected_infection
    df['patients_in_ICU']=patients_in_ICU
    df['patients_on_ventilators']=patients_on_ventilators
    driver.close()

    return df

def Mississippi_state_info():
    df_hosp=Mississippi_icu_vents_hospitalizations()
    # driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    URL = "https://msdh.ms.gov/msdhsite/_static/14,0,420.html"
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL)
    time.sleep(60)

    dt_str=(driver.find_element_by_xpath('//*[@id="article"]/div/h3[1]').text).replace('New Cases and Deaths as of ','').strip(' ')
    mon=month_string_to_number(dt_str.split(' ')[0])
    dt=dt_str.split(' ')[1]
    yr=datetime.now().strftime('%Y')
    dt_str=str(mon)+'/'+str(dt)+"/"+str(yr)

    print('confirmed cases')
    confirmed=(driver.find_element_by_xpath('//*[@id="caseClassificationTable"]/tbody/tr[1]/td[4]/strong').text)

    print('deaths')
    deaths=(driver.find_element_by_xpath('//*[@id="caseClassificationTable"]/tbody/tr[2]/td[4]/strong').text)

    print('tests')
    tests=(driver.find_element_by_xpath('//*[@id="article"]/div/table[3]/tbody/tr[4]/td[3]/strong').text)

    print('serology')
    serology=(driver.find_element_by_xpath('//*[@id="article"]/div/table[3]/tbody/tr[4]/td[4]/strong').text)
    # df_hosp
    # list(df_hosp['date_lst'].unique())[-1]
    driver.close()
    df=pd.DataFrame()
    
    df['Number of COVID-19 Tests (PCR)']=[tests.replace(',','')]
    df['Positive COVID-19 Tests (PCR)']=[confirmed.replace(',','')]
    df['COVID-19 Test Positivity %']=[str(int(confirmed.replace(',',''))/int(tests.replace(',',''))*100)+'%']
    df['Number of COVID-19 Tests (Serology)']=[serology.replace(',','')]
    df['Deaths']=[deaths.replace(',','')]
    df['Current COVID Hospitalizations']=[int(str(list(df_hosp['patients_with_confirmed_infection'].unique())[-1]).replace(',',''))+int(str(list(df_hosp['patients_with_suspected_infection'].unique())[-1]).replace(',',''))]
    df['Current COVID ICU patients']=[int(str(list(df_hosp['patients_in_ICU'].unique())[-1]).replace(',',''))]
    df['Current COVID Vent patients']=[int(str(list(df_hosp['patients_on_ventilators'].unique())[-1]).replace(',',''))]
    df['State']='Mississippi'
    df['Date']=dt_str
    print(df)
    for c in ['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
        if c not in ['Number of COVID-19 Tests (Serology)','Date','State','Current COVID Vent patients','Current COVID ICU patients','Current COVID Hospitalizations','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths']:
            df[c]=""

    df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]

    df.to_csv(Manual_output_dir+'Mississippi_State_File.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')

def Oklahoma_State_data_gen():
    URL = "https://coronavirus.health.ok.gov/executive-order-reports"
    pdf_file_name=Path(download_dir+ '\\Oklahoma.pdf')
    
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)    
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL)
    time.sleep(60)
    action = ActionChains(driver)
    action.send_keys(Keys.ESCAPE).perform()
    driver.maximize_window()
    dt_str=(driver.find_element_by_xpath('/html/body/div[2]/main/div/div/div[1]/div/div/div[7]/div/div/div[1]/div[1]/div[1]/h3/a').text).replace('Executive Order Report ','')
    pdf_url=driver.find_element_by_xpath('/html/body/div[2]/main/div/div/div[1]/div/div/div[7]/div/div/div[1]/div[1]/div[2]/div/ul/li/div/span/a').get_attribute('href')
    print(pdf_url)
    driver.close()
    response=requests.get(pdf_url)    
    pdf_file_name.write_bytes(response.content)    
    pdfFileObj = open(pdf_file_name, 'rb')
    pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
    print("Number of pages:-"+str(pdfReader.numPages))
    num = pdfReader.numPages
    i =0
    c=""
    while(i<num):    
        pageObj = pdfReader.getPage(i)
        text=pageObj.extractText()
        text1 = text.lower()
        for line in text1:            		
            c=c+line    
        i= i+1

    data=c.split('\n')
    for d in data:
        print(d)
    for di in range(0,len(data)):
        if 'Total Number of Specimens Tested to Date:'.lower() in data[di]:
            print('Total Number of Specimens Tested to Date:')
            pcr_tests=data[di+1].replace(',','')
            print(pcr_tests)
        if 'Total Positive Specimen:'.lower() in data[di]:
            print('Total Positive Specimen:')
            positive_pcr_tests=data[di+1].replace(',','')
            print(positive_pcr_tests)
        if 'Percent Positive:'.lower() in data[di]:
            print('Percent Positive')
            tests_positivity=data[di+1].replace(',','')
            print(tests_positivity)
        if 'Total Deaths:'.lower() in data[di]:
            print('Total Deaths:')
            deaths=data[di+1].replace(',','')
            print(deaths)
        if 'COVID-19 Cases Currently Hospitalized:'.lower() in data[di]:
            print('COVID-19 Cases Currently Hospitalized:')
            # 496 (206 in icu)
            temp=data[di+1]
            covid_hospitalizations=temp.split('(')[0].strip(' ').replace(',','')
            icu_hospitalization=(temp.split('(')[1]).split(' ')[0].replace(',','')
            print(covid_hospitalizations)
            print(icu_hospitalization)
        if 'Ventilators Available:'.lower() in data[di]:
            print('Ventilators Available:')
            vent_available=data[di+1].split(' ')[0].replace(',','')
            print(vent_available)
        if '(active cases):'.lower() in data[di]:
            print('(active cases):')
            print(data[di+1]) ## total-cases
            tc=int(data[di+1].replace(',','').strip(' '))

    df=pd.DataFrame()
    df['Number of COVID-19 Tests (PCR)']=[pcr_tests]
    df['Positive COVID-19 Tests (PCR)']=[positive_pcr_tests]
    df['COVID-19 Test Positivity %']=[tests_positivity]
    df['Deaths']=[deaths]
    df['Current COVID Hospitalizations']=[covid_hospitalizations]
    df['Current COVID ICU patients']=[icu_hospitalization]
    df['Hospital Vent capacity']=vent_available
    df['State']='Oklahoma'
    # dt_str='9/25/2020'
    df['Date']=dt_str

    for c in ['County','State_County_Id','FIPS Code','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
        if c not in ['Date','State','Hospital Vent capacity','Current COVID ICU patients','Current COVID Hospitalizations','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths']:
            df[c]=""

    df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]

    df.to_csv(Manual_output_dir+'Oklahoma_State_File.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')

def Louisiana_state_data_gen():    

    URL1=r"https://public.tableau.com/views/COVID19demog/DataonCOVIN-19RelatedDeathsToDate?:embed=y&:showVizHome=no&:host_url=https%3A%2F%2Fpublic.tableau.com%2F&:embed_code_version=3&:device=phone&:tabs=no&:toolbar=no&:showAppBanner=false&:display_spinner=no&:loadOrderID=1"

    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL1)
    time.sleep(60)
    #to extract updated date 
    dt_temp=driver.find_element_by_xpath('//*[@id="tabZoneId12"]/div/div/div/div[1]/div/span/div/span').text
    dt_str=dt_temp.split(' ')[-1].replace('.','')
    print(dt_str)    
    time.sleep(10)
    driver.close()

    URL='https://www.arcgis.com/apps/opsdashboard/index.html#/4a6de226701e45bdb542f09b73ee79e1'
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    
    driver = webdriver.Chrome(executable_path=driverpath,
                            chrome_options=chromeOptions)
        

    driver.get(URL)
    timeout = 60
    time.sleep(timeout)
    driver.maximize_window()
    els=driver.find_elements_by_class_name('responsive-text-label')
    # cases
    cases=(els[7].text).replace(',','')
    #deaths
    deaths=(els[9].text).replace(',','')
    #tests
    tests=(els[11].text).replace(',','')
    #covid hosp
    hosp=(els[20].text).replace(',','')
    # covid vents
    vents=(els[23].text).replace(',','')

    df_icu=pd.read_csv(download_dir+"\\ICU Bed Availability by Region.csv")
    df_icu_In_Use=df_icu[df_icu['Status']=='In Use']
    icu_beds_in_use=0
    for i in df_icu_In_Use['ICU Beds Available']:
        try:
            icu_beds_in_use=int(str(i))+icu_beds_in_use
        except:
            pass
    df_icu_availble=df_icu[df_icu['Status']=='Still Available']
    icu_beds_available=0
    for i in df_icu_availble['ICU Beds Available']:
        try:
            icu_beds_available=int(str(i))+icu_beds_available
        except:
            pass
    
    df=pd.DataFrame()
    df['Number of COVID-19 Tests (PCR)']=[tests]
    df['Positive COVID-19 Tests (PCR)']=cases
    df['Deaths']=deaths
    df['COVID-19 Test Positivity %']=int(cases)/int(tests)
    df['Current COVID Hospitalizations']=hosp
    df['Current COVID ICU patients']=icu_beds_in_use
    df['Current COVID Vent patients']=vents
    df['Total ICU Beds in county']=icu_beds_available+icu_beds_in_use
    df['Hospital ICU capacity']=icu_beds_available
    df['Total Vents in county']=2233
    df['Date']=dt_str
    df['State']='Louisiana'
    
    for c in ['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
        if c not in ['Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','Deaths','COVID-19 Test Positivity %','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Total ICU Beds in county','Hospital ICU capacity','Total Vents in county','Date','State']:
            df[c]=""

    df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]
    df.to_csv(Manual_output_dir+'Louisiana_State_File.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')    

# Mississippi_state_info()
# print('Mississippi_state_info')

# Oklahoma_State_data_gen()
# print('Oklahoma_State_data_gen')

Louisiana_state_data_gen()
print('Louisiana_state_data_gen')


WY_cumulative_cases_gen()
print('WY_cumulative_cases_gen')

WY_county_test_gen()
print('WY_county_test_gen')

WY_age_group_gen()
print('WY_age_group_gen')

Mississippi_county_data_gen()
print('Mississippi_county_data_gen')

Louisiana_parish_data_gen()
print('Louisiana_parish_data_gen')

Louisiana_age_group_data_gen()
print('Louisiana_age_group_data_gen')

Mississippi_icu_vents_hospitalizations()
print('Mississippi_icu_vents_hospitalizations')

    


