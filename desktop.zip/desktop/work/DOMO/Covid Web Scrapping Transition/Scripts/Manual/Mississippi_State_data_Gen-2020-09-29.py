from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"

def icu_vents_hospitalizations():
    # driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    URL = "https://app.powerbigov.us/view?r=eyJrIjoiNzhkM2M5YzItMWM4OC00YmI1LWEyMTktNDUxNjQ5YjVkM2U1IiwidCI6IjU1OTA0MmRjLThiZjAtNGQ4Ni05ZmMwLWZiZjRjNzUwM2M3OSJ9"
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL)

    time.sleep(60)
    driver.maximize_window()

    time.sleep(10)

    source=driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/div/div/div')
    source=driver.find_element_by_class_name('preTextWithEllipsis')
    # source.click()
    action = ActionChains(driver)
    action.context_click(source).perform()
    time.sleep(10)
    action = ActionChains(driver)
    action.send_keys(Keys.ENTER).perform()

    time.sleep(60)
    # driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/visual-modern/div/svg/svg/g[1]/svg[1]/rect').click()
    # action.context_click()

    # driver.find_element_by_xpath('//*[@id="contextmenu-label-text5"]').click()
    # try:
    #     driver.find_element_by_class_name('itemLabel trimmedTextWithEllipsis').click()
    # except Exception as e:
    #     print(str(e)+"-1")

    # try:
    #     driver.find_element_by_xpath('/html/body/div[5]/drop-down-list/ng-transclude/ng-repeat/drop-down-list-item/ng-transclude/ng-switch/div').click()
    # except Exception as e:
    #     print(str(e)+"-2")

    # time.sleep(60)

    date_lst=[]
    patients_with_confirmed_infection=[]
    patients_with_suspected_infection=[]
    patients_in_ICU=[]
    patients_on_ventilators=[]

    driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/visual-container-header-modern/div/div[1]/div/visual-header-item-container[2]/div/button').click()

    for i in range(1,22):
        date_lst.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[3]/div/div['+str(i)+']').text)

    for i in range(1,21):
        patients_with_confirmed_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[1]/div['+str(i)+']').text)

    patients_with_confirmed_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[1]/div').text)


    for i in range(1,21):
        patients_with_suspected_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[2]/div['+str(i)+']').text)

    patients_with_suspected_infection.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[2]/div').text)

    for i in range(1,21):
        patients_in_ICU.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[3]/div['+str(i)+']').text)

    patients_in_ICU.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[3]/div').text)

    for i in range(1,21):
        patients_on_ventilators.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[1]/div[4]/div['+str(i)+']').text)

    patients_on_ventilators.append(driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/detail-visual-modern/div/visual-modern/div/div/div[2]/div[1]/div[4]/div/div[2]/div[4]/div').text)

    df=pd.DataFrame()
    df['date_lst']=date_lst
    df['patients_with_confirmed_infection']=patients_with_confirmed_infection
    df['patients_with_suspected_infection']=patients_with_suspected_infection
    df['patients_in_ICU']=patients_in_ICU
    df['patients_on_ventilators']=patients_on_ventilators
    driver.close()

    return df

def month_string_to_number(string):
    m = {
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr':4,
         'may':5,
         'jun':6,
         'jul':7,
         'aug':8,
         'sep':9,
         'oct':10,
         'nov':11,
         'dec':12
        }
    s = string.strip()[:3].lower()

    try:
        out = m[s]
        return out
    except:
        raise ValueError('Not a month')

def other_info():
    df_hosp=icu_vents_hospitalizations()
    # driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    URL = "https://msdh.ms.gov/msdhsite/_static/14,0,420.html"
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(URL)
    time.sleep(60)

    dt_str=(driver.find_element_by_xpath('//*[@id="article"]/div/h3[1]').text).replace('New Cases and Deaths as of ','').strip(' ')
    mon=month_string_to_number(dt_str.split(' ')[0])
    dt=dt_str.split(' ')[1]
    yr=datetime.now().strftime('%Y')
    dt_str=str(mon)+'/'+str(dt)+"/"+str(yr)

    print('confirmed cases')
    confirmed=(driver.find_element_by_xpath('//*[@id="caseClassificationTable"]/tbody/tr[1]/td[4]/strong').text)

    print('deaths')
    deaths=(driver.find_element_by_xpath('//*[@id="caseClassificationTable"]/tbody/tr[2]/td[4]/strong').text)

    print('tests')
    tests=(driver.find_element_by_xpath('//*[@id="article"]/div/table[3]/tbody/tr[4]/td[3]/strong').text)

    print('serology')
    serology=(driver.find_element_by_xpath('//*[@id="article"]/div/table[3]/tbody/tr[4]/td[4]/strong').text)
    df_hosp
    # list(df_hosp['date_lst'].unique())[-1]
    
    df=pd.DataFrame()
    
    df['Number of COVID-19 Tests (PCR)']=[tests.replace(',','')]
    df['Positive COVID-19 Tests (PCR)']=[confirmed.replace(',','')]
    df['COVID-19 Test Positivity %']=[str(int(confirmed.replace(',',''))/int(tests.replace(',',''))*100)+'%']
    df['Number of COVID-19 Tests (Serology)']=[serology.replace(',','')]
    df['Deaths']=[deaths.replace(',','')]
    df['Current COVID Hospitalizations']=[int(str(list(df_hosp['patients_with_confirmed_infection'].unique())[-1]).replace(',',''))+int(str(list(df_hosp['patients_with_suspected_infection'].unique())[-1]).replace(',',''))]
    df['Current COVID ICU patients']=[int(str(list(df_hosp['patients_in_ICU'].unique())[-1]).replace(',',''))]
    df['Current COVID Vent patients']=[int(str(list(df_hosp['patients_on_ventilators'].unique())[-1]).replace(',',''))]
    df['State']='Mississippi'
    df['Date']=dt_str
    print(df)
    for c in ['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']:
        if c not in ['Number of COVID-19 Tests (Serology)','Date','State','Current COVID Vent patients','Current COVID ICU patients','Current COVID Hospitalizations','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Deaths']:
            df[c]=""

    df=df[['State','County','State_County_Id','FIPS Code','Date','Number of COVID-19 Tests (PCR)','Positive COVID-19 Tests (PCR)','COVID-19 Test Positivity %','Number of COVID-19 Tests (Serology)','Positive COVID-19 Tests (Serology)','Deaths','Current COVID Hospitalizations','Current COVID ICU patients','Current COVID Vent patients','Hospital (In-patient) capacity','Hospital ICU capacity','Hospital Vent capacity','Total In-patient beds in county','Total ICU Beds in county','Total Vents in county','Last Updated date from API','Last Updated date from ETL']]

    df.to_csv(r'Mississippi_State_File.csv',index=False,quoting=csv.QUOTE_ALL,date_format='%Y-%m-%d')


    driver.close()

other_info()