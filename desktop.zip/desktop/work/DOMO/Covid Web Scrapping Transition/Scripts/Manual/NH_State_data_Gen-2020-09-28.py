from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
inc_file=r'C:\Users\asrilekh\Desktop\work\DOMO\Covid Web Scrapping Transition\Files\Manual Activity\NH_State.csv'
URL = "https://e.infogram.com/78f47d8d-c751-4ea1-a3d0-598d505057b2?src=embed"

chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get(URL)
time.sleep(120)
try:
    # driver.switch_to_frame(driver.find_element_by_xpath('//*[@id="node-149590"]/div/div[2]/div[2]/div[1]/div[2]/div/div/p[13]/iframe'))
    table_id=driver.find_element_by_xpath('//*[@id="ecb6c8f2-75e1-4a0f-aae4-87ebb7d0958b"]/div[1]/div/div[3]/div/div/div/div/div[2]/table')
    print("entered-1")
    table_data_id=driver.find_element_by_xpath('//*[@id="ecb6c8f2-75e1-4a0f-aae4-87ebb7d0958b"]/div[1]/div/div[3]/div/div/div/div/div[1]/table/tbody')
    parent_rows=table_data_id.find_elements_by_tag_name('tr')
    print("entered-2"+str(len(parent_rows)))
    driver.find_element_by_xpath('//*[@id="ecb6c8f2-75e1-4a0f-aae4-87ebb7d0958b"]/div[1]/div/div[3]/div/div/div/div/div[1]/table/tbody/tr[1]/td[1]/span').click()
    ActionChains(driver).key_down(Keys.CONTROL).send_keys(Keys.END)
    for pr_i in range(len(parent_rows),len(parent_rows)+1):                
        try:
            pr=parent_rows[pr_i-1]
            tdr=pr.find_elements_by_tag_name('td')
            c=""            
            for tdr_i in range(1,len(tdr)+1):
                try:
                    # print(pr.find_elements_by_tag_name('td')[tdr_i].text)                    
                    c=c+''+(driver.find_element_by_xpath('//*[@id="ecb6c8f2-75e1-4a0f-aae4-87ebb7d0958b"]/div[1]/div/div[3]/div/div/div/div/div[1]/table/tbody/tr['+str(pr_i)+']/td['+str(tdr_i)+']/span').text).replace(',','')+','
                except:
                    print("exception in :")
                    print(tdr_i)
            c=c[0:len(c)-1]
            print(c)
            print("completed reading data for "+str(pr_i))
            f=open(inc_file,'a')
            f.write(c+"\n")
            f.close()
        except Exception as e:
            print("Exception in generating row data"+str(e))
    
except Exception as e:
    print(str(e))
finally:
    driver.close()
