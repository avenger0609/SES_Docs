import csv
import json

csvfile = open('ALL_UIDXWALK_FINAL_THRU05102019.csv', 'r')
jsonfile = open('ALL_UIDXWALK_FINAL_THRU05102019_parsed_multiline.json', 'w')

fieldnames = ("uid","prov_nm","Hosp_Provkey")
reader = csv.DictReader(csvfile, fieldnames)
for row in reader:
    json.dump(row, jsonfile)
    jsonfile.write('\n')