import csv
import os

inputFileName = "header_2019_ang_cy.csv"
outputFileName = os.path.splitext(inputFileName)[0] + "_group_name_Updated_FINAL.csv"

#with open(splitted_header_2017_6_mod_02252019_cy.csv, 'rb') as inFile, open(splitted_header_2017_6_mod_02252019_cy_updated.csv, 'wb') as outfile:
with open(inputFileName, newline='') as inFile, open(outputFileName, 'w', newline='') as outfile:
    r = csv.reader(inFile)
    w = csv.writer(outfile)

    next(r, None)  # skip the first row from the reader, the old header
	# write new header
    w.writerow(['submarket','Funding_Arrangement','Hosp_Provkey','OOA_OON','purchaser_id','Treatmt_Setting','Case_Status','Case_Type','end_dt','start_dt','admit_type','bcrt_denial_days','Dx_Prim','plan','member_zip','mbr_minor_mkt','mkt_region','mbr_state','aco_ind','aco_key','hicn','lob','cms_geo_code','business_segment_adj','sub_plan','Group_Id','product_desc','ltc_flg','dual','network','flu_indicator','entity_adj','product','contract_pbp','market','tfm_product','mkt_cont_pilot','company_code_adj','prov_tin','outlier_flag','ACO_NAME','readmit_flag','readmit_flag_7d','ad1d_flg','span','year','month','week','group_name','ip_admit','SNF_admit','ip_ip','ip_snf','snf_ip','index_acute','index_acute_readmit30','acute_snf_acute','acute_snf_home_acute','snf_discharge','ip_discharge','ip_day','snf_day'])
	# w.writerow(['submarket', 'Funding_Arrangement', 'Hosp_Provkey', 'OOA_OON', 'purchaser_id', 'Treatmt_Setting', 'Case_Status', 'Case_Type', 'end_dt', 'start_dt', 'admit_type', 'bcrt_denial_days', 'Dx_Prim', 'plan', 'member_zip', 'mbr_minor_mkt', 'mbr_region', 'mbr_state', 'aco_ind', 'aco_key', 'hicn', 'lob', 'cms_geo_code', 'business_segment_adj', 'sub_plan', 'Group_Id', 'product_desc', 'ltc_flg', 'dual', 'network', 'flu_indicator', 'entity_adj', 'product', 'contract_pbp', 'market', 'tfm_product', 'mkt_cont_pilot', 'company_code_adj', 'prov_tin', 'outlier_flag', 'ACO_NAME', 'readmit_flag', 'readmit_flag_7d', 'ad1d_flg', 'span', 'year', 'month', 'week', 'group_name', 'ip_admit', 'SNF_admit', 'ip_ip', 'ip_snf', 'snf_ip', 'index_acute', 'index_acute_readmit30', 'acute_snf_acute', 'acute_snf_home_acute', 'snf_discharge', 'ip_discharge', 'ip_day', 'SNF_day'])
    for row in r:
        w.writerow(row)