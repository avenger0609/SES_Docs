import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3
from datetime import datetime
import pickle
def data_extract():
    try:
        print("started generating files for mpwr trm utilization file")
        df = pd.read_excel('parameters.xlsx')
        converterS = {col: str for col in df.columns}
        df = pd.read_excel('parameters.xlsx',converters=converterS)        
        print(df)
        sui_cntr=0
        accng_yr_cntr=0
        global_app_cntr=0
        accng_yr_lst=[]
        for i in range(0,len(df)):
            if str(df.iloc[i,0])=='nan':
                junk=1
            else:
                accng_yr_lst.append(str(df.iloc[i,0]))        
        accng_yr_lst_str_qry=""
        if len(accng_yr_lst) > 0:
            accng_yr_lst_str_qry=" and dbo.uv_cb_vetting.AccountingYearMonth in "+str(accng_yr_lst).replace('[','(').replace(']',')')
        
        #### SUI DATA EXTRACTION
        sui_lst_str_qry=""
        for i in range(0,len(df)):
            if str(df.iloc[i,1])=='nan':
                continue
            else:
                if sui_cntr==0:
                    sui_lst_str_qry=sui_lst_str_qry+" in ('"+str(df.iloc[i,1])+"'"
                    sui_cntr=1
                else:
                    sui_lst_str_qry=sui_lst_str_qry+",'"+str(df.iloc[i,1])+"'"
        sui_lst_str_qry=sui_lst_str_qry+")"
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params) 
        if sui_cntr==1:
            sql_string="SELECT * FROM dbo.uv_cb_vetting where dbo.uv_cb_vetting.ServiceUniqueIdentifier"+sui_lst_str_qry+" "+accng_yr_lst_str_qry
            print(sql_string)
            dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
            df_ext = pd.read_sql_query(sql_string, engine)
            print(str(len(df_ext)))
            print("data fetched") 
            if len(df_ext) >0:
                try:                          
                    df_ext.to_excel('sui_data'+dt+'.xlsx',index=False)            
                except Exception as e:
                    print(str(e))
                    for col_i in df_ext.columns:            
                        try:
                            df_ext[col_i]=df_ext[col_i].apply(str) 
                        except:
                            df_ext[col_i]=pd.to_datetime(df_ext[col_i], format='%Y-%m-%d %H:%M:%S')                     
                    df_ext.to_csv('sui_data'+dt+'.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")       
        #### SUI DATA EXTRACTION
        #### GLOBAL APP DATA EXTRACTION
        gapp_lst_str_qry=""
        
        for i in range(0,len(df)):                        
            if str(df.iloc[i,2])=='nan':
                continue
            else:
                if global_app_cntr==0:
                    gapp_lst_str_qry=gapp_lst_str_qry+" in ('"+str(df.iloc[i,2])+"'"
                    global_app_cntr=1
                else:
                    gapp_lst_str_qry=gapp_lst_str_qry+",'"+str(df.iloc[i,2])+"'"
        gapp_lst_str_qry=gapp_lst_str_qry+")"
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params) 
        if global_app_cntr==1:
            sql_string="SELECT * FROM dbo.uv_cb_vetting where dbo.uv_cb_vetting.GlobalApplicationID "+gapp_lst_str_qry+" "+accng_yr_lst_str_qry
            print(sql_string)
            dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
            df_ext = pd.read_sql_query(sql_string, engine)
            print(str(len(df_ext)))
            print("data fetched") 
            if len(df_ext) >0:
                try:                          
                    df_ext.to_excel('global_app_id_data'+dt+'.xlsx',index=False)            
                except Exception as e:
                    print(str(e))
                    for col_i in df.columns:            
                        try:
                            df_ext[col_i]=df_ext[col_i].apply(str) 
                        except:
                            df_ext[col_i]=pd.to_datetime(df_ext[col_i], format='%Y-%m-%d %H:%M:%S')                     
                    df_ext.to_csv('global_app_id_data'+dt+'.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")       
        #### global app DATA EXTRACTION
           
        
    except Exception as e:
        print("error while generating trm utilization File for 78000 DFITBM"+str(e))

data_extract()


