from turbodbc import connect
from pandas import DataFrame
import csv

connection = connect(dsn='TRMDB')
cursor = connection.cursor()
# stmt="SELECT * FROM dbo.uv_cb_vetting WHERE globalapplicationid in ('UHGWM110-005266') and computeunitpctram IS NOT NULL and computeunitpctcpu IS NOT NULL and accountingyearmonth=\'1804\'"
# stmt="SELECT * FROM dbo.uv_cb_vetting WHERE GL_OU in ('01510') and accountingyearmonth=\'1805\'"
# stmt="SELECT * FROM dbo.uv_cb_vetting WHERE GL_OU in ('01510') and accountingyearmonth in ('1905','1904','1903','1902','1901','1812','1811','1810','1809','1808','1807','1806','1805')"
stmt="SELECT * FROM dbo.uv_cb_vetting WHERE GL_OU in ('01510') and accountingyearmonth in ('1905','1904','1903','1902','1901','1812')"
cursor.executemany(stmt)
cur_df=DataFrame(cursor.fetchall())
cur_df.columns=['RowID','AccountingYearMonth','VolumeYearMonth','DateOfChargeback','DivisionID','ServiceGroup','ServiceGroupCostCenter','ServiceCodeName','ServiceCode','BillCodeName','BillingCode','BillCodeStatus','ServiceUniqueIdentifier','SUIdescription','ServicePhysical','ServiceVirtual','InternalComment','AppName','TMDB_SearchCode','Published','ProjectNumber','Project_Name','Project_Manager','ServiceRequestNumber','ServiceDeliveryDate','CustomerAcceptance','BusinessSegmentName','GL_BU','GL_OU','GL_LOC','GL_ACCT','GL_DEPT','ConsumingServiceGroup','GL_PROD','GL_CUST','GL_PID','UnadjustedUnits','AdjustedUnits','UnadjustedStorage','AdjustedStorage','AdjSanOrAdjStorage','San_Cost','BaseService_Cost','ProdNonProd','EnvironmentCode','DataCenterCode','DRMates','DRCode','NetworkZone','ChangeReason','Requestor','Description','RequestorEmail','CreateDate','RequestType','ParentRequestID','ParentRequestor','ParentRequestorEmail','ParentDescription','ParentCreateDate','ParentRequestType','ProjectName','ProjectRequestor','ProjectManager','Prompt_ID','BusinessApplicationName','GL_CodeOwner','LongApplicationName','Global Application Id','ComputeUnitPctCPU','ComputeUnitPctRAM','CPUAllocated','CPUAverageUtilPct','CPUPeakUtilPct','RAMAllocated','RAMAverageUtilPct','RAMPeakUtilPct','PctUptime','FileName','FileKey','RecordID','TransactionCycleKey','FileOutput','OutputYesNo','RateTypeID','UnitRate','UnitCost','AdjUnitCost','AdjUnitCost_presplit','StorageRate','StorageCost','AdjStorageCost','AdjStorageCost_presplit','Rate Type','GL Source','App Source','Project Source','Cap','Floor','Multiplier','RecordID_presplit','GL_PRAC','CBUniqueKey']
print(type(cur_df))
print(str(len(cur_df)))
try:
    cur_df.to_excel("c:\\users\\asrilekh\\documents\\TRMDB_Data_OU_01510_roll_6.xlsx",index=False)
except Exception as e:
    print(str(e))
    cur_df.to_csv("c:\\users\\asrilekh\\documents\\TRMDB_Data_OU_01510_roll_6.csv",index=False,quoting=csv.QUOTE_ALL)
