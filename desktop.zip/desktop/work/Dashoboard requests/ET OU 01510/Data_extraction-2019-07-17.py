import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3
from datetime import datetime

def data_extract():
    try:
        print("started generating files")        
        params = quote_plus(r'Driver={ODBC Driver 13 for SQL Server};Server=DBSEP6312;Database=TRMDB;Trusted_Connection=yes;')
        engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params) 
        #### acctng yr DATA EXTRACTION      
        sql_string="select distinct accountingyearmonth as ac from uv_cb_vetting where accountingyearmonth in  ('1905','1904','1903','1902','1901') order by ac"
        dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
        df = pd.read_sql_query(sql_string, engine)
        print(str(len(df)))
        print("data fetched")         
        try:                          
            df.to_excel('acctng_yr_data'+dt+'.xlsx',index=False)            
        except Exception as e:
            print(str(e))
            for col_i in df.columns:            
                try:
                    df[col_i]=df[col_i].apply(str) 
                except:
                    df[col_i]=pd.to_datetime(df[col_i], format='%Y-%m-%d %H:%M:%S')                     
            df.to_csv('acctng_yr_data'+dt+'.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")
        #### acctng yr DATA EXTRACTION 
           
        #### service code name DATA EXTRACTION      
        sql_string="select distinct ServiceCodeName from uv_cb_vetting where accountingyearmonth in  ('1905','1904','1903','1902','1901') order by ServiceCodeName"
        dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
        df = pd.read_sql_query(sql_string, engine)
        print(str(len(df)))
        print("data fetched")         
        try:                          
            df.to_excel('svc_code_name_data'+dt+'.xlsx',index=False)            
        except Exception as e:
            print(str(e))
            for col_i in df.columns:            
                try:
                    df[col_i]=df[col_i].apply(str) 
                except:
                    df[col_i]=pd.to_datetime(df[col_i], format='%Y-%m-%d %H:%M:%S')                     
            df.to_csv('svc_code_name_data'+dt+'.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")
        #### service code name DATA EXTRACTION  

        #### dept DATA EXTRACTION      
        sql_string="select distinct GL_Dept from uv_cb_vetting where accountingyearmonth in  ('1905','1904','1903','1902','1901') order by GL_Dept"
        dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
        df = pd.read_sql_query(sql_string, engine)
        print(str(len(df)))
        print("data fetched")         
        try:                          
            df.to_excel('dept_data'+dt+'.xlsx',index=False)            
        except Exception as e:
            print(str(e))
            for col_i in df.columns:            
                try:
                    df[col_i]=df[col_i].apply(str) 
                except:
                    df[col_i]=pd.to_datetime(df[col_i], format='%Y-%m-%d %H:%M:%S')                     
            df.to_csv('dept_data'+dt+'.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")
        #### dept DATA EXTRACTION 

        #### app DATA EXTRACTION      
        sql_string="select distinct GlobalApplicationID from uv_cb_vetting where accountingyearmonth in  ('1905','1904','1903','1902','1901') order by GlobalApplicationID"
        dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
        df = pd.read_sql_query(sql_string, engine)
        print(str(len(df)))
        print("data fetched")         
        try:                          
            df.to_excel('app_data'+dt+'.xlsx',index=False)            
        except Exception as e:
            print(str(e))
            for col_i in df.columns:            
                try:
                    df[col_i]=df[col_i].apply(str) 
                except:
                    df[col_i]=pd.to_datetime(df[col_i], format='%Y-%m-%d %H:%M:%S')                     
            df.to_csv('app_data'+dt+'.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y %H:%M:%S")
        #### app DATA EXTRACTION    
             
        
    except Exception as e:
        print("error while generating trm utilization File for 78000 DFITBM"+str(e))

data_extract()


