import os
import pandas as pd
import numpy as np
from datetime import datetime
from dateutil.relativedelta import relativedelta

files_dir=r'C:\Users\asrilekh\Documents\NGAM Automation\Mar 2020\PForms Mar2020'
os.chdir(files_dir)

output_agg_file=r'Agg file_m.xlsx'
writer = pd.ExcelWriter(output_agg_file)


last_month = datetime.now() - relativedelta(months=1)

last_mon_text = format(last_month, '%m-%B-%Y')
last_mon_text='03-March-2020'
print(last_mon_text)

Year_Val=str(last_mon_text.split('-')[2])
mon_Val_sngl_num=str(int(str(last_mon_text.split('-')[0]))*1)
mon_Val_doubl_num=str(last_mon_text.split('-')[0])

int_Year_Val=int(str(last_mon_text.split('-')[2]))
int_mon_Val_sngl_num=(int(str(last_mon_text.split('-')[0]))*1)

#################### VLOOKUP Generation ####################

existing_vlookup_file=r'existing_vlookup.xlsx'
existing_vlookup_sname=r'Vlookup'
DBFile=r'DB.xlsx'
DBSname=r'DB'

dbdf=pd.read_excel(DBFile,sheet_name=DBSname,encoding='latin-1')
# print(dbdf.columns)
dbdf=dbdf[['Unnamed: 9','MSID']]
dbdf['Name']=dbdf['Unnamed: 9']
dbdf=dbdf[['Name','MSID']]

evlddf=pd.read_excel(existing_vlookup_file,sheet_name=existing_vlookup_sname,encoding='latin-1')

df=evlddf.append(dbdf,ignore_index=True)

df_op=df.dropna(subset=['MSID'])
df_op=df_op.drop_duplicates(subset=['Name','MSID'], keep='last')

df=df.dropna(subset=['MSID'])
df=df.dropna(subset=['Name'])
df=df.drop_duplicates(subset=['Name'], keep='last')
df=df.drop_duplicates(subset=['Name','MSID'], keep='last')

df_vlookup=df

df_op.to_excel(writer,existing_vlookup_sname,index=False,columns=list(df_op.columns))

#################### VLOOKUP Generation ####################

######################### AHT Pivot generation #########################

filename=r'AHT Per Skill.xlsx'
csv_filename=r'AHT Per Skill.csv'
sheet_name=r'RAW'
year_month_col='P_YearMonth'
year_month=Year_Val+'-'+mon_Val_doubl_num
row_labels_lst=['P_Name']
values_lst=['ACD Calls','Total Handle Time']



fields = {col: str for col in [year_month_col]}
src_df=pd.read_csv(csv_filename,converters=fields,encoding='latin-1')
src_df=(src_df.loc[src_df[year_month_col].isin([year_month])])

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

# pivot=pivot.reset_index(drop=False, inplace=False, col_level=0, col_fill='')

pivot_cols=list(pivot.columns)
print(pivot_cols)

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])

dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']
dest_df[year_month_col]=year_month
dest_df['Sum of AHT Calc']=df_join_res['Total Handle Time']/df_join_res['ACD Calls']
dest_df['Sum of ACD Calls']=df_join_res['ACD Calls']
dest_df['Sum of Total Handle Time']=df_join_res['Total Handle Time']
dest_df['Year']=int_Year_Val
dest_df['Year_Str']=Year_Val
dest_df['Month']=int_mon_Val_sngl_num
dest_df['Month_Str']=mon_Val_sngl_num
dest_df['MSID']=df_join_res['MSID']
dest_df['Combo']=dest_df['Year_Str']+dest_df['Month_Str']+dest_df['MSID']
dest_df=dest_df.drop(columns=['Month_Str','Year_Str'])
dest_df=dest_df[[year_month_col,'P_Name','Sum of AHT Calc','Sum of ACD Calls','Sum of Total Handle Time','Year','Month','MSID','Combo']]

dest_df.to_excel(writer,'AHT',index=False,columns=list(dest_df.columns))

print('Completed generation of AHT Pivot')

######################### AHT Pivot generation #########################


######################### Transfer Rate Pivot generation #########################

filename=r'Transfer Report.xlsx'
csv_filename=r'Transfer Report.csv'
sheet_name=r'Raw'
year_month_col='P_Year-Month'
year_month=Year_Val+"-"+mon_Val_doubl_num
row_labels_lst=['P_Name']
values_lst=['Calls Handled','Transfer Count']


fields = {col: str for col in [year_month_col]}
src_df=pd.read_csv(csv_filename, converters=fields,encoding='latin-1')

src_df=(src_df.loc[src_df[year_month_col].isin([year_month])])

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

pivot_cols=list(pivot.columns)
print(pivot_cols)

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='inner',on=["Name"])


dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']
dest_df[year_month_col]=year_month
dest_df['Sum of Transfer Count']=df_join_res['Transfer Count']
dest_df['Sum of Calls Handled']=df_join_res['Calls Handled']
dest_df['Transfer %']=df_join_res['Transfer Count']/df_join_res['Calls Handled']

dest_df['P_Year']=int_Year_Val
dest_df['Year_Str']=Year_Val
dest_df['Month']=int_mon_Val_sngl_num
dest_df['Month_Str']=mon_Val_sngl_num
dest_df['MSID']=df_join_res['MSID']
dest_df['Combo']=dest_df['Year_Str']+dest_df['Month_Str']+dest_df['MSID']
dest_df=dest_df.drop(columns=['Month_Str','Year_Str'])
dest_df=dest_df[[year_month_col,"P_Name","Sum of Transfer Count","Sum of Calls Handled","Transfer %","P_Year","Month","MSID","Combo"]]
dest_df.to_excel(writer,'Transfer Rate',index=False,columns=list(dest_df.columns))

print("Completed transfer rate pivot generation")
######################### Transfer Rate Pivot generation #########################

######################### NPS Pivot generation #########################

filename=r'NPS.xlsx'
csv_filename=r'NPS.csv'
sheet_name=r'RAW'
year_month_col='P_YearMonth'
year_month=Year_Val+"-"+mon_Val_doubl_num
row_labels_lst=['P_Name']
values_lst=['AggUES Count','AggUES2%','Promoter','Detractor','NPS Count']


fields = {col: str for col in [year_month_col]}
src_df=pd.read_csv(csv_filename, converters=fields,encoding='latin-1')

src_df=(src_df.loc[src_df[year_month_col].isin([year_month])])

src_df['AggUES2%'] = src_df['AggUES2%'].str.rstrip('%').astype('float') / 100.0

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

pivot_cols=list(pivot.columns)
print(pivot_cols)

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])

dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']
dest_df[year_month_col]=year_month

dest_df['AggUESCount']=df_join_res['AggUES Count']
dest_df['Agg UES 2']=df_join_res['AggUES2%']
dest_df['Promoter']=df_join_res['Promoter']
dest_df['Detractor']=df_join_res['Detractor']
dest_df['NPS Count']=df_join_res['NPS Count']


dest_df['NPS %']=((df_join_res['Promoter']/df_join_res['NPS Count'])-(df_join_res['Detractor']/df_join_res['NPS Count']))*100

dest_df['P_Year']=int_Year_Val
dest_df['Month']=int_mon_Val_sngl_num
dest_df['Month_Str']=mon_Val_sngl_num
dest_df['MSID']=df_join_res['MSID']
dest_df['Combo']=Year_Val+dest_df['Month_Str']+dest_df['MSID']
dest_df=dest_df.drop(columns=['Month_Str'])
dest_df=dest_df[[year_month_col,"P_Name","AggUESCount","Agg UES 2","Promoter","Detractor","NPS Count","NPS %","P_Year","Month","MSID","Combo"]]
dest_df.to_excel(writer,'NPS ',index=False,columns=list(dest_df.columns))

print("NPS Pivot generation completed")
######################### NPS Pivot generation #########################


######################### FCR 2 Pivot generation #########################

filename=r'PSO FCR2 Summary Report.xlsx'
csv_filename=r'PSO FCR2 Summary Report.csv'
sheet_name=r'FCR Raw'
year_month_col='P_Year-Month'
year_month=Year_Val+"-"+mon_Val_sngl_num
row_labels_lst=['P_Name']
values_lst=['NON Repeat','ORS Count']


fields = {col: str for col in [year_month_col]}
src_df=pd.read_csv(csv_filename, converters=fields,encoding='latin-1')

src_df=(src_df.loc[src_df[year_month_col].isin([year_month])])

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

pivot_cols=list(pivot.columns)
print(pivot_cols)

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])

dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']
dest_df[year_month_col]=year_month

dest_df['Sum of NON Repeat']=df_join_res['NON Repeat']
dest_df['Sum of ORS Count']=df_join_res['ORS Count']

dest_df['FCR %']=df_join_res['NON Repeat']/df_join_res['ORS Count']

dest_df['P_Year']=int_Year_Val
dest_df['Month']=int_mon_Val_sngl_num
dest_df['MSID']=df_join_res['MSID']
dest_df['Combo']=Year_Val+mon_Val_sngl_num+dest_df['MSID']
dest_df=dest_df[[year_month_col,"P_Name","Sum of NON Repeat","Sum of ORS Count","FCR %","P_Year","Month","MSID","Combo"]]
dest_df.to_excel(writer,'FCR 2',index=False,columns=list(dest_df.columns))

print('FCR 2 pivot generation completed')
######################### FCR 2 Pivot generation #########################

######################### FCR 2 Raw Pivot generation #########################

filename=r'PSO FCR2 Summary Report.xlsx'
csv_filename=r'PSO FCR2 Summary Report.csv'
sheet_name=r'FCR Raw'
year_month_col='P_Year-Month'
year_month=Year_Val+"-"+mon_Val_sngl_num
row_labels_lst=['P_Name','P_WE']
values_lst=['Repeat','NON Repeat','ORS Count','FCR Goal','CThresh']


fields = {col: str for col in [year_month_col]}
src_df=pd.read_csv(csv_filename,converters=fields,encoding='latin-1')

src_df=(src_df.loc[src_df[year_month_col].isin([year_month])])

src_df['FCR Goal'] = src_df['FCR Goal'].str.rstrip('%').astype('float') / 100.0
src_df['CThresh'] = src_df['CThresh'].str.rstrip('%').astype('float') / 100.0

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

pivot_cols=list(pivot.columns)
print(pivot_cols)

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])


dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']
dest_df['P_WE']=df_join_res['P_WE']
dest_df['P_Year']=int_Year_Val
dest_df[year_month_col]=year_month

for v in values_lst:
    dest_df[v]=df_join_res[v]

dest_df['Month']=int_mon_Val_sngl_num
dest_df['Month_Str']=mon_Val_sngl_num
dest_df['Combo']=dest_df['P_Name']+Year_Val+dest_df['Month_Str']
dest_df=dest_df.drop(columns=['Month_Str'])
dest_df[["P_Name","P_WE","P_Year",year_month_col,"Repeat","NON Repeat","ORS Count","FCR Goal","CThresh","Month","Combo"]]
dest_df.to_excel(writer,'FCR 2 Raw',index=False,columns=list(dest_df.columns))
print("FCR2 raw pivot generation completed")
######################### FCR 2 Raw Pivot generation #########################

######################### Release Rate Pivot generation #########################

filename=r'Release Rate.xlsx'
csv_filename=r'Release Rate.csv'
sheet_name=r'RAW'
year_month_col='P_Year-Month'
year_month=Year_Val+"-"+mon_Val_doubl_num
row_labels_lst=['P_Name']
values_lst=['Released?','SumOfP_Count']

fields = {col: str for col in [year_month_col]}
src_df=pd.read_csv(csv_filename, converters=fields,encoding='latin-1')

src_df=(src_df.loc[src_df[year_month_col].isin([year_month])])

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])

pivot_cols=list(pivot.columns)
print(pivot_cols)

dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']
dest_df[year_month_col]=year_month

dest_df['Sum of Released?']=df_join_res['Released?']
dest_df['Sum of SumOfP_Count']=df_join_res['SumOfP_Count']
dest_df['Sum of Release%']=df_join_res['Released?']/df_join_res['SumOfP_Count']

dest_df['P_Year']=int_Year_Val
dest_df['Month']=int_mon_Val_sngl_num
dest_df['Month_Str']=dest_df['Month'].astype(str)
dest_df['MSID']=df_join_res['MSID']
dest_df['Combo']=Year_Val+dest_df['Month_Str']+dest_df['MSID']
dest_df=dest_df.drop(columns=['Month_Str'])
dest_df=dest_df[[year_month_col,"P_Name","Sum of Released?","Sum of SumOfP_Count","Sum of Release%","P_Year","Month","MSID","Combo"]]
dest_df.to_excel(writer,'Release Rate',index=False,columns=list(dest_df.columns))
print("Release rate pivot generation")
######################### Release Rate Pivot generation #########################

######################### Escalation Pivot generation #########################

filename=r'PSO Escalation Dashboard.xlsx'
csv_filename=r'PSO Escalation Dashboard.csv'
sheet_name=r'AHTRaw'
year_month_col='P_Year-Month'
year_month=Year_Val+"-"+mon_Val_doubl_num
row_labels_lst=['P_Name']
values_lst=['Escalated Call Count','ACD ']

fields = {col: str for col in [year_month_col]}
src_df=pd.read_csv(csv_filename, converters=fields,encoding='latin-1')

src_df=(src_df.loc[src_df[year_month_col].astype(str).isin([year_month])])

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

pivot_cols=list(pivot.columns)
print(pivot_cols)

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])

dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']
dest_df[year_month_col]=year_month

dest_df['Sum of Escalated Call Count']=df_join_res['Escalated Call Count']
dest_df['Sum of ACD ']=df_join_res['ACD ']
dest_df['Esc %']=df_join_res['Escalated Call Count']/df_join_res['ACD ']

dest_df['P_Year']=int_Year_Val
dest_df['Month']=int_mon_Val_sngl_num
dest_df['Month_Str']=mon_Val_sngl_num
dest_df['MSID']=df_join_res['MSID']
dest_df['Combo']=Year_Val+dest_df['Month_Str']+dest_df['MSID']
dest_df=dest_df.drop(columns=['Month_Str'])
dest_df=dest_df[[year_month_col,"P_Name","Sum of Escalated Call Count","Sum of ACD ","Esc %","P_Year","Month","MSID","Combo"]]

dest_df.to_excel(writer,'Esclation',index=False,columns=list(dest_df.columns))
print("Escalation pivot generation completed")
######################### Escalation Pivot generation #########################


######################### Adherence Pivot generation #########################

filename=r'202003 - Open Time Adherence.xlsm'
sheet_name=r'RAW'
year_month_col='P_Year-Month'
year_month=Year_Val+"-"+mon_Val_doubl_num
row_labels_lst=['P_Name']
values_lst=['Min in Adherence','Min out of Adherence']


src_df=pd.read_excel(filename,sheet_name=sheet_name,encoding='latin-1')

pivot = src_df.pivot_table(index=row_labels_lst, values=values_lst, aggfunc='sum', fill_value=0)
pivot=pivot.reset_index()

pivot_cols=list(pivot.columns)
print(pivot_cols)

pivot["Name"]=pivot['P_Name']
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])


dest_df=pd.DataFrame()

dest_df['P_Name']=df_join_res['P_Name']


dest_df['Min in Adherence']=df_join_res['Min in Adherence']
dest_df['Min out of Adherence']=df_join_res['Min out of Adherence']


dest_df['P_Year']=int_Year_Val
dest_df['Month']=int_mon_Val_sngl_num
dest_df['Month_Str']=mon_Val_sngl_num
dest_df['MSID']=df_join_res['MSID']
dest_df['Combo']=Year_Val+dest_df['Month_Str']+dest_df['MSID']
dest_df=dest_df.drop(columns=['Month_Str'])
dest_df=dest_df[["P_Year","P_Name","Min in Adherence","Min out of Adherence","Month","MSID","Combo"]]
dest_df.to_excel(writer,'Adherence',index=False,columns=list(dest_df.columns))
print('Adherence pivot generation completed')
######################### Adherence Pivot generation #########################



################# SCORE CARD SHEETS GENERATION ##############################

score_card=r'202003 - Scorecard.xlsm'
score_card_sname=r'FRONTLINERS'

df=pd.read_excel(score_card,sheet_name=score_card_sname,skiprows=14,encoding='latin-1')
df=df[['EID','MSID','EMPLOYEE NAME']]
df['Year']=Year_Val
df['MonthName']=(last_mon_text.split('-')[1])[0:3]
df['Month']=mon_Val_sngl_num
df['Combo']=df['Year']+df['Month']+df['MSID']
df['Combo - Name Month']=df['EMPLOYEE NAME']+df['Year']+df['Month']
df=df[['Combo','EID','MSID','EMPLOYEE NAME','Year','MonthName','Month','Combo - Name Month']]
df.to_excel(writer,'MSID List from Scorecard',index=False,columns=list(df.columns))

existing_vlookup_file=r'existing_ms id emp name.xlsx'
existing_vlookup_sname=r'ms id emp name'


dbdf=df[['MSID','EMPLOYEE NAME']]


evlddf=pd.read_excel(existing_vlookup_file,sheet_name=existing_vlookup_sname,encoding='latin-1')

df=evlddf.append(dbdf,ignore_index=True)

df=df.dropna(subset=['MSID'])
df=df.drop_duplicates(subset=['MSID','EMPLOYEE NAME'], keep='last')

df.to_excel(writer,existing_vlookup_sname,index=False,columns=list(df.columns))   
writer.save() 
print("score card sheets generated for agg file completed")
################# SCORE CARD SHEETS GENERATION ##############################


################  Agent score card .xlsx file generation ########################

Year_Val=str(last_mon_text.split('-')[2])
mon_Val_sngl_num=str(int(str(last_mon_text.split('-')[0]))*1)
mon_Val_doubl_num=str(last_mon_text.split('-')[0])

score_card=r'202003 - Scorecard.xlsm'
score_card_sname=r'FRONTLINERS'

df=pd.read_excel(score_card,sheet_name=score_card_sname,skiprows=14)
df=df[['Serial No.','EID','MSID','EMPLOYEE NAME','SUPERVISOR','PROCESS','LOCATION','QVC SG','AGENT STATUS','OVERALL RATING','KPI RATING','CORE VALUES RATING','HYGIENE RATING','TOTAL QVC AMOUNT','METRIC 1','METRIC 2','METRIC 3','METRIC 1.1','METRIC 2.1','METRIC 3.1','METRIC 1.2','METRIC 2.2','METRIC 3.2','METRIC 1.3','METRIC 2.3','METRIC 3.3','KPI','CORE VALUES','HYGIENE','AGG UES','CV - INTEGRITY','CV - COMPASSION','CV - RELATIONSHIP','CV - INNOVATION','CV - PERFORMANCE','ADHERENCE','RELEASE RATE','LOST HOURS','SCHEDULED PLANNED PAID','PLANNED PAID DAYS','AHT % TO GOAL','AHT GOAL',' B&E',' CLAIMS',' INTAKE',' B&E VOLUME IN %',' CLAIMS VOLUME IN %',' INTAKE VOLUME IN %','DAYS PRESENT <8 DAYS','CAP','ATTENDANCE (LWOP, LOA ETC.)','PIP','OTHER','FAILED METRIC','QVC ELIGIBILITY','QVC PAYOUT TYPE','QVC AMOUNT %','CURVE RANKING','SCORECARD TYPE','REMARKS']]

# df=df[['EID','MSID','EMPLOYEE NAME']]
df['Year']=Year_Val
df['Month']=last_mon_text.split('-')[1]
df['MonthName']=mon_Val_sngl_num
scds=datetime.date(datetime(int(Year_Val),int(mon_Val_sngl_num),1))
scds=format(scds,'%d/%m/%Y')
df['slice_date']= scds
df['Combo']=df['Year']+df['MonthName']+df['MSID']

df=df[['Combo','Serial No.','EID','MSID','EMPLOYEE NAME','SUPERVISOR','PROCESS','LOCATION','QVC SG','AGENT STATUS','OVERALL RATING','KPI RATING','CORE VALUES RATING','HYGIENE RATING','TOTAL QVC AMOUNT','METRIC 1','METRIC 2','METRIC 3','METRIC 1.1','METRIC 2.1','METRIC 3.1','METRIC 1.2','METRIC 2.2','METRIC 3.2','METRIC 1.3','METRIC 2.3','METRIC 3.3','KPI','CORE VALUES','HYGIENE','AGG UES','CV - INTEGRITY','CV - COMPASSION','CV - RELATIONSHIP','CV - INNOVATION','CV - PERFORMANCE','ADHERENCE','RELEASE RATE','LOST HOURS','SCHEDULED PLANNED PAID','PLANNED PAID DAYS','AHT % TO GOAL','AHT GOAL',' B&E',' CLAIMS',' INTAKE',' B&E VOLUME IN %',' CLAIMS VOLUME IN %',' INTAKE VOLUME IN %','DAYS PRESENT <8 DAYS','CAP','ATTENDANCE (LWOP, LOA ETC.)','PIP','OTHER','FAILED METRIC','QVC ELIGIBILITY','QVC PAYOUT TYPE','QVC AMOUNT %','CURVE RANKING','SCORECARD TYPE','REMARKS','Year','Month','MonthName','slice_date']]

df.to_excel(r'AgentScoreCard_m.xlsx',sheet_name='Sheet1',index=False)
print('Agent score card .xlsx file generation completed')
################  Agent score card .xlsx file generation ########################


################  AgentCountbySup.xlsx file generation ########################

score_card=r'202003 - Scorecard.xlsm'
score_card_sname=r'FRONTLINERS'

df=pd.read_excel(score_card,sheet_name=score_card_sname,skiprows=14)
df=df[['MSID','SUPERVISOR']]

pivot = df.pivot_table(index='SUPERVISOR', values='MSID', aggfunc='count', fill_value=0)
pivot=pivot.reset_index()
pivot['MSID_P']=pivot['MSID']
pivot["Name"]=pivot['SUPERVISOR']
pivot=pivot.drop(columns=['MSID'])
df_join_res=pd.merge(pivot,df_vlookup,how='left',on=["Name"])


df1=df_join_res
df1['Year']=Year_Val
df1['Month Name Short']=last_mon_text.split('-')[1]
df1['AgentCount']=df1['MSID_P']
df1=df1[['Year','Month Name Short','SUPERVISOR','AgentCount','MSID']]
df1.to_excel(r'AgentCountbySup_m.xlsx',sheet_name='Sheet1',index=False)
print('AgentCountbySup.xlsx file generation completed')
################  AgentCountbySup.xlsx file generation ########################


################  pforms_supervisor.xlsx file generation ########################

score_card=r'202003 - Scorecard.xlsm'
score_card_sname=r'SUPERVISORS'

df=pd.read_excel(score_card,sheet_name=score_card_sname,skiprows=14)
# print(df.columns)
df=df[['Serial No.','EID','MSID','EMPLOYEE NAME','SUPERVISOR','LOCATION','AGENT STATUS','METRIC 1.1', 'METRIC 2.1','METRIC 3.1','QVC ELIGIBILITY','QVC PAYOUT TYPE']]
df['Month']=mon_Val_sngl_num
df['Year']=Year_Val
df['MonthName']=last_mon_text.split('-')[1]

df.to_excel(r'Pfrom_Supervisor_m.xlsx',sheet_name='Sheet1',index=False)
print('pforms_supervisor.xlsx file generation completed')
################  pforms_supervisor.xlsx file generation ########################