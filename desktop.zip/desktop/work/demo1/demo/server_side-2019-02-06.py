import os
from zipfile import ZipFile
from flask import Blueprint, Flask, render_template, request, redirect, url_for, send_from_directory, jsonify, send_file
# from werkzeug import secure_filename
from logging import Formatter, FileHandler
import shutil
import logging

wfnaudit = Blueprint('wfnaudit', __name__, template_folder='templates')


# This is the path to the upload directory
directory = 'upload/'
basedir = os.path.abspath(os.path.dirname(__file__))

# Initialize the Flask application

app = Flask(__name__)


# These are the extension that we are accepting to be uploaded

app.config['ALLOWED_EXTENSIONS'] = set(['ADJ'])

# For a given file, return whether it's an allowed type or not


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


@wfnaudit.route('/test')
def index():
    print("test")
    return render_template('home_page.html')

if __name__ == '__main__':
    app.run(debug=True)