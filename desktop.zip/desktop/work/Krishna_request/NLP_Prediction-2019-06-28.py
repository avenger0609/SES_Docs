#!/usr/bin/env python
# coding: utf-8

# In[1]:


import ImportPythonModules
from ImportPythonModules import *


logreg = LogisticRegression()
def PrintFeatureCoeffs(model, TestX):
    # Get numerical feature importances
    importances = list(model.coef_)
    # List of tuples with variable and importance
    feature_importances = [(feature, round(importance, 2)) for feature, importance in zip(TestX.columns, importances)]
    # Sort the feature importances by most important first
    feature_importances = sorted(feature_importances, key = lambda x: x[1], reverse = True)
    # Print out the feature and importances 
    [print('Variable: {:20} Importance: {}'.format(*pair)) for pair in feature_importances];
    
def PrintLogRegSummary(TestX, TestY, PredictedY):
    # Print Classification Report
    print(classification_report(TestY,PredictedY))
    # Print Confusion Matrix
    print(confusion_matrix(TestY, PredictedY))
    y_pred_proba = logreg.predict_proba(TestX)[:, 1]
    # Print ROC Curve
    [fpr, tpr, thr] = roc_curve(TestY, y_pred_proba)
    print('Train/Test split results:')
    print(logreg.__class__.__name__+" accuracy is %2.3f" % accuracy_score(TestY, PredictedY))
    print(logreg.__class__.__name__+" log_loss is %2.3f" % log_loss(TestY, y_pred_proba))
    print(logreg.__class__.__name__+" auc is %2.3f" % auc(fpr, tpr))
    print("The coefficients of the logistic regresion with are:")
    #PrintFeatureCoeffs(logreg, TestX)
    print(logreg.coef_)
    #print(zip(TestX.columns, logreg.coef_))
    idx = np.min(np.where(tpr > 0.95)) # index of the first threshold for which the sensibility > 0.95
    plt.figure()
    plt.plot(fpr, tpr, color='coral', label='ROC curve (area = %0.3f)' % auc(fpr, tpr))
    plt.plot([0, 1], [0, 1], 'k--')
    plt.plot([0,fpr[idx]], [tpr[idx],tpr[idx]], 'k--', color='blue')
    plt.plot([fpr[idx],fpr[idx]], [0,tpr[idx]], 'k--', color='blue')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate (1 - specificity)', fontsize=14)
    plt.ylabel('True Positive Rate (recall)', fontsize=14)
    plt.title('Receiver operating characteristic (ROC) curve')
    plt.legend(loc="lower right")
    plt.show()
    print("Using a threshold of %.3f " % thr[idx] + "guarantees a sensitivity of %.3f " % tpr[idx] +  
          "and a specificity of %.3f" % (1-fpr[idx]) + 
          ", i.e. a false positive rate of %.2f%%." % (np.array(fpr[idx])*100))

def PrintFeatureImportances(model, TestX):
    # Get numerical feature importances
    importances = list(model.feature_importances_)
    # List of tuples with variable and importance
    feature_importances = [(feature, round(importance, 2)) for feature, importance in zip(TestX.columns, importances)]
    # Sort the feature importances by most important first
    feature_importances = sorted(feature_importances, key = lambda x: x[1], reverse = True)
    # Print out the feature and importances 
    [print('Variable: {:20} Importance: {}'.format(*pair)) for pair in feature_importances];



def print_confusion_matrix(y_true, y_pred):
    cm = confusion_matrix(y_true, y_pred)
    print('True positive = ', cm[0][0])
    print('False positive = ', cm[0][1])
    print('False negative = ', cm[1][0])
    print('True negative = ', cm[1][1])
    return cm

def PrintCARTSummary(dt, TestX, TestY, Predictions):
    print("Test Accuracy:", accuracy_score(TestY, Predictions))
    cm = print_confusion_matrix(TestY, Predictions) 
    print("Sensitivity=",(cm[0][0]/(cm[0][0]+cm[1][0])))
    PrintFeatureImportances(dt, TestX)
    #print(dict(zip(TestX.columns, dt.feature_importances_)))
    importances = dt.feature_importances_
    indices = np.argsort(importances)
    plt.figure(1)
    plt.title('Feature Importances')
    plt.barh(range(len(indices)), importances[indices], color='b', align='center')
    plt.xlabel('Relative Importance')

    # In[3]:

# def nlp_prediction(path1,fname):
def nlp_prediction():
    # Step1: Load the input files given for Analysis
    input = pd.read_excel("C:\\Users\\asrilekh\\desktop\\work\\krishna_request\\PPM_Updated_EDA_all.xlsx")
    # input = pd.read_excel(fname)
    raw = input.copy(deep=True)      # Create a dummy data frame from the original list
    print(raw.columns) # Get all the columns names  
    print(raw.dtypes)


    # In[4]:


    print(raw.shape)
    for i in raw.columns:
        print(i, "---> Unique values=", raw[i].nunique(), "|||| NA Values=", sum(pd.isnull(raw[i])))


    # In[5]:


    ########################################################################################
    # Method1: Drop all the corelated variables
    ########################################################################################
    raw_dummies = pd.get_dummies(raw, columns=['healthplan','epd_uhnregion','sat3','com1','cs1','rx1','mr1','mr2','net1a','cred1a','auth1a','cl4','permission','draw'])


    # In[6]:


    raw_dummies.columns


    # In[7]:


    raw_2016 = raw_dummies[raw_dummies.year == 2016]
    raw_2017 = raw_dummies[raw_dummies.year == 2017]
    raw_2018 = raw_dummies[raw_dummies.year == 2018]
    raw_2019 = raw_dummies[raw_dummies.year == 2019]


    # In[8]:


    raw.to_csv("C:\\Users\\asrilekh\\desktop\\work\\krishna_request\\dummies.csv")


    # In[9]:


    # Consider 2018 as Training data and 2019 as Test data
    TrainingX_2018 = raw_2018
    TrainingY_2018 = raw_2018['sat1']
    TrainingY_2018 = TrainingY_2018.replace(2, 0, regex=True)

    TestX_2019 = raw_2019
    TestY_2019 = raw_2019['sat1']
    TestY_2019 = TestY_2019.replace(2, 0, regex=True)

    TestX_2017 = raw_2017
    TestY_2017 = raw_2017['sat1']
    TestY_2017 = TestY_2017.replace(2, 0, regex=True)

    TestX_2016 = raw_2016
    TestY_2016 = raw_2016['sat1']
    TestY_2016 = TestY_2016.replace(2, 0, regex=True)

    TrainingX_2018.drop(['sat1','year'], axis =1, inplace=True)
    TestX_2019.drop(['sat1','year'], axis =1, inplace=True)
    TestX_2017.drop(['sat1','year'], axis =1, inplace=True)
    TestX_2016.drop(['sat1','year'], axis =1, inplace=True)


    # In[10]:


    # Run Logistic Regression
    logreg = LogisticRegression()

    logreg.fit(TrainingX_2018, TrainingY_2018)
    Predictions_Logit_2019 = logreg.predict(TestX_2019)
    Predictions_Logit_2017 = logreg.predict(TestX_2017)
    Predictions_Logit_2016 = logreg.predict(TestX_2016)


    # In[11]:


    # In[12]:


    PrintLogRegSummary(TestX_2019, TestY_2019, Predictions_Logit_2019)


    # In[13]:


    PrintLogRegSummary(TestX_2017, TestY_2017, Predictions_Logit_2017)


    # In[14]:


    PrintLogRegSummary(TestX_2016, TestY_2016, Predictions_Logit_2016)


    # In[15]:




    # In[16]:


    # Decision Tree Classifier
    # Based on GINI index
    dt_gini = DecisionTreeClassifier(criterion = "gini", random_state = 11)
    trainedmodel_gini = dt_gini.fit(TrainingX_2018, TrainingY_2018)
    Predictions_DT_GINI_2019 = dt_gini.predict(TestX_2019)
    Predictions_DT_GINI_2017 = dt_gini.predict(TestX_2017)
    Predictions_DT_GINI_2016 = dt_gini.predict(TestX_2016)

    # Based on Entropy Loss
    dt_entr = DecisionTreeClassifier(criterion= "entropy", random_state= 42)
    trainedmodel_entr = dt_entr.fit(TrainingX_2018, TrainingY_2018)
    Predictions_DT_ENTR_2019 = dt_entr.predict(TestX_2019)
    Predictions_DT_ENTR_2017 = dt_entr.predict(TestX_2017)
    Predictions_DT_ENTR_2016 = dt_entr.predict(TestX_2016)


    # In[17]:


    # In[18]:


    PrintCARTSummary(dt_gini, TestX_2016, TestY_2016, Predictions_DT_GINI_2016)


    # In[19]:


    PrintCARTSummary(dt_gini, TestX_2017, TestY_2017, Predictions_DT_GINI_2017)


    # In[20]:


    PrintCARTSummary(dt_gini, TestX_2019, TestY_2019, Predictions_DT_GINI_2019)


    # In[21]:


    PrintCARTSummary(dt_entr, TestX_2019, TestY_2019, Predictions_DT_ENTR_2019)


    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[23]:


    # Training AdaBoost algorithm with 10-Fold Cross Validation
    kfold = model_selection.KFold(n_splits=10, random_state=42)
    AdaBoost = AdaBoostClassifier(n_estimators=150,learning_rate=0.1)#,algorithm='SAMME')
    results = model_selection.cross_val_score(AdaBoost, TrainingX_2018, TrainingY_2018, cv=kfold)
    print(results.mean())
    adatrained = AdaBoost.fit(TrainingX_2018,TrainingY_2018)
    y_pred = AdaBoost.predict(TestX_2019)
    print(accuracy_score(y_pred, TestY_2019))
    PrintFeatureImportances(AdaBoost, TestX_2019)
    importances = AdaBoost.feature_importances_
    indices = np.argsort(importances)
    plt.figure(1)
    plt.title('Feature Importances')
    plt.barh(range(len(indices)), importances[indices], color='b', align='center')
    plt.xlabel('Relative Importance')
    #print(dict(zip(TestX_2019.columns, AdaBoost.feature_importances_)))


    # In[24]:


    y_pred = AdaBoost.predict(TestX_2017)
    print(accuracy_score(y_pred, TestY_2017))
    print(classification_report(TestY_2017, y_pred))
    PrintFeatureImportances(AdaBoost, TestX_2017)
    importances = AdaBoost.feature_importances_
    indices = np.argsort(importances)
    plt.figure(1)
    plt.title('Feature Importances')
    plt.barh(range(len(indices)), importances[indices], color='b', align='center')
    plt.xlabel('Relative Importance')
    #print(dict(zip(TestX_2017.columns, AdaBoost.feature_importances_)))


    # In[25]:


    y_pred = AdaBoost.predict(TestX_2016)
    print(accuracy_score(y_pred, TestY_2016))
    PrintFeatureImportances(AdaBoost, TestX_2016)
    importances = AdaBoost.feature_importances_
    indices = np.argsort(importances)
    plt.figure(1)
    plt.title('Feature Importances')
    plt.barh(range(len(indices)), importances[indices], color='b', align='center')
    plt.xlabel('Relative Importance')
    #print(dict(zip(TestX_2016.columns, AdaBoost.feature_importances_)))


    # In[ ]:





    # In[26]:


    from sklearn.ensemble import RandomForestRegressor
    ### Running a Random Forest model and checking the accuracy....
    rf = RandomForestRegressor(n_estimators = 1000, random_state = 42)
    # Train the model on training data
    rf.fit(TrainingX_2018, TrainingY_2018);
    # Use the forest's predict method on the test data
    Predictions_RF_2019 = rf.predict(TestX_2019)
    Predictions_RF_2017 = rf.predict(TestX_2017)
    Predictions_RF_2016 = rf.predict(TestX_2016)

    # Calculate the absolute errors
    errors_2019 = abs(Predictions_RF_2019 - TestY_2019)
    errors_2017 = abs(Predictions_RF_2017 - TestY_2017)
    errors_2016 = abs(Predictions_RF_2016 - TestY_2016)

    # Print out the mean absolute error (mae)
    print('Mean Absolute Error for 2019 data:', round(np.mean(errors_2019), 2))
    print('Mean Absolute Error for 2017 data:', round(np.mean(errors_2017), 2))
    print('Mean Absolute Error for 2016 data:', round(np.mean(errors_2016), 2))

    # Calculate mean absolute percentage error (MAPE)
    mape_2019 = 100 * (errors_2019 / Predictions_RF_2019)
    mape_2017 = 100 * (errors_2017 / Predictions_RF_2017)
    mape_2016 = 100 * (errors_2016 / Predictions_RF_2016)

    print("MAPE 2019: ",mape_2019)
    print("MAPE 2017: ",mape_2017)
    print("MAPE 2016: ",mape_2016)

    # Calculate and display accuracy
    accuracy_2019 = 100 - np.mean(mape_2019)
    accuracy_2017 = 100 - np.mean(mape_2017)
    accuracy_2016 = 100 - np.mean(mape_2016)

    print('Accuracy 2019:', round(accuracy_2019, 2), '%.')
    print('Accuracy 2017:', round(accuracy_2017, 2), '%.')
    print('Accuracy 2016:', round(accuracy_2016, 2), '%.')


    # In[27]:


    #print_confusion_matrix(TestY_2016, Predictions_RF_2016)
    #print(dict(zip(TestY_2019.columns, rf.feature_importances_)))


    # In[29]:


    #print(accuracy_score(Predictions_RF_2017, TestY_2017))
    #print(dict(zip(TestY_2017.columns, rf.feature_importances_)))


    # In[30]:


    #print(accuracy_score(Predictions_RF_2019, TestY_2019))
    #print(dict(zip(TestY_2019.columns, rf.feature_importances_)))


    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[32]:


    from sklearn import tree
    import pydot 
    #from sklearn.externals.six import StringIO 

    # dotfile = open("C://Users//achand27//Dtree.export_graphviz(dt_gini, out_file='C://Users//achand27//Documents//Projects//AnalyticsProjs//NLP//Input_PPM//PPMtree.dot')   
    # ocuments//Projects//AnalyticsProjs//NLP//Input_PPM//PPM_dtree.dot", 'w')
    # tree.export_graphviz(dt_gini, out_file = dotfile, feature_names = TrainingX_2018.columns)
    # dotfile.close()
    #dot_data = StringIO() 
    # tree.export_graphviz(dt_gini, out_file = dotfile, feature_names = TrainingX_2018.columns)
    # graph = pydot.graph_from_dot_data(dot_data.getvalue()) 
    # graph[0].write_pdf("iris.pdf")  # must access graph's first element

nlp_prediction()