#!/usr/bin/env python
# coding: utf-8

# In[1]:


import ImportPythonModules
from ImportPythonModules import *


def ConvertToBinary(x):
    if x>7:
        return 1 #'Promoter'
    else:
        return 2 #'NonPromoter'


def data_pp_np_prediction(path1,fname):
    # In[11]:


    # Step1: Load the input files given for Analysis
    input = pd.read_excel(fname)
    raw = input.copy(deep=True)      # Create a dummy data frame from the original list
    raw.columns      # Get all the columns names 


    # In[12]:


    # Check the data types of the data frame
    print(raw.shape)
    for i in raw.columns:
        print(i, "---> Unique values=", raw[i].nunique(),"|||| NA Values=", sum(pd.isnull(raw[i])), "|||type=", raw[i].dtype)


    # In[15]:


    # The below plot tells how the NA variables are distributed in the 2018 data....
    print("Below is the NA value distribution for raw data")
    plt.figure(figsize=(16,8))
    sns.heatmap(raw.isnull(),yticklabels=False,cbar=False,cmap='viridis');


    # In[16]:


    raw.head(2)


    # In[65]:


    # Consider only those observations whose sat1 scores are available...
    raw_filtered = raw[raw.sat1>-1]  # this dataframe contains those observations whose sat1 scores are >= 0
    raw_unknown = raw[raw.sat1<0] # Collect all unknown sat1 score observations in other dataframe
    print("The shape of dataframe when sat1 scores are available:   ", raw_filtered.shape)
    print("The shape of dataframe when sat1 scores are not available:   ", raw_unknown.shape)


    # In[66]:


    # Create new column i.e. year
    raw_filtered['rptqtr'] = raw_filtered['rptqtr'].apply(str) 
    raw_filtered['year'] = ""
    raw_filtered['year'] = raw_filtered['rptqtr'].apply(lambda x: x[:4])
    raw_filtered.drop('rptqtr', axis = 1, inplace=True)
    raw_filtered['year'] = raw_filtered.year.astype(int)
    print("The shape of dataframe for the years 2016/17/18/2019:   ", raw_filtered.shape)


    # In[67]:


    # Convert all columns which has 0-10 ratings in to Promoters and Non-Promoters category. 
    # anything 9,10 is highly rated and left over are not properly rated...

    # In[68]:


    # Impute the NaN values with 0 for flag columns....
    # Flag for Core Strategic account
    # Contracted with Medicare Flag 
    # Is the org type an FQHC? 
    # Is the provider in the platinum service model?
    # Select the role that best represents your primary role in your medical practice. (Please select only one.)
    # Select the role that best represents your primary role in your medical practice. (Please select only one.)
    # Select the role that best represents your primary role in your medical practice. (Please select only one.)
    raw_filtered['strategic_acct_flag'].fillna(0, inplace=True)
    raw_filtered['core_acct_flag'].fillna(0, inplace=True)
    raw_filtered['medicare_flag'].fillna(0, inplace=True)
    raw_filtered['fqhc_flag'].fillna(0, inplace=True)
    raw_filtered['platinum_flag'].fillna(0, inplace=True)
    raw_filtered['a1_md'].fillna(0, inplace=True)
    raw_filtered['a1_pm'].fillna(0, inplace=True)
    raw_filtered['a1_other'].fillna(0, inplace=True)


    # In[69]:


    # If there is any NULL value in the sat2 column, then fill it from the sat1 column
    # If there is any NULL value in the sat3, sat4 column, then fill it from the sat2 column

    #sat2 ---> Unique values= 11 |||| NA Values= 6  --- sat2: Overall Sat
    #sat3 ---> Unique values= 12 |||| NA Values= 1034 --- sat3: Likelihood to renew with UHC
    #sat4 ---> Unique values= 11 |||| NA Values= 21 --- sat4: Easy to do business with

    # sat1 ---> Unique values= 13 |||| NA Values= 0 |||type= int64
    # sat2 ---> Unique values= 11 |||| NA Values= 10 |||type= float64
    # sat3 ---> Unique values= 13 |||| NA Values= 4344 |||type= float64
    # sat4 ---> Unique values= 12 |||| NA Values= 33 |||type= float64
    raw_filtered['sat2'].fillna(raw_filtered['sat1'], inplace=True)
    #raw_filtered['sat3'].fillna(raw_filtered['sat3'].mode()[0], inplace=True)
    raw_filtered['sat3'].fillna(raw_filtered['sat4'], inplace=True)  # Why imputed with Sat2, look at above NA count.. more...so, let us not got with sat1 target variable
    raw_filtered['sat4'].fillna(raw_filtered['sat1'], inplace=True)
    raw_filtered['sat3'].fillna(raw_filtered['sat1'], inplace=True)
    # Cofilteredt the 1 to 10 Ratings into binary format i.e. 1, 2
    raw_filtered['sat1'] = raw_filtered['sat1'].apply(ConvertToBinary)
    raw_filtered['sat2'] = raw_filtered['sat2'].apply(ConvertToBinary)
    raw_filtered['sat3'] = raw_filtered['sat3'].apply(ConvertToBinary)
    raw_filtered['sat4'] = raw_filtered['sat4'].apply(ConvertToBinary)


    # In[70]:


    # com1 ---> Unique values= 12 |||| NA Values= 4  -> Ability to proactively inform
    # com2a ---> Unique values= 12 |||| NA Values= 6 -> Ease of accessing info
    # com2b ---> Unique values= 12 |||| NA Values= 30 -> Ease of understanding
    # com2c ---> Unique values= 12 |||| NA Values= 19 -> Clarity of info
    # com2d ---> Unique values= 12 |||| NA Values= 30 -> Timing of info provided
    ## Below lines are for imputing the communication columns

    # raw_2018['com2a'] = raw_2018['com2a'].fillna(value=raw_2018['com1'])
    # raw_2018['com2b'] = raw_2018['com2b'].fillna(value=raw_2018['com1'])
    # raw_2018['com2c'] = raw_2018['com2c'].fillna(value=raw_2018['com1'])
    # raw_2018['com2d'] = raw_2018['com2d'].fillna(value=raw_2018['com1'])

    raw_filtered['com1']  = raw_filtered['com1'].fillna(value=raw_filtered['sat1'])
    raw_filtered['com2a'] = raw_filtered['com2a'].fillna(value=raw_filtered['sat1'])
    raw_filtered['com2b'] = raw_filtered['com2b'].fillna(value=raw_filtered['sat1'])
    raw_filtered['com2c'] = raw_filtered['com2c'].fillna(value=raw_filtered['sat1'])
    raw_filtered['com2d'] = raw_filtered['com2d'].fillna(value=raw_filtered['sat1'])

    raw_filtered['com1']  = raw_filtered['com1'].apply(ConvertToBinary)
    raw_filtered['com2a'] = raw_filtered['com2a'].apply(ConvertToBinary)
    raw_filtered['com2b'] = raw_filtered['com2b'].apply(ConvertToBinary)
    raw_filtered['com2c'] = raw_filtered['com2c'].apply(ConvertToBinary)
    raw_filtered['com2d'] = raw_filtered['com2d'].apply(ConvertToBinary)


    # In[71]:


    # cs1  ---> Unique values= 11 |||| NA Values= 9	Overall, how satisfied are you with the service experience provided to you by UnitedHealthcare?				
    # cs2a ---> Unique values= 12 |||| NA Values= 12	rate UHC Provider Service call center on the Number of times you are transferred on average when speaking with a customer service representative				
    # cs2b ---> Unique values= 12 |||| NA Values= 24	Please indicate how you would rate UHC Provider Service call center on the Ability of representatives to correctly resolve your issue on the first call				
    # cs2c ---> Unique values= 12 |||| NA Values= 31	Please indicate how you would rate UHC Provider Service call center on the  Time it takes to close an issue after requesting a claim adjustment				
    # cs3a ---> Unique values= 12 |||| NA Values= 21	"Timeliness of claims processing on first submission"				
    # cs3b ---> Unique values= 12 |||| NA Values= 23	"Accuracy of claims processing on first submission"				
    # cs3c ---> Unique values= 12 |||| NA Values= 26	"Clear on reasons for a denied claim"				
    # cs3d ---> Unique values= 12 |||| NA Values= 28	"Timeliness of the claim reconsideration process"				
    # cs3e ---> Unique values= 12 |||| NA Values= 32	"Accuracy of the claim reconsideration process"				
    # cs3f ---> Unique values= 12 |||| NA Values= 33	"Ease of the appeals process"				
    # cs3g ---> Unique values= 12 |||| NA Values= 29	"Timeliness of the appeals process"				

    raw_filtered['cs1']  = raw_filtered['cs1'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs2a'] = raw_filtered['cs2a'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs2b'] = raw_filtered['cs2b'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs2c'] = raw_filtered['cs2c'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs3a'] = raw_filtered['cs3a'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs3b'] = raw_filtered['cs3b'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs3c'] = raw_filtered['cs3c'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs3d'] = raw_filtered['cs3d'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs3e'] = raw_filtered['cs3e'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs3f'] = raw_filtered['cs3f'].fillna(value=raw_filtered['sat1'])
    raw_filtered['cs3g'] = raw_filtered['cs3g'].fillna(value=raw_filtered['sat1'])

    raw_filtered['cs1']  = raw_filtered['cs1'].apply(ConvertToBinary)
    raw_filtered['cs2a'] = raw_filtered['cs2a'].apply(ConvertToBinary)
    raw_filtered['cs2b'] = raw_filtered['cs2b'].apply(ConvertToBinary)
    raw_filtered['cs2c'] = raw_filtered['cs2c'].apply(ConvertToBinary)
    raw_filtered['cs3a'] = raw_filtered['cs3a'].apply(ConvertToBinary)
    raw_filtered['cs3b'] = raw_filtered['cs3b'].apply(ConvertToBinary)
    raw_filtered['cs3c'] = raw_filtered['cs3c'].apply(ConvertToBinary)
    raw_filtered['cs3d'] = raw_filtered['cs3d'].apply(ConvertToBinary)
    raw_filtered['cs3e'] = raw_filtered['cs3e'].apply(ConvertToBinary)
    raw_filtered['cs3f'] = raw_filtered['cs3f'].apply(ConvertToBinary)
    raw_filtered['cs3g'] = raw_filtered['cs3g'].apply(ConvertToBinary)


    # In[72]:


    # Impute the below columns with sat1 as the count is less than 2%
    # cred1a: Reimbursement: Competitiveness of rates, 
    # cred1b: Communications: Ease of understanding medical and reimbursement policies
    # cred1c: Communications: Consistency of medical and reimbursement policies
    # cred1d: Onboarding: Ease of credentialing process
    # cred1e: Onboarding: Ease of contracting process
    raw_filtered['cred1a'].fillna(value=raw_filtered['sat1'], inplace = True)
    raw_filtered['cred1b'].fillna(value=raw_filtered['sat1'], inplace = True)
    raw_filtered['cred1c'].fillna(value=raw_filtered['sat1'], inplace = True)
    raw_filtered['cred1d'].fillna(value=raw_filtered['sat1'], inplace = True)
    raw_filtered['cred1e'].fillna(value=raw_filtered['sat1'], inplace = True)

    raw_filtered['cred1a'] = raw_filtered['cred1a'].apply(ConvertToBinary)
    raw_filtered['cred1b'] = raw_filtered['cred1b'].apply(ConvertToBinary)
    raw_filtered['cred1c'] = raw_filtered['cred1c'].apply(ConvertToBinary)
    raw_filtered['cred1d'] = raw_filtered['cred1d'].apply(ConvertToBinary)
    raw_filtered['cred1e'] = raw_filtered['cred1e'].apply(ConvertToBinary)


    # In[73]:


    # rx1 ---> Unique values= 13 |||| NA Values= 1040  Ease of matching drugs to formulary and treatment plan.
    # rx2 ---> Unique values= 12 |||| NA Values= 43  Ease of prior authorization
    # rx3 ---> Unique values= 12 |||| NA Values= 81  Timeliness of prior authorization
    raw_filtered['rx1'].fillna(value=raw_filtered['rx2'], inplace=True)
    raw_filtered['rx3'].fillna(value=raw_filtered['rx2'], inplace=True)
    raw_filtered['rx1'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['rx2'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['rx3'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['rx1'] = raw_filtered['rx1'].apply(ConvertToBinary)
    raw_filtered['rx2'] = raw_filtered['rx2'].apply(ConvertToBinary)
    raw_filtered['rx3'] = raw_filtered['rx3'].apply(ConvertToBinary)


    # In[74]:


    # auth1a ---> Unique values= 12 |||| NA Values= 12   Ease of prior authorization for non-radiology services
    # auth1b ---> Unique values= 12 |||| NA Values= 13   Timeliness of prior authorization for non-radiology services
    # auth1c ---> Unique values= 12 |||| NA Values= 21   Ease of notification/prior authorization for radiology
    # auth1d ---> Unique values= 12 |||| NA Values= 21   Timeliness of notification/prior authorization process for radiology
    # auth1e ---> Unique values= 12 |||| NA Values= 28   Ease of clinical review process 
    # auth1f ---> Unique values= 12 |||| NA Values= 25   Timeliness of clinical review process

    raw_filtered['auth1a'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['auth1b'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['auth1c'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['auth1d'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['auth1e'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['auth1f'].fillna(value=raw_filtered['sat1'], inplace=True)

    raw_filtered['auth1a'] = raw_filtered['auth1a'].apply(ConvertToBinary)
    raw_filtered['auth1b'] = raw_filtered['auth1b'].apply(ConvertToBinary)
    raw_filtered['auth1c'] = raw_filtered['auth1c'].apply(ConvertToBinary)
    raw_filtered['auth1d'] = raw_filtered['auth1d'].apply(ConvertToBinary)
    raw_filtered['auth1e'] = raw_filtered['auth1e'].apply(ConvertToBinary)
    raw_filtered['auth1f'] = raw_filtered['auth1f'].apply(ConvertToBinary)


    # In[75]:


    # mr1 ---> Unique values= 12 |||| NA Values= 27  MedRecords: Frequency of medical record requests
    # mr2 ---> Unique values= 12 |||| NA Values= 26  MedRecords: Number of medical records requested
    # mr3 ---> Unique values= 12 |||| NA Values= 27  MedRecords: Coordination of medical record requests

    raw_filtered['mr1'].fillna(value=raw_filtered['mr1'].mode()[0], inplace=True)
    raw_filtered['mr2'].fillna(value=raw_filtered['mr2'].mode()[0], inplace=True)
    raw_filtered['mr3'].fillna(value=raw_filtered['mr3'].mode()[0], inplace=True)

    raw_filtered['mr1'] = raw_filtered['mr1'].apply(ConvertToBinary)
    raw_filtered['mr2'] = raw_filtered['mr2'].apply(ConvertToBinary)
    raw_filtered['mr3'] = raw_filtered['mr3'].apply(ConvertToBinary)


    # In[76]:


    # net1a ---> Unique values= 12 |||| NA Values= 27 Network: Quality of network
    # net1b ---> Unique values= 12 |||| NA Values= 26 Network: Number of specialists for referrals
    # net1c ---> Unique values= 12 |||| NA Values= 29 Network: Availability of specialists to accommodate your referrals

    raw_filtered['net1a'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['net1b'].fillna(value=raw_filtered['sat1'], inplace=True)
    raw_filtered['net1c'].fillna(value=raw_filtered['sat1'], inplace=True)

    raw_filtered['net1a'] = raw_filtered['net1a'].apply(ConvertToBinary)
    raw_filtered['net1b'] = raw_filtered['net1b'].apply(ConvertToBinary)
    raw_filtered['net1c'] = raw_filtered['net1c'].apply(ConvertToBinary)


    # In[77]:


    raw_filtered['cl4'].astype(str, inplace=True)
    raw_filtered['cl4'].fillna('No', inplace=True)
    raw_filtered['cl4'] = raw_filtered['cl4'].replace(r'^\s*$', np.nan, regex=True)
    raw_filtered['cl4'] = raw_filtered['cl4'].str.replace("Don't know", 'No')

    print(raw_filtered['cl4'].value_counts())
    raw_filtered['cl4'].astype(str, inplace=True)
    print("---------------------")
    raw_filtered['cl4'] = pd.get_dummies(raw_filtered['cl4'])
    print(raw_filtered['cl4'].value_counts())


    # In[78]:


    # Would you like to be entered into the cash prize drawing? (Contact info. required for entry)
    raw_filtered['draw'] = raw_filtered['draw'].replace(-3, 2, regex=True)
    raw_filtered['draw'] = raw_filtered['draw'].replace(-2, 2, regex=True)
    raw_filtered['draw'].fillna(0, inplace=True)
    raw_filtered['draw'] = raw_filtered['draw'].replace(0, 2, regex=True)
    print(raw_filtered['draw'].value_counts())


    # In[79]:


    #May we have your permission to contact you for future research studies?
    raw_filtered['permission'] = raw_filtered['permission'].replace(-3, 2, regex=True)
    raw_filtered['permission'] = raw_filtered['permission'].replace(-2, 2, regex=True)
    print(raw_filtered['permission'].value_counts())


    # In[80]:


    raw_filtered['cl3other_r12'] = raw_filtered['cl3other_r12'].replace(r'^\s*$', np.nan, regex=True)
    raw_filtered['epd_state'].fillna(value='Other', inplace=True)
    raw_filtered['epd_uhnregion'].fillna(value='Other', inplace=True)
    raw_filtered['cl3other_r12'].fillna(value='Other', inplace=True)


    # In[81]:


    raw_filtered.drop('cl3other_r12', axis=1, inplace=True)


    # In[82]:


    # Converting categorical into numeric or ordinal numbers

    raw_filtered["respondent_type"] = raw_filtered["respondent_type"].astype('category')
    raw_filtered["respondent_type_cat"] = raw_filtered["respondent_type"].cat.codes

    #Identifies if the response was received via mail or web survey
    raw_filtered["mode"] = raw_filtered["mode"].astype('category')
    raw_filtered["mode_cat"] = raw_filtered["mode"].cat.codes

    raw_filtered.drop(['respondent_type','mode'], axis=1, inplace=True)


    # In[84]:


    # cl2: How many physicians are in your practice?
    raw_filtered['cl2'].fillna(value='0', inplace=True)  # Fill NA values with 1 as atleast 1 advocate available at the provider
    raw_filtered['cl2'] = raw_filtered['cl2'].replace(r'^\s*$', '1', regex=True)
    raw_filtered['cl2'] = raw_filtered['cl2'].replace('Refused', '0', regex=True)
    raw_filtered['cl2'] = raw_filtered['cl2'].apply(lambda x: str(x)[:2] if (str(x).find('to') != -1) else x)
    raw_filtered['cl2'] = raw_filtered['cl2'].apply(lambda x: str(x)[:3] if (str(x).find('or') != -1) else x)
    #raw_filtered['cl2'] = raw_filtered['cl2'].astype(str)
    raw_filtered['cl2'] = raw_filtered['cl2'].astype(int)


    # In[ ]:





    # In[86]:


    # Based on the above unique values, and the count of it, dropping those columns whose cardinality is high

    # Below are removed because epd_ columns are its duplicates and they are enriched with more data
    raw_filtered.drop(['address','email','name','city','phone','state','zipcode'], axis =1, inplace=True)  # These are captured in enriched columns...
    # Below are the text related columns which are considered for text analytics related problem
    raw_filtered.drop(['sat1_oe','cl1_oe','a1_other_ops','qtryr','response_date','time','survey'], axis = 1, inplace=True)
    # Below enriched columns are dropped because of less significance and high cardinality
    raw_filtered.drop(['epd_firstname','epd_lastname','epd_primphone','epd_emailadr','epd_street','epd_city'], axis =1, inplace=True)


    # In[87]:


    # Below columns are imputed based on their NULL values...
    raw_filtered.mpin.fillna(0, inplace=True)
    raw_filtered.npi.fillna(0, inplace=True)
    raw_filtered['epd_county'].fillna('others', inplace=True)
    raw_filtered['epd_zipcd'].fillna(0, inplace=True)
    raw_filtered['epd_mappingmkt'].fillna('others', inplace=True)
    raw_filtered['epd_mktname'].fillna('others', inplace=True)
    raw_filtered['epd_corpownername'].fillna('others', inplace=True)


    # In[88]:


    # The below plot tells how the NA variables are distributed in the 2018 data....
    plt.figure(figsize=(14,8))
    sns.heatmap(raw_filtered.isnull(),yticklabels=False,cbar=False,cmap='viridis');


    # In[89]:


    # Reset the data frame with proper index...
    raw_filtered.reset_index(drop=True)


    # In[90]:


    # Export the preprocessed data frame into an excel file...
    
    raw_filtered.to_excel(path1+"PPM_Updated_all.xlsx")


    # In[456]:


    raw_filtered['cl2'].isnull().count()

    return path1+"PPM_Updated_all.xlsx"
    # In[ ]:




# data_pp_np_prediction()