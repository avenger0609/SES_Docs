#!/usr/bin/env python
# coding: utf-8

# In[2]:


import ImportPythonModules
from ImportPythonModules import *


# Define chisquare as class...
class ChiSquare:
    def __init__(self, dataframe):
        self.df = dataframe
        self.p = None #P-Value
        self.chi2 = None #Chi Test Statistic
        self.dof = None        
        self.dfObserved = None
        self.dfExpected = None
        self.dfResults = None
        
    def _print_chisquare_result(self, colX, alpha):
        result = ""
        if self.p<alpha:
            result="{0} is IMPORTANT for Prediction\n".format(colX)
        else:
            result="{0} is NOT an important predictor. (Discard {0} from model)".format(colX)
        print(result)
        
    def TestIndependence(self,colX,colY, alpha=0.05):
        X = self.df[colX].astype(str)
        Y = self.df[colY].astype(str)
        
        self.dfObserved = pd.crosstab(Y,X) 
        
        chi2, p, dof, expected = stats.chi2_contingency(self.dfObserved.values)
        self.p = p
        self.chi2 = chi2
        self.dof = dof 
        print("chi2:",chi2)
        #print("p value for statistical significance is: ",p)  # T
        print("The expected frequency is:",expected)  # These are expected frequencies
        self.dfExpected = pd.DataFrame(expected, columns=self.dfObserved.columns, index = self.dfObserved.index)
        
        self._print_chisquare_result(colX,alpha)

    def CrossTab(self,colX,colY, alpha=0.05):
        X = self.df[colX].astype(str)
        Y = self.df[colY].astype(str)
        
        #self.dfObserved = rp.crosstab(Y,X) 
        table, results = rp.crosstab(Y, X, prop= 'col', test= 'chi-square')
       # print("The chi2 test between", colname(X), "\t", colname(Y),"\n :")
        print(results)
        print(table)



# In[3]:

def eda_nlp_prediction(path1,fname):
    # Step1: Load the input files given for Analysis
    input = pd.read_excel(fname)

    raw = input.copy(deep=True)      # Create a dummy data frame from the original list
    #raw_2018 = input_2018.copy(deep=True)      # Create a dummy data frame from the original list
    raw.columns      # Get all the columns names 


    # In[4]:


    # Check the simple distribution plot for the Target Variable...
    sns.distplot(raw['sat1']);
    print(raw.groupby('sat1').size())
    print(raw.sat1.value_counts().sum())

    # sns.distplot(raw_2018['sat1']);
    # print(raw_2018.groupby('sat1').size())
    # print(raw_2018.sat1.value_counts().sum())


    # In[5]:


    sns.distplot(raw['sat1']);
    print(raw.groupby('sat1').size())
    print(raw.sat1.value_counts().sum())

    # Do you need a network provider...1 means no..i dont want..
    sns.distplot(raw['cl4']);
    print(raw.groupby('cl4').size())
    print(raw.sat1.value_counts().sum())


    # In[6]:


    # How are healthplan and state related to each other
    rp.summary_cat(raw[['healthplan', 'epd_state' ]])


    # In[7]:


    # How are regions and sat1 scores related...
    plt.figure(figsize=(8,6))
    raw.groupby(['epd_uhnregion', 'sat1'])['id'].count().plot('bar')

    print(raw.groupby(['epd_uhnregion', 'sat1'])['id'].count())


    # In[8]:


    # State wise relation with sat1 scores
    plt.figure(figsize=(21,12))
    raw.groupby(['epd_state', 'sat1'])['id'].count().plot('bar')
    print(raw.groupby(['epd_state', 'sat1'])['id'].count())


    # In[9]:


    # Are healthplan and epd state associated between each other
    table, results = rp.crosstab(raw['healthplan'], raw['epd_state'], prop= 'col', test= 'chi-square')
    table


    # In[10]:


    results


    # In[11]:


    # The above result shows that the chi2 value is high with high cramer's V value and significant p value that there is 
    # 100% statistically significant relationship between 2 columns..
    # The strength of that relationship is high, there is no need for Post-Hoc tests here....
    raw.drop('epd_state',axis=1, inplace=True)
    #raw_2018.drop('epd_state',axis=1, inplace=True)


    # In[12]:


    # Check the cross tab associativity between 2 columns...
    comtable, comresults = rp.crosstab(raw['region'],raw['epd_uhnregion'], prop= 'col', test= 'chi-square')
    print(comtable)
    print(comresults)


    # In[13]:


    raw.drop('region',axis=1, inplace=True)
    #raw_2018.drop('region',axis=1, inplace=True)


    # In[14]:



    # In[15]:


    #Initialize ChiSquare Class
    cT = ChiSquare(raw)


    # In[17]:


    #Feature Selection and association between sat scores...
    testColumns = ['sat1','sat2','sat3','sat4','cl4', 'permission','strategic_acct_flag', 'core_acct_flag', 'medicare_flag', 'cands_flag', 'fqhc_flag', 'platinum_flag', 'a1_md', 'a1_pm', 'a1_other']
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[16]:


    #Feature Selection and association between sat scores...
    testColumns = ['sat1','sat2','sat3','sat4']
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[17]:


    #Feature Selection
    testColumns = ['com1','com2a','com2b','com2c','com2d']
    for var in testColumns:
        cT.TestIndependence(colX=var,colY='sat1' )  
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[18]:


    # From the above results it is clear that Com2a is highly correlated with Com2b, Com2c, Com2d
    ToBeRemovedColumns = ['com2b','com2c','com2d']


    # In[19]:


    #Feature Selection
    testColumns = ['cred1a','cred1b','cred1c','cred1d','cred1e']
    for var in testColumns:
        cT.TestIndependence(colX=var,colY='sat1' )  
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[20]:


    ToBeRemovedColumns.append('cred1c')
    print(ToBeRemovedColumns)


    # In[21]:


    #Feature Selection
    testColumns = ['rx1','rx2','rx3']
    for var in testColumns:
        cT.TestIndependence(colX=var,colY='sat1' )  
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[22]:


    ToBeRemovedColumns.append('rx3')
    print(ToBeRemovedColumns)


    # In[23]:


    #Feature Selection
    testColumns = ['auth1a','auth1b','auth1c','auth1d','auth1e','auth1f']
    for var in testColumns:
        cT.TestIndependence(colX=var,colY='sat1' )  
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[24]:


    ToBeRemovedColumns.append('auth1b')
    ToBeRemovedColumns.append('auth1d')
    ToBeRemovedColumns.append('auth1f')
    print(ToBeRemovedColumns)


    # In[25]:


    #Feature Selection
    testColumns = ['mr1','mr2','mr3']
    for var in testColumns:
        cT.TestIndependence(colX=var,colY='sat1' )  
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[26]:


    ToBeRemovedColumns.append('mr3')
    print(ToBeRemovedColumns)


    # In[27]:


    #Feature Selection
    testColumns = ['net1a','net1b','net1c']
    for var in testColumns:
        cT.TestIndependence(colX=var,colY='sat1' )  
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[28]:


    ToBeRemovedColumns.append('net1c')
    print(ToBeRemovedColumns)


    # In[29]:


    #Feature Selection
    testColumns = ['cs1','cs2a','cs2b','cs2c','cs3a','cs3b','cs3c','cs3d','cs3e','cs3f','cs3g']
    for var in testColumns:
        cT.TestIndependence(colX=var,colY='sat1' )  
        
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[30]:


    ToBeRemovedColumns.append('cs3e')
    ToBeRemovedColumns.append('cs3g')


    # In[ ]:





    # In[31]:


    raw.columns


    # In[32]:


    #Feature Selection
    testColumns = ['cl3o1', 'cl3o2', 'cl3o3', 'cl3o4', 'cl3o5', 'cl3o6', 'cl3o7', 'cl3o8', 'cl3o9', 'cl3o10','cl3o11']
    
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[33]:


    #Feature Selection
    testColumns = ['epd_county','epd_zipcd', 'epd_uhnregion', 'epd_mappingmkt', 'epd_mktname','epd_corpownername']
    
    for i, columna in enumerate(testColumns):
        for j, columnb in enumerate(testColumns):
            print(format(testColumns[i]), testColumns[j])
            cT.CrossTab(format(testColumns[i]), format(testColumns[j]))


    # In[34]:


    ToBeRemovedColumns.append('epd_county')
    ToBeRemovedColumns.append('epd_zipcd')
    ToBeRemovedColumns.append('epd_mappingmkt')
    ToBeRemovedColumns.append('epd_mktname')
    ToBeRemovedColumns.append('epd_corpownername')
    print(ToBeRemovedColumns)


    # In[35]:


    # With the above tests of chi-square independence performed between sat1 and each of the sub groups and within themselves....
    # Below are the variables considered from each group
    # com1 - considered, com2a com2b com2c com2d com2e - Not considered
    # 
    raw.drop(ToBeRemovedColumns, axis=1, inplace=True)


    # In[36]:


    #id	fixid	tin	mpin	npi
    # Below columns because of high cardinality unique values.... which can be used for EDA not for predicting model...
    raw.drop(['id','fixid','tin','mpin','npi'], axis=1, inplace=True)


    # In[37]:


    raw.head(5)


    # In[ ]:





    # In[38]:


    raw.to_excel(path1+"PPM_Updated_EDA_all.xlsx")

    return path1+"PPM_Updated_EDA_all.xlsx"
    # In[ ]:




# eda_nlp_prediction()