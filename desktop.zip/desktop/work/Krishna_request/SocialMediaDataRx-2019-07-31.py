def socialmediadata(path):
    #!/usr/bin/env python
    # coding: utf-8

    # In[19]:


    # -*- coding: utf-8 -*-
    """
    Created on Wed Jul 10 00:27:50 2019

    @author: achand27
    """
    
    import numpy as np
    import pandas as pd
    import nltk
    import re #for regex
    import pickle as cPickle
    from wordcloud import WordCloud  # for word clouds
    from textblob import TextBlob
    import matplotlib.pyplot as plt
    import seaborn as sns
    import string
    import re
    from scipy import stats
    import math
    import pyLDAvis
    import pyLDAvis.gensim  # don't skip this
    import spacy

    from nltk.tokenize import sent_tokenize, word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem.wordnet import WordNetLemmatizer
    from nltk.util import ngrams
    from nltk.classify.scikitlearn import SklearnClassifier
    from nltk import NaiveBayesClassifier
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.feature_extraction.text import CountVectorizer
    from nltk.sentiment.vader import SentimentIntensityAnalyzer  # Sentiment Analysis

    from sklearn.metrics import roc_auc_score # we will use auc as the evaluation metric
    from sklearn.linear_model import LogisticRegression
    from sklearn.naive_bayes import MultinomialNB
    from sklearn.svm import SVC

    import nltk
    from nltk.tokenize import word_tokenize, wordpunct_tokenize   # Tokens
    from nltk.tokenize.treebank import TreebankWordDetokenizer

    from nltk.corpus import stopwords  # Removing Stopwords
    from nltk.stem import PorterStemmer # Stemming
    from nltk.stem.snowball import SnowballStemmer  # Advanced stemmer than porter or lancaster
    from nltk.sentiment.vader import SentimentIntensityAnalyzer  # Sentiment Analysis
    # N Gram analysis
    import nltk
    from nltk.tokenize import word_tokenize, wordpunct_tokenize   # Tokens
    from nltk.corpus import stopwords  # Removing Stopwords
    from nltk.stem import PorterStemmer # Stemming
    from nltk.stem.snowball import SnowballStemmer  # Advanced stemmer than porter or lancaster
    from nltk.sentiment.vader import SentimentIntensityAnalyzer  # Sentiment Analysis
    # N Gram analysis
    from nltk.util import ngrams
    from nltk.collocations import BigramAssocMeasures, BigramCollocationFinder
    from nltk.collocations import TrigramAssocMeasures, TrigramCollocationFinder
    # Topic Modeling
    from sklearn.decomposition import LatentDirichletAllocation
    from nltk.chunk import tree2conlltags, conlltags2tree

    # Classification Algorithms for prediction
    from nltk.classify.scikitlearn import SklearnClassifier
    from nltk import NaiveBayesClassifier

    from wordcloud import WordCloud  # for word clouds
    from textblob import TextBlob

    # Gensim libraries
    import gensim
    from gensim import corpora, models
    from gensim.utils import simple_preprocess
    from gensim.models import CoherenceModel
    from gensim.test.utils import common_texts 
    from gensim.models.doc2vec import Doc2Vec, TaggedDocument 
    from gensim.models import Word2Vec as gensim_word2vec


    #from feature.db_interface import DBInterface
    from sklearn.metrics import classification_report
    from sklearn.metrics import confusion_matrix
    from sklearn.metrics import accuracy_score
    from sklearn import decomposition, ensemble
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.feature_extraction.text import CountVectorizer
    from sklearn.metrics import confusion_matrix, classification_report
    from sklearn.metrics import precision_recall_fscore_support as score
    from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm


    # In[2]:


    """
    Load the cvs files with the training and test data
    """
    def LoadData():
        df_train = pd.read_csv(path+'tweets.csv', encoding="ISO-8859-1")
    #    df_train = df_train.sample(frac=1).reset_index(drop=True)
        df = df_train['text']
        #Pickle the data frames
        df.to_pickle(path+'df.pkl')
        print ("Finished loading and pickling data")
        
    def preProcessTweet(tweet):
        """
        Function to pre-process the tweet
        """
        #str(tweet.encode('utf-8')) 
        str(tweet)
        tweet.lower()
        #Replace all words preceded by '@' with 'USER_NAME'
        tweet = re.sub(r'@[^\s]+', 'USER_NAME', tweet)    
        #Replace all url's with 'URL'
        tweet = re.sub(r'www.[^\s]+ | http[^\s]+',' URL ', tweet)    
        #Replace all hashtags with the word
        tweet = tweet.strip('#')    
        #Replace words with long repeated characters with the shorter form
        tweet = re.sub(r'(.)\1{2,}', r'\1', tweet)    
        #Remove any extra white space
        tweet = re.sub(r'[\s]+', ' ', tweet)    
        return tweet

    def preProcessData():
        """
        Obtained the pickled data and pre-process.
        The pre-processed data is then pickled 
        """
        df_train = pd.read_pickle(path+'df.pkl')
        #Pre-process the data
        df_train['tweet'] = df_train['tweet'].apply(preProcessTweet)    
        #Pickle pre-processed data frames
        df_train.to_pickle(path+'df_training_preprocessed.pkl')
        print ("Training and test data is now pre-processed")
        
    def feature_Extractor(tweet):
        """
        Takes a tweet and extracts its features
        """
        tweet_words = set(tweet)
        features = {}
        for word in featureList:
            features['contains(%s)' % word] = (word in tweet_words)
        return features

    def getFeatureVector(tweet, flag):
        """
        The function takes a tweet and does some processing
        to remove stopwords, remove punctuation, lemmatize/stem
        and reject any words that are non-alpha. Depending on the 
        flag selected, it will return a unigram, bigram, or a
        mix of the two. It returns a list with the filtered n-grams
        """
        
    # flag = 3 #1 for unigram; 2 for bigram; 3 for mix
        
        #tokenize the tweet and convert each token to lower case
        tokens = [token.lower() for token in word_tokenize(tweet)]
        #tokens = [token.lower() for token in word_tokenize(tweet.decode('latin-1'))]
        

        punctuations = ["'", ":", ",", "-", ".", "!", "(", ")", "?", '"', ";"]
        stopWords = stopwords.words('english')
        stopWords.append("#")
        stopWords.append("%")
        stopWords = set(stopWords)
        lemmatizer = WordNetLemmatizer()
        
        #Remove stopwords, punctuation, 'url', and 'user_name'
        filteredTokens = []
        featureVector = []
        for token in tokens:
            if (token in punctuations or token in stopWords):
                continue
            elif (token == 'url' or token == 'user_name'):
                continue
            elif token.isalpha()== False: #reject non-alpha tokens
                continue
            else:
                #Normalize the tokens, either by stemming or lemmatization
                #I might also have to tag the tokens with Parts of Speech
                #<lemmatize words>
                token = lemmatizer.lemmatize(token)
                
                #This is the feature vector for each tweet
                filteredTokens.append(token)
                if flag == 1:
                    #unigrams
                    featureVector = filteredTokens
                elif flag == 2:
                    #bigrams 
                    featureVector = list(nltk.bigrams(filteredTokens))
                    if featureVector != []: #ensure it is not an empty list
                        #Convert the tuple of bigrams to a string
                        featureVector = [' '.join(bigram) for bigram in featureVector]
                elif flag == 3:
                    # trigrams
                    featureVector = list(nltk.trigrams(filteredTokens))
                    if featureVector != []: #ensure it is not an empty list
                        #Convert the tuple of trigrams to a string
                        featureVector = [' '.join(trigram) for trigram in featureVector]
                else:
                    #mixgrams
                    featureVector = list(nltk.everygrams(filteredTokens, max_len=2))
                    if featureVector != []:
                        #Convert any tuple of n-grams to a string
                        temp = []
                        for everygram in featureVector:
                            if type(everygram) == tuple:
                                everygram = ' '.join(everygram)
                            temp.append(everygram)
                        featureVector = temp
                                            
        return featureVector
                
    def getFeatures(df, flag):
        """
        This function obtains features from a data set using a Bag of Words or Bag of n-grams approach
        """
        tweets = []
        allWords = []
        
        #Set flag for unigram (Bag of words) or n-gram(Bag of n-grams)
        #Flag = 2 # 1 is unigram; 2 is bigram; any otehr is a mixed bag of unigram and bigram (everygram)
        
        for row in df.itertuples():
            polarity = row[1]
            tweet = row[2]
            
            #Obtain the feature vector for each tweet
            featureVector = getFeatureVector(tweet, flag)
            
            #tweets is a list containing tuples of filtered n-grams
            #and their respective sentiments
            tweets.append((featureVector, polarity))
            
            #Get list of all words/n-grams from all the tweets
            allWords.extend(featureVector)
                
        #Return dict with the frequency distribution of each word/n-gram
        wordDist = nltk.FreqDist(allWords)
        
        #Get a list of the features with each word/n-gram in the dist as a feature
        featureList = wordDist.keys()
            
        return featureList, tweets

    def generateTrainFeatureList(num):    
        #Load pre-processed pickled data frame
        df = pd.read_pickle(path+'df_training_preprocessed.pkl')
        df = df[:num]    
        #Extract the data set
        unifeatureList, unitweets = getFeatures(df, 1)
        bifeatureList, bitweets = getFeatures(df, 2)
        trifeatureList, tritweets = getFeatures(df, 3)
        #Pickle the feature list and tweets
        num = num/1000
        pickle.dump(featureList, open('featureList_train_{0}k.pkl'.format(num), 'wb'))
        pickle.dump(tweets, open('tweets_train_{0}k.pkl'.format(num), 'wb'))     
        print ("Pickle of train feature list and {0}k tweets successful".format(num))
        
    def feature_extraction(data, method = "tfidf"):
        #arguments: data = all the tweets in the form of array, method = type of feature extracter
        #methods of feature extractions: "tfidf" and "doc2vec"
        if method == "tfidf":
            tfv=TfidfVectorizer(sublinear_tf=True, stop_words = "english") # we need to give proper stopwords list for better performance
            features=tfv.fit_transform(data)
        elif method == "doc2vec":
            None
        else:
            return "Incorrect inputs"
        return features    

    def train_classifier(features, label, classifier = "logistic_regression"):
        #arguments: features = output of feature_extraction(...), label = labels in array form, classifier = type of classifier 
        if classifier == "logistic_regression": # auc (train data): 0.8780618441250002
            model = LogisticRegression(C=1.)
        elif classifier == "naive_bayes": # auc (train data): 0.8767891829687501
            model = MultinomialNB()
        elif classifier == "svm": # can't use sklearn svm, as way too much of data so way to slow. have to use tensorflow for svm
            model = SVC()
        else:
            print("Incorrect selection of classifier")
        #fit model to data
        model.fit(features, label)
        #make prediction on the same (train) data
        probability_to_be_positive = model.predict_proba(features)[:,1]
        #chcek AUC(Area Undet the Roc Curve) to see how well the score discriminates between negative and positive
        print ("auc (train data):" , roc_auc_score(label, probability_to_be_positive))
        #print top 10 scores as a sanity check
        print ("top 10 scores: ", probability_to_be_positive[:10])


    # In[3]:


    df_socialmedia = pd.read_excel(path+'SocialMediaDataRx.xlsx', encoding="ISO-8859-1")
    df_media = df_socialmedia[['Message','CountryCode','Sentiment']]
    df_media['tweet_text'] = df_media['Message'].apply(preProcessTweet) 
    data = np.array(df_media['tweet_text'])


    # In[5]:


    df_media


    # In[7]:


    #Extract the data set
    df = df_media[['tweet_text','Message']]
    #featureList, tweets = getFeatures(df_train[['tweet_text','text']])
    unifeatureList, unitweets = getFeatures(df, 1)
    bifeatureList, bitweets = getFeatures(df, 2)
    trifeatureList, tritweets = getFeatures(df, 3)
    df['unigrams'] = unitweets
    df['bigrams'] = bitweets
    df['trigrams'] = tritweets


    # In[13]:


    ##########################################################################################
    #  Basic feature extraction using text data
    ##########################################################################################
    # Compute the word count of the text data
    def compute_wordcount(raw, col, col_count):
        raw[col_count] = raw[col].apply(lambda x: len(str(x).split(" ")))
        return raw[col_count]

    # Compute the character count of the text data
    def compute_charactercount(raw, col, char_count):
        raw[char_count] = raw[col].str.len() ## this also includes spaces
        return raw[char_count]

    # Compute the average word length of the text data
    def compute_avgwordlength(sentence):
        words = sentence.split()
        return (sum(len(word) for word in words)/len(words)) 

    ##########################################################################################
    # Basic Text Pre-processing of text data
    ##########################################################################################
    # Replace the enpty string with a suitable comment...
    # Assumption: If Passives has rating 8, consider them as promoters
    # Assumption: If Passives has rating 7, consider them as detractors
    # Below are the functions written for the Text Preprocessing
    def ImputeEmptyComments(df, col1, col2):
        df[col1][df[col2] > 7] = df[col1].fillna(value='Positive Comment')
        df[col1][df[col2] < 8] = df[col1].fillna(value='Negative Comment')
        return df[col1]

    def ImputeTargetNULLComments(df, col1, col2):
        df[col1] = np.where(df[col1] == -1, df[col2], df[col1])
        df[col1] = np.where(df[col1] == -2, df[col2], df[col1])    
        return df[col1]

    ############## Convert all the characters into lower case ###############################
    def convert_lowercase(raw, col):
        raw[col] = raw[col].apply(lambda x: str(x).lower())
        return raw[col]

    ############## Remove all numbers from the column ###############################
    def remove_numbers(raw, col):
        raw[col] = raw[col].apply(lambda x: x.translate(str.maketrans('','',string.digits)))
        return raw[col] 

    ############## Remove all punctuations from the column ###############################
    def remove_punctuation(raw, col):
        raw[col] = raw[col].apply(lambda x: x.translate(str.maketrans('','',string.punctuation)))
        return raw[col]

    # Create a Stopwords package...customize the default stopwords package available in the nltk package
    def prepareStopWords():
        stopwordsList = []
        # Load default stop words and add a few more specific to my text.
        stopwordsList = stopwords.words('english') #) - {'to','not','no'}
        stopwordsList.remove('to')
        stopwordsList.remove('not')
        stopwordsList.remove('no')
        stopwordsList.append('im')
        stopwordsList.append('ive')
        stopwordsList.append('isnt')
        stopwordsList.append('also')
        stopwordsList.append('might')
        stopwordsList.append('may')
        return stopwordsList

    ############## Remove all stopwords from the column ###############################
    def remove_stopwords(raw, col, stop):
        raw[col] = raw[col].apply(lambda x: ' '.join([word for word in x.split() if word not in stop]))
        return raw[col] 

    ############## Remove some irrelevant words from the column ###############################
    def remove_irrelevantwords(raw, col, highlyusedwords):
        raw[col] = raw[col].apply(lambda x: ' '.join(lambda x: ' '.join(word for word in x.split() if word not in highlyusedwords)))
        return raw[col] 

    ############## Correct spellings of words from the column ###############################
    def correct_spellings(raw, col):
        raw[col] = raw[col].apply(lambda x: str(TextBlob(x).correct()))
        return raw[col] 

    ############## Remove high frequency of words from the column ###############################
    def remove_highfreq_words(raw, col):
        freq = pd.Series(' '.join(raw[col]).split()).value_counts()[:10]
        freq = list(freq.index)
        raw[col] = raw[col].apply(lambda x: " ".join(x for x in x.split() if x not in freq))
        return raw[col]

    ############## Remove low frequency/rare of words from the column ###############################
    def remove_rare_words(raw, col):
        freq = pd.Series(' '.join(raw[col]).split()).value_counts()[-10:]
        freq = list(freq.index)
        raw[col] = raw[col].apply(lambda x: " ".join(x for x in x.split() if x not in freq))   
        return raw[col]

    ############## Tokenization of sentences from the column ###############################
    def tokenize_words(raw, col):
        #raw[col] = raw[col].apply(lambda x: x.split())
        #return raw[col]
        return raw.apply(lambda row: nltk.word_tokenize(row[col]), axis=1)
    #TextBlob(raw[col][1]).words

    ############## De-Tokenization of sentences from the column ###############################
    detokenized_doc = [] 
    def detokenize_words(raw, col):
        for i in range(len(raw)): 
            t = ' '.join(tokenized_doc[i]) 
            detokenized_doc.append(t) 

    ############## Lemmatization of words from the column ###############################
    def lemmatize_words(lemmatizer, text):
        return [lemmatizer.lemmatize(w) for w in w_tokenizer.tokenize(text)]
        #raw[col] = raw[col].apply(lambda x: " ".join([Word(word).lemmatize() for word in x.split()]))
        #return raw[col]


    # In[32]:


    def PerformSentimentAnalysis(df, col, filepath):
        sia = SentimentIntensityAnalyzer()
        df['polarity'] = df[col].apply(lambda s: sia.polarity_scores(s))
        df['polarity_compound'] = df[col].apply(lambda s: sia.polarity_scores(s)['compound'])
        df['polarity_positive'] = df[col].apply(lambda s: sia.polarity_scores(s)['pos'])
        df['polarity_negative'] = df[col].apply(lambda s: sia.polarity_scores(s)['neg'])
        df['polarity_neutral'] = df[col].apply(lambda s: sia.polarity_scores(s)['neu'])
        df['subjectivity'] = df[col].apply(lambda s: TextBlob(s).sentiment.subjectivity)

        for ind,row in df.iterrows():
            if df.loc[ind,'polarity_compound'] == 0.0: 
                df.loc[ind,'result'] = 2
            elif df.loc[ind,'polarity_compound'] > 0.0:
                df.loc[ind,'result'] = 1
            else:
                df.loc[ind,'result'] = 0
            
        df.to_csv(filepath)
        
        
    def RunClassifications(df, col, filepath):    
        with open(filepath, 'w') as fp :
                writer = csv.writer(fp, delimiter=',')
                writer.writerow(["Kbest","Feature Extraction","Classifier","Accuracy","Precsion", "Recall", "FScores", "gram"])  # write header
                total_bag_of_words_model = ["TfidfVectorizer"]
                for gram_type in range(1,4) :
                    for bag_of_word_model in total_bag_of_words_model :
                        if bag_of_word_model == "CountVectorizer" :
                            bag_of_words = CountVectorizer(ngram_range=(gram_type, gram_type))
                        if bag_of_word_model == "TfidfVectorizer" :
                            bag_of_words = TfidfVectorizer(ngram_range=(gram_type, gram_type))
                        X = bag_of_words.fit_transform(df[col]).toarray()
                        y = df.result
                        y= y.astype('int')
                        total_classifier = ["GaussianNB","LogisticRegression","RandomForestClassifier"]
                        for classifier_name in total_classifier:
                            if classifier_name == "GaussianNB" :
                                from sklearn.naive_bayes import GaussianNB
                                classifier = GaussianNB()
                            if classifier_name == "SDGClassifier" :
                                from sklearn.linear_model import SGDClassifier
                                classifier = SGDClassifier()
                            if classifier_name == "LogisticRegression" :
                                from sklearn.linear_model import LogisticRegression
                                classifier = LogisticRegression()
                            if classifier_name == "RandomForestClassifier" :
                                from sklearn.ensemble import RandomForestClassifier
                                classifier = RandomForestClassifier()

                            #Dimension Reductionality - #Using CH2 as parameter for selecting KBest   
                            list = [10,50,100,500]
                            for knum in list:
                                X_new = SelectKBest(chi2, k=knum).fit_transform(X, y)
                                #split data into test and train
                                #from sklearn.cross_validation import train_test_split
                                X_train, X_test, y_train, y_test = train_test_split(X_new, y, test_size = 0.20, random_state = 0)
                                classifier.fit(X_train, y_train)
                                y_pred = classifier.predict(X_test)
                                #Making the confusion Matrix
                                cm = confusion_matrix(y_test, y_pred)
                                accuracy = (cm[0][0] + cm[1][1]) / len(y_test)
                                precision, recall, fscore, support = score(y_test, y_pred, average='weighted')
                                accuracy = float(str(accuracy)[:6])
                                precision = float(str(precision)[:6])
                                recall = float(str(recall)[:6])
                                fscore = float(str(fscore)[:6])
                                writer.writerow([knum,bag_of_word_model, classifier_name,accuracy, precision, recall, fscore, gram_type])  # write header
        # print("SentimentAnalysis completed")    


    # In[20]:


    highlyusedwords = ['health','cigna','aetna','uhc','insurance','unitedhealthcare','united healthcare','health care',
                    'unitedhealthcares','patients','patient','insurances','united','uniteds','healthcare']
    #df['Comments'] = convert_lowercase(df,'tweet_text')
    #df['Comments'] = remove_punctuation(df,'Comments')

    def TextProcessing(comments, highlyusedwords):
        comments['Comments'] = convert_lowercase(comments,'tweet_text')
    # comments['Comments'] = remove_numbers(comments,'Comments')
        comments['Modified'] = remove_punctuation(comments,'Comments')
        comments['Cleaned'] = remove_stopwords(comments,'Modified', prepareStopWords())
        comments['Filtered'] = remove_stopwords(comments,'Cleaned', highlyusedwords)
        lowfreqwords = pd.Series(' '.join(comments['Filtered']).split()).value_counts()[-5:]
        lowfreqs = list(lowfreqwords.index)                         
        comments['Filtered'] = comments['Filtered'].apply(lambda x: " ".join(x for x in x.split() if x not in lowfreqs))
        comments["nb_chars"] = comments['Filtered'].apply(lambda x: len(x))  
        comments["nb_words"] = comments['Filtered'].apply(lambda x: len(x.split(" ")))
        comments['Tokens'] = comments.apply(lambda row: nltk.word_tokenize(row['Filtered']), axis=1)
        comments['Pos'] = comments.apply(lambda row: nltk.pos_tag(row['Tokens']), axis =1)
        lemmatizer = nltk.stem.WordNetLemmatizer()
        comments['Stems'] = comments['Tokens'].apply(lambda x: [lemmatizer.lemmatize(y,'v') for y in x])
        return comments


    # In[ ]:





    # In[21]:


    uhc_processed = TextProcessing(df, highlyusedwords)


    # In[37]:


    stop = stopwords.words('english')
    lista=['havent','could','would','see','set','many','use','list','tell','name','find','four','two','one','pt','get','go','need','without','log','cant','try','every','make','send','ever','say','year','give','dont']
    stop.append(lista)


    # In[38]:


    ###################### TOPIC MODELING ####################
    import time
    from pprint import pprint

    def TopicModeling(df, col):
        data_words = list(df[col])
        # Build the bigram and trigram models
        bigram = gensim.models.Phrases(data_words, min_count=5, threshold=100) # higher threshold fewer phrases.
        trigram = gensim.models.Phrases(bigram[data_words], threshold=100)  
        # Faster way to get a sentence clubbed as a trigram/bigram
        bigram_mod = gensim.models.phrases.Phraser(bigram)
        trigram_mod = gensim.models.phrases.Phraser(trigram)
        # See trigram example
        #print(bigram_mod[bigram_mod[uhc_data_words[1]]])
        # Remove Stop Words
        data_words_nostops =  [[word for word in simple_preprocess(str(doc)) if word not in stop] for doc in data_words]
        # Form Bigrams
        data_words_bigrams = [bigram_mod[doc] for doc in data_words_nostops]#make_bigrams(data_words_nostops)
        data_words_trigrams = [trigram_mod[bigram_mod[doc]] for doc in data_words_nostops]
        # Create Dictionary
        id2word = corpora.Dictionary(data_words_bigrams)
        # Create Corpus
        texts = data_words_bigrams
        # Term Document Frequency
        corpus = [id2word.doc2bow(text) for text in texts]    
        # Build LDA model
        lda_model = gensim.models.ldamodel.LdaModel(corpus=corpus,
                                                id2word=id2word,
                                                num_topics=10, 
                                                random_state=100,
                                                update_every=1,
                                                chunksize=100,
                                                passes=10,
                                                alpha='auto',
                                                per_word_topics=True)                                               
        # Print the Keyword in the 20 topics
        pprint(lda_model.print_topics())
        doc_lda = lda_model[corpus]	 
        # Compute Perplexity
        print('\nPerplexity: ', lda_model.log_perplexity(corpus))  # a measure of how good the model is. lower the better.
        # Compute Coherence Score
        coherence_model_lda = CoherenceModel(model=lda_model, texts=data_words_bigrams, dictionary=id2word, coherence='c_v')
        #coherence_lda = coherence_model_lda.get_coherence()
        #print('\nCoherence Score: ', coherence_lda)	
        
        return lda_model, corpus


    # In[39]:


    uhc_topicmodel, uhc_corpus = TopicModeling(uhc_processed,'Stems')


    # In[30]:


    path1 = path+"Output/"
    top_words_per_topic = []
    for t in range(uhc_topicmodel.num_topics):
        top_words_per_topic.extend([(t, ) + x for x in uhc_topicmodel.show_topic(t, topn = 10)])
        pd.DataFrame(top_words_per_topic, columns=['Topic', 'Word', 'P']).to_csv(path1 + "_optumrxlda.csv")


    # In[36]:


    import csv
    from sklearn.feature_selection import SelectKBest, chi2
    from sklearn.model_selection import train_test_split
    PerformSentimentAnalysis(uhc_processed, 'Filtered', path1 + 'SentiAnalysis.csv')
    RunClassifications(uhc_processed, 'Filtered', path1 + '_optumrx_classification.csv')
    print("text mining completed")

    # In[ ]:

# socialmediadata("c:/users/asrilekh/desktop/work/krishna_request/")
# socialmediadata("/app/Analytics_POCS/")



