# import pandas as pd

# def csv_file_to_json(fname):

#     abs_fname="/app/Analytics_POCS/output/"+fname
#     cdf=pd.read_csv(abs_fname,encoding = 'unicode_escape')
#     print(cdf.columns)
#     converterS = {col: str for col in cdf.columns}
#     df = pd.read_csv(abs_fname,converters=converterS,encoding = 'unicode_escape')
#     e=df.to_json()


import csv  
import json  
import ast 
import os
import pandas as pd

def csv_file_to_json(fname):
    # fname="_optumrx_classification.csv"
    # abs_fname="/app/Analytics_POCS/Output/"+fname
    abs_fname="C:/Users/asrilekh/Desktop/work/Krishna_request/output/"+fname

    # Open the CSV  
    try:
        f = open( abs_fname, 'rU', encoding="latin-1" )  
        # f.seek(1,0)
        print(str(type(f)))
    except Exception as e:
        out="Please enter correct file name "#+str(e)
        return out
    
    reader = csv.DictReader( f)
    # reader = csv.DictReader(f,fieldnames=)
    
     
    try:
        print(str(type(reader)))
        out = json.dumps( [ row for row in reader ] )  
    except Exception as e:
        out="Please enter correct file name"
    out=ast.literal_eval(out)
    return out[1:]
   


print((csv_file_to_json("_optumrx_classification.csv")))