def textanalytics(path):
    #!/usr/bin/env python
    # coding: utf-8

    # In[73]:


    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    import string
    import re
    from scipy import stats
    import math

    import nltk
    from nltk.tokenize import word_tokenize, wordpunct_tokenize
    from nltk.corpus import stopwords
    from nltk.stem import PorterStemmer
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    from nltk.collocations import BigramAssocMeasures, BigramCollocationFinder, TrigramAssocMeasures, TrigramCollocationFinder
    from nltk.chunk import tree2conlltags, conlltags2tree
    from nltk.stem.snowball import SnowballStemmer

    from textblob import TextBlob
    from gensim.test.utils import common_texts 
    from gensim.models.doc2vec import Doc2Vec, TaggedDocument 
    from gensim.models import Word2Vec as gensim_word2vec
    #from feature.db_interface import DBInterface
    from gensim import corpora, models

    # Gensim libraries
    import gensim
    from gensim.utils import simple_preprocess
    from gensim.models import CoherenceModel

    from sklearn import decomposition, ensemble
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.feature_extraction.text import CountVectorizer
    from sklearn import model_selection, preprocessing, linear_model, naive_bayes, metrics, svm
    import csv
    from sklearn.feature_selection import SelectKBest, chi2
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import confusion_matrix, classification_report
    from sklearn.metrics import precision_recall_fscore_support as score


    # Topic Modeling
    from sklearn.decomposition import LatentDirichletAllocation
    from nltk.chunk import tree2conlltags, conlltags2tree

    # Classification Algorithms for prediction
    from nltk.classify.scikitlearn import SklearnClassifier
    from nltk import NaiveBayesClassifier


    import xgboost as xg 
    from keras.preprocessing import text, sequence
    from keras import layers, models, optimizers
    import requests
    import urllib.request
    #import urllib2 
    import time
    from bs4 import BeautifulSoup

    SIMILAR = 0
    DIFFERENT = 90
    import warnings
    pd.options.mode.chained_assignment = None


    # In[2]:


    # read the input excel file
    input = pd.read_excel(path+"ppm_complete_2016_tilldate.xlsx")


    # In[18]:


    raw = input.copy(deep=True)      # Create a dummy data frame from the original list
    raw.columns      # Get all the columns names    


    # In[19]:


    raw.dtypes         # Get all the object types for input data columns


    # In[20]:


    # Step2: # Fill the empty with neighbouring columns
    #raw_nlp['sat1_oe'] = ImputeEmptyComments(raw_nlp, 'sat1_oe', 'sat1')
    raw['sat1_oe'].astype(str)                            # Convert entre dataset to string
    #raw = raw[np.isfinite(raw['sat1_oe'])]
    raw = raw[pd.notnull(raw['sat1_oe'])]
    #raw['sat1_oe'][raw['sat1'] > 7] = raw['sat1_oe'].fillna(value='Positive Comment')
    #raw['sat1_oe'][raw['sat1'] < 8] = raw['sat1_oe'].fillna(value='Negative Comment')


    # In[21]:


    raw = raw[raw['sat1'] > -1]
    raw['sat1_oe'].shape


    # In[22]:


    raw.astype(str)                            # Convert entre dataset to string
    print("The shape of the dataframe is: ", raw.shape)
    raw_nlp = raw[['sat1','sat1_oe']]
    print(raw_nlp.head(5))     # Print the head of the data set 


    # In[23]:


    # Explanation for the data distribution based on NPS scores....
    #The above graph tells that the sat1 scores are more towards 10,9,8 which are positives. That means that the sentiment
    #of the data is more towards positive feedback. 
    # We can make here that sentiment polarity is more positive so as text cloud and ngram analysis.... This is just based on
    # probability

    # 5 Important Maps
    # 1. How are sat1 scores distributed
    # 2. Check the average sat1 scores per quarter and year
    # 3. Check the sat1 scores per each quarter and year
    # 4. Show the top words and its distribution against each quarter and year


    # In[24]:


    ##########################################################################################
    #  Basic feature extraction using text data
    ##########################################################################################
    # Compute the word count of the text data
    def compute_wordcount(raw, col, col_count):
        raw[col_count] = raw[col].apply(lambda x: len(str(x).split(" ")))
        return raw[col_count]

    # Compute the character count of the text data
    def compute_charactercount(raw, col, char_count):
        raw[char_count] = raw[col].str.len() ## this also includes spaces
        return raw[char_count]

    # Compute the average word length of the text data
    def compute_avgwordlength(sentence):
        words = sentence.split()
        return (sum(len(word) for word in words)/len(words)) 

    ##########################################################################################
    # Basic Text Pre-processing of text data
    ##########################################################################################
    # Replace the enpty string with a suitable comment...
    # Assumption: If Passives has rating 8, consider them as promoters
    # Assumption: If Passives has rating 7, consider them as detractors
    # Below are the functions written for the Text Preprocessing
    def ImputeEmptyComments(df, col1, col2):
        df[col1][df[col2] > 7] = df[col1].fillna(value='Positive Comment')
        df[col1][df[col2] < 8] = df[col1].fillna(value='Negative Comment')
        return df[col1]

    def ImputeTargetNULLComments(df, col1, col2):
        df[col1] = np.where(df[col1] == -1, df[col2], df[col1])
        df[col1] = np.where(df[col1] == -2, df[col2], df[col1])    
        return df[col1]

    ############## Convert all the characters into lower case ###############################
    def convert_lowercase(raw, col):
        raw[col] = raw[col].apply(lambda x: str(x).lower())
        return raw[col]

    ############## Remove all numbers from the column ###############################
    def remove_numbers(raw, col):
        raw[col] = raw[col].apply(lambda x: x.translate(str.maketrans('','',string.digits)))
        return raw[col] 

    ############## Remove all punctuations from the column ###############################
    def remove_punctuation(raw, col):
        raw[col] = raw[col].apply(lambda x: x.translate(str.maketrans('','',string.punctuation)))
        return raw[col]

    # Create a Stopwords package...customize the default stopwords package available in the nltk package
    def prepareStopWords():
        stopwordsList = []
        # Load default stop words and add a few more specific to my text.
        stopwordsList = stopwords.words('english') #) - {'to','not','no'}
        stopwordsList.remove('to')
        stopwordsList.remove('not')
        stopwordsList.remove('no')
        stopwordsList.append('im')
        stopwordsList.append('ive')
        stopwordsList.append('isnt')
        stopwordsList.append('also')
        stopwordsList.append('might')
        stopwordsList.append('may')
        return stopwordsList

    ############## Remove all stopwords from the column ###############################
    def remove_stopwords(raw, col, stop):
        raw[col] = raw[col].apply(lambda x: ' '.join([word for word in x.split() if word not in stop]))
        return raw[col] 

    ############## Remove some irrelevant words from the column ###############################
    def remove_irrelevantwords(raw, col, highlyusedwords):
        raw[col] = raw[col].apply(lambda x: ' '.join(lambda x: ' '.join(word for word in x.split() if word not in highlyusedwords)))
        return raw[col] 

    ############## Correct spellings of words from the column ###############################
    def correct_spellings(raw, col):
        raw[col] = raw[col].apply(lambda x: str(TextBlob(x).correct()))
        return raw[col] 

    ############## Remove high frequency of words from the column ###############################
    def remove_highfreq_words(raw, col):
        freq = pd.Series(' '.join(raw[col]).split()).value_counts()[:10]
        freq = list(freq.index)
        raw[col] = raw[col].apply(lambda x: " ".join(x for x in x.split() if x not in freq))
        return raw[col]

    ############## Remove low frequency/rare of words from the column ###############################
    def remove_rare_words(raw, col):
        freq = pd.Series(' '.join(raw[col]).split()).value_counts()[-10:]
        freq = list(freq.index)
        raw[col] = raw[col].apply(lambda x: " ".join(x for x in x.split() if x not in freq))   
        return raw[col]

    ############## Tokenization of sentences from the column ###############################
    def tokenize_words(raw, col):
        #raw[col] = raw[col].apply(lambda x: x.split())
        #return raw[col]
        return raw.apply(lambda row: nltk.word_tokenize(row[col]), axis=1)
    #TextBlob(raw[col][1]).words

    ############## De-Tokenization of sentences from the column ###############################
    detokenized_doc = [] 
    def detokenize_words(raw, col):
        for i in range(len(raw)): 
            t = ' '.join(tokenized_doc[i]) 
            detokenized_doc.append(t) 

    ############## Lemmatization of words from the column ###############################
    def lemmatize_words(lemmatizer, text):
        return [lemmatizer.lemmatize(w) for w in w_tokenizer.tokenize(text)]
        #raw[col] = raw[col].apply(lambda x: " ".join([Word(word).lemmatize() for word in x.split()]))
        #return raw[col]

    ##########################################################################################
    # Advance Text Processing
    ##########################################################################################

    ############## Create TFIDF matrix for words from the column ###############################
    def create_tfidf_matrix(raw, col):
        # n gram level tfidf
        tfidf = TfidfVectorizer(max_features=1000, lowercase=True, token_pattern=r'\w{1,}', analyzer='word', stop_words= 'english',ngram_range=(2,3))   
        # word level vectorizer
        tfidf_vect = TfidfVectorizer(analyzer='word', token_pattern=r'\w{1,}', max_features=1000) 
        sklearn_tfidf = TfidfVectorizer(norm='l2', min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=False)
        tfidf_set = sklearn_tfidf.fit_transform(raw[col])
        return tfidf_set     

    ############## Create Bag of words from the column ###############################
    def create_bag_of_words(raw, col):
        bow = CountVectorizer(max_features=1000, lowercase=True, ngram_range=(1,1),analyzer = "word")
        raw_bow = bow.fit_transform(raw[col])
        return raw_bow

    ############## Perform sentiment analyzer for the words in the column ###############################
    def perform_sentiment_analysis(raw, col, col_sentiment):
        raw[col_sentiment] = raw[col].apply(lambda x: TextBlob(x).sentiment[0])
        return raw[col_sentiment]

    ############## Train Test split of the data ###############################
    def TrainTestSplit(df, col, test_size, random_state):
        df_trn, df_val = train_test_split(df, stratify = df[col], test_size = test_size, random_state = random_state)
        return df_trn, df_val

    ############## Count Vectorizer of the data ###############################
    def count_vectorizer(df, col):
        count_vect = CountVectorizer(analyzer='word', token_pattern=r'\w{1,}')
        count_vect.fit(df[col])
        df_count =  count_vect.transform(train_x)
        return df_count

    ############## Topic Modeling LDA(Latent Dirchlet Allocation) of the data ###############################
    def lda_model(df_count):
        lda_model = decomposition.LatentDirichletAllocation(n_components=20, learning_method='online', max_iter=20)
        X_topics = lda_model.fit_transform(df_count)
        topic_word = lda_model.components_ 
        vocab = count_vect.get_feature_names()
        return topic_word, vocab

    ############## view the topic models ###############################
    def view_topic_model(topic_word, vocab):
        n_top_words = 10
        topic_summaries = []
        for i, topic_dist in enumerate(topic_word):
            topic_words = numpy.array(vocab)[numpy.argsort(topic_dist)][:-(n_top_words+1):-1]
            topic_summaries.append(' '.join(topic_words))
        return topic_summaries

    ############## train the  model ###############################
    def train_model(classifier, feature_vector_train, label, feature_vector_valid, is_neural_net=False):
        # fit the training dataset on the classifier
        classifier.fit(feature_vector_train, label)    
        # predict the labels on validation dataset
        predictions = classifier.predict(feature_vector_valid)    
        if is_neural_net:
            predictions = predictions.argmax(axis=-1)    
        return metrics.accuracy_score(predictions, valid_y)

    ############## Create NGrams of the data ###############################
    class CharacterNGramFeatures:
        def __init__(self):
            self.count_vectorizer = CountVectorizer(ngram_range=(3,5), min_df=5, analyzer='char')
            self.tfidf_transformer = TfidfTransformer()
            self.first = True
        def extractFeatures(self, df):
            features = None
            if self.first:
                counts = self.count_vectorizer.fit_transform(df["comment"])
                features = self.tfidf_transformer.fit_transform(counts)
                self.first = False
            else:
                counts = self.count_vectorizer.transform(df["comment"])
                features = self.tfidf_transformer.transform(counts)
            return features


    # In[27]:


    # These highly used words are not required for analysis against each company
    highlyusedwords = ['health','uhc','insurance','unitedhealthcare','united healthcare','health care',
                    'unitedhealthcares','patients','patient','insurances','united','uniteds','healthcare','united_health_care']

    def TextProcessing(comments, highlyusedwords):
        comments['Comments'] = convert_lowercase(comments,'sat1_oe')
        comments['Comments'] = remove_numbers(comments,'Comments')
        comments['Modified'] = remove_punctuation(comments,'Comments')
        comments['Cleaned'] = remove_stopwords(comments,'Modified', prepareStopWords())
        comments['Filtered'] = remove_stopwords(comments,'Cleaned', highlyusedwords)
        lowfreqwords = pd.Series(' '.join(comments['Filtered']).split()).value_counts()[-5:]
        lowfreqs = list(lowfreqwords.index)                         
        comments['Filtered'] = comments['Filtered'].apply(lambda x: " ".join(x for x in x.split() if x not in lowfreqs))
        comments["nb_chars"] = comments['Filtered'].apply(lambda x: len(x))  
        comments["nb_words"] = comments['Filtered'].apply(lambda x: len(x.split(" ")))
        comments['Tokens'] = comments.apply(lambda row: nltk.word_tokenize(row['Filtered']), axis=1)
        comments['Bigrams'] = comments.apply(lambda row: list(nltk.bigrams(row['Tokens'])), axis = 1)
        comments['Trigrams'] = comments.apply(lambda row: list(nltk.trigrams(row['Tokens'])), axis = 1)                                     
        comments['Pos'] = comments.apply(lambda row: nltk.pos_tag(row['Tokens']), axis =1)
        lemmatizer = nltk.stem.WordNetLemmatizer()
        comments['Stems'] = comments['Tokens'].apply(lambda x: [lemmatizer.lemmatize(y,'v') for y in x])
        return comments


    # In[28]:


    # This is a word to Vector model of the text analytics....
    class Word2Vec:
        def __init__(self):
            # load model
            self.w2v_model = gensim_word2vec.load('model/word2vec/all_lowercased_stemmed')
            # initialize stemmer
            self.stemmer = SnowballStemmer('english')
            # grab stopword list
            self.stop = stopwords.words('english')

        def extractFeatures(self, df):
            data = self.remove_stop_and_stem(df['comment'])
            vectors = np.asarray(list(map(self.comment_to_vectors, data)))
            return vectors

        def text_to_wordlist(self, comment):
            try:
                comment_text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '', comment, flags=re.MULTILINE)
                comment_text = re.sub(r'<\/?em>', '', comment_text, flags=re.MULTILINE)
                comment_text = re.sub("[^a-zA-ZöÖüÜäÄß]"," ", comment_text)
                comment_text = re.sub("\s\s+"," ", comment_text)
                comment_text = comment_text.lower() + '. '
            except:
                comment_text = ''
            return comment_text

        def to_wordlist(self, data):
            return data.apply(self.text_to_wordlist)

        def remove_stopwords(self, data):
            return data.apply(lambda x: [item for item in str(x).split(' ') if item not in self.stop])

        def stem(self, data):
            return data.apply(lambda x: " ".join([self.stemmer.stem(y) for y in x]))

        def word_to_position(self, word):
            try:
                return self.w2v_model.wv[word]
            except:
                return -1

        def comment_to_vectors(self, comment):
            words = comment.split(' ')
            result = list(map(self.word_to_position, words))
            result = sum(result) / len(words)
            return result

        def remove_stop_and_stem(self, data):
            data = self.to_wordlist(data)
            data = self.remove_stopwords(data)
            data = self.stem(data)
            return data


    # In[29]:


    # This class is for topic modeling 
    class TopicModeling:
        def initialiseModel(self):
            self.stopwords = []
            for row in open("data/stopwords_de.txt"):
                self.stopwords.append(row.replace('\n', '').replace('\r', ''))
            try:
                self.dict = corpora.Dictionary().load('model/ldamodel/dictionary.dict')
                self.lda = models.LdaModel.load('model/ldamodel/lda.model')
                return True
            except:  # handle other exceptions such as attribute errors
                warnings.warn(
                    'Could not open dictionary or lda-model. Maybe it does not exist. Train and Save it with "trainAndSaveModel"' +
                    ' TopicModel-Feature is not used.')
                return False

        def saveDict(self):
            articles = []
            for tuple in self.dbinterface.get_all_articles():
                articles.append(tuple[0])
            articles = self.remove_stopwords(articles)
            dictionary = corpora.Dictionary(articles)
            dictionary.save("model/ldamodel/dictionary.dict")

        def calculateKullbackLeibnerDivergence(self, comment, article_url, articles):
            dbinterface = DBInterface()
            kullbackLeiblerDivergence = 0
            articles = articles[articles['url'] == article_url]
            if articles.shape[0] > 0:
                article = articles.iloc[0]['body']
                if not article is None:
                    article_body = article
                    bow_article = self.dict.doc2bow(article_body.lower().split(' '))
                    bow_comment = self.dict.doc2bow(comment.lower().split(' '))
                    get_topicdistribution_for_comment = self.lda.get_document_topics(bow_comment, minimum_probability=0)
                    get_topicdistribution_for_commentarticle = self.lda.get_document_topics(bow_article, minimum_probability=0)
                    kullbackLeiblerDivergence = stats.entropy([tupel[1] for tupel in get_topicdistribution_for_comment],
                                                            [tupel[1] for tupel in get_topicdistribution_for_commentarticle])
            return kullbackLeiblerDivergence

        def trainAndSaveModel(self):
            dbinterface = DBInterface()
            articles = []
            for tuple in dbinterface.get_all_articles():
                articles.append(tuple[0])
            articles = self.remove_stopwords(articles)
            dictionary = corpora.Dictionary(articles)
            # calculate bow and save the corpus
            dictionary.save("model/ldamodel/dictionary.dict")
            corpus = [dictionary.doc2bow(text) for text in articles]
            print('starting training')
            self.lda = models.ldamodel.LdaModel(corpus, num_topics=200, alpha='auto')
            # save the trained model
            self.lda.save('model/ldamodel/lda.model')
            print('training finished')

        def get_diff_for_topics(self, document_topics, comment_topics):
            probability_diffs = []
            for tupel in comment_topics:
                probability_for_topic_in_comment = tupel[1]
                probability_for_topic_in_document = self.get_topic_probability(document_topics, tupel[0])
                diff = abs(probability_for_topic_in_comment - probability_for_topic_in_document)
                probability_diffs.append(diff)
            average = sum(probability_diffs) / len(probability_diffs)
            print(average)

        def get_topic_probability(self, topic_distribution, topic_number):
            for tupel in topic_distribution:
                if topic_number == tupel[0]:
                    return tupel[1]
            return 0

        def remove_stopwords(self, list):
            cleaned_list = ['notempty']  #fix error when it only contains stopwords
            for item in list:
                if item is not None:
                    item = self.remove_stopwords_for_text(item)
                else:
                    item = ''
                cleaned_list.append(item)
            return cleaned_list

        def remove_stopwords_for_text(self, text):
            text_list = []
            for item in text.split(' '):
                item_lowered = item.lower()
                if item_lowered not in self.stopwords:
                    text_list.append(item_lowered)
            return text_list


    # In[30]:


    ##### Find topics with in the features...
    class TopicFeatures:
        def get_cos_similarity_for_article(self, comment, article):
            cos_sim_in_degree = SIMILAR
            corpus = [comment.strip()]
            if article is str and len(article) > 0 and type(comment) is str:
                vector = TfidfVectorizer(min_df=1)
                corpus.extend([article])
                print(corpus)
                vector.fit(corpus)
                tfidf_comment = vector.transform([comment])
                tfidf_article = vector.transform([article])
                cos_sim = cosine_similarity(tfidf_comment, tfidf_article)
                cos_sim_in_degree = self._cos_to_degree(cos_sim)
            return cos_sim_in_degree

        def get_cos_similarity_for_Negative_comments_of_article(self, comment, hate_comments):
            cos_sim_in_degree = DIFFERENT
            corpus = [comment.strip()]
            if len(hate_comments) != 0 and type(comment) is str:
                comment = comment + ' nostop'
                hate_comments_corpus = 'nostop'
                for hate_comment in hate_comments:
                    hate_comments_corpus += ' ' + hate_comment
                corpus.extend([hate_comments_corpus])
                vector = TfidfVectorizer(min_df=1)
                vector.fit(corpus)
                tfidf_comment = vector.transform([comment])
                tfidf_hate_comments = vector.transform([hate_comments_corpus])
                cos_sim = cosine_similarity(tfidf_comment, tfidf_hate_comments)
                cos_sim_in_degree = self._cos_to_degree(cos_sim)
            return cos_sim_in_degree

        def _cos_to_degree(self, cos):
            if cos <= 1.0 and cos >= 0:
                return math.degrees(math.acos(cos))
            return 0


    # In[31]:


    # Below is the simple distribution of how the sat1 scores are distributed with their count.....
    raw_nlp['sat1_oe'] = raw_nlp['sat1_oe'].astype(str)
    print(raw_nlp.groupby('sat1').size());
    # sns.distplot(raw_nlp['sat1']);


    # In[32]:


    raw_nlp = TextProcessing(raw_nlp, highlyusedwords)


    # In[33]:


    raw_nlp.head(5)


    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[ ]:





    # In[34]:


    # Get all the default punctuations from the list of all the words...
    print(set(string.punctuation))


    # In[35]:


    ### Create 2 separate data frames ....one for promoters and another for detractors
    raw_promoters = raw_nlp[raw_nlp['sat1'] > 7]
    raw_detractors = raw_nlp[raw_nlp['sat1'] < 7]
    print("Promoters:", raw_promoters.shape)
    print("Detractors:", raw_detractors.shape)


    # In[36]:


    for token in raw_detractors.Pos:
        print((token))


    # In[50]:


    from nltk.corpus import wordnet
    from itertools import product
    list1 = []
    for tokens in raw_detractors.Pos:
        list2 = []
        for token in tokens:
            if((token[:][1]=='NN') or(token[:][1]=='NNS')):
                list2.append(token[:][0])
        print(list2)
        list1.append(list2)
    raw_detractors['Topics'] = list1
        #allsyns1 = set(ss for word in list2 for ss in wordnet.synsets(word))
        #allsyns2 = set(ss for word in list1 for ss in wordnet.synsets(word))
        #best = max((wordnet.wup_similarity(s1, s2) or 0, s1, s2) for s1, s2 in product(allsyns1, allsyns2))
        #print(best)


    # In[52]:


    raw_detractors.head(5)


    # In[53]:


    list1 = []
    for tokens in raw_promoters.Pos:
        list2 = []
        for token in tokens:
            if((token[:][1]=='NN') or(token[:][1]=='NNS')):
                list2.append(token[:][0])
        print(list2)
        list1.append(list2)
    raw_promoters['Topics'] = list1


    # In[56]:


    # Check the top 10 frequency words for Promoters
    #highfreqwords = raw_nlp.Filtered.str.split(expand=True).stack().value_counts()
    highfreqwords = raw_promoters.Topics.value_counts()
    print("Printing top 10 high frequency words leaving 1st(i.e.to)\n",highfreqwords[1:].head(20)) 
    print("Printing bottom 10 low frequency words\n",highfreqwords.tail(10))


    # In[57]:


    # Check the top 10 frequency words...
    #highfreqwords = raw_detractors.Filtered.str.split(expand=True).stack().value_counts()
    highfreqwords = raw_detractors.Topics.value_counts()
    print("Printing top 10 high frequency words leaving 1st(i.e.to)\n",highfreqwords[1:].head(20)) 
    #print("Printing bottom 10 low frequency words\n",highfreqwords.tail(10))


    # In[63]:


    ###################### TOPIC MODELING ####################
    # Below is the topic modeling done using LDA Latent Dirichlet Allocation
    # Lemmatized words forma list and then fed into gensim phrases function..
    # Once Phrases generated, stopwords are removed and corpora is formed from bigrams
    # Based on which LDA is run against top 10 frequency words of assigned weight for each topic...
    stop = prepareStopWords()
    def TopicModeling(df, col):
        data_words = list(df[col])
        # Build the bigram and trigram models
        bigram = gensim.models.Phrases(data_words, min_count=5, threshold=100) # higher threshold fewer phrases.
        trigram = gensim.models.Phrases(bigram[data_words], threshold=100)  
        # Faster way to get a sentence clubbed as a trigram/bigram
        bigram_mod = gensim.models.phrases.Phraser(bigram)
        trigram_mod = gensim.models.phrases.Phraser(trigram)
        # See trigram example
        #print(bigram_mod[bigram_mod[uhc_data_words[1]]])
        # Remove Stop Words
        data_words_nostops =  [[word for word in simple_preprocess(str(doc)) if word not in stop] for doc in data_words]
        # Form Bigrams
        data_words_bigrams = [bigram_mod[doc] for doc in data_words_nostops]#make_bigrams(data_words_nostops)
        data_words_trigrams = [trigram_mod[bigram_mod[doc]] for doc in data_words_nostops]
        # Create Dictionary
        id2word = corpora.Dictionary(data_words_bigrams)
        # Create Corpus
        texts = data_words_bigrams
        # Term Document Frequency
        corpus = [id2word.doc2bow(text) for text in texts]    
        # Build LDA model
        lda_model = gensim.models.ldamodel.LdaModel(corpus=corpus,
                                                id2word=id2word,
                                                num_topics=10, 
                                                random_state=100,
                                                update_every=1,
                                                chunksize=100,
                                                passes=10,
                                                alpha='auto',
                                                per_word_topics=True)                                               
        # Print the Keyword in the 20 topics
        pprint(lda_model.print_topics())
        doc_lda = lda_model[corpus]	 
        # Compute Perplexity
        print('\nPerplexity: ', lda_model.log_perplexity(corpus))  # a measure of how good the model is. lower the better.
        # Compute Coherence Score
        coherence_model_lda = CoherenceModel(model=lda_model, texts=data_words_bigrams, dictionary=id2word, coherence='c_v')
        coherence_lda = coherence_model_lda.get_coherence()
        print('\nCoherence Score: ', coherence_lda)	
        
        return lda_model, corpus


    # In[79]:


    from pprint import pprint
    uhc_detopicmodel, uhc_decorpus = TopicModeling(raw_detractors,'Stems')
    uhc_prtopicmodel, uhc_prcorpus = TopicModeling(raw_promoters,'Stems')
    # path = "C:\\Users\\achand27\\Documents\\Projects\\AnalyticsProjs\\NLP\\Input_PPM\\"
    top_words_per_topic = []
    for t in range(uhc_detopicmodel.num_topics):
        top_words_per_topic.extend([(t, ) + x for x in uhc_detopicmodel.show_topic(t, topn = 10)])
    pd.DataFrame(top_words_per_topic, columns=['Topic', 'Word', 'P']).to_csv(path + "_detractors_lda.csv")
    top_words_per_topic = []
    for t in range(uhc_prtopicmodel.num_topics):
        top_words_per_topic.extend([(t, ) + x for x in uhc_prtopicmodel.show_topic(t, topn = 10)])
    pd.DataFrame(top_words_per_topic, columns=['Topic', 'Word', 'P']).to_csv(path + "_promoters_lda.csv")


    # In[77]:


    def PerformSentimentAnalysis(df, col, filepath):
        sia = SentimentIntensityAnalyzer()
        df['polarity'] = df[col].apply(lambda s: sia.polarity_scores(s))
        df['polarity_compound'] = df[col].apply(lambda s: sia.polarity_scores(s)['compound'])
        df['polarity_positive'] = df[col].apply(lambda s: sia.polarity_scores(s)['pos'])
        df['polarity_negative'] = df[col].apply(lambda s: sia.polarity_scores(s)['neg'])
        df['polarity_neutral'] = df[col].apply(lambda s: sia.polarity_scores(s)['neu'])
        df['subjectivity'] = df[col].apply(lambda s: TextBlob(s).sentiment.subjectivity)
        
    #     for ind,row in df.iterrows():
    #         if df.loc[ind,'polarity_compound'] == 0.0: 
    #              df.loc[ind,'result'] = 2
    #         elif df.loc[ind,'polarity_compound'] > 0.0:
    #              df.loc[ind,'result'] = 1
    #         else:
    #              df.loc[ind,'result'] = 0
            
        df.to_csv(filepath)
        
        
    # Below function is for running classification algorithms..    
    def RunClassifications(df, col, filepath):    
        with open(filepath, 'w') as fp :
                writer = csv.writer(fp, delimiter=',')
                writer.writerow(["Kbest","Feature Extraction","Classifier","Accuracy","Precsion", "Recall", "FScores", "gram"])  # write header
                total_bag_of_words_model = ["TfidfVectorizer"]
                for gram_type in range(1,4) :
                    for bag_of_word_model in total_bag_of_words_model :
                        if bag_of_word_model == "CountVectorizer" :
                            bag_of_words = CountVectorizer(ngram_range=(gram_type, gram_type))
                        if bag_of_word_model == "TfidfVectorizer" :
                            bag_of_words = TfidfVectorizer(ngram_range=(gram_type, gram_type))
                        X = bag_of_words.fit_transform(df[col]).toarray()
                        y = df.result
                        y= y.astype('int')
                        total_classifier = ["GaussianNB","LogisticRegression","RandomForestClassifier"]
                        for classifier_name in total_classifier:
                            if classifier_name == "GaussianNB" :
                                from sklearn.naive_bayes import GaussianNB
                                classifier = GaussianNB()
                            if classifier_name == "SDGClassifier" :
                                from sklearn.linear_model import SGDClassifier
                                classifier = SGDClassifier()
                            if classifier_name == "LogisticRegression" :
                                from sklearn.linear_model import LogisticRegression
                                classifier = LogisticRegression()
                            if classifier_name == "RandomForestClassifier" :
                                from sklearn.ensemble import RandomForestClassifier
                                classifier = RandomForestClassifier()

                            #Dimension Reductionality - #Using CH2 as parameter for selecting KBest   
                            list = [10,50,100,500]
                            for knum in list:
                                X_new = SelectKBest(chi2, k=knum).fit_transform(X, y)
                                #split data into test and train
                                #from sklearn.cross_validation import train_test_split
                                X_train, X_test, y_train, y_test = train_test_split(X_new, y, test_size = 0.20, random_state = 0)
                                classifier.fit(X_train, y_train)
                                y_pred = classifier.predict(X_test)
                                #Making the confusion Matrix
                                cm = confusion_matrix(y_test, y_pred)
                                accuracy = (cm[0][0] + cm[1][1]) / len(y_test)
                                precision, recall, fscore, support = score(y_test, y_pred, average='weighted')
                                accuracy = float(str(accuracy)[:6])
                                precision = float(str(precision)[:6])
                                recall = float(str(recall)[:6])
                                fscore = float(str(fscore)[:6])
                                writer.writerow([knum,bag_of_word_model, classifier_name,accuracy, precision, recall, fscore, gram_type])  # write header
        # print("SentimentAnalysis completed") 


    # In[78]:


    # Print the Classification and Sentiment Analaysis into the separate files for each insurnace company
    filepath = path+'SentimentAnalysis_'
    PerformSentimentAnalysis(raw_detractors, 'Filtered', filepath + '_detractors.csv')
    RunClassifications(raw_detractors, 'Filtered', filepath + '_detractors_classification.csv')
    PerformSentimentAnalysis(raw_promoters, 'Filtered', filepath + '_promoters.csv')
    RunClassifications(raw_promoters, 'Filtered', filepath + '_promoters_classification.csv')


    # In[112]:


    surveytopics = pd.read_excel(path+"TopicClusters.xlsx")
    surveytopics


    # In[117]:


    from nltk.corpus import wordnet as wn
    from nltk.corpus import wordnet_ic
    reimbursement=wn.synsets('reimbursement', pos=wn.NOUN)[0] #get the first noun synonym of the word "dog"
    #scores  = reimbursement.res_similarity(reimbursement, raw_detractors['Pos'])


    # In[118]:





    # In[ ]:





    # In[88]:


    #Compare word with another word
    from nltk.corpus import wordnet

    list1 = ['Compare', 'require']
    list2 = ['choose', 'copy', 'define', 'duplicate', 'find', 'how', 'identify', 'label', 'list', 'listen', 'locate', 'match', 'memorise', 'name', 'observe', 'omit', 'quote', 'read', 'recall', 'recite', 'recognise', 'record', 'relate', 'remember', 'repeat', 'reproduce', 'retell', 'select', 'show', 'spell', 'state', 'tell', 'trace', 'write']
    list3 = []

    for word1 in list1:
        for word2 in list2:
            wordFromList1 = wordnet.synsets(word1)
            wordFromList2 = wordnet.synsets(word2)
            if wordFromList1 and wordFromList2: #Thanks to @alexis' note
                s = wordFromList1[0].wup_similarity(wordFromList2[0])
                list3.append(s)
                print(word1 + " vs " + word2)
                print(s)


    # In[ ]:





    #                        

    # In[ ]:


# textanalytics("c:/users/asrilekh/desktop/work/krishna_request/")
textanalytics("/app/Analytics_POCS/")

