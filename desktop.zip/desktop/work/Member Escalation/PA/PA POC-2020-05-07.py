import pandas as pd
import csv

csv_file='pa_all_matched_formatted.csv'
csv_test_file='pa_all_matched_formatted_test.csv'
print("Started")
sasds = pd.read_csv('pa_all_matched.csv',encoding='latin-1',chunksize=10000,iterator=True)
dfs = [] # holds data chunks
for chunk in sasds:    
    dfs.append(chunk)
print(len(dfs))
count_all_records = sum([len(x) for x in dfs])
print(count_all_records)
no_of_lines_written=0
for df in dfs:
    df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].astype(str)
    df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].str.rstrip('.0')
    df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].apply(lambda x: x.zfill(12))
    if no_of_lines_written==0:
        df.to_csv(csv_test_file,index=False,quoting=csv.QUOTE_ALL)
        df.to_csv(csv_file,index=False,quoting=csv.QUOTE_ALL)        
        no_of_lines_written=no_of_lines_written+len(df)
        print("Number of lines written to csv file="+str((no_of_lines_written)))
    else:
        df.to_csv(csv_file,mode="a",header=False,index=False)        
        no_of_lines_written=no_of_lines_written+len(df)
        print("Number of lines written to csv file="+str((no_of_lines_written)))
print('Completed ')




################ joining 

first_test_file=csv_test_file
first_file='pa_all_matched_formatted.csv'
second_file='decn_rsn_grouping.csv'
output_file='join_res.csv'
columns_list=['decn_rsn_typ_desc']


######################################################################

df2=pd.read_csv(second_file,encoding = 'latin_1')
print("completed second file "+str(len(df2)))
df1=pd.read_csv(first_test_file,encoding = 'latin_1')
print("completed first file "+str(len(df1)))

# creating a empty bucket to save result
df_result = pd.DataFrame(columns=(df1.columns.append(df2.columns)).unique())
df_result.to_csv(output_file,index_label=False)

# deleting df1 to save memory
del(df1)


file1 = open("testfile_counter.txt","w")

def preprocess(x):      
    
    df=pd.merge(x,df2,how='left',on=columns_list)
    df.to_csv(output_file,mode="a",header=False,index=False)
    file1.write(str(len(df))+"\n")

reader = pd.read_csv(first_file, chunksize=10000) # chunksize depends with you colsize

[preprocess(r) for r in reader]
file1.close()

df=pd.read_csv(output_file,encoding='latin_1')
print("join result length "+str(len(df)))

table = pd.pivot_table(df, index=['SBSCR_MBR_PTY_ID'],columns=['decn_otcome_typ_desc'], aggfunc='count', fill_value=0)
table.to_csv('decn_rsn_typ_desc_pivot.csv',index=False)

table = pd.pivot_table(df, index=['SBSCR_MBR_PTY_ID'],columns=['descn_rsn_group'], aggfunc='count', fill_value=0)
table.to_csv('descn_rsn_group_pivot.csv',index=False)