import pandas as pd
import csv

output_file='join_res.csv'
# def preprocess(x,no_of_lines_written):      

reader = pd.read_csv(output_file, chunksize=100000) # chunksize depends with you colsize
no_of_lines_written=0
# [preprocess(r,no_of_lines_written) for r in reader]

file1 = open("File_counter_smpi_test.csv","w")
file1.write("Run Number,uniq_smpi_before,dotydcols_lst_b4,dotyd_recds b4 run,,uniq_smpi_after,dotyd_recds_aftr_run,dotydcols_lst_aftr,uniq_smpi_before,drgcols_lst_before,drg_recds b4 run,uniq_smpi_before,drg_recds_aftr_run,drgcols_lst_before"+"\n")


decn_otcome_typ_desc_lst=[]
descn_rsn_group_lst=[]
SBSCR_MBR_PTY_ID_Pivot_lst=[]

c=0
for x in reader:
    fws=""
    print("running for "+str(c+1))
    c=c+1
    fws=fws+'"'+str(c+1)+'"'

    cur_decn_otcome_typ_desc_lst=list(x['decn_otcome_typ_desc'].unique())
    cur_descn_rsn_group_lst=list(x['descn_rsn_group'].unique())
    cur_SBSCR_MBR_PTY_ID_Pivot_lst=list(x['SBSCR_MBR_PTY_ID'].unique())

    decn_otcome_typ_desc_lst.extend(cur_decn_otcome_typ_desc_lst)
    descn_rsn_group_lst.extend(cur_descn_rsn_group_lst)
    SBSCR_MBR_PTY_ID_Pivot_lst.extend(cur_SBSCR_MBR_PTY_ID_Pivot_lst)

    decn_otcome_typ_desc_lst=list(set(decn_otcome_typ_desc_lst))
    descn_rsn_group_lst=list(set(descn_rsn_group_lst))
    SBSCR_MBR_PTY_ID_Pivot_lst=list(set(SBSCR_MBR_PTY_ID_Pivot_lst))

    x['SBSCR_MBR_PTY_ID_Pivot']=x['SBSCR_MBR_PTY_ID']

    if no_of_lines_written==0:
        
        table = pd.pivot_table(x, values='SBSCR_MBR_PTY_ID_Pivot', index=['SBSCR_MBR_PTY_ID'],columns=['decn_otcome_typ_desc'], aggfunc='count', fill_value=0)        
        table=table.reset_index()
        table.to_csv('decn_otcome_typ_desc_pivot.csv',index=False,quoting=csv.QUOTE_ALL)
        table.to_csv('decn_otcome_typ_desc_pivot_test.csv',index=False,quoting=csv.QUOTE_ALL)

        
        table1 = pd.pivot_table(x, values='SBSCR_MBR_PTY_ID_Pivot', index=['SBSCR_MBR_PTY_ID'],columns=['descn_rsn_group'], aggfunc='count', fill_value=0)        
        table1=table1.reset_index()
        table1.to_csv('descn_rsn_group_pivot.csv',index=False,quoting=csv.QUOTE_ALL)
        table1.to_csv('descn_rsn_group_pivot_test.csv',index=False,quoting=csv.QUOTE_ALL)

        if len(list(table1['SBSCR_MBR_PTY_ID'].unique()))!=len(list(table['SBSCR_MBR_PTY_ID'].unique())):
            print("In result not matched:"+str(len(list(table1['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(table['SBSCR_MBR_PTY_ID'].unique()))))
        else:
	        pass
            #print("In result matched:"+str(len(list(table1['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(table['SBSCR_MBR_PTY_ID'].unique()))))
               
        no_of_lines_written=no_of_lines_written+len(x)
        
    else:        

        table = pd.pivot_table(x, values='SBSCR_MBR_PTY_ID_Pivot', index=['SBSCR_MBR_PTY_ID'],columns=['decn_otcome_typ_desc'], aggfunc='count', fill_value=0)        
        table=table.reset_index()
        dotdps=pd.read_csv('decn_otcome_typ_desc_pivot.csv') 
        #print(dotdps.head(5)) 
        fws=fws+',"'+str(len(list(dotdps['SBSCR_MBR_PTY_ID'].unique())))+'"' 
        fws=fws+',"'+str(list(dotdps.columns))+'"'
        fws=fws+',"'+str(len(dotdps))+'"'
        
        res_df=pd.concat([dotdps,table])
        res_df.fillna(0)    
        fws=fws+',"'+str(len(list(res_df['SBSCR_MBR_PTY_ID'].unique())))+'"' 
        fws=fws+',"'+str(list(res_df.columns))+'"'
        fws=fws+',"'+str(len(res_df))+'"'
        
        res_df.to_csv('decn_otcome_typ_desc_pivot.csv',index=False,quoting=csv.QUOTE_ALL) 

        #-----------------------------

        table1 = pd.pivot_table(x, values='SBSCR_MBR_PTY_ID_Pivot', index=['SBSCR_MBR_PTY_ID'],columns=['descn_rsn_group'], aggfunc='count', fill_value=0)        
        table1=table1.reset_index()
        drgps=pd.read_csv('descn_rsn_group_pivot.csv')
        #print(drgps.head(5)) 
        fws=fws+',"'+str(len(list(drgps['SBSCR_MBR_PTY_ID'].unique())))+'"' 
        fws=fws+',"'+str(list(drgps.columns))+'"'
        fws=fws+',"'+str(len(drgps))+'"'
        
        res_df1=pd.concat([drgps,table1])
        res_df1.fillna(0) 
        fws=fws+',"'+str(len(list(res_df1['SBSCR_MBR_PTY_ID'].unique())))+'"' 
        fws=fws+',"'+str(list(res_df1.columns))+'"'
        fws=fws+',"'+str(len(res_df1))+'"\n'        
        
        res_df1.to_csv('descn_rsn_group_pivot.csv',index=False,quoting=csv.QUOTE_ALL)  

        #----------------------------- 

        if len(list(drgps['SBSCR_MBR_PTY_ID'].unique()))!=len(list(dotdps['SBSCR_MBR_PTY_ID'].unique())):
            print(drgps.columns)
            print(dotdps.columns)
            print("old not matched:"+str(len(list(drgps['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(dotdps['SBSCR_MBR_PTY_ID'].unique()))))
        else:
	        pass            
            #print("old matched:"+str(len(list(drgps['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(dotdps['SBSCR_MBR_PTY_ID'].unique()))))
        
        if len(list(table['SBSCR_MBR_PTY_ID'].unique()))!=len(list(table1['SBSCR_MBR_PTY_ID'].unique())):
            print("Current not matched:"+str(len(list(table1['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(table['SBSCR_MBR_PTY_ID'].unique()))))
        else:
	        pass
            #print("Current matched:"+str(len(list(table1['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(table['SBSCR_MBR_PTY_ID'].unique()))))

        if len(list(res_df1['SBSCR_MBR_PTY_ID'].unique()))!=len(list(res_df['SBSCR_MBR_PTY_ID'].unique())):
            print(res_df1.columns)
            print(res_df.columns)
            print("In result not matched:"+str(len(list(res_df1['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(res_df['SBSCR_MBR_PTY_ID'].unique()))))
        else:
            print(res_df1.columns)
            print(res_df.columns)
	        # pass	
            print("In result matched:"+str(len(list(res_df1['SBSCR_MBR_PTY_ID'].unique())))+"-"+str(len(list(res_df['SBSCR_MBR_PTY_ID'].unique()))))
        
             
        no_of_lines_written=no_of_lines_written+len(x)
        

    file1.write(fws)  

file1.close()

test_df=pd.DataFrame()
test_df['decn_otcome_typ_desc_lst']=decn_otcome_typ_desc_lst
test_df.to_csv('decn_otcome_typ_desc_lst.csv')
test_df=pd.DataFrame()
test_df['descn_rsn_group_lst']=descn_rsn_group_lst
test_df.to_csv('descn_rsn_group_lst.csv')
test_df=pd.DataFrame()
test_df['SBSCR_MBR_PTY_ID_Pivot_lst']=SBSCR_MBR_PTY_ID_Pivot_lst
test_df.to_csv('SBSCR_MBR_PTY_ID_Pivot_lst.csv')

print(res_df1.columns)
print(res_df.columns)
