#for pivots generation

import pandas as pd
import csv

df=pd.read_csv('join_res.csv',usecols=['SBSCR_MBR_PTY_ID','decn_otcome_typ_desc','descn_rsn_group'])
x=df
x['SBSCR_MBR_PTY_ID_Pivot']=x['SBSCR_MBR_PTY_ID']
table = pd.pivot_table(x, values='SBSCR_MBR_PTY_ID_Pivot', index=['SBSCR_MBR_PTY_ID'],columns=['decn_otcome_typ_desc'], aggfunc='count', fill_value=0)
table=table.reset_index()
table.to_csv('decn_otcome_typ_desc_pivot.csv_1',index=False,quoting=csv.QUOTE_ALL)
table1 = pd.pivot_table(x, values='SBSCR_MBR_PTY_ID_Pivot', index=['SBSCR_MBR_PTY_ID'],columns=['descn_rsn_group'], aggfunc='count', fill_value=0)
table1=table1.reset_index()
table1.to_csv('descn_rsn_group_pivot.csv_1',index=False,quoting=csv.QUOTE_ALL)
df_join_res=pd.merge(table,table1,how='inner',on=["SBSCR_MBR_PTY_ID"])
df_join_res.to_csv('decn_otcome_typ_desc_rsn_group_join.csv',index=False,quoting=csv.QUOTE_ALL)




## ets and baseline files generation

df_ETS_claim_agg=pd.read_csv('ETS_claim_agg.csv')
df_ets_call_agg=pd.read_csv('ets_call_agg.csv')
df_join_res_ets=pd.merge(df_ETS_claim_agg,df_ets_call_agg,how='inner',on=["SBSCR_MBR_PTY_ID"])
df_join_res_ets.to_csv('ETS_Calls_Claims_data.csv',index=False,quoting=csv.QUOTE_ALL)

df=df_join_res_ets
df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].astype(str)
df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].str.rstrip('.0')
df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].apply(lambda x: x.zfill(12))
df_join_res_ets=df


df_claim_agg_full_pop=pd.read_csv('claim_agg_full_pop.csv')

df_claim_agg_full_pop=df_claim_agg_full_pop.drop_duplicates()
df_claim_agg_full_pop=df_claim_agg_full_pop.drop_duplicates(subset=['SBSCR_MBR_PTY_ID'])

df_call_agg_full_pop=pd.read_csv('call_agg_full_pop.csv')

df_call_agg_full_pop=df_call_agg_full_pop.drop_duplicates()
df_call_agg_full_pop['Counts']=df_call_agg_full_pop.SBSCR_MBR_PTY_ID.groupby(df_call_agg_full_pop.SBSCR_MBR_PTY_ID).transform('count')
df_call_agg_full_pop=df_call_agg_full_pop[df_call_agg_full_pop['Counts'] < 2]
df_call_agg_full_pop=df_call_agg_full_pop.drop(columns=['Counts'])

df_join_res_agg_pop=pd.merge(df_call_agg_full_pop,df_claim_agg_full_pop,how='inner',on=["SBSCR_MBR_PTY_ID"])

df=df_join_res_agg_pop
df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].astype(str)
df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].str.rstrip('.0')
df['SBSCR_MBR_PTY_ID']=df['SBSCR_MBR_PTY_ID'].apply(lambda x: x.zfill(12))
df_join_res_agg_pop=df

df_full_pop_pivot_join=pd.merge(df_join_res_agg_pop,df_join_res,how='inner',on=["SBSCR_MBR_PTY_ID"])
df_ets_pivot_join=pd.merge(df_join_res_ets,df_join_res,how='inner',on=["SBSCR_MBR_PTY_ID"])

df_ets_pivot_join.to_csv('ETS_And_Pivot_Merge.csv',index=False,quoting=csv.QUOTE_ALL)
df_full_pop_pivot_join.to_csv('Baseline_And_Pivot_Merge.csv',index=False,quoting=csv.QUOTE_ALL)

print('completed')




