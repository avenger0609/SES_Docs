#!/usr/bin/python

#https://www.tutorialspoint.com/python/python_sending_email.htm

import smtplib
import os
import time
from pprint import pprint
import win32com.client as win32
import time
from datetime import datetime
import datetime
import csv
from datetime import datetime

os.chdir('\\\\uhc00502\\data\\UHT_TRMCB\\Incoming')
print(os.getcwd())

sender = 'srilekha.anumula@optum.com'
receivers = ['srilekha.anumula@optum.com']

subject1="ts"
content1="msg"

message = """From: Srilekha <srilekha.anumula@optum.com>
To: Srilekha <srilekha.anumula@optum.com>; Srilekha <srilekha.anumula@optum.com>
Cc: Srilekha <srilekha.anumula@optum.com>
BCc: Srilekha <srilekha.anumula@optum.com>
MIME-Version: 1.0
Content-type: text/html
Subject: New files posted to Incoming folder

<p>Hi Everyone,</p>
<p>Please find below list of files posted to  <a href=\\\\uhc00502\\data\\UHT_TRMCB\\Incoming>Incoming</a> folder as on  : </p>


"""
try:        
    smtpObj = smtplib.SMTP('mail25.uhc.com')
    smtpObj.sendmail(sender, receivers, message)         
    print ("Successfully sent email")
except:
    print ("Error: unable to send email")





