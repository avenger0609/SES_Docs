import os
import time
from pprint import pprint
import win32com.client as win32
import time
from datetime import datetime
import datetime
import csv
from datetime import datetime

os.chdir('\\\\uhc00502\\data\\UHT_TRMCB\\Incoming')
print(os.getcwd())
file_error=0
try:
    file1 = open("sync.txt","r")
    y=list()
    for line in file1:
        y.append(line.rstrip(line[-1:]))
except:
    print("error in reading file")
    file_error=1
# if file_error==1: # file doesn't exist
#     existing_files=list()
#     existing_files.append("Business Process Management (UHC MR) -Special Services Chargeback ($21000).msg".lower()+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), "Business Process Management (UHC MR) -Special Services Chargeback ($21000).msg")))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), "Business Process Management (UHC MR) -Special Services Chargeback ($21000).msg"))))))
#     existing_files.append("ss.csv".lower()+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), "ss.csv")))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), "ss.csv"))))))
#     existing_files.append("Sybase Enterprise Agreement - 2013.msg".lower()+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), "Sybase Enterprise Agreement - 2013.msg")))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), "Sybase Enterprise Agreement - 2013.msg"))))))
#     file1 = open("sync.txt","w")
#     for x1 in existing_files:
#         file1.write(x1+"\n")

# try:
#     if len(y)==0: #empty file
#         file1.close()
#         existing_files=list()
#         existing_files.append("Business Process Management (UHC MR) -Special Services Chargeback ($21000).msg".lower()+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), "Business Process Management (UHC MR) -Special Services Chargeback ($21000).msg")))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), "Business Process Management (UHC MR) -Special Services Chargeback ($21000).msg"))))))
#         existing_files.append("ss.csv".lower()+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), "ss.csv")))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), "ss.csv"))))))
#         existing_files.append("Sybase Enterprise Agreement - 2013.msg".lower()+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), "Sybase Enterprise Agreement - 2013.msg")))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), "Sybase Enterprise Agreement - 2013.msg"))))))
#         file1 = open("sync.txt","w")
#         for x1 in existing_files:
#             file1.write(x1+"\n")
# except:
#     junk=1
def newfiles_check():
    

# creating a forever loop
    
    
    
    try:
        existing_files=list()
        file1 = open("sync.txt","r")
        for line in file1:
            existing_files.append(line.rstrip(line[-1:]))
        files_list=list()
        for entry in os.scandir('\\\\uhc00502\\data\\UHT_TRMCB\\Incoming'):
            if entry.is_file():
                # print(entry.name)
                files_list.append(entry.name+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), entry)))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), entry))))))
        msg_body=""
        sno=0
        new_fnames=list()
        new_flag=0
        for fname in files_list:
            # print(fname)
            if fname.lower() in existing_files or  fname.lower().startswith('sync.txt')   :
                junk=1
            else:
                new_flag=1
                hlink='\\\\uhc00502\\data\\UHT_TRMCB\\Incoming'
                msg_body=msg_body+"<p>"+str(sno+1)+"."+fname.split('!')[0]+"</a></p>"
                new_fnames.append(fname.split('!')[0])
                # msg_body=msg_body+"<p><a href="+hlink+">"+fname+"</a></p>"
                sno=sno+1
                existing_files.append(fname.lower())
        if new_flag==1:
            outlook = win32.Dispatch('outlook.application')
            mail = outlook.CreateItem(0)
            # mail.To = 'sreekanth.bhallamudi@optum.com'
            # mail.CC= 'itcb@uhc.com;suman_mondal@optum.com;neeti_kaushik@optum.com;ankineedu.thota@optum.com;dheerendra.pasupuleti@optum.com'
            # mail.BCC= 'srilekha.anumula@optum.com'
            mail.To='srilekha.anumula@optum.com'
            # mail.To='srilekha.anumula@optum.com;neeti_kaushik@optum.com;sreekanth.bhallamudi@optum.com;itcb@uhc.com'
            sub_1=""
            sub_i=0
            for nfn in new_fnames:
                if sub_i==0:                    
                    sub_1="\\\\"+nfn+"\\\\"
                    sub_i=1
                else:
                    sub_1=sub_1+" and "+"\\\\"+nfn+"\\\\"
            mail.Subject = 'CB File '+sub_1+' dropped in TRM Folder'
            mail.Body =""
            hlink='\\\\uhc00502\\data\\UHT_TRMCB\\Incoming'
            # mail.HTMLBody='<p><h3>Note:This is Auto Generated email</h3></P><p>Hi Everyone,</p><p>Please find below list of files posted to share drive:</p>'+msg_body+"<p>Thanks.</p>"
            mail.HTMLBody='<p>Hi Everyone,</p><p>Please find below list of files posted to  '+'<a href='+hlink+'>'+"Incoming"+'</a>'+' folder as on '+ (str((datetime.now())))+':</p>'+msg_body+"<p>Thanks.</p>"

            # To attach a file to the email (optional):
            # attachment  = "c:\\users\\asrilekh\\desktop\\work\\swing Analysis\\start_up.py"
            # mail.Attachments.Add(attachment)

            mail.Send()
            file1 = open("sync.txt","w")
            for x1 in existing_files:
                file1.write(x1+"\n")

        else:
            print("No New files as of "+(str((datetime.now()))))
        print(msg_body)
    except Exception as  e1:
        print('Issue while executing script'+str(e1))
        # try:
        #     outlook = win32.Dispatch('outlook.application')
        #     mail = outlook.CreateItem(0)
        #     # mail.To = 'srilekha.anumula@optum.com;sreekanth.bhallamudi@optum.com'
        #     mail.To='srilekha.anumula@optum.com'
        #     mail.Subject = 'Issue while executing python script'
        #     mail.Body =""
        #     mail.HTMLBody='<p>Issue while executing python script</p>'
        #     mail.Send()
        # except:
        #     print('Issue while executing script')
# time.sleep(300)
while True:
    # print("started")
    newfiles_check()
    # time.sleep(3600)




# pprint([(x[0], time.ctime(x[1].st_mtime)) for x in sorted([(fn, os.stat(fn)) for fn in os.listdir("c:\\users\\asrilekh\\desktop\\work\\swing analysis")], key = lambda x: x[1].st_mtime)])

# f_list=[(x[0], time.ctime(x[1].st_mtime)) for x in sorted([(fn, os.stat(fn)) for fn in os.listdir("\\\\nasv0066\\special_ice_cb_project_repository")], key = lambda x: x[1].st_mtime)]
# print(str(len(f_list)))
# h=0
# for f in f_list:
#     len_str=len(str(f).split(',')[0])-1
#     file_name=(str(f).split(',')[0][2:len_str])
#     print(file_name)
#     if os.path.isfile("\\\\nasv0066\\special_ice_cb_project_repository\\"+file_name) and (file_name!='ss.csv') and (str(file_name).split('.')[1]!='.msg'):
#         print(file_name)


# files_list=list()
# for root, dirs, files in os.walk("\\\\nasv0066\\special_ice_cb_project_repository"):
#     for filename in files:
#         try:
#
#         # print(filename)
#         files_list.append("\\\\nasv0066\\special_ice_cb_project_repository"+filename)
# for filename in files_list:
#     print(filename)


# os.curdir="\\\\nasv0066\\special_ice_cb_project_repository"
# files = filter(os.path.isfile, os.listdir( os.curdir ) )  # files only
# # files = [ f for f in os.listdir( os.curdir ) if os.path.isfile(f) ]
# print(os.curdir)
# print(files)
