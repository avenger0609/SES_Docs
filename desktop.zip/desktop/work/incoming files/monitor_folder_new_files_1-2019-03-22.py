import os
import time
from pprint import pprint
import win32com.client as win32
import time
from datetime import datetime
import datetime
import csv
from datetime import datetime
import smtplib

os.chdir('\\\\uhc00502\\data\\UHT_TRMCB\\Incoming')
print(os.getcwd())
while True:

    try:
        existing_files=list()
        files_list=list()
        for entry in os.scandir('\\\\uhc00502\\data\\UHT_TRMCB\\Incoming'):
            if entry.is_file():
                # print(entry.name)
                files_list.append(entry.name+"!"+str(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), entry)))))+"!"+str(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), entry))))))
        msg_body=""
        sno=0
        new_fnames=list()
        new_flag=0
        for fname in files_list:
            # print(fname)
            if fname.lower() in existing_files or  fname.lower().startswith('sync.txt')   :
                junk=1
            else:
                new_flag=1
                hlink='\\\\uhc00502\\data\\UHT_TRMCB\\Incoming'
                msg_body=msg_body+str(sno+1)+"."+fname.split('!')[0]+"\n"
                new_fnames.append(fname.split('!')[0])                
                sno=sno+1
                existing_files.append(fname.lower())
        if new_flag==1:            
            sub_1=""
            sub_i=0
            for nfn in new_fnames:
                if sub_i==0:                    
                    sub_1="\\\\"+nfn+"\\\\"
                    sub_i=1
                else:
                    sub_1=sub_1+" and "+"\\\\"+nfn+"\\\\"
            Subject = 'CB File '+sub_1+' dropped in TRM Folder'
            hlink='\\\\uhc00502\\data\\UHT_TRMCB\\Incoming'    
            sender = 'srilekha.anumula@optum.com'
            receivers = ['srilekha.anumula@optum.com']

            subject1="ts"
            content1="msg"

            message = """From: Srilekha <srilekha.anumula@optum.com>
            To: Srilekha <srilekha.anumula@optum.com>; Srilekha <srilekha.anumula@optum.com>
            Cc: Srilekha <srilekha.anumula@optum.com>
            BCc: Srilekha <srilekha.anumula@optum.com>
            MIME-Version: 1.0
            Content-type: text/html
            Subject: New files posted to Incoming folder

            <p>Hi Everyone,</p>
            <p>Please find below list of files posted to  <a href=\\\\uhc00502\\data\\UHT_TRMCB\\Incoming>Incoming</a> folder as on %s  : </p>
            %s

            """%(str((datetime.now())),msg_body)
            try:        
                smtpObj = smtplib.SMTP('mail25.uhc.com')
                smtpObj.sendmail(sender, receivers, message)         
                print ("Successfully sent email")
            except:
                print ("Error: unable to send email")
                   
            
        

        else:
            print("No New files as of "+(str((datetime.now()))))
        print(msg_body)
    except Exception as  e1:
        print('Issue while executing script'+str(e1))


    
