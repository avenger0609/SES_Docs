## worked ###
from selenium import webdriver
import pandas as pd
import os

for r,d,f in os.walk(r'C:\Users\asrilekh\Downloads\Srilekha Files'):
    print(len(f))
    for fi in f:
        try:
            print(fi)
            df = pd.read_excel(os.path.join(r'C:\Users\asrilekh\Downloads\Srilekha Files',fi),usecols=['CS Service Unique Identifier'])
            print(df.columns)
            s1=""
            for i in range(0,len(df)):            
                if len(str(df.iloc[i,0]).strip(' '))==5:
                    s1=s1+str(df.iloc[i,0])+","
            s1=s1[0:len(s1)-1]
            print(s1)
            print('----------')
        except Exception as e:
            print(str(e))