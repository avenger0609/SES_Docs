## worked ###
from selenium.webdriver.common.keys import Keys 
from selenium import webdriver
import time
import pandas as pd
import xlsxwriter

# def configid1(config_id_lst):

config_id_lst=[]
file1 = open("c:\\users\\asrilekh\\documents\\testfile.txt","r",encoding='latin-1')
for line in file1:
    #print(line)
    config_id_lst.append(line.rstrip(line[-1:]))
config_id_lst=config_id_lst[240:300]
print(len(config_id_lst))

#config_id_lst static should be placed here
res_1006013_lst=list()
res_1006013_lst.append("Role!Display!Type!MS ID!MS ID Type!Email")
driverpath = "C:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get(" http://asrilekh:UHGtech-4@scrc2013.optum.com/Knowledge/Pages/OwnerLookup.aspx?url=%c3%a2%c2%80%c2%9dtarget=_blank")
time.sleep(30)
driver.find_element_by_xpath('//*[@id="ctl00_ctl38_g_4d978d11_bc92_46b5_aeb0_a3afb63e7726"]/div/div/div/div/input').click()
driver.find_element_by_xpath('//*[@id="ctl00_ctl38_g_4d978d11_bc92_46b5_aeb0_a3afb63e7726"]/div/div/div/div/input').clear()

# driver.find_element_by_xpath('//*[@id="spbody"]/div/div/div/input').send_keys()
# print("test")

for cid in config_id_lst:
    print(cid)
    try:

        driver.find_element_by_xpath('//*[@id="ctl00_ctl38_g_4d978d11_bc92_46b5_aeb0_a3afb63e7726"]/div/div/div/div/input').clear()
        driver.find_element_by_xpath('//*[@id="ctl00_ctl38_g_4d978d11_bc92_46b5_aeb0_a3afb63e7726"]/div/div/div/div/input').send_keys(cid)
        driver.find_element_by_xpath('//*[@id="ctl00_ctl38_g_4d978d11_bc92_46b5_aeb0_a3afb63e7726"]/div/div/div/div/a').click()
        time.sleep(60)
        tbl_id=driver.find_element_by_xpath('//*[@id="ctl00_ctl38_g_4d978d11_bc92_46b5_aeb0_a3afb63e7726"]/div/div/div/table')   
          
        rows=tbl_id.find_elements_by_tag_name("tr")
        
        for row in rows:
            try:
                # print(str(row.find_elements_by_tag_name("td")))
                col=row.find_elements_by_tag_name("td")[0]
                # print(col.text)
                res_1006013_lst.append(cid+"!"+str(col.text)+"!"+(row.find_elements_by_tag_name("td")[1]).text+"!"+(row.find_elements_by_tag_name("td")[2]).text+"!"+(row.find_elements_by_tag_name("td")[3]).text+"!"+(row.find_elements_by_tag_name("td")[4]).text+"!"+(row.find_elements_by_tag_name("td")[5]).text)
                file1.write(cid+"!"+str(col.text)+"\n")
            except:
                # print("exception")
                junk=1
        

    except Exception as e:
        print("exception for "+ cid+" is "+str(e))
        # driver.switch_to.default_content()
        # driver.find_element_by_xpath("//input[@onclick= \"fnReset();\"]").click()
        time.sleep(30)

merged_x = "C:\\users\\asrilekh\\documents\\res_1006013_5.xlsx"
merged_x_wb = xlsxwriter.Workbook(merged_x)
merged_sheet = merged_x_wb.add_worksheet("data")

for deli in range(0, len(res_1006013_lst)):
    del_str = res_1006013_lst[deli].split('!')
    for delsi in range(0, len(del_str)):
        merged_sheet.write(deli, delsi, del_str[delsi])
merged_x_wb.close()
