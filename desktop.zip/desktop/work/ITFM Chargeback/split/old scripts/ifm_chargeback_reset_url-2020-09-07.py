## worked ###
from selenium.webdriver.common.keys import Keys 
from selenium import webdriver
import time
import pandas as pd
import xlsxwriter
from ifm_chargeback_reset_url import *

# file1 = open("testfile_106003_1.txt","w")
df = pd.read_excel(r'C:\Users\asrilekh\Desktop\work\ITFM Chargeback\Files\Optum Tech GSD - Computer Services.xlsx',usecols=[10,26])
print(df.columns)
config_id_lst=list()
for i in range(0,len(df)):
    
    if (str(df.iloc[i,0]).strip(' ')=='i1006013' or str(df.iloc[i,0]).strip(' ')=='1006013'):        
        config_id_lst.append(str(df.iloc[i,1]))
config_id_lst = list(dict.fromkeys(config_id_lst))
print(len(config_id_lst))
file1 = open("c:\\users\\asrilekh\\documents\\testfile.txt","w")
for x1 in config_id_lst:
    file1.write(x1+"\n")
file1.close()


print("completed")
