## worked ###
from selenium.webdriver.common.keys import Keys 
from selenium import webdriver
import time
import pandas as pd
import xlsxwriter

# file1 = open("testfile_106003_1.txt","w")
df = pd.read_excel('C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\nsaolapu@corpimsvcs.com\\cs_file.xlsx',usecols=[10,26])
print(df.columns)
config_id_lst=list()
for i in range(0,len(df)):
    
    if (str(df.iloc[i,0]).strip(' ')=='i1006013' or str(df.iloc[i,0]).strip(' ')=='1006013'):        
        config_id_lst.append(str(df.iloc[i,1]))
config_id_lst = list(dict.fromkeys(config_id_lst))
print(len(config_id_lst))
c=0
file1 = open(r"c:\users\asrilekh\documents\testfile.txt","w")
for x1 in config_id_lst:
    if str(x1).lower().startswith('adobe'):
        continue
    file1.write(x1+"\n")
    c=c+1
file1.close()
print(c)
# #config_id_lst static should be placed here
# res_1006013_lst=list()
# driverpath = "C:\\ProgramData\\Chrome_driver_76.0.3809.68\\chromedriver.exe"
# chromeOptions = webdriver.ChromeOptions()
# chromeOptions.add_experimental_option('useAutomationExtension', False)
# driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
# driver.get(" http://asrilekh:UHGtech-4@scrc2013.optum.com/Knowledge/Pages/OwnerLookup.aspx?url=%c3%a2%c2%80%c2%9dtarget=_blank")
# time.sleep(30)
# driver.find_element_by_xpath("//input[@onclick= \"fnReset();\"]").click()
# # print("test")

# for cid in config_id_lst:
#     print(cid)
#     try:
#         driver.switch_to_frame(driver.find_element_by_tag_name("iframe"))
#         # print("test1")
#         time.sleep(30)
#         driver.find_element_by_name("tbUrl").send_keys(cid)
#         # print("test2")
#         driver.find_element_by_id('btnSubmit').click()
#         time.sleep(120)
#         # driver.switch_to.default_content()
#         # driver.find_element_by_xpath("//input[@onclick= \"fnReset();\"]").click()
#         # print("test3")
#         tbl_id=driver.find_element_by_xpath("//*[@id=\"gvResults\"]")
#         # tbl_id=driver.find_element_by_id("gvResults")
#         # print("test4")
#         rows=tbl_id.find_elements_by_tag_name("tr")
#         # print("test5")
#         # //*[@id="gvResults"]/tbody/tr[2]/td[1]
#         # print(rows)
#         for row in rows:
#             try:
#                 # print(str(row.find_elements_by_tag_name("td")))
#                 col=row.find_elements_by_tag_name("td")[0]
#                 # print(col.text)
#                 res_1006013_lst.append(cid+"!"+str(col.text))
#                 file1.write(cid+"!"+str(col.text)+"\n")
#             except:
#                 # print("exception")
#                 junk=1

#         driver.switch_to.default_content()
#         driver.find_element_by_xpath("//input[@onclick= \"fnReset();\"]").click()
#         time.sleep(30)

#     except Exception as e:
#         print("exception for "+ cid+" is "+str(e))
#         driver.switch_to.default_content()
#         driver.find_element_by_xpath("//input[@onclick= \"fnReset();\"]").click()
#         time.sleep(30)

# merged_x = "C:\\users\\asrilekh\\documents\\res_1006013_1.xlsx"
# merged_x_wb = xlsxwriter.Workbook(merged_x)
# merged_sheet = merged_x_wb.add_worksheet("data")

# for deli in range(0, len(res_1006013_lst)):
#     del_str = res_1006013_lst[deli].split('!')
#     for delsi in range(0, len(del_str)):
#         merged_sheet.write(deli, delsi, del_str[delsi])
# merged_x_wb.close()
