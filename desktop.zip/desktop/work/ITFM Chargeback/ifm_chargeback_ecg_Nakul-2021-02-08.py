## worked ###
from selenium import webdriver
import pandas as pd

df = pd.read_excel('C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\nsaolapu@corpimsvcs.com\\cs_file.xlsx',usecols=[10,26])
print(df.columns)
s1=""
for i in range(0,len(df)):
    
    if (str(df.iloc[i,0]).strip(' ')=='1008003' or str(df.iloc[i,0]).strip(' ')=='i1008003') and ("(A)" not in str(df.iloc[i,1]).strip(' ')):
        # print("entered")
        s1=s1+str(df.iloc[i,1])+","
s1=s1[0:len(s1)-1]
print(s1)




driverpath = "C:\\ProgramData\\Chrome_driver_79.0.3945.16\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
print("https://ecgdash.healthtechnologygroup.com/cockpit/configsearch.do")
driver.get("https://ecgdash.healthtechnologygroup.com/cockpit/configsearch.do")
# driver.find_element_by_name('USER').send_keys('asrilekh')
# driver.find_element_by_name ('PASSWORD').send_keys('UHGtech-2')
# driver.find_element_by_xpath("//input[@onclick= \"submitForm();\"]").click()
driver.find_element_by_name('search_configurationID').send_keys(s1)
driver.find_element_by_id('searchConfig').click()
driver.find_element_by_id('exportexcelresults').click()

