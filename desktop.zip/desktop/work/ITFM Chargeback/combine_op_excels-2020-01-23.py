import pandas as pd
import glob

import os

filelist = list()
for root, dirs, files in os.walk(r"C:\Users\asrilekh\Documents\itfm monthly report", topdown=False):
    for f in files:
        filelist.append(os.path.join(root, f))

# print(directory_list)
ndf=0

    
if ndf==0:
    files2 = pd.read_excel(filelist[0])
    files2['FileName'] = filelist[0]
    new_df=files2[0:0]
    ndf=1

for i in  filelist: 
    files2 = pd.read_excel(i)
    files2['FileName'] = i 
    new_df = new_df.append(files2) 
    print (i)


writer = pd.ExcelWriter("C:\\Users\\asrilekh\\Documents\\itfm monthly report\\Export.xlsx")
new_df.to_excel(writer,'All')
writer.save()


