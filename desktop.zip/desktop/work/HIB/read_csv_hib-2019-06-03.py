import pandas as pd
import sqlite3
import json

##################
# 1. give input file path in  pd.read_csv
# 2. give path of HIB_Sqlite.db
# 3.abosolute path to data.json
##############

### reading input files ###########
rename_col_lst=['submarket','Funding_Arrangement','Hosp_Provkey','OOA_OON','purchaser_id','Treatmt_Setting','Case_Status','Case_Type','end_dt','start_dt','admit_type','bcrt_denial_days','Dx_Prim','plan','member_zip','mbr_minor_mkt','mkt_region','mbr_state','aco_ind','aco_key','hicn','lob','cms_geo_code','business_segment_adj','sub_plan','Group_Id','product_desc','ltc_flg','dual','network','flu_indicator','entity_adj','product','contract_pbp','market','tfm_product','mkt_cont_pilot','company_code_adj','prov_tin','outlier_flag','ACO_NAME','readmit_flag','readmit_flag_7d','ad1d_flg','span','year','month','week','group_name','ip_admit','SNF_admit','ip_ip','ip_snf','snf_ip','index_acute','index_acute_readmit30','acute_snf_acute','acute_snf_home_acute','snf_discharge','ip_discharge','ip_day','SNF_day']
req_col_lst=['year','month','week','market','business_segment_adj','product_desc','ACO_NAME','flu_indicator','admit_type','Case_Type','Treatmt_Setting','entity_adj','mkt_region','mbr_minor_mkt','mbr_state','Hosp_Provkey','outlier_flag','Funding_Arrangement','ip_snf','snf_ip','readmit_flag','ad1d_flg','index_acute','ip_day','SNF_day','index_acute_readmit30','ip_discharge','snf_discharge','ip_admit','SNF_admit']
conv_cofloat_col_lst=req_col_lst
# ['ip_admit','ip_discharge','snf_admit','snf_discharge','ip_day','SNF_day','index_acute_readmit30','index_acute']
converterS = {col: str for col in conv_cofloat_col_lst}
print(str(converterS))
print(str(type(converterS)))
df=pd.read_csv('C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\pprakhar@corpimsvcs.com\\header_2019_6_04142019_ytd_ang.csv',sep=',',header=0,names=rename_col_lst,usecols=req_col_lst,converters=converterS,encoding = 'unicode_escape')
print(df.columns)
### reading input files ###########

######### aggregating columns using sqlite ###################

db_file = "C:\\Users\\asrilekh\\Desktop\\work\\HIB\\HIB_Sqlite.db"
con = sqlite3.connect(db_file)
cur = con.cursor()
df.to_sql("HIB_Data_Tbl", con, if_exists='replace', index=False)
qry=u"select year, month, week, market, business_segment_adj, product_desc, ACO_NAME, flu_indicator, admit_type, Case_Type, Treatmt_Setting, entity_adj, mkt_region, mbr_minor_mkt, mbr_state, Hosp_Provkey, outlier_flag, Funding_Arrangement,sum(ip_admit) as ip_admit, sum(ip_discharge) as ip_discharge, sum(SNF_admit) as SNF_admit, sum(snf_discharge) as snf_discharge,sum(ip_snf) as ip_snf, sum(snf_ip) as snf_ip, sum(readmit_flag) as readmit_flag, sum(ad1d_flg) as ad1d_flg,sum(index_acute) as index_acute, sum(ip_day) as ip_day, sum(SNF_day) as SNF_day, sum(index_acute_readmit30) as index_acute_readmit30 from HIB_Data_Tbl group by year, month, week, market, business_segment_adj, product_desc, ACO_NAME, flu_indicator, admit_type, Case_Type, Treatmt_Setting, entity_adj, mkt_region, mbr_minor_mkt, mbr_state,Hosp_Provkey, outlier_flag, Funding_Arrangement;"
# qry=u"select year, month, week, market, business_segment_adj, product_desc, ACO_NAME, flu_indicator, admit_type, Case_Type, Treatmt_Setting, entity_adj, mkt_region, mbr_minor_mkt, mbr_state, Hosp_Provkey, outlier_flag, Funding_Arrangement,sum(ip_admit) as ip_admit, sum(ip_discharge) as ip_discharge, sum(SNF_admit) as SNF_admit, sum(snf_discharge) as snf_discharge,sum(ip_snf) as ip_snf, sum(snf_ip) as snf_ip, sum(readmit_flag) as readmit_flag, sum(ad1d_flg) as ad1d_flg,sum(index_acute) as index_acute, sum(ip_day) as ip_day, sum(SNF_day) as SNF_day, sum(index_acute_readmit30) as index_acute_readmit30 from HIB_Data_Tbl group by year;"
df_sqlite_res = pd.read_sql_query(qry, con)
# s1=""
# for row in range(0,len(df_sqlite_res)):    
#     for col in range(0,len(df_sqlite_res.columns)):
#         s1=s1+"!"+str(df_sqlite_res.iloc[row,col])
#     print(s1)
#     print("***********************************************")
#     s1=""

######### aggregating columns using sqlite ###################

#########geenerating json object #################

data =[]
for row in range(0,len(df_sqlite_res)):
    # print(str(row))
    elm = {}
    for col in range(0,len(df_sqlite_res.columns)):
        elm[df_sqlite_res.columns[col]]=str(df_sqlite_res.iloc[row,col])
    data.append(elm)
print(type(data))

############ generating json object ###############

# print(json.dumps(data))
with open('data.json', 'w') as outfile:
    json.dump(data, outfile)