var sql = require('mssql');
var sqlConfig = {
#   user: 'ms\\asrilekh',
#   password: 'UHGtech-3',
  server: 'DBSEP6312',  
  database: 'TRMDB'
};

(async function () {
  try {
    console.log("sql connecting......")
    let pool = await sql.connect(sqlConfig)
    let result = await pool.request()
      .query('select table_name from INFORMATION_SCHEMA.TABLES')  // subject is my database table name

    console.log(result )

  } catch (err) {
    console.log(err);
  }
})()