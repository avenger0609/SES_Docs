# Import the county data and print out the first few rows
from domojupyter import *
input = read_dataframe('Model Prep')
input.head(3)
for col in input.columns: 
    print(col)
objs = list()
extra = list()
ps = list()
modelOutput = pd.DataFrame() #creates a new dataframe that's empty

for index, row in input.head(10).iterrows():
    rowParams = Parameters(
        population=row['Population']*.07,
        current_hospitalized=row['JH Confirmed'],
        date_first_hospitalized=datetime.strptime(row['first_death_min_4'], '%Y-%m-%d').date(), # use the first day of death - 4
        #doubling_time=4.0,
        hospitalized=Disposition(0.025, 7),
        icu=Disposition(0.0075, 9),
        infectious_days=14, # 7, 14, 21
        market_share=1.0,
        n_days=200,
        mitigation_date=datetime.strptime(row['Order Date'], '%Y-%m-%d').date(), #date.today() was the origianl thing here., 
        relative_contact_rate=0.3, #.1-.6
        ventilated=Disposition(0.005, 10),
    )
    objs.append(SimSirModel(rowParams))
    extra.append(row)
    ps.append(rowParams)
    print(row['County'])

for i in range(0,len(objs)):
        newdf = objs[i].census_floor_df
        newdf['County Name'] = extra[i]['County']
        newdf['State'] = extra[i]['State']
        newdf['FIPS'] = extra[i]['FIPS']
        newdf['infectionRate'] = objs[i].beta
        newdf['recoveryRate'] = objs[i].gamma
        newdf['R0'] = objs[i].r_naught
        newdf['simName'] = 'Simulation 1: days a person is infectious = 14'
        loopFin = newdf.merge(objs[i].sim_sir_w_date_floor_df, left_on='date', right_on='date')
        modelOutput = modelOutput.append(loopFin, True)