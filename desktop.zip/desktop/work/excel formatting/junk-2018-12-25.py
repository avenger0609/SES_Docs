

y_non_citrix_data=list()
y_non_citrix_sui=list()
y_citrix_data=list()
y_citrix_sui=list()
y_server_related_data=list()
y_server_related_sui=list()
y_ContactCenter_data=list()
y_ContactCenter_sui=list()
y_Telephone_data=list()
y_Telephone_sui=list()
tcs_service_cd_indx=0
tcs_segment_indx=2
sui_indx=3
service_cd_indx=9
segment_indx=2

y=list()

cdf = pd.read_excel(prev_csfilename, sheet_name="NonCitrix", header=None)
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(y_non_citrix_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            y_non_citrix_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    y_non_citrix_data.append(s1)
    y.append(s1)
    s1 = ""
cdf = pd.read_excel(prev_csfilename, sheet_name="Citrix")
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(y_citrix_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            y_citrix_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    y_citrix_data.append(s1)
    y.append(s1)
    s1 = ""
cdf = pd.read_excel(prev_csfilename, sheet_name="Server Related")
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(y_server_related_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            y_server_related_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    y_server_related_data.append(s1)
    y.append(s1)
    s1 = ""
# ns file name
cdf = pd.read_excel(prev_nsfilename, sheet_name="_ContactCenter")
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(y_ContactCenter_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            y_ContactCenter_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    y_ContactCenter_data.append(s1)
    y.append(s1)
    s1 = ""

cdf = pd.read_excel(prev_nsfilename, sheet_name="_Telephone")
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(y_Telephone_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            y_Telephone_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    y_Telephone_data.append(s1)
    y.append(s1)
    s1 = ""
# ns file name

print(str((datetime.datetime.now())))
wb_name=prev_mergedfilename
wb = openpyxl.Workbook()
sheet = wb.active
sheet.title="Merged"

for i in range(0,len(y)):
    s = y[i].split('!')
    for j in range(0,len(s)):
        c1 = sheet.cell(row=i+1, column=j+1)
        c1.value=s[j].replace('nan','')
wb.save(wb_name)
wb.close()

print(str((datetime.datetime.now())))
print("completed merging of previous month")