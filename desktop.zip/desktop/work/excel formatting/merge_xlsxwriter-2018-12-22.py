import xlsxwriter

#swing analysis

# Create an new Excel file and add a worksheet.
workbook = xlsxwriter.Workbook('swing_application.xlsx')

worksheet = workbook.add_worksheet()

#swing details
merge_format = workbook.add_format({
    'bold': 10,
    'top':2,
    'bottom':2,
    'right':2,
    'left':2,
    'border': 2,
    'align': 'center',
    'valign': 'vcenter',
    'font_color': 'orange',
    'font_size':24,
    'bg_color':'#A2D0D0'})
worksheet.merge_range('A1:H2', 'Swing Details', merge_format)
#swing details
#service name
merge_format = workbook.add_format({
    'bold': 4,
    'top':1,
    'bottom':1,
    'right':1,
    'left':1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'font_color': 'black',
    'font_size':14,
    'bg_color':'#FFB5DA'})
worksheet.set_column('A:B', 12)

worksheet.set_row(2, 20)
worksheet.set_row(3, 60)
worksheet.merge_range('A3:B4', 'Service name', merge_format)
#service name
#segment
merge_format = workbook.add_format({
    'bold': 4,
    'top':1,
    'bottom':1,
    'right':1,
    'left':1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'font_color': 'black',
    'font_size':14,
    'bg_color':'#FFFF80'})
worksheet.set_column('C:D', 12)
worksheet.set_row(3, 20)
worksheet.set_row(4, 60)
worksheet.merge_range('C3:D4', 'Segment', merge_format)
#segment
#$ Chg from Last Month
merge_format = workbook.add_format({
    'bold': 4,
    'top':1,
    'bottom':1,
    'right':1,
    'left':1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'font_color': 'black',
    'font_size':14,
    'bg_color':'#80FFFF'})
worksheet.set_column('E:F', 12)
worksheet.set_row(2, 20)
worksheet.set_row(3, 60)
worksheet.merge_range('E3:F4', '$ Chg from Last Month', merge_format)
#$ Chg from Last Month
#% Chg from Last Month
merge_format = workbook.add_format({
    'bold': 4,
    'top':1,
    'bottom':1,
    'right':1,
    'left':1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'font_color': 'black',
    'font_size':14,
    'bg_color':'#AAAAFF'})
worksheet.set_column('G:H', 12)
worksheet.set_row(2, 20)
worksheet.set_row(3, 60)
worksheet.merge_range('G3:H4', '% Chg from Last Month', merge_format)
#% Chg from Last Month
#SYBASE - Legacy Service
merge_format = workbook.add_format({
    'bold': 4,
    'top':1,
    'bottom':1,
    'right':1,
    'left':1,
    'border': 1,
    'align': 'center',
    'valign': 'vcenter',
    'font_color': 'black',
    'font_size':14,
    'bg_color':'#FFFFFF'})
worksheet.set_column('A:B', 12)
worksheet.set_row(4, 20)
worksheet.set_row(5, 60)
#worksheet.merge_range('A4:B5', 'SYBASE - Legacy Service', merge_format)
worksheet.merge_range('G4:H5', '% Chg from Last Month', merge_format)
#SYBASE - Legacy Service
workbook.close()