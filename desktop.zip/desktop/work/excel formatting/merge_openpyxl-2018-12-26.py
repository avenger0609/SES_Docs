import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell

op_svc_name = "op_svc_name"
op_seg_name = "op_seg_name"
op_chng_frm_last = "op_chng_frm_last"
op_chng_frm_last_per = "op_chng_frm_last_per"
op_prev_sui_cnt = "op_prev_sui_cnt"
op_cur_sui_cnt = "op_cur_sui_cnt"
op_mom_variance = "op_mom_variance"
op_mom_inc_r_dec = "op_mom_inc_r_dec"
op_summary = "op_summary"
op_sui_added = "op_sui_added"
op_units_added = "op_units_added"
op_cost_added = "op_cost_added"
op_sui_deleted = "op_sui_deleted"
op_units_deleted = "op_units_deleted"
op_cost_deleted = "op_cost_deleted"
op_adj_sui_inc = "op_adj_sui_inc"
op_adj_units_inc = "op_adj_units_inc"
op_adj_cost_inc = "op_adj_cost_inc"
op_adj_sui_dec = "op_adj_sui_dec"
op_adj_units_dec = "op_adj_units_dec"
op_adj_cost_dec = "op_adj_cost_dec"
op_sui_inc = "op_sui_inc"
op_units_inc = "op_units_inc"
op_cost_inc = "op_cost_inc"
op_sui_dec = "op_sui_dec"
op_units_dec = "op_units_dec"
op_cost_dec = "op_cost_dec"
op_final_cnt = "op_final_cnt"
op_rounded_value = "op_rounded_value"
wb = openpyxl.Workbook()
wb.create_sheet('Sheet 2')
sheet=wb.get_sheet_by_name('Sheet 2')
sheet.title="experiment"
#Swing details
# sheet.merge_cells('A1:H2')
# cell = sheet.cell(row=1, column=1)
# cell.value = 'Sunny day'
# cell.alignment = Alignment(horizontal='center', vertical='center')
# cell = sheet.cell(row=1, column=1)
# cell.border=Border(left=Side(style='double'),right=Side(style='double'),top=Side(style='double'), bottom=Side(style='double'))
# cell = sheet.cell(row=2, column=2)
# cell.border=Border(left=Side(style='double'),right=Side(style='double'),top=Side(style='double'), bottom=Side(style='double'))
sheet.merge_cells(start_row=1,start_column=1,end_row=2,end_column=8)
cell=sheet.cell(row=1,column=1)
cell.value='Swing Details'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(1,3):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFA2D0D0',
                   end_color='FFA2D0D0',
                   fill_type='solid')
sheet['A1'].fill = redFill
for i in range(1,3):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24, color='ffD55500', bold=True)
#Swing details
##service name
sheet.merge_cells(start_row=3,start_column=1,end_row=4,end_column=2)
cell=sheet.cell(row=3,column=1)
cell.value='service name'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(3,5):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFB5DA',
                   end_color='FFFFB5DA',
                   fill_type='solid')
sheet['A3'].fill = redFill
for i in range(3,5):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[3].height = float(20)
sheet.row_dimensions[4].height = float(60)
##service name
##segment
sheet.merge_cells(start_row=3,start_column=3,end_row=4,end_column=4)
cell=sheet.cell(row=3,column=3)
cell.value='segment'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(3,5):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFF80',
                   end_color='FFFFFF80',
                   fill_type='solid')
sheet['C3'].fill = redFill
for i in range(3,5):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[3].height = float(20)
sheet.row_dimensions[4].height = float(60)
##segment
##$ Chg from Last Month
sheet.merge_cells(start_row=3,start_column=5,end_row=4,end_column=6)
cell=sheet.cell(row=3,column=5)
cell.value='$ Chg from Last Month'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(3,5):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF80FFFF',
                   end_color='FF80FFFF',
                   fill_type='solid')
sheet['E3'].fill = redFill
for i in range(3,5):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[3].height = float(20)
sheet.row_dimensions[4].height = float(60)
##$ Chg from Last Month
#% Chg from Last Month
sheet.merge_cells(start_row=3,start_column=7,end_row=4,end_column=8)
cell=sheet.cell(row=3,column=7)
cell.value='% Chg from Last Month'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(3,5):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFAAAAFF',
                   end_color='FFAAAAFF',
                   fill_type='solid')
sheet['G3'].fill = redFill
for i in range(3,5):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[3].height = float(20)
sheet.row_dimensions[4].height = float(60)
#% Chg from Last Month
##SYBASE - Legacy Service
sheet.merge_cells(start_row=5,start_column=1,end_row=6,end_column=2)
cell=sheet.cell(row=5,column=1)
cell.value=op_svc_name  #### needs to be edited
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(5,7):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFD3D3D3',
                   end_color='FFD3D3D3',
                   fill_type='solid')
sheet['A5'].fill = redFill
for i in range(5,7):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[5].height = float(20)
sheet.row_dimensions[6].height = float(60)
##SYBASE - Legacy Service
##Segment name-- OH as we are dealing with this
sheet.merge_cells(start_row=5,start_column=3,end_row=6,end_column=4)
cell=sheet.cell(row=5,column=3)
cell.value=op_seg_name####### to be changed with segment name we are dealing
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(5,7):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFD3D3D3',
                   end_color='FFD3D3D3',
                   fill_type='solid')
sheet['C5'].fill = redFill
for i in range(5,7):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[5].height = float(20)
sheet.row_dimensions[6].height = float(60)
##Segment name-- OH as we are dealing with this
##$ Chg from Last Month--- -413736.4 --- as we are dealing with this particular sheet and needs to be changed
sheet.merge_cells(start_row=5,start_column=5,end_row=6,end_column=6)
cell=sheet.cell(row=5,column=5)
cell.value=op_chng_frm_last####### needs to be changed as per derived amount variance in summary
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(5,7):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFD3D3D3',
                   end_color='FFD3D3D3',
                   fill_type='solid')
sheet['E5'].fill = redFill
for i in range(5,7):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[5].height = float(20)
sheet.row_dimensions[6].height = float(60)
##$ Chg from Last Month--- -413736.4 --- as we are dealing with this particular sheet and needs to be changed
#% Chg from Last Month--- -116.29 --- as we are dealing with this particular sheet and needs to be changed rounded to 2 decimls
sheet.merge_cells(start_row=5,start_column=7,end_row=6,end_column=8)
cell=sheet.cell(row=5,column=7)
cell.value=op_chng_frm_last_per####needs to be changed rounded to 2 decimls from summary
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(5,7):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFD3D3D3',
                   end_color='FFD3D3D3',
                   fill_type='solid')
sheet['G5'].fill = redFill
for i in range(5,7):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        #sheet.column_dimensions[j].width = float(20)-- column width adjustment

        cell.font = Font(name='Calibri', size=14,color='ff000000')
sheet.row_dimensions[5].height = float(20)
sheet.row_dimensions[6].height = float(60)
#% Chg from Last Month--- -116.29 --- as we are dealing with this particular sheet and needs to be changed rounded to 2 decimls

#blank line insertion
sheet.merge_cells(start_row=7,start_column=1,end_row=7,end_column=8)
cell=sheet.cell(row=7,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(7,8):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFA9A9A9',
                   end_color='FFA9A9A9',
                   fill_type='solid')
sheet['A7'].fill = redFill
sheet.row_dimensions[7].height = float(50)
#blank line insertion
#SUI Analysis
sheet.row_dimensions[8].height = float(50)
sheet.row_dimensions[9].height = float(50)
sheet.merge_cells(start_row=8,start_column=1,end_row=9,end_column=8)
cell=sheet.cell(row=8,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="SUI Analysis"
for i in range(8,10):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFA2D0D0',
                   end_color='FFA2D0D0',
                   fill_type='solid')
sheet['A8'].fill = redFill
for i in range(8,10):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24,color='ffD55500',bold=True)

#SUI Analysis
#SUI Count
sheet.row_dimensions[10].height = float(20)
sheet.merge_cells(start_row=10,start_column=1,end_row=10,end_column=4)
cell=sheet.cell(row=10,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="SUI Count"
for i in range(10,11):
    for j in range(1,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFFF8C8C',
                   end_color='FFFF8C8C',
                   fill_type='solid')
sheet['A10'].fill = redFill
for i in range(10,11):
    for j in range(1,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=16,color='ff6700CE',bold=True)
#SUI Count
#Previous Month
sheet.row_dimensions[11].height = float(20)
sheet.merge_cells(start_row=11,start_column=1,end_row=11,end_column=2)
cell=sheet.cell(row=11,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Previous Month"
for i in range(11,12):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FF22B14C',
                   end_color='FF22B14C',
                   fill_type='solid')
sheet['A11'].fill = redFill
for i in range(11,12):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ffffffff',bold=True)
#Previous Month
#Current Month
sheet.row_dimensions[11].height = float(20)
sheet.merge_cells(start_row=11,start_column=3,end_row=11,end_column=4)
cell=sheet.cell(row=11,column=3)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Current Month"
for i in range(11,12):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FF934900',end_color='FF934900',fill_type='solid')
sheet['C11'].fill = redFill
for i in range(11,12):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ffffffff',bold=True)
#Current Month
#MOM variance
sheet.row_dimensions[11].height = float(20)
sheet.row_dimensions[10].height = float(20)
sheet.merge_cells(start_row=10,start_column=5,end_row=11,end_column=6)
cell=sheet.cell(row=10,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="MOM Variance"
for i in range(10,12):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FF0000BB',end_color='FF0000BB',fill_type='solid')
sheet['E10'].fill = redFill
for i in range(10,12):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ffffffff',bold=True)
#MOM variance
#Increase/Decrease
sheet.row_dimensions[11].height = float(20)
sheet.row_dimensions[10].height = float(20)
sheet.merge_cells(start_row=10,start_column=7,end_row=11,end_column=8)
cell=sheet.cell(row=10,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Increase / Decrease"
for i in range(10,12):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFD3D3D3',end_color='FFD3D3D3',fill_type='solid')
sheet['G10'].fill = redFill
for i in range(10,12):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ffffffff',bold=True)
#Increase/Decrease
#previouse month SUI count-- needs to be changed --- populated to 384.00 for now
sheet.row_dimensions[12].height = float(20)
sheet.row_dimensions[13].height = float(20)
sheet.merge_cells(start_row=12,start_column=1,end_row=13,end_column=2)
cell=sheet.cell(row=12,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_prev_sui_cnt   #### needs to be changed
for i in range(12,14):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',end_color='FFFFFFFF',fill_type='solid')
sheet['A12'].fill = redFill
for i in range(12,14):
    for j in range(1,3):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ff000000',bold=True)
#previouse month SUI count-- needs to be changed --- populated to 384.00 for now
#Current month SUI count-- needs to be changed --- populated to 390.00 for now
sheet.row_dimensions[12].height = float(20)
sheet.row_dimensions[13].height = float(20)
sheet.merge_cells(start_row=12,start_column=3,end_row=13,end_column=4)
cell=sheet.cell(row=12,column=3)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_cur_sui_cnt  #### needs to be changed
for i in range(12,14):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',end_color='FFFFFFFF',fill_type='solid')
sheet['C12'].fill = redFill
for i in range(12,14):
    for j in range(3,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ff000000',bold=True)
#current month SUI count-- needs to be changed --- populated to 390.00 for now
#MOM Variance-- needs to be changed --- populated to 6.00 for now
sheet.row_dimensions[12].height = float(20)
sheet.row_dimensions[13].height = float(20)
sheet.merge_cells(start_row=12,start_column=5,end_row=13,end_column=6)
cell=sheet.cell(row=12,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_mom_variance  #### needs to be changed
for i in range(12,14):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',end_color='FFFFFFFF',fill_type='solid')
sheet['E12'].fill = redFill
for i in range(12,14):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ff000000',bold=True)
#MOM Variance-- needs to be changed --- populated to 6.00 for now
#Increase/Decrease Variance-- needs to be changed --- populated to Increase for now
sheet.row_dimensions[12].height = float(20)
sheet.row_dimensions[13].height = float(20)
sheet.merge_cells(start_row=12,start_column=7,end_row=13,end_column=8)
cell=sheet.cell(row=12,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_mom_inc_r_dec  #### needs to be changed
for i in range(12,14):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',end_color='FFFFFFFF',fill_type='solid')
sheet['G12'].fill = redFill
for i in range(12,14):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14,color='ff000000',bold=True)
#Increase/Decrease Variance-- needs to be changed --- populated to Increase for now
#6 SUI's Variance(Increase) was observed in Nov month compared to Oct month.--need to be changed
sheet.merge_cells(start_row=14,start_column=1,end_row=16,end_column=8)
cell=sheet.cell(row=14,column=1)
cell.value=op_summary####.--need to be changed
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(14,17):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A14'].fill = redFill
for i in range(14,17):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=12, color='ff000000', bold=False)

#6 SUI's Variance(Increase) was observed in Nov month compared to Oct month.-- need to be changed
#blank line insertion
sheet.merge_cells(start_row=17,start_column=1,end_row=17,end_column=8)
cell=sheet.cell(row=17,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(17,18):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFA9A9A9',
                   end_color='FFA9A9A9',
                   fill_type='solid')
sheet['A17'].fill = redFill
sheet.row_dimensions[17].height = float(20)
#blank line insertion
#Variance Summary
sheet.merge_cells(start_row=18,start_column=1,end_row=19,end_column=8)
cell=sheet.cell(row=18,column=1)
cell.value='Variance Summary'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(18,20):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFA2D0D0',
                   end_color='FFA2D0D0',
                   fill_type='solid')
sheet['A18'].fill = redFill
for i in range(18,20):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24, color='ffD55500', bold=True)
#Variance Summary
#Summary
sheet.row_dimensions[20].height = float(50)
sheet.row_dimensions[21].height = float(50)
sheet.merge_cells(start_row=20,start_column=1,end_row=21,end_column=4)
cell=sheet.cell(row=20,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Summary"
for i in range(20,22):
    for j in range(1,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['A20'].fill = redFill
for i in range(20,22):
    for j in range(1,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=16,color='ff000000',bold=True)
#Summary
#Units
sheet.row_dimensions[20].height = float(50)
sheet.row_dimensions[21].height = float(50)
sheet.merge_cells(start_row=20,start_column=5,end_row=21,end_column=6)
cell=sheet.cell(row=20,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Units"
for i in range(20,22):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['E20'].fill = redFill
for i in range(20,22):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=16,color='ff000000',bold=True)
#Units
#$ Value
sheet.row_dimensions[20].height = float(50)
sheet.row_dimensions[21].height = float(50)
sheet.merge_cells(start_row=20,start_column=7,end_row=21,end_column=8)
cell=sheet.cell(row=20,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="$ Value"
for i in range(20,22):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['G20'].fill = redFill
for i in range(20,22):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=16,color='ff000000',bold=True)
#$ Value
#Total units added from New SUI's
sheet.merge_cells(start_row=22,start_column=1,end_row=22,end_column=3)
cell=sheet.cell(row=22,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Total units added from New SUI's"
for i in range(22,23):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A22'].fill = redFill
for i in range(22,23):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total units added from New SUI's
#Total units removed from SUI's
sheet.merge_cells(start_row=23,start_column=1,end_row=23,end_column=3)
cell=sheet.cell(row=23,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Total units removed from SUI's"
for i in range(23,24):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A23'].fill = redFill
for i in range(23,24):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total units removed from SUI's
#Total Adjusted Units (Increase)
sheet.merge_cells(start_row=24,start_column=1,end_row=24,end_column=3)
cell=sheet.cell(row=24,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Total Adjusted Units (Increase)"
for i in range(24,25):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A24'].fill = redFill
for i in range(24,25):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Increase)
#Total Adjusted Units (Decrease)
sheet.merge_cells(start_row=25,start_column=1,end_row=25,end_column=3)
cell=sheet.cell(row=25,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Total Adjusted Units (Decrease)"
for i in range(25,26):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A25'].fill = redFill
for i in range(25,26):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Decrease)
#Total Units Increased
sheet.merge_cells(start_row=26,start_column=1,end_row=26,end_column=3)
cell=sheet.cell(row=26,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Total Units Increased"
for i in range(26,27):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A26'].fill = redFill
for i in range(26,27):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Units Increased
#Total Units Decreased
sheet.merge_cells(start_row=27,start_column=1,end_row=27,end_column=3)
cell=sheet.cell(row=27,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Total Units Decreased"
for i in range(27,28):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A27'].fill = redFill
for i in range(27,28):
    for j in range(1,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Units Decreased
#Total units added from New SUI's-- value needs to be replaced-- 6 for now
sheet.merge_cells(start_row=22,start_column=4,end_row=22,end_column=4)
cell=sheet.cell(row=22,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_sui_added ######## needs to be cahnged
for i in range(22,23):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['D22'].fill = redFill
for i in range(22,23):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total units added from New SUI's-- value needs to be replaced-- 6 for now
#Total units removed from SUI's-- value needs to be replaced-- "-" for now
sheet.merge_cells(start_row=23,start_column=4,end_row=23,end_column=4)
cell=sheet.cell(row=23,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_sui_deleted # needs to be changed
for i in range(23,24):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['D23'].fill = redFill
for i in range(23,24):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total units removed from SUI's-- value needs to be replaced-- "-" for now
#Total Adjusted Units (Increase)-- value needs to be replaced-- 6 for now
sheet.merge_cells(start_row=24,start_column=4,end_row=24,end_column=4)
cell=sheet.cell(row=24,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_adj_sui_inc ### needs to be changed
for i in range(24,25):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['D24'].fill = redFill
for i in range(24,25):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Increase)-- value needs to be replaced-- 6 for now
#Total Adjusted Units (Decrease)-- value needs to be replaced-- "-" for now
sheet.merge_cells(start_row=25,start_column=4,end_row=25,end_column=4)
cell=sheet.cell(row=25,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_adj_sui_dec
for i in range(25,26):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['D25'].fill = redFill
for i in range(25,26):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Decrease)-- value needs to be replaced-- "-" for now
#Total Units Increased-- value needs to be replaced-- 12 for now
sheet.merge_cells(start_row=26,start_column=4,end_row=26,end_column=4)
cell=sheet.cell(row=26,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_sui_inc ##### needs to be changed
for i in range(26,27):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB5B5FF',
                   end_color='FFB5B5FF',
                   fill_type='solid')
sheet['D26'].fill = redFill
for i in range(26,27):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Units Increased-- value needs to be replaced-- 12 for now
#Total Units Decreased-- value needs to be replaced-- 0 for now
sheet.merge_cells(start_row=27,start_column=4,end_row=27,end_column=4)
cell=sheet.cell(row=27,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_sui_dec ### needs to be changed
for i in range(27,28):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB5B5FF',
                   end_color='FFB5B5FF',
                   fill_type='solid')
sheet['D27'].fill = redFill
for i in range(27,28):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Units Decreased-- value needs to be replaced-- 0 for now
#Total units added from New SUI's( under units column)-- value needs to be replaced-- "-8988' for now
sheet.merge_cells(start_row=22,start_column=5,end_row=22,end_column=6)
cell=sheet.cell(row=22,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_units_added ######## needs to be cahnged
for i in range(22,23):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['E22'].fill = redFill
for i in range(22,23):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ffff0000')
#Total units added from New SUI's( under units column)-- value needs to be replaced-- "-8988' for now
#Total units removed from SUI's( under units column)-- value needs to be replaced-- "-" for now
sheet.merge_cells(start_row=23,start_column=5,end_row=23,end_column=6)
cell=sheet.cell(row=23,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_units_deleted # needs to be changed
for i in range(23,24):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['E23'].fill = redFill
for i in range(23,24):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total units removed from SUI's( under units column)-- value needs to be replaced-- "-" for now
#Total Adjusted Units (Increase)( under units column)-- value needs to be replaced-- "6" for now
sheet.merge_cells(start_row=24,start_column=5,end_row=24,end_column=6)
cell=sheet.cell(row=24,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_adj_units_inc ### needs to be changed
for i in range(24,25):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['E24'].fill = redFill
for i in range(24,25):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Increase)( under units column)-- value needs to be replaced-- "6" for now
#Total Adjusted Units (Decrease)( under units column)-- value needs to be replaced-- "-" for now
sheet.merge_cells(start_row=25,start_column=5,end_row=25,end_column=6)
cell=sheet.cell(row=25,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_adj_units_dec
for i in range(25,26):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['E25'].fill = redFill
for i in range(25,26):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Decrease)( under units column)-- value needs to be replaced-- "-" for now
#Total Units Increased( under units column)-- value needs to be replaced-- "-8888" for now
sheet.merge_cells(start_row=26,start_column=5,end_row=26,end_column=6)
cell=sheet.cell(row=26,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_units_inc ##### needs to be changed
for i in range(26,27):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB5B5FF',
                   end_color='FFB5B5FF',
                   fill_type='solid')
sheet['E26'].fill = redFill
for i in range(26,27):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ffff0000')
#Total Units Increased( under units column)-- value needs to be replaced-- "-8888" for now
#Total Units Decreased( under units column)-- value needs to be replaced-- "0.00" for now
sheet.merge_cells(start_row=27,start_column=5,end_row=27,end_column=6)
cell=sheet.cell(row=27,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_units_dec  ### needs to be changed
for i in range(27,28):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB5B5FF',
                   end_color='FFB5B5FF',
                   fill_type='solid')
sheet['E27'].fill = redFill
for i in range(27,28):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Units Decreased( under units column)-- value needs to be replaced-- "0.00" for now
#Total units added from New SUI's( under $ value column)-- value needs to be replaced-- "-418391.4' for now
sheet.merge_cells(start_row=22,start_column=7,end_row=22,end_column=8)
cell=sheet.cell(row=22,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_cost_added ######## needs to be cahnged
for i in range(22,23):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['G22'].fill = redFill
for i in range(22,23):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ffff0000')
#Total units added from New SUI's( under $ value column)-- value needs to be replaced-- "-418391.4' for now
#Total units removed from SUI's( under $ value column)-- value needs to be replaced-- "-" for now
sheet.merge_cells(start_row=23,start_column=7,end_row=23,end_column=8)
cell=sheet.cell(row=23,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_cost_deleted # needs to be changed
for i in range(23,24):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['G23'].fill = redFill
for i in range(23,24):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total units removed from SUI's( under $ value column)-- value needs to be replaced-- "-" for now
#Total Adjusted Units (Increase)( under $ value column)-- value needs to be replaced-- "4655" for now
sheet.merge_cells(start_row=24,start_column=7,end_row=24,end_column=8)
cell=sheet.cell(row=24,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_adj_cost_inc ### needs to be changed
for i in range(24,25):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['G24'].fill = redFill
for i in range(24,25):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Increase)( under $ Value column)-- value needs to be replaced-- "6" for now
#Total Adjusted Units (Decrease)( under $ Value column)-- value needs to be replaced-- "-" for now
sheet.merge_cells(start_row=25,start_column=7,end_row=25,end_column=8)
cell=sheet.cell(row=25,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_adj_cost_dec
for i in range(25,26):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['G25'].fill = redFill
for i in range(25,26):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Adjusted Units (Decrease)( under $ Value column)-- value needs to be replaced-- "-" for now
#Total Units Increased( under $ Value column)-- value needs to be replaced-- "-413736.4" for now
sheet.merge_cells(start_row=26,start_column=7,end_row=26,end_column=8)
cell=sheet.cell(row=26,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_cost_inc ##### needs to be changed
for i in range(26,27):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB5B5FF',
                   end_color='FFB5B5FF',
                   fill_type='solid')
sheet['G26'].fill = redFill
for i in range(26,27):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ffff0000')
#Total Units Increased( under $ Value column)-- value needs to be replaced-- "-413736.4" for now
#Total Units Decreased( under $ Value column)-- value needs to be replaced-- "0.00" for now
sheet.merge_cells(start_row=27,start_column=7,end_row=27,end_column=8)
cell=sheet.cell(row=27,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value=op_cost_dec  ### needs to be changed
for i in range(27,28):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB5B5FF',
                   end_color='FFB5B5FF',
                   fill_type='solid')
sheet['G27'].fill = redFill
for i in range(27,28):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=10,color='ff000000')
#Total Units Decreased( under $ Value column)-- value needs to be replaced-- "0.00" for now
#Final Count
sheet.merge_cells(start_row=28,start_column=1,end_row=28,end_column=4)
cell=sheet.cell(row=28,column=1)
cell.value='Final Count'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(28,29):
    for j in range(1,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF79B5FF',
                   end_color='FF79B5FF',
                   fill_type='solid')
sheet['A28'].fill = redFill
for i in range(28,29):
    for j in range(1,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=11, color='ff000000', bold=True)
sheet.row_dimensions[28].height = float(30)
#Final Count
#Final Count(under units)
sheet.merge_cells(start_row=28,start_column=5,end_row=28,end_column=6)
cell=sheet.cell(row=28,column=5)
cell.value=''
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(28,29):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['E28'].fill = redFill
for i in range(28,29):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=11, color='ff000000', bold=True)
sheet.row_dimensions[28].height = float(30)
#Final Count(under units)
#Final Count(under $ Value)-- "-413736.40" for now
sheet.merge_cells(start_row=28,start_column=7,end_row=28,end_column=8)
cell=sheet.cell(row=28,column=7)
cell.value=op_final_cnt ### needs to be changed
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(28,29):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['G28'].fill = redFill
for i in range(28,29):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=11, color='ffff0000', bold=False)
sheet.row_dimensions[28].height = float(30)
#Final Count(under $ Value)-- "-413736.40" for now
#Rounded Off Value
sheet.merge_cells(start_row=29,start_column=1,end_row=30,end_column=6)
cell=sheet.cell(row=29,column=1)
cell.value='Rounded Off Value'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(29,31):
    for j in range(1,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFFFFF',
                   end_color='FFFFFFFF',
                   fill_type='solid')
sheet['A29'].fill = redFill
for i in range(29,31):
    for j in range(1,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)

#Rounded Off Value
#Rounded Off Value under $ Value
sheet.merge_cells(start_row=29,start_column=7,end_row=30,end_column=8)
cell=sheet.cell(row=29,column=7)
cell.value=op_rounded_value### needs to be changed
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(29,31):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFF0000',
                   end_color='FFFF0000',
                   fill_type='solid')
sheet['G29'].fill = redFill
for i in range(29,31):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=18, color='ff000000', bold=True)
#Rounded Off Value under $ Value
#blank line insertion
sheet.merge_cells(start_row=31,start_column=1,end_row=31,end_column=8)
cell=sheet.cell(row=31,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(31,32):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFA9A9A9',
                   end_color='FFA9A9A9',
                   fill_type='solid')
sheet['A31'].fill = redFill
sheet.row_dimensions[31].height = float(20)
#blank line insertion
#Application Variance
sheet.merge_cells(start_row=32,start_column=1,end_row=33,end_column=8)
cell=sheet.cell(row=32,column=1)
cell.value='Application Variance'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(32,34):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFA2D0D0',
                   end_color='FFA2D0D0',
                   fill_type='solid')
sheet['A32'].fill = redFill
for i in range(32,34):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24, color='ffD55500', bold=True)
#Application Variance
#application variance heading-- TMDB Code
sheet.merge_cells(start_row=34,start_column=1,end_row=35,end_column=1)
cell=sheet.cell(row=34,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="TMDB Code"
for i in range(34,36):
    for j in range(1,2):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['A34'].fill = redFill
sheet.row_dimensions[34].height = float(30)
sheet.row_dimensions[35].height = float(20)
for i in range(34,36):
    for j in range(1,2):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#application variance heading-- TMDB Code
#application variance heading-- Application
sheet.merge_cells(start_row=34,start_column=2,end_row=35,end_column=3)
cell=sheet.cell(row=34,column=2)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Application"
for i in range(34,36):
    for j in range(2,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['B34'].fill = redFill
sheet.row_dimensions[34].height = float(30)
sheet.row_dimensions[35].height = float(20)
for i in range(34,36):
    for j in range(2,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#application variance heading-- Application
#application variance heading-- SUI's
sheet.merge_cells(start_row=34,start_column=4,end_row=35,end_column=4)
cell=sheet.cell(row=34,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="SUI's"
for i in range(34,36):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['D34'].fill = redFill
sheet.row_dimensions[34].height = float(30)
sheet.row_dimensions[35].height = float(20)
for i in range(34,36):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#application variance heading-- SUI's
#application variance heading-- Units
sheet.merge_cells(start_row=34,start_column=5,end_row=35,end_column=6)
cell=sheet.cell(row=34,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Units"
for i in range(34,36):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['E34'].fill = redFill
sheet.row_dimensions[34].height = float(30)
sheet.row_dimensions[35].height = float(20)
for i in range(34,36):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#application variance heading-- Units
#application variance heading-- $ Value
sheet.merge_cells(start_row=34,start_column=7,end_row=35,end_column=8)
cell=sheet.cell(row=34,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="$ Value"
for i in range(34,36):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet['G34'].fill = redFill
sheet.row_dimensions[34].height = float(30)
sheet.row_dimensions[35].height = float(20)
for i in range(34,36):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#application variance heading-- $ Value
app_var_data=list()
for i in range(0,5):
    s1=""
    for j in range(0,5):
        s1=s1+str(i)+str(j)+"!"
    print(s1)
    app_var_data.append(s1)
app_var_row_num=36
for i in range(0,len(app_var_data)):
    app_str=app_var_data[i].split('!')
    # application variance data-- TMDB Code
    sheet.merge_cells(start_row=app_var_row_num, start_column=1, end_row=app_var_row_num, end_column=1)
    cell = sheet.cell(row=app_var_row_num, column=1)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = app_str[0]
    for i in range(app_var_row_num,app_var_row_num+1):
        for j in range(1, 2):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    cell.fill = redFill

    for i in range(app_var_row_num, app_var_row_num+1):
        for j in range(1, 2):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance data-- TMDB Code
    # application variance data-- Application
    sheet.merge_cells(start_row=app_var_row_num, start_column=2, end_row=app_var_row_num, end_column=3)
    cell = sheet.cell(row=app_var_row_num, column=2)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = app_str[1]
    for i in range(app_var_row_num,app_var_row_num+1):
        for j in range(2, 4):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    cell.fill = redFill
    for i in range(app_var_row_num, app_var_row_num+1):
        for j in range(2, 4):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance data-- Application
    # application variance data-- SUI's
    sheet.merge_cells(start_row=app_var_row_num, start_column=4, end_row=app_var_row_num, end_column=4)
    cell = sheet.cell(row=app_var_row_num, column=4)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = app_str[2]
    for i in range(app_var_row_num, app_var_row_num+1):
        for j in range(4, 5):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    cell.fill = redFill
    for i in range(app_var_row_num,app_var_row_num+1):
        for j in range(4, 5):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance data-- SUI's
    # application variance data-- Units
    sheet.merge_cells(start_row=app_var_row_num, start_column=5, end_row=app_var_row_num, end_column=6)
    cell = sheet.cell(row=app_var_row_num, column=5)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = app_str[3]
    for i in range(app_var_row_num,app_var_row_num+1):
        for j in range(5, 7):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    cell.fill = redFill
    for i in range(app_var_row_num,app_var_row_num+1):
        for j in range(5, 7):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance data-- Units
    # application variance data-- $ Value
    sheet.merge_cells(start_row=app_var_row_num, start_column=7, end_row=app_var_row_num, end_column=8)
    cell = sheet.cell(row=app_var_row_num, column=7)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = app_str[4]
    for i in range(app_var_row_num,app_var_row_num+1):
        for j in range(7, 9):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFB4B467',
                          end_color='FFB4B467',
                          fill_type='solid')
    cell.fill = redFill
    for i in range(app_var_row_num, app_var_row_num+1):
        for j in range(7, 9):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance heading-- $ Value
    app_var_row_num=app_var_row_num+1
#blank line, project heading, project data
project_row=app_var_row_num
#blank line insertion
sheet.merge_cells(start_row=project_row,start_column=1,end_row=project_row,end_column=8)
cell=sheet.cell(row=project_row,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(project_row,project_row+1):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFA9A9A9',
                   end_color='FFA9A9A9',
                   fill_type='solid')
sheet.cell(project_row,1).fill = redFill

sheet.row_dimensions[project_row].height = float(20)
#blank line insertion
project_row=project_row+1
#Project Variance
sheet.merge_cells(start_row=project_row,start_column=1,end_row=project_row+1,end_column=8)
cell=sheet.cell(row=project_row,column=1)
cell.value='Project Variance'
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(project_row,project_row+2):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFA2D0D0',
                   end_color='FFA2D0D0',
                   fill_type='solid')
sheet.cell(project_row,column=1).fill = redFill
for i in range(project_row,project_row+2):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24, color='ffD55500', bold=True)
#Project Variance
project_row=project_row+2
#project variance heading-- project#
sheet.merge_cells(start_row=project_row,start_column=1,end_row=project_row+1,end_column=1)
cell=sheet.cell(row=project_row,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Project#"
for i in range(project_row,project_row+2):
    for j in range(1,2):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet.cell(project_row,1).fill = redFill
sheet.row_dimensions[project_row].height = float(30)
sheet.row_dimensions[project_row+1].height = float(20)
for i in range(project_row,project_row+2):
    for j in range(1,2):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#project variance heading-- project#
#project variance heading-- requestor
sheet.merge_cells(start_row=project_row,start_column=2,end_row=project_row+1,end_column=3)
cell=sheet.cell(row=project_row,column=2)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Requestor"
for i in range(project_row,project_row+2):
    for j in range(2,4):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet.cell(project_row,2).fill = redFill
sheet.row_dimensions[project_row].height = float(30)
sheet.row_dimensions[project_row+1].height = float(20)
for i in range(project_row,project_row+1):
    for j in range(2,4):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#project variance heading-- requestor
#project variance heading-- SUI's
sheet.merge_cells(start_row=project_row,start_column=4,end_row=project_row+1,end_column=4)
cell=sheet.cell(row=project_row,column=4)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="SUI's"
for i in range(project_row,project_row+2):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet.cell(project_row,4).fill = redFill
sheet.row_dimensions[project_row].height = float(30)
sheet.row_dimensions[project_row+1].height = float(20)
for i in range(project_row,project_row+2):
    for j in range(4,5):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#project variance heading-- SUI's

#project variance heading-- Units
sheet.merge_cells(start_row=project_row,start_column=5,end_row=project_row+1,end_column=6)
cell=sheet.cell(row=project_row,column=5)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Units"
for i in range(project_row,project_row+2):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet.cell(project_row,5).fill = redFill
sheet.row_dimensions[project_row].height = float(30)
sheet.row_dimensions[project_row+1].height = float(20)
for i in range(project_row,project_row+2):
    for j in range(5,7):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#project variance heading-- Units
#project variance heading-- $ Value
sheet.merge_cells(start_row=project_row,start_column=7,end_row=project_row+1,end_column=8)
cell=sheet.cell(row=project_row,column=7)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="$ Value"
for i in range(project_row,project_row+2):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFB4B467',
                   end_color='FFB4B467',
                   fill_type='solid')
sheet.cell(project_row,7).fill = redFill
sheet.row_dimensions[project_row].height = float(30)
sheet.row_dimensions[project_row+1].height = float(20)
for i in range(project_row,project_row+2):
    for j in range(7,9):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=14, color='ff000000', bold=True)
#project variance heading-- $ Value
prj_var_data=list()
for i in range(5,10):
    s1=""
    for j in range(0,5):
        s1=s1+str(i)+str(j)+"!"
    print(s1)
    prj_var_data.append(s1)
project_row=project_row+2
for i in range(0,len(prj_var_data)):
    prj_str=prj_var_data[i].split('!')
    # project variance data-- project#
    sheet.merge_cells(start_row=project_row, start_column=1, end_row=project_row, end_column=1)
    cell = sheet.cell(row=project_row, column=1)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = prj_str[0]
    for i in range(project_row,project_row+1):
        for j in range(1, 2):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    sheet.cell(project_row,1).fill = redFill

    for i in range(project_row, project_row+1):
        for j in range(1, 2):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # project variance data-- project#
    # project variance data-- requestor
    sheet.merge_cells(start_row=project_row, start_column=2, end_row=project_row, end_column=3)
    cell = sheet.cell(row=project_row, column=2)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = prj_str[1]
    for i in range(project_row,project_row+1):
        for j in range(2, 4):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    sheet.cell(project_row,2).fill = redFill
    for i in range(project_row, project_row+1):
        for j in range(2, 4):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance data-- Application
    # application variance data-- SUI's
    sheet.merge_cells(start_row=project_row, start_column=4, end_row=project_row, end_column=4)
    cell = sheet.cell(row=project_row, column=4)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = prj_str[2]
    for i in range(project_row, project_row+1):
        for j in range(4, 5):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    sheet.cell(project_row,4).fill = redFill
    for i in range(project_row,project_row+1):
        for j in range(4, 5):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # project variance data-- SUI's
    # project variance data-- Units
    sheet.merge_cells(start_row=project_row, start_column=5, end_row=project_row, end_column=6)
    cell = sheet.cell(row=project_row, column=5)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = prj_str[3]
    for i in range(project_row,project_row+1):
        for j in range(5, 7):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFFFFFFF',
                          end_color='FFFFFFFF',
                          fill_type='solid')
    sheet.cell(project_row,5).fill = redFill
    for i in range(project_row,project_row+1):
        for j in range(5, 7):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance data-- Units
    # application variance data-- $ Value
    sheet.merge_cells(start_row=project_row, start_column=7, end_row=project_row, end_column=8)
    cell = sheet.cell(row=project_row, column=7)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.value = prj_str[4]
    for i in range(project_row,project_row+1):
        for j in range(7, 9):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFB4B467',
                          end_color='FFB4B467',
                          fill_type='solid')
    cell.fill = redFill
    for i in range(project_row, project_row+1):
        for j in range(7, 9):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=14, color='ff000000', bold=False)
    # application variance heading-- $ Value
    project_row=project_row+1
#blank line insertion
sheet.merge_cells(start_row=project_row,start_column=1,end_row=project_row,end_column=8)
cell=sheet.cell(row=project_row,column=1)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(project_row,project_row+1):
    for j in range(1,9):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'),
                             bottom=Side(style='thick'))
redFill = PatternFill(start_color='FFA9A9A9',
                   end_color='FFA9A9A9',
                   fill_type='solid')
sheet.cell(project_row,1).fill = redFill

sheet.row_dimensions[project_row].height = float(20)
#blank line insertion
redFill = PatternFill(start_color='FFFF0000',
                   end_color='FFFF0000',
                   fill_type='solid')
###### add suis details
add_row=1
sheet.merge_cells(start_row=add_row,start_column=9,end_row=add_row+1,end_column=9)
cell=sheet.cell(row=add_row,column=9)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(add_row,add_row+2):
    for j in range(9,10):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF800000',
                   end_color='FF800000',
                   fill_type='solid')
sheet.cell(add_row,9).fill = redFill
sheet.column_dimensions['I'].width = float(2)
sheet.merge_cells(start_row=add_row,start_column=10,end_row=add_row+1,end_column=27)
cell=sheet.cell(row=add_row,column=10)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="SUI Additions"
for i in range(add_row,add_row+2):
    for j in range(10,28):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFFFB5DA',
                   end_color='FFFFB5DA',
                   fill_type='solid')
sheet.cell(add_row,10).fill = redFill
for i in range(add_row, add_row + 2):
    for j in range(10,28):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24, color='ff000000', bold=True)
add_row=add_row+2
add_row_header="Date of Charge Back!Service Group!Service Code!Service Code Description!Service Delivery Date!Service Unique Identifier!SUI Description!Service Physical!Service Virtual!TMDB Search Code!TMDB Application Name!Project #!Project Name!Project Requester!Segment!Unit Rate!Adjusted Service Units!Adjusted Service Cost"
add_row_header_str=add_row_header.split('!')
hi=0
for k in range(10,28):
    sheet.merge_cells(start_row=add_row, start_column=k, end_row=add_row, end_column=k)
    cell = sheet.cell(row=add_row, column=k)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    #print(str(hi))
    cell.value =add_row_header_str[hi]
    for i in range(add_row, add_row + 1):
        for j in range(k,k+1):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFB4B467',
                          end_color='FFB4B467',
                          fill_type='solid')
    sheet.cell(add_row,k).fill=redFill
    for i in range(add_row, add_row + 1):
        for j in range(k, k+1):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=8, color='ff000000', bold=True)
    hi=hi+1
sheet.merge_cells(start_row=add_row,start_column=9,end_row=add_row,end_column=9)
cell=sheet.cell(row=add_row,column=9)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(add_row,add_row+2):
    for j in range(9,10):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF800000',
                   end_color='FF800000',
                   fill_type='solid')
sheet.cell(add_row,9).fill = redFill
sheet.column_dimensions['I'].width = float(2)
add_row=add_row+1
# sui_add_data_lst=list()
# for i in range(0,5):
#     s1=""
#     for j in range(0,18):
#         s1=s1+"add"+str(i)+str(j)+"!"
#     print(s1)
#     sui_add_data_lst.append(s1)
# for m in range(0,len(sui_add_data_lst)):
#     add_row_header_str = sui_add_data_lst[m].split('!')
#     hi = 0
#     for k in range(10, 28):
#         sheet.merge_cells(start_row=add_row, start_column=k, end_row=add_row, end_column=k)
#         cell = sheet.cell(row=add_row, column=k)
#         cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
#         # print(str(hi))
#         cell.value = add_row_header_str[hi]
#         for i in range(add_row, add_row + 1):
#             for j in range(k, k + 1):
#                 cell = sheet.cell(row=i, column=j)
#                 cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
#                                      bottom=Side(style='thin'))
#         redFill = PatternFill(start_color='FFFFFFFF',
#                               end_color='FFFFFFFF',
#                               fill_type='solid')
#         sheet.cell(add_row, k).fill = redFill
#         for i in range(add_row, add_row + 1):
#             for j in range(k, k + 1):
#                 cell = sheet.cell(row=i, column=j)
#                 cell.font = Font(name='Calibri', size=8, color='ff000000', bold=True)
#         hi = hi + 1
#     sheet.merge_cells(start_row=add_row, start_column=9, end_row=add_row, end_column=9)
#     cell = sheet.cell(row=add_row, column=9)
#     cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
#     for i in range(add_row, add_row + 2):
#         for j in range(9, 10):
#             cell = sheet.cell(row=i, column=j)
#             cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
#                                  bottom=Side(style='thin'))
#     redFill = PatternFill(start_color='FF800000',
#                           end_color='FF800000',
#                           fill_type='solid')
#     sheet.cell(add_row, 9).fill = redFill
#     sheet.column_dimensions['I'].width = float(2)
#     add_row = add_row + 1
#

###### add suis details

###### del suis details
del_row=1
sheet.merge_cells(start_row=del_row,start_column=28,end_row=del_row+1,end_column=28)
cell=sheet.cell(row=del_row,column=28)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(del_row,del_row+2):
    for j in range(28,29):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF800000',
                   end_color='FF800000',
                   fill_type='solid')
sheet.cell(del_row,28).fill = redFill
sheet.column_dimensions['AB'].width = float(2)
sheet.merge_cells(start_row=del_row,start_column=29,end_row=del_row+1,end_column=46)
cell=sheet.cell(row=del_row,column=29)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="SUI Removals"
for i in range(del_row,del_row+2):
    for j in range(29,47):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF79B5FF',
                   end_color='FF79B5FF',
                   fill_type='solid')
sheet.cell(del_row,29).fill = redFill
for i in range(del_row, del_row + 2):
    for j in range(29,47):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24, color='ff000000', bold=True)
del_row=del_row+2
del_row_header="Date of Charge Back!Service Group!Service Code!Service Code Description!Service Delivery Date!Service Unique Identifier!SUI Description!Service Physical!Service Virtual!TMDB Search Code!TMDB Application Name!Project #!Project Name!Project Requester!Segment!Unit Rate!Adjusted Service Units!Adjusted Service Cost"
del_row_header_str=del_row_header.split('!')
hi=0
for k in range(29,47):
    sheet.merge_cells(start_row=del_row, start_column=k, end_row=del_row, end_column=k)
    cell = sheet.cell(row=del_row, column=k)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    #print(str(hi))
    cell.value =del_row_header_str[hi]
    for i in range(del_row, del_row + 1):
        for j in range(k,k+1):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFB4B467',
                          end_color='FFB4B467',
                          fill_type='solid')
    sheet.cell(del_row,k).fill=redFill
    for i in range(del_row, del_row + 1):
        for j in range(k, k+1):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=8, color='ff000000', bold=True)
    hi=hi+1
sheet.merge_cells(start_row=del_row,start_column=10,end_row=del_row,end_column=10)
cell=sheet.cell(row=del_row,column=10)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(del_row,del_row+2):
    for j in range(28,29):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF800000',
                   end_color='FF800000',
                   fill_type='solid')
sheet.cell(del_row,28).fill = redFill
sheet.column_dimensions['AB'].width = float(2)
del_row=del_row+1
# sui_del_data_lst=list()
# for i in range(0,5):
#     s1=""
#     for j in range(0,18):
#         s1=s1+"del"+str(i)+str(j)+"!"
#     print(s1)
#     sui_del_data_lst.append(s1)
# for m in range(0,len(sui_del_data_lst)):
#     del_row_header_str = sui_del_data_lst[m].split('!')
#     hi = 0
#     for k in range(29, 47):
#         sheet.merge_cells(start_row=del_row, start_column=k, end_row=del_row, end_column=k)
#         cell = sheet.cell(row=del_row, column=k)
#         cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
#         # print(str(hi))
#         cell.value = del_row_header_str[hi]
#         for i in range(del_row, del_row + 1):
#             for j in range(k, k + 1):
#                 cell = sheet.cell(row=i, column=j)
#                 cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
#                                      bottom=Side(style='thin'))
#         redFill = PatternFill(start_color='FFFFFFFF',
#                               end_color='FFFFFFFF',
#                               fill_type='solid')
#         sheet.cell(del_row, k).fill = redFill
#         for i in range(del_row, del_row + 1):
#             for j in range(k, k + 1):
#                 cell = sheet.cell(row=i, column=j)
#                 cell.font = Font(name='Calibri', size=8, color='ff000000', bold=True)
#         hi = hi + 1
#     sheet.merge_cells(start_row=del_row, start_column=28, end_row=del_row, end_column=28)
#     cell = sheet.cell(row=del_row, column=28)
#     cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
#     for i in range(del_row, del_row + 2):
#         for j in range(28, 29):
#             cell = sheet.cell(row=i, column=j)
#             cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
#                                  bottom=Side(style='thin'))
#     redFill = PatternFill(start_color='FF800000',
#                           end_color='FF800000',
#                           fill_type='solid')
#     sheet.cell(del_row,28).fill = redFill
#     sheet.column_dimensions['AB'].width = float(2)
#     del_row = del_row + 1


###### del suis details

###### adjustment suis details
adj_row=1
sheet.merge_cells(start_row=adj_row,start_column=47,end_row=adj_row+1,end_column=47)
cell=sheet.cell(row=adj_row,column=47)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(adj_row,adj_row+2):
    for j in range(47,48):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF800000',
                   end_color='FF800000',
                   fill_type='solid')
sheet.cell(adj_row,47).fill = redFill
sheet.column_dimensions['AU'].width = float(2)
sheet.merge_cells(start_row=adj_row,start_column=48,end_row=adj_row+1,end_column=69)
cell=sheet.cell(row=adj_row,column=48)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
cell.value="Adjusted Units Variance"
for i in range(adj_row,adj_row+2):
    for j in range(48,70):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FFC0C0C0',
                   end_color='FFC0C0C0',
                   fill_type='solid')
sheet.cell(adj_row,48).fill = redFill
for i in range(adj_row, adj_row + 2):
    for j in range(48,70):
        cell = sheet.cell(row=i, column=j)
        cell.font = Font(name='Calibri', size=24, color='ff000000', bold=True)
adj_row=adj_row+2
adj_row_header="Date of Charge Back!Service Group!Service Code!Service Code Description!Service Delivery Date!Service Unique Identifier!SUI Description!Service Physical!Service Virtual!TMDB Search Code!TMDB Application Name!Project #!Project Name!Project Requester!Segment!Unit Rate!Adjusted Service Units!Adjusted Service Cost!previous month units!previous month cost!variance units!variance cost"
adj_row_header_str=adj_row_header.split('!')
hi=0
for k in range(48,70):
    sheet.merge_cells(start_row=adj_row, start_column=k, end_row=adj_row, end_column=k)
    cell = sheet.cell(row=adj_row, column=k)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    #print(str(hi))
    cell.value =adj_row_header_str[hi]
    for i in range(adj_row, adj_row + 1):
        for j in range(k,k+1):
            cell = sheet.cell(row=i, column=j)
            cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                                 bottom=Side(style='thin'))
    redFill = PatternFill(start_color='FFB4B467',
                          end_color='FFB4B467',
                          fill_type='solid')
    sheet.cell(adj_row,k).fill=redFill
    for i in range(adj_row, adj_row + 1):
        for j in range(k, k+1):
            cell = sheet.cell(row=i, column=j)
            cell.font = Font(name='Calibri', size=8, color='ff000000', bold=True)
    hi=hi+1
sheet.merge_cells(start_row=adj_row,start_column=47,end_row=adj_row,end_column=47)
cell=sheet.cell(row=adj_row,column=47)
cell.alignment = Alignment(horizontal='center', vertical='center',wrap_text=True)
for i in range(adj_row,adj_row+2):
    for j in range(47,48):
        cell = sheet.cell(row=i, column=j)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
                             bottom=Side(style='thin'))
redFill = PatternFill(start_color='FF800000',
                   end_color='FF800000',
                   fill_type='solid')
sheet.cell(adj_row,47).fill = redFill
sheet.column_dimensions['AU'].width = float(2)
adj_row=adj_row+1
# sui_cfwd_data_lst_cur=list()
# for i in range(0,5):
#     s1=""
#     for j in range(0,22):
#         s1=s1+"adj"+str(i)+str(j)+"!"
#     print(s1)
#     sui_cfwd_data_lst_cur.append(s1)
# for m in range(0,len(sui_cfwd_data_lst_cur)):
#     adj_row_header_str = sui_cfwd_data_lst_cur[m].split('!')
#     hi = 0
#     for k in range(48, 70):
#         sheet.merge_cells(start_row=adj_row, start_column=k, end_row=adj_row, end_column=k)
#         cell = sheet.cell(row=adj_row, column=k)
#         cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
#         # print(str(hi))
#         cell.value = adj_row_header_str[hi]
#         for i in range(adj_row, adj_row + 1):
#             for j in range(k, k + 1):
#                 cell = sheet.cell(row=i, column=j)
#                 cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
#                                      bottom=Side(style='thin'))
#         redFill = PatternFill(start_color='FFFFFFFF',
#                               end_color='FFFFFFFF',
#                               fill_type='solid')
#         sheet.cell(adj_row, k).fill = redFill
#         for i in range(adj_row, adj_row + 1):
#             for j in range(k, k + 1):
#                 cell = sheet.cell(row=i, column=j)
#                 cell.font = Font(name='Calibri', size=8, color='ff000000', bold=True)
#         hi = hi + 1
#     sheet.merge_cells(start_row=adj_row, start_column=9, end_row=adj_row, end_column=9)
#     cell = sheet.cell(row=adj_row, column=9)
#     cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
#     for i in range(adj_row, adj_row + 2):
#         for j in range(47, 48):
#             cell = sheet.cell(row=i, column=j)
#             cell.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'),
#                                  bottom=Side(style='thin'))
#     redFill = PatternFill(start_color='FF800000',
#                           end_color='FF800000',
#                           fill_type='solid')
#     sheet.cell(adj_row, 47).fill = redFill
#     sheet.column_dimensions['I'].width = float(2)
#     adj_row = adj_row + 1
#

###### adj suis details

wb.save("C:\\Users\\asrilekh\\Desktop\\demo4.xlsx")
wb.close()