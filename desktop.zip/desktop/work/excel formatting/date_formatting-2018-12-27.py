from datetime import datetime


def date_format_fun(date_str):
    d = (datetime.strptime(date_str, '%Y-%m-%d'))
    day_string = d.strftime('%#m/%#d/%Y')
    return day_string
#print(day_string)

#(datetime.strptime(s2[x_svc_delivry_dt_indx] , '%Y-%m-%d %H:%M:%S')).strftime('%#m/%#d/%Y')