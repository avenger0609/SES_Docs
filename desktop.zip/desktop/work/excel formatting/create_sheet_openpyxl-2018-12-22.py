import openpyxl

wb = openpyxl.Workbook()
wb.create_sheet('Sheet 2')
sheet=wb.get_sheet_by_name('Sheet 2')
sheet.title="experiment"
for i in range(1,10):
    for j in range(1,10):
        c1 = sheet.cell(row=i, column=j)
        c1.value="srilekha anumulapelli"
target=wb.copy_worksheet(sheet)
wb.save("C:\\Users\\asrilekh\\Desktop\\demo2.xlsx")
wb.close()