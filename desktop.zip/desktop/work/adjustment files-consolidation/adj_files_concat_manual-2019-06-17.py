import pandas as pd
import csv

TCS_filename="C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\pdheeren@corpimsvcs.com\\APR 2019 Adjustments.xlsx"
TCS_filename="C:\\Users\\asrilekh\\Documents\\MAY 2019 Adjustments V3.xlsx"
adj_snames=list()
df_final=pd.DataFrame()
adj_snames.append('1 Avella Network Persona')
adj_snames.append('2 ISW Informatica')
adj_snames.append('3 Rx Manual')
adj_snames.append('4 RAA')
adj_snames.append('5 Network Persona')
req_col_lst=['Date of Charge Back','Service Group Cost Center','Original Applic Name or Internal Comment','Project #','Service Delivery Date','Customer Acceptance','GL BU','GL OU','GL Loc','GL Acct','GL Dept','GL Prod','GL Cust','GL Prj ID','Billing Code','Service Physical','Service Virtual','Service Storage','Service Unique Identifier (SUI)','Service Units','Service Request Number','Business Application Search Code','Prod or NonProd','ERD Mate','ERD Code','SUI Desc','Network Zone','Data Center Code','Environment Code','CS_CB_UNIQUE_KEY']
for col_i in range(0,len(req_col_lst)):
    req_col_lst[col_i]=req_col_lst[col_i].lower().strip(' ')
# print(len(req_col_lst))
df_final=pd.DataFrame()
for i in adj_snames:
    try:
        str_col_lst=[]
        req_col_indx_lst=[]
        not_present_col_lst=[]
        df = pd.read_excel(TCS_filename,sheet_name=i)
        # print(str(df.columns))
        col_lst=list(df.columns)
        for col_i in range(0,len(col_lst)):
            col_lst[col_i]=col_lst[col_i].lower().strip(' ')
        for r_i in req_col_lst:
            try:
                req_col_indx_lst.append(col_lst.index(r_i.lower()))
            except:
                # junk=1
                not_present_col_lst.append(r_i)
        if len(not_present_col_lst)> 0:
            print(str(not_present_col_lst)+" columns are missing in sheet "+i)
            continue
        for name, dtype in df.dtypes.iteritems():
            if "date" not in str(dtype).lower() and name in req_col_lst:
                str_col_lst.append(name)
            # print(name, dtype)
        # print(str(len(req_col_indx_lst)))
        converterS = {col: str for col in str_col_lst}
        # print(str(str_col_lst))
        df = pd.read_excel(TCS_filename,sheet_name=i,usecols=req_col_indx_lst,converters=converterS)
        if len(df_final)==0:
            df_final=df[0:0]
        # print(str(len(df.columns)))
        print(str(len(df)))
        df_final = pd.concat([df, df_final],sort=False)    
        print(str(len(df_final)))
    except Exception as e:
        print(str(e))
# df_final.columns=req_col_lst
# print(str(len(df_final)))
# print(str(len(df_final.columns)))
# df_final.to_csv(TCS_filename.replace('.xlsx','.csv'),index=False,quoting=csv.QUOTE_ALL,date_format="%Y-%m-%d")
df_final.to_csv(TCS_filename.replace('.xlsx','.csv'),index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y")