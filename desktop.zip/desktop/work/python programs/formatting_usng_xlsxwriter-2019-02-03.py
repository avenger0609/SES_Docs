####### formatting using xlsxwriter

import xlsxwriter
from datetime import datetime
import os
import csv
import openpyxl
import pandas as pd
import numpy as np
import datetime
import time
from dateutil import parser
import redis
import re
import xlrd
import xlwt

print(str((datetime.datetime.now())))

xl = pd.ExcelFile('TCS Dec 13 - Nov Swing Final Copy.xlsx')
df = xl.parse()
a=xl.sheet_names
for i in a:
    print(str(i))

tcs_x=list()
h=0
major_swing_indx=6
segment_index=2
count=0

for i in a:
    sname=str(i)
    print(sname)
    if h==0:
        cdf = pd.read_excel('TCS Dec 13 - Nov Swing Final Copy.xlsx', sheet_name=sname,header=0,skiprows=1)
    s1 = ""
    for i in range(0, len(cdf)):
        if(str(cdf.iloc[i, major_swing_indx]).strip(' ').upper()!='YES'):
            continue
        else:
            if (str(cdf.iloc[i, segment_index]).strip(' ').upper() == 'SVR TOTAL'):
                continue
            else:
                count=count+1
        for j in range(0, len(cdf.columns)):
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
        tcs_x.append(s1)
        s1 = ""
print(str(count))
file = open("filenametest.txt", "w")
for i in range(0,len(tcs_x)):
    file.write(tcs_x[i]+"\n")
file.close()

#x=list()
#y=list()

tcs_service_cd_indx=0
tcs_segment_indx=2
sui_indx=21
service_cd_indx=46
segment_indx=10
filt_data_cur=list()
sui_lst_data_cur=list()
filt_data_prev=list()
sui_lst_data_prev=list()
sui_add_lst=list()
sui_del_lst=list()
sui_cfwd_lst_cur=list()
sui_cfwd_lst_prev=list()
sui_cur_hit=0
sui_prev_hit=0
final_wb_name="swing_analysis_report.xls"
final_wb=xlwt.Workbook()
for tcs_i in range(0,len(tcs_x)):
    for i in range(1, len(x)):
        if (str(tcs_x[tcs_i].split('!')[tcs_service_cd_indx]).strip(' ').upper()==str(x[i].split('!')[service_cd_indx]).strip(' ').upper()) and (str(tcs_x[tcs_i].split('!')[tcs_segment_indx]).strip(' ').upper()==str(x[i].split('!')[segment_indx]).strip(' ').upper()):
            filt_data_cur.append(x)
            sui_lst_data_cur.append(str(x[i].split('!')[sui_indx]).strip(' '))
    for i in range(1, len(y)):
        if (str(tcs_x[tcs_i].split('!')[tcs_service_cd_indx]).strip(' ').upper() == str(y[i].split('!')[service_cd_indx]).strip(' ').upper()) and (str(tcs_x[tcs_i].split('!')[tcs_segment_indx]).strip(' ').upper() == str(y[i].split('!')[segment_indx]).strip(' ').upper()):
            filt_data_prev.append(y)
            sui_lst_data_prev.append(str(y[i].split('!')[sui_indx]).strip(' '))
    for i in range(0,len(sui_lst_data_cur)):
        sui_cur_hit=0
        for j in range(0,len(sui_lst_data_prev)):
            if(sui_lst_data_cur[i].upper()==sui_lst_data_prev[j].upper()):
                sui_cfwd_lst_cur.append(sui_lst_data_cur[i])
                sui_cur_hit=1
        if sui_cur_hit==0:
            sui_add_lst.append(sui_lst_data_cur[i])

    for i in range(0, len(sui_lst_data_prev)):
        sui_prev_hit = 0
        for j in range(0, len(sui_lst_data_cur)):
            if (sui_lst_data_cur[j].upper() == sui_lst_data_prev[i].upper()):
                sui_cfwd_lst_prev.append(sui_lst_data_cur[j])
                sui_prev_hit = 1
        if sui_prev_hit == 0:
            sui_del_lst.append(sui_lst_data_cur[i])


    final_sheet = final_wb.add_sheet(str(tcs_x[tcs_i].split('!')[tcs_service_cd_indx]).strip(' ').upper()+"_"+str(tcs_x[tcs_i].split('!')[tcs_segment_indx]).strip(' ').upper())
    font = xlwt.Font()  # Create Font
    font.bold = True  # Set font to Bold
    style = xlwt.XFStyle()  # Create Style
    style.font = font  # Add Bold Font to Style
    final_sheet.write_merge(16, 17, 0, 11, 'ADDITIONS', style)
    fsrownum=20

    cur_hdr=x[0].split('!')
    print(str(len(cur_hdr)))
    for chi in range(0,len(cur_hdr)):
        print(str(len(chi)))
        final_sheet.write(fsrownum,chi,cur_hdr[chi])
    fsrownum=fsrownum+1
    #writing additions
    for addi in range(0,len(sui_add_lst)):
        add_str=sui_add_lst[addi].split('!')
        for addsi in range(0,len(add_str)):
            final_sheet.write(fsrownum, addsi, add_str[addsi])
        fsrownum=fsrownum+1
    # writing additions

    font = xlwt.Font()  # Create Font
    font.bold = True  # Set font to Bold
    style = xlwt.XFStyle()  # Create Style
    style.font = font  # Add Bold Font to Style
    final_sheet.write_merge(fsrownum+2, fsrownum+4, 0, 11, 'ADDITIONS', style)
    fsrownum=fsrownum+6

    # writing deletions
    for deli in range(0, len(sui_del_lst)):
        del_str = sui_add_lst[deli].split('!')
        for delsi in range(0, len(del_str)):
            final_sheet.write(fsrownum, delsi, del_str[delsi])
        fsrownum = fsrownum + 1
    # writing deletions

    font = xlwt.Font()  # Create Font
    font.bold = True  # Set font to Bold
    style = xlwt.XFStyle()  # Create Style
    style.font = font  # Add Bold Font to Style
    final_sheet.write_merge(fsrownum + 2, fsrownum + 4, 0, 11, 'ADDITIONS', style)
    fsrownum = fsrownum + 6

    #writing carry forwarded
    for cfwdi in range(0,sui_lst_data_cur):
        cfwd_str=sui_lst_data_cur[cfwdi].split('!')
        for cfwdsi in range(0,len(cfwd_str)):
            final_sheet.write(fsrownum, cfwdsi, cfwd_str[cfwdsi])
        fsrownum = fsrownum + 1

    # writing carry forwarded


final_wb.save(final_wb_name)


