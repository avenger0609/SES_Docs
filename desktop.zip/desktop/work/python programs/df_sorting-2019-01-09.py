import pandas as pd


xl=pd.ExcelFile("Book1.xlsx")
# df = xl.parse("Sheet1")
df = pd.read_excel("Book1.xlsx", sheet_name="Sheet1" )
s1=""
for i in range(0, len(df)):
    for j in range(0, len(df.columns)):
        if j == 21 or j == 1 or j == 2 or j == 10 or j == 20:
            s1 = s1 + str(df.iloc[i, j]) + "!"
    print(str(i)+"-"+s1)
    s1=""
df = df.sort_values(["Service Unique Identifier","Service Group Cost Center"])
s1=""
for i in range(0, len(df)):
    for j in range(0, len(df.columns)):
        if j==21 or j==1 or j==2 or j==10 or j==20:
            s1 = s1 + str(df.iloc[i, j]) + "!"
    print(str(i)+"-"+s1)
    s1=""
