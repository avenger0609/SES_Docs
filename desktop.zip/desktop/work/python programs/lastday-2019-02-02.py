import datetime
from datetime import datetime
import calendar

def get_last_day(s1):

    year1=s1.split('-')[0]
    month1=s1.split('-')[1]
    s1=str(calendar.monthrange(year1,month1)).replace('(','').replace(')','').replace(' ','').split(',')
    date_str=datetime(year1,month1,s1[1])
    return date_str.strftime('%Y-%m-%d')
