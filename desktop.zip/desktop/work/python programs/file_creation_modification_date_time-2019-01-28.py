import os
from datetime import datetime

os.chdir="C:\\Users\\asrilekh\\Desktop\\work\swing analysis"
os.path.join(os.getcwd(), "rev__ContactCenter_swing_analysis_report.xlsx")
fname="rev__ContactCenter_swing_analysis_report.xlsx"
# gives time
print(os.path.getmtime(os.path.join(os.getcwd(), fname)))
print(os.path.getctime(os.path.join(os.getcwd(), "rev__ContactCenter_swing_analysis_report.xlsx")))
#gives date
print(datetime.fromtimestamp((os.path.getmtime(os.path.join(os.getcwd(), "rev__ContactCenter_swing_analysis_report.xlsx")))))
print(datetime.fromtimestamp((os.path.getctime(os.path.join(os.getcwd(), "rev__ContactCenter_swing_analysis_report.xlsx")))))
