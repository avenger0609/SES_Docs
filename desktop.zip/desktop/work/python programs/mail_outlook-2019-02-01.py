import win32com.client as win32
outlook = win32.Dispatch('outlook.application')
mail = outlook.CreateItem(0)
mail.To = 'srilekha.anumula@optum.com'
# mail.Cc='srilekha.anumula.optum.com'
mail.Subject = 'Message subject'
mail.Body = 'Message body\n'+'abc'
mail.HTMLBody = '<p>HTML Message body</p><p>line2</p>' #this field is optional

# To attach a file to the email (optional):
attachment  = "\\\\nasv0066\\special_ice_cb_project_repositor\\sync.txt"
mail.Attachments.Add(attachment)

mail.Send()
