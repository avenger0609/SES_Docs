from shutil import copyfile

copyfile('\\\\NAS00038pn\\data\\Tech_Economics\\VMWare_ITBM\\Outgoing_Prod\\VM Ware_DISPLAY_NAME_1012001_1902_MPWR_ChargebackData.csv', 'C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\VM Ware_DISPLAY_NAME_1012001_1902_MPWR_ChargebackData.csv')