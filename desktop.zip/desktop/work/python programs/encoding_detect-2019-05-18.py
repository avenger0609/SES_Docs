import chardet

fname='C:\\Users\\asrilekh\\Desktop\\May-Test\\'+"VM Ware_DISPLAY_NAME_78008_1904_MPWR_ChargebackData.csv"
with open(fname, 'rb') as f:
    result = chardet.detect(f.read())
    print(result)