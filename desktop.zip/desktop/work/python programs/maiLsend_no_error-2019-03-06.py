#!/usr/bin/perl
use MIME::Lite;


$from1="rizwan.syedali@optum.com"
$to="srilekha.anumula@optum.com"
$subject="test"
$message="test1"



my $mail_server="mail25.uhc.com";
$msg = MIME::Lite->new(
                 From     => $from1,
                 To       => $to,
                 Subject  => $subject,
                 Data     => $message
                 );
                 
#$msg->send;
$msg->send('smtp',$mail_server,Timeout=>60,Port => 25 ) or die("Unable to send mail : $!\n");
print "Email Sent Successfully\n";