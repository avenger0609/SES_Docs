# from pymongo import MongoClient
import pymongo

myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
print(myclient.list_database_names())
mydb = myclient["HandsFreeAnalytics"]
print(mydb.list_collection_names())
# mycol = mydb["Conversation_History"]
mycol = mydb["hfa_interim"]
mydoc = mycol.find({})
print(str(mydoc.count()))
for x in mydoc:
  print(x)
  