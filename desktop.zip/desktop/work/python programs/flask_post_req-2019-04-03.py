from flask import Flask
from flask import render_template,jsonify,request
import requests
import random
import urllib3
from flask import json

app = Flask(__name__)
app.secret_key = '12345'
@app.route('/messages', methods = ['POST'])
def api_message():
    print(str(request))
    print(type(request))  
    print(str(request.data))  
    
    if request.headers['Content-Type'] == 'text/plain':
        print( "Text Message: " + request.data)

    elif request.headers['Content-Type'] == 'application/json':
        print("JSON Message: " + str((str(request.json))))
    else:
        print( "415 Unsupported Media Type ;)")

app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(port=6060)