#from openpyxl import Workbook
#from openpyxl import load_workbook
#from openpyxl.styles import Font
import pandas as Pandas
#import numpy as np
import csv
import os
from glob import iglob
import shutil
import zipfile
from wfnaudit.logdata import logger

class Wfn_Audit:
	def __init__(self):
		self.input_files_path = ""
		self.zippedFile = ""

	def UnzipZippedFile(self, zippedFile, path):
		print(path)
		with zipfile.ZipFile(zippedFile,"r") as zip_ref:
			zip_ref.extractall(path)


	def mergefiles(self):
		try:
			AdjFileList = [ filename for filename in os.listdir(self.input_files_path) if filename.endswith(".ADJ") ]
			print(AdjFileList)
			destination=open(self.input_files_path + '/MERGED_FILE.ADJ','w+')		
			for filename in AdjFileList:
				if filename.lower() not in "MERGED_FILE.ADJ":
					NxtADJFile =  open(self.input_files_path + "/" + filename,'r',encoding="ISO-8859-1")
					data = NxtADJFile.readlines()[3:]
					destination.writelines(data)
					NxtADJFile.close()
		except Exception as e:
			error = str(e)
			print(str(e))
	
	def filesize(self):
		file_size=os.path.getsize(self.input_files_path +"/MERGED_FILE.ADJ")
		return int(file_size)
		
			
		
		
	def skippinglines(self):
		try:
			count1=0
			count2=0

			mf=open(self.input_files_path + '/MERGED_FILE.ADJ', "r")
			lines=mf.readlines()
			mf.close()
			i=0;
			mf=open(self.input_files_path + '/MERGED_FILE.ADJ', "w")
			for line in lines:
				if line.startswith('DP1'):
					count1=1
					continue
				if count1==1:
					count2=1
					count1=0
					continue
				if count2==1:
					count2=0
					count1=0
					continue
				mf.write(line)
			print("Skipped unwanted lines")
			mf.close()
		except Exception as e:
			error = str(e)
			print(str(e))
			

	def perform_logics(self):
		try:

			f=	open(self.input_files_path + "/MERGED_FILE.ADJ","r")
			f1 = open( self.input_files_path + "/PARSED.CSV", "w")
			f1.writelines("ROW_NBR,MJ_RCD_NBR,BLOCK_NBR,RCD_NBR,PAYGROUP,FILE_NBR,SUBRECORD,ID1,MOD1,VALUE1,ID2,MOD2,VALUE2,ID3,MOD3,VALUE3,TERMINATION" + "\n")

			ROW_NBR = 0
			MJ_RCD_NBR = 0
			BLOCK_NBR = 0
			RCD_NBR = 0
			TERMINATION = ''


			for a_line in f:
				#This is a Seq
				ROW_NBR = ROW_NBR + 1
				SUBRECORD = str(a_line[15:18]).strip()
				#=IF(AND(R2<>"X",H3="B11"), C2+1,C2)
				if TERMINATION != 'X' and SUBRECORD == 'B11':
					MJ_RCD_NBR = str(int(MJ_RCD_NBR) + 1)
				else:
					MJ_RCD_NBR = str(MJ_RCD_NBR) if int(MJ_RCD_NBR) > 0 else 1

				#=IF(R2="X", D2,D2+1)
				if TERMINATION == 'X':
					BLOCK_NBR = str(BLOCK_NBR)
					RCD_NBR = str(int(RCD_NBR) + 1)
				else:
					BLOCK_NBR = str(int(BLOCK_NBR) + 1)
					RCD_NBR = 1

				#=IF(R2="X",E2+1,1)

				#ROW_NBR=str(a_line[2:6]).strip()
				#MJ_RCD_NBR=str(a_line[2:6]).strip()
				#RCD_NBR = str(a_line[2:6]).strip()

				PAYGROUP = str(a_line[2:5]).strip()
				FILE_NBR = str(a_line[6:12]).strip()
				ID1 = str(a_line[31:33]).strip()
				MOD1=str(a_line[33:36]).strip()
				VALUE1=str(a_line[37:47]).strip()
				ID2=str(a_line[47:49]).strip()
				MOD2=str(a_line[49:52]).strip()
				VALUE2=str(a_line[53:63]).strip()
				ID3=str(a_line[63:65]).strip()
				MOD3=str(a_line[65:68]).strip()
				VALUE3=str(a_line[69:79]).strip()
				TERMINATION=str(a_line[87:88]).strip()

				f1.writelines( str(ROW_NBR) + "," + str(MJ_RCD_NBR) + "," + str(BLOCK_NBR) + "," + str(RCD_NBR) + "," + PAYGROUP + "," + FILE_NBR + "," + SUBRECORD + "," + ID1\
				+ "," + MOD1 + "," + VALUE1 + "," + ID2 + "," + MOD2  + "," + VALUE2 + "," + ID3 + "," +  MOD3 + "," + VALUE3 + "," + TERMINATION + "\n")
			f.close()
			f1.close()
		except Eception as e:
			error = str(e)
			print(str(e))
	def replace(self):
		try:
			# Read in the file
			with open(self.input_files_path + "/PARSED.CSV", "r") as file :
				filedata = file.read()

			# Replace the target string
			filedata = filedata.replace('Ð', '}')
			file.close()


			# Write the file out again
			with open(self.input_files_path + "/PARSED.CSV", "w") as file:
				file.write(filedata)
			file.close()
		except Exception as e:
			error = str(e)
			print(str(e))

	
		


	def Start(self, path , zippedFile):
		self.input_files_path = path
		print(path)
		self.zippedFile = zippedFile
		print(zippedFile)
		Wfn_Audit.UnzipZippedFile(self, zippedFile, path)
		print(" Unzip Completed")
		Wfn_Audit.mergefiles(self)
		print(" Merging Completed")
		file_size = Wfn_Audit.filesize(self)
		if file_size > 0 :
			try:
				Wfn_Audit.skippinglines(self)
				print("skipping unwanted lines completed")
				Wfn_Audit.perform_logics(self)
				print(" PARSED file is generated")
				Wfn_Audit.replace(self)
				print("special charecter is replaced")
				return 'Passed'
			except Exception as e:
				print(str(e))
				return False
		else:
			return 'Failed'
		

