import os
from zipfile import ZipFile
from flask import Blueprint, Flask, render_template, request, redirect, url_for, send_from_directory, jsonify, send_file
# from werkzeug import secure_filename
from logging import Formatter, FileHandler
import shutil
import logging
# from WFN_AUDIT import Wfn_Audit as Bal_Val
# from wfnaudit.logdata import logger
# import wfnaudit.twoparts_p as Bal_dec

wfnaudit = Blueprint('wfnaudit', __name__, template_folder='templates')

# This is the path to the upload directory
directory = 'upload/'
basedir = os.path.abspath(os.path.dirname(__file__))

# Initialize the Flask application

app = Flask(__name__)


# These are the extension that we are accepting to be uploaded

app.config['ALLOWED_EXTENSIONS'] = set(['ADJ'])

# For a given file, return whether it's an allowed type or not


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


@wfnaudit.route('/DT_India/DC_balance_Audit')
def index():
    return render_template('Clientside_balances_WFN_Audit.html')


@wfnaudit.route('/uploadbal_wfnaudit/', methods=['GET', 'POST'])
def upldbalfile():
    if request.method == 'POST':
        os.chdir(basedir)
        print('*************bal************************')
        try:
            client_id = request.form['client_ID_ena']
        except Exception as e:
            print('****1st exception*****')
            error = str(e)
            print(error)
            '''logger.info(error)'''
            return render_template('wfnaudit/Clientside_balances_WFN_Audit.html')
        if (client_id.isdigit()):
            print(client_id)
            print(directory)
            new_directory = basedir + "/" + directory + client_id
            new_directory_bal = basedir + "/" + directory + client_id
            try:
                files = request.files['file_zip']
            except Exception as e:
                print('*********')
                logger.info ('******')
                error = str(e)
                '''logger.info(error)'''
                print (error)
                return _template('Clientside_balances_WFN_Audit.html')
                print(new_directory)
            try:
                if not os.path.exists(new_directory):
                    os.mkdir(new_directory)
                else:
                    shutil.rmtree(new_directory)
                    os.mkdir(new_directory)
                    '''logger.info("Directory deleted and recreated")'''
                    logger.getLog('Directory deleted and recreated',client_id)
                    print("Directory deleted and recreated")
            except Exception as e:
                error = str(e)
                '''logger.info(error)'''
                print(str(e))

            filename = secure_filename("ADJ_FILES.zip")
            print(filename)
            print(basedir)
            updir = os.path.join(basedir, new_directory_bal)
            print(updir)
            files.save(os.path.join(updir, filename))
            file_size = os.path.getsize(os.path.join(updir, filename))
            return jsonify(name=filename, size=file_size)

@wfnaudit.route('/generateAudit/', methods=['GET', 'POST'])
def downloadfile():
    if request.method == 'POST':
        try:
            client_id = request.form['client_ID_ref1']
        except Exception as e:
            print(e)
        print(client_id)
        zip_directory = basedir + "/" + directory + client_id
        new_directory = basedir + "/" + directory + client_id + "/AUDITFILES"
        """os.mkdir(new_directory)"""
        os.chdir(basedir)
        os.chdir(zip_directory)
        if not os.path.exists(new_directory):
            os.mkdir(new_directory)
        obj_wfn = Bal_Val.Wfn_Audit()
        try:
            msg = obj_wfn.Start(new_directory,"ADJ_FILES.zip")
            print (msg)
            if msg == 'Failed':
                print("incompatible files uploaded")
                
                logger.getLog('incompatible files uploaded', client_id)
                return jsonify(name=client_id,error=msg)

        except Exception as e:
            error = str(e)
            print(str(e))
            

        zip_directory = basedir + "/" + directory + client_id
        new_directory = basedir + "/" + directory + client_id + "/AUDITFILES"
        
        os.chdir(basedir)
        os.chdir(new_directory)
        pf = open('PARSED.CSV', 'r')
        precords = pf.readlines()
        pf.close()
        pf = open('PARSED_D.CSV', 'w')
        pf.write(client_id)
        for pline in precords:
            pf.write(pline)
        pf.close()
        os.chdir(basedir)
        os.chdir(new_directory)
        if not os.path.exists(new_directory):
            os.mkdir(new_directory)
        obj_decon = Bal_dec.BalDecon()
        print("starting DECON part")
        item_list = os.listdir(new_directory)
        print(item_list)
        print(new_directory)
        try:
            msg = obj_decon.start(new_directory)
            print(msg)
            if msg == 'Failed':
                print("Error in executing Decon Query")
                
                logger.getLog('incompatible files uploaded', client_id)
                return jsonify(name=client_id, error=msg)

        except Exception as e:
            error = str(e)
            print(str(e))

        item_list = os.listdir(new_directory)
        
        
        os.chdir(new_directory)
        
        
        if 'DECON.csv' not in item_list:
            print("only PARSED file is generated")
            file_paths_list = ['PARSED.CSV']
            logger.getLog('only PARSED file generated', client_id)
            try:
                with ZipFile('WFN_AUDIT_FILES.zip', 'w') as zip:
                    for file in file_paths_list:
                        print(file)
                        try:
                            zip.write(file)
                            mas = 'passed'
                        except Exception as e:
                            error = str(e)
            except Exception as e:
                error = str(e)
                print(str(e))
                print(str(e))

        else:
            if ('PARSED.CSV' in item_list):
                if ('DECON.csv' in item_list):
                    print("item list matching with file list")
                    try:
                        with ZipFile('WFN_AUDIT_FILES.zip', 'w') as zip:
                            # writing each file one by one
                            for file in item_list:
                                print(file)
                                try:
                                    zip.write(file)
                                    msg = 'passed'
                                except Exception as e:
                                    error = str(e)
                                    print(str(e))

                    except Exception as e:
                        error = str(e)
                        print(str(e))
                else:
                    print("required files are not generated")

                    logger.getLog('required files are not generated', client_id)
                    msg = 'Failed'
            else:
                print("required files are not generated")
            
                logger.getLog('required files are not generated', client_id)
                msg = 'Failed'
        return jsonify(name=client_id, error=msg)


@wfnaudit.route('/return_file_wfn/<client_id>')
def return_file_bal(client_id):
    print("starting to download files")
    new_directory = basedir + "/" + directory + client_id[0:5] + "/AUDITFILES"
    os.chdir(basedir)
    print(new_directory)
    path = new_directory + "/WFN_AUDIT_FILES.zip"
    print(path)
    return send_file(path, attachment_filename='WFN_AUDIT_FILES.zip')


@wfnaudit.route('/return_file_Bal_log/<client_id>')
def return_file_log(client_id):
    print("starting to download files")
    new_directory = basedir + "/" + 'log/' + client_id[0:5] +'.txt'
    os.chdir(basedir)
    print(new_directory)
    path =  basedir + "/" + 'log/' +  client_id[0:5] +'.txt'
    print(path)
    return send_file(path, attachment_filename='LOGFILE.txt')
        
    

if __name__ == '__main__':
    app.run(debug=True)
