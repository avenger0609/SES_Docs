
import os
import time
from pprint import pprint

pprint([(x[0], time.ctime(x[1].st_mtime)) for x in sorted([(fn, os.stat(fn)) for fn in os.listdir("c:\\users\\asrilekh\\desktop\\work\\swing analysis")], key = lambda x: x[1].st_mtime)])
