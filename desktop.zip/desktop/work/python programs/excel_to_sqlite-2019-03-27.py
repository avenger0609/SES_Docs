import pandas as pd
import sqlite3

db_file = "C:\\Users\\asrilekh\\Documents\\claims_test\\claims.db"
con = sqlite3.connect(db_file)
cur = con.cursor()

df = pd.read_excel('C:\\Users\\asrilekh\\Documents\\claims_test\\sample for NLP.xlsx')
df.to_sql("claims_sample", con, if_exists='append', index=False)


cur.execute("SELECT * FROM claims_sample")

rows = cur.fetchall()

for row in rows:
        print(row)

con.commit()
con.close()



