## not worked #####
import pandas as pd
import csv

df=pd.read_csv('c:\\users\\asrilekh\\documents\\ITBM_Montly_Refresh\\april\\VM Ware_DISPLAY_NAME_78000_1903_MPWR_ChargebackData.csv',sep=',',header=0,encoding = 'unicode_escape')
# converterS=""
str_col_lst=[]
dt_col_lst=[]
for name, dtype in df.dtypes.iteritems():
    if "date" not in str(name).lower():
        str_col_lst.append(name)
    else:
        dt_col_lst.append(name)
converterS = {col: str for col in str_col_lst}
converterS = {col: str for col in df.columns}
df=pd.read_csv('c:\\users\\asrilekh\\documents\\ITBM_Montly_Refresh\\april\\VM Ware_DISPLAY_NAME_78000_1903_MPWR_ChargebackData.csv',sep=',',header=0,converters=converterS,parse_dates={'datetime':dt_col_lst},encoding = 'unicode_escape')
for name, dtype in df.dtypes.iteritems():
    print(name+"--"+str(dtype))
df.to_csv('c:\\users\\asrilekh\\documents\\ITBM_Montly_Refresh\\april\\VM Ware_DISPLAY_NAME_78000_1903_MPWR_ChargebackData_V1.csv',index=False,quoting=csv.QUOTE_ALL,date_format="%m/%d/%Y")
