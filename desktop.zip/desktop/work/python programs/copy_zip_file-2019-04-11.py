from shutil import copyfile
latest_file='\\\\NAS00038pn\\data\\Tech_Economics\\VMWare_ITBM\\Outgoing_Prod\\ZIP_FILES\\1902_allfiles.zip'
copyfile(latest_file, 'C:\\Users\\asrilekh\\Documents\\1902files.zip')