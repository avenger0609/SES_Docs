
import merging_excels as merging_excels


merging_excels.merge_outputs()