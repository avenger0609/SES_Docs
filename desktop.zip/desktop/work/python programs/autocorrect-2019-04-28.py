from autocorrect import spell

a=spell("re-submitting")
print(a)