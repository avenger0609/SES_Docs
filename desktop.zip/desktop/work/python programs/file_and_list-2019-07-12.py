

# x=list()
# x.append('a1')
# x.append('a2')
# x.append('a3')
# x.append('a4')
# x.append('a5')
# x.append('a6')

# file1 = open("testfile.txt","w")
# for x1 in x:
#     file1.write(x1+"\n")

file1 = open("C:\\Users\\asrilekh\\Downloads\\object-detection-opencv-master\\yolov3.weights","r",encoding='latin-1')
for line in file1:
    print(line)
    # x.append(line.rstrip(line[-1:]))
# print(x)
