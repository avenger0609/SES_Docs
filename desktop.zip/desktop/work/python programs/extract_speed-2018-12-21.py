import multiprocessing
import xlsxwriter
from datetime import datetime
import os
import csv
import openpyxl
import pandas as pd
import numpy as np
import datetime
import time
from dateutil import parser
import redis
import re
import xlrd
import xlwt

print(str((datetime.datetime.now())))

if((int(str(datetime.datetime.now().month))*1)==1):
    csfilename = str(datetime.datetime.now().year-1)+"12_UHG_IT_CB_Data_CS.xlsx"
    nsfilename = str(datetime.datetime.now().year-1)+"12_UHG_IT_CB_Data_NS.xlsx"
    mergedfilename = str(datetime.datetime.now().year-1)+"12_UHG_IT_CB_Data.xlsx"
    prev_csfilename = str(datetime.datetime.now().year - 1) + "11_UHG_IT_CB_Data_CS.xlsx"
    prev_nsfilename = str(datetime.datetime.now().year - 1) + "11_UHG_IT_CB_Data_NS.xlsx"
    prev_mergedfilename = str(datetime.datetime.now().year - 1) + "11_UHG_IT_CB_Data.xlsx"

elif((int(str(datetime.datetime.now().month))*1)==2):
    prev_csfilename = str(datetime.datetime.now().year-1)+"12_UHG_IT_CB_Data_CS.xlsx"
    prev_nsfilename = str(datetime.datetime.now().year-1)+"12_UHG_IT_CB_Data_NS.xlsx"
    prev_mergedfilename = str(datetime.datetime.now().year-1)+"12_UHG_IT_CB_Data.xlsx"
    csfilename = str(datetime.datetime.now().year)+"01_UHG_IT_CB_Data_CS.xlsx"
    nsfilename = str(datetime.datetime.now().year)+"01_UHG_IT_CB_Data_NS.xlsx"
    mergedfilename = str(datetime.datetime.now().year)+"01_UHG_IT_CB_Data.xlsx"
elif(((int((str(datetime.datetime.now().month)))*1)>2) and ((int((str(datetime.datetime.now().month)))*1)<11)):
    csfilename = str(datetime.datetime.now().year)+"0" + str(int(str(datetime.datetime.now().month - 1))*1) + "_UHG_IT_CB_Data_CS.xlsx"
    nsfilename = str(datetime.datetime.now().year)+"0" + str(int(str(datetime.datetime.now().month - 1))*1) +  "_UHG_IT_CB_Data_NS.xlsx"
    mergedfilename = str(datetime.datetime.now().year)+"0" + str(int(str(datetime.datetime.now().month - 1))*1) +  "_UHG_IT_CB_Data.xlsx"

    prev_csfilename = str(datetime.datetime.now().year)+"0" + str(int(str(datetime.datetime.now().month - 2))*1) +  "_UHG_IT_CB_Data_CS.xlsx"
    prev_nsfilename = str(datetime.datetime.now().year)+"0" + str(int(str(datetime.datetime.now().month - 2))*1) +  "_UHG_IT_CB_Data_NS.xlsx"
    prev_mergedfilename = str(datetime.datetime.now().year)+"0" + str(int(str(datetime.datetime.now().month - 2))*1) +  "_UHG_IT_CB_Data.xlsx"

elif((int(str(datetime.datetime.now().month))*1)==11):

    csfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 1) + "_UHG_IT_CB_Data_CS.xlsx"
    nsfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 1) + "_UHG_IT_CB_Data_NS.xlsx"
    mergedfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 1) + "_UHG_IT_CB_Data.xlsx"
    prev_csfilename = str(datetime.datetime.now().year) + "0" + str(int(str(datetime.datetime.now().month - 2)) * 1) + "_UHG_IT_CB_Data_CS.xlsx"
    prev_nsfilename = str(datetime.datetime.now().year) + "0" + str(int(str(datetime.datetime.now().month - 2)) * 1) + "_UHG_IT_CB_Data_NS.xlsx"
    prev_mergedfilename = str(datetime.datetime.now().year) + "0" + str(int(str(datetime.datetime.now().month - 2)) * 1) + "_UHG_IT_CB_Data.xlsx"


else:
    csfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 1) + "_UHG_IT_CB_Data_CS.xlsx"
    nsfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 1) + "_UHG_IT_CB_Data_NS.xlsx"
    mergedfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 1) + "_UHG_IT_CB_Data.xlsx"

    prev_csfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 2) + "_UHG_IT_CB_Data_CS.xlsx"
    prev_nsfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 2) + "_UHG_IT_CB_Data_NS.xlsx"
    prev_mergedfilename = str(datetime.datetime.now().year) + str(datetime.datetime.now().month - 2) + "_UHG_IT_CB_Data.xlsx"


print("current month file name"+csfilename)
print("previous month file name"+prev_csfilename)

x_non_citrix_data=list()
x_non_citrix_sui=list()
x_citrix_data=list()
x_citrix_sui=list()
x_server_related_data=list()
x_server_related_sui=list()
x_ContactCenter_data=list()
x_ContactCenter_sui=list()
x_Telephone_data=list()
x_Telephone_sui=list()
tcs_service_cd_indx=0
tcs_segment_indx=2
sui_indx=3
service_cd_indx=9
segment_indx=2

x=list()
xl = pd.ExcelFile(csfilename)
df = xl.parse()
a=xl.sheet_names
for i in a:
    print(str(i))
cdf = pd.read_excel(csfilename, sheet_name=str(a[0]), header=None,usecols=[8, 9, 21, 23, 25, 26, 31, 34, 66, 67, 10, 46])
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(x_non_citrix_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            x_non_citrix_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    x_non_citrix_data.append(s1)
    x.append(s1)
    s1 = ""
cdf = pd.read_excel(csfilename, sheet_name=str(a[1]),usecols=[8, 9, 21, 23, 25, 26, 31, 34, 66, 67, 10, 46])
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(x_citrix_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            x_citrix_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    x_citrix_data.append(s1)
    x.append(s1)
    s1 = ""
cdf = pd.read_excel(csfilename, sheet_name=str(a[2]),usecols=[8, 9, 21, 23, 25, 26, 31, 34, 66, 67, 10, 46])
print(str(len(cdf)))

print(str(len(cdf.columns)))

s1 = ""
for i in range(0, len(cdf)):
    for j in range(0, len(cdf.columns)):
        # s1 = s1 + str(cdf.iloc[i, j]) + "!"
        if j == sui_indx:
            s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(x_server_related_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
            x_server_related_sui.append(str(cdf.iloc[i, j]))
        else:
            s1 = s1 + str(cdf.iloc[i, j]) + "!"
    # print(s1)
    x_server_related_data.append(s1)
    x.append(s1)
    s1 = ""
# # ns file name
# cdf = pd.read_excel(nsfilename, sheet_name="_ContactCenter",usecols=[8, 9, 21, 23, 25, 26, 31, 34, 66, 67, 10, 46])
# print(str(len(cdf)))
#
# print(str(len(cdf.columns)))
#
# s1 = ""
# for i in range(0, len(cdf)):
#     for j in range(0, len(cdf.columns)):
#         # s1 = s1 + str(cdf.iloc[i, j]) + "!"
#         if j == sui_indx:
#             s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(x_server_related_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
#             x_ContactCenter_sui.append(str(cdf.iloc[i, j]))
#         else:
#             s1 = s1 + str(cdf.iloc[i, j]) + "!"
#     # print(s1)
#     x_ContactCenter_data.append(s1)
#     x.append(s1)
#     s1 = ""
#
# cdf = pd.read_excel(nsfilename, sheet_name="_Telephone",usecols=[8, 9, 21, 23, 25, 26, 31, 34, 66, 67, 10, 46])
# print(str(len(cdf)))
#
# print(str(len(cdf.columns)))
#
# s1 = ""
# for i in range(0, len(cdf)):
#     for j in range(0, len(cdf.columns)):
#         # s1 = s1 + str(cdf.iloc[i, j]) + "!"
#         if j == sui_indx:
#             s1 = s1 + str(cdf.iloc[i, j]) + "}" + str(x_server_related_sui.count(str(cdf.iloc[i, j])) + 1) + "!"
#             x_Telephone_sui.append(str(cdf.iloc[i, j]))
#         else:
#             s1 = s1 + str(cdf.iloc[i, j]) + "!"
#     # print(s1)
#     x_Telephone_data.append(s1)
#     x.append(s1)
#     s1 = ""
# # ns file name

print(str((datetime.datetime.now())))

wb_name=mergedfilename
workbook = xlsxwriter.Workbook(wb_name)
worksheet = workbook.add_worksheet()


for i in range(0,len(x)):
    s=x[i].split('!')

    for j in range(0,len(s)):
        worksheet.write(i, j, s[j].replace('nan',''))
       # worksheet.write(i, j, s[j])

workbook.close()


print("completed merging of current month")
print(str((datetime.datetime.now())))