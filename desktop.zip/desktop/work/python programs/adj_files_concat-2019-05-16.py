import pandas as pd
import csv

TCS_filename="C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\tkumar51@corpimsvcs.com\\Apr 2018 Adjustments data V2.xlsx"
# xl = pd.ExcelFile(TCS_filename)
# df = xl.parse()
# a = xl.sheet_names
adj_snames=list()
# for i in a:
#     sname = str(i)
#     print(sname)
#     cdf = pd.read_excel(TCS_filename, sheet_name=sname, header=0,usecols=[0,1,2,3], skiprows=1)
#     print(cdf.columns)
#     if "ID" in cdf.columns:
#         for j in range(0,len(cdf)):
#             adj_snames.append(cdf.loc[j,"ID"])
#         break
# print(adj_snames)
df_final=pd.DataFrame()
adj_snames.append('1')
adj_snames.append('2')
adj_snames.append('3')
adj_snames.append('5')
adj_snames.append('6')
adj_snames.append('7')
adj_snames.append('8')
adj_snames.append('9')
adj_snames.append('10')
for i in adj_snames:
    try:
        if i=='4':
            continue
        df = pd.read_excel(TCS_filename,sheet_name=i)
        converterS = {col: str for col in df.columns}
        df = pd.read_excel(TCS_filename,sheet_name=i,converters=converterS)
        print(str(len(df)))
        df_final = pd.concat([df, df_final])    
        print(str(len(df_final)))
    except Exception as e:
        print(str(e))
df_final.to_csv("adju_test.csv",index=False,quoting=csv.QUOTE_ALL)
df_final.to_csv(TCS_filename.replace('.xlsx','.csv'),index=False,quoting=csv.QUOTE_ALL)