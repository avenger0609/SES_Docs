import pandas as pd
import xlsxwriter
import os
from datetime import datetime
import chardet

files_list=list()
for entry in os.scandir('C:\\Users\\asrilekh\\Desktop\\May-Test'):
    if entry.is_file():
        if ".csv" in str(entry.name).lower():
            files_list.append(entry.name)

for fname in files_list:
    print(fname)
    try:
        # with open('C:\\Users\\asrilekh\\Desktop\\May-Test\\'+fname, 'rb') as f:
        #     result = chardet.detect(f.read())
        #     print(result)
        cdf=pd.read_csv('C:\\Users\\asrilekh\\Desktop\\May-Test\\'+fname,encoding = 'unicode_escape')
        # cdf=pd.read_csv('C:\\Users\\asrilekh\\Desktop\\May-Test\\'+fname,encoding = result)
        # print(cdf.columns)
        converterS = {col: str for col in cdf.columns}
        # print(str(converterS))
        cdf=pd.read_csv('C:\\Users\\asrilekh\\Desktop\\May-Test\\'+fname,converters=converterS,encoding = 'unicode_escape')
        # cdf=pd.read_csv('C:\\Users\\asrilekh\\Desktop\\May-Test\\'+fname,converters=converterS,encoding = result)
        for i in range(0,len(cdf)):
            for j in range(0,len(cdf.columns)):
                if len(str(cdf.iloc[i,j]))>249:
                    print("row="+str(i+1)+",column="+str(j+1)+",data="+str(cdf.iloc[i,j]))
    except Exception as e:
        print(str(e))