import pandas as pd
import xlsxwriter
def compare_csv(f1,f2):
    # f1='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\April\\UHG_OPERATING_UNIT_GEN_PSTREE_20190412-203104.csv'
    # f2='C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\April\\UHG_OPERATING_UNIT_GEN_PSTREE_20190412-203104.csv'
    cdf1=pd.read_csv(f1)
    cdf2=pd.read_csv(f2)
    junk=0
    if len(cdf1)==len(cdf2):
        junk=1
    else:
        print("number of records in both files are different-"+str(len(cdf1))+"-"+str(len(cdf2)))

    if len(cdf1.columns)==len(cdf2.columns):
        junk=1
    else:
        print("number of columns in both files are different-"+str(len(cdf1.columns))+"-"+str(len(cdf2.columns)))
    diff_lst=list()
    diff_lst.append("row number!column number!first file value!second file value")
    if junk==0:    
        for i in range(0,len(cdf1)):        
            for j in range(0, len(cdf1.columns)):    
                if str(cdf1.iloc[i, j])==str(cdf2.iloc[i, j]):
                    ok=1
                else:
                    s1=str(i+1)+"!"+str(j+1)+"!"+str(cdf1.iloc[i, j])+"!"+str(cdf2.iloc[i, j])
                    diff_lst.append(s1)
    if len(diff_lst) > 1:
        merged_x="c:\\users\\asrilekh\\documents\\compare_csv\\"+(f1.split('\\')[len(f1.split('\\'))-1]).split('.')[0]+"_compare.xlsx"
        merged_x_wb = xlsxwriter.Workbook(merged_x)
        merged_sheet = merged_x_wb.add_worksheet("det_recds")
        for deli in range(0, len(diff_lst)):
            del_str = diff_lst[deli].split('!')
            for delsi in range(0, len(del_str)):
                value_w="N/A" if str(del_str[delsi].strip(' '))=='' else str(del_str[delsi].strip(' '))
                merged_sheet.write(deli, delsi, value_w)  ##format changed
        merged_x_wb.close()
            
            