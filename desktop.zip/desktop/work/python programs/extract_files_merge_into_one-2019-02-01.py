import os
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell
import xlsxwriter
from datetime import datetime
import os
import csv
import openpyxl
import pandas as pd
import numpy as np
import datetime
import time
from dateutil import parser
import redis
import re
import xlrd
import xlwt
from datetime import datetime
import datetime

files_list=list()
for root, dirs, files in os.walk("C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\tkumar51@corpimsvcs.com\\missing files"):
    for filename in files:
        print(filename)
        files_list.append("C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\tkumar51@corpimsvcs.com\\missing files\\"+filename)
h=0
comp_list=list()
prev_list=list()
cur_list=list()
# cdf = pd.read_excel(files_list[0], sheet_name="CBVetting",header=None,skiprows=1)
# print(cdf)
for fi in range(0,len(files_list)):
    print(files_list[fi])
    if h==0:
        cdf = pd.read_excel(files_list[fi], sheet_name="CBVetting",header=None,skiprows=1)
        h = 1
    else:
        cdf = pd.read_excel(files_list[fi], sheet_name="CBVetting",header=None,skiprows=2)

    s1 = ""
    for i in range(0, len(cdf)):
        for j in range(0, len(cdf.columns)):
            s1 = s1 + str(cdf.iloc[i, j]).replace('!','') + "!"

        # print(s1)
        comp_list.append(s1)
        s1 = ""
for i in range(0,len(comp_list)):
    s2=""
    s1=comp_list[i].split('!')
    if s1[0]=="2018-11":
        for j in range(0, len(s1)):
            s2=s2+s1[j]+"!"
        prev_list.append(s2)
    elif s1[0]=="2018-12":
        for j in range(0, len(s1)):
            s2=s2+s1[j]+"!"
        cur_list.append(s2)
    elif s1[0]=="Accting Period":
        for j in range(0, len(s1)):
            s2=s2+s1[j]+"!"
        prev_list.append(s2)
        cur_list.append(s2)
    else:
        print("not matched")

reamining_comb_wb = xlsxwriter.Workbook("C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\tkumar51@corpimsvcs.com\\missing files\\remaining_codes_complete.xlsx")
worksheet = reamining_comb_wb.add_worksheet()
for i in range(0,len(comp_list)):
    s=comp_list[i].split('!')

    for j in range(0,len(s)):
        worksheet.write(i, j, s[j].replace('nan',''))
        #worksheet.write(i, j, s[j])

reamining_comb_wb.close()
reamining_prev_wb = xlsxwriter.Workbook("C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\tkumar51@corpimsvcs.com\\missing files\\remaining_codes_prev.xlsx")
worksheet = reamining_prev_wb.add_worksheet()
for i in range(0,len(prev_list)):
    s=prev_list[i].split('!')

    for j in range(0,len(s)):
        worksheet.write(i, j, s[j].replace('nan',''))
        #worksheet.write(i, j, s[j])

reamining_prev_wb.close()


reamining_cur_wb = xlsxwriter.Workbook("C:\\Users\\asrilekh\\Documents\\MyJabberFiles\\tkumar51@corpimsvcs.com\\missing files\\remaining_codes_cur.xlsx")
worksheet = reamining_cur_wb.add_worksheet()
for i in range(0,len(cur_list)):
    s=cur_list[i].split('!')

    for j in range(0,len(s)):
        worksheet.write(i, j, s[j].replace('nan',''))
        #worksheet.write(i, j, s[j])

reamining_cur_wb.close()
