from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import sys
import smtplib

def alerts(subject,body,From,To_mails,*args):
    for mail in To_mails:
        msg = MIMEMultipart()
        msg['To'] = mail
        msg['From'] = From
        msg['Subject'] = subject
        body = body
        msg.attach(MIMEText(body, 'plain'))
        if args is not ():
            filename = args[1]
            result_path = args[0]
            attachment = open(result_path, "rb")
            p = MIMEBase('application', 'octet-stream')
            p.set_payload((attachment).read())
            encoders.encode_base64(p)
            p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
            msg.attach(p)
        s = smtplib.SMTP('mail25.uhc.com', 25)
        message = msg.as_string()
        s.sendmail(From,mail,message)
        s.quit()

alerts("subject","body","srilekha.anumula@optum.com","srilekha.anumula@optum.com")