from openpyxl import Workbook
wb = Workbook()
ws = wb.active
for i in range(10):
    c = ws['A%d' %(i+1)]
    c.value = 12
    c.number_format = "$###,###,###"
wb.save("test.xlsx")