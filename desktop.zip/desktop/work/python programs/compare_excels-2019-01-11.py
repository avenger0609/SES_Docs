import pandas as pd


first_fn="f1.xlsx"
second_fn="f1.xlsx"
cdf = pd.read_excel(first_fn, sheet_name="Data")
cdf1=pd.read_excel(second_fn,sheet_name="merged_x")

for i in range(0,len(cdf)):
    for j in range(0,len(cdf.columns)):
        if str(cdf.iloc[i, j])==str(cdf1.iloc[i, j]):
            test=1
        else:
            print("diff in"+str(i)+"th row"+str(j)+"th column"+cdf.iloc[i,j]+"-"+cdf1.iloc[i,j])

