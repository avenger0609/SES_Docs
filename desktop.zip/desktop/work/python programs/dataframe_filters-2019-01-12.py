import pandas as pd


xl=pd.ExcelFile("Book1.xlsx")
# df = xl.parse("Sheet1")
df = pd.read_excel("Book1.xlsx", sheet_name="Sheet1" )
s1=""
# df=df.filter(items=['Service Code','Service Unique Identifier'])
# df=df.filter(like='3002005',axis=0)
# print(df.iloc[0])
# print(str((df.head(n=1))))
df1=pd.DataFrame()
df1=df1.append((df.iloc[0]))
df1=df1.append((df.iloc[1]))
# df1=df1.drop(0)
# df1=df1.drop(1)
df1.sort_values(["Service Code"])
# print(str(len(df1)))
# print(str(len(df1.columns)))

df2=df[0:0]
for i in range(0,100000):
    df2=df2.append(df.iloc[0])
    print(str((i)))
df2=df[0:0]
print(str(len(df2)))
# print(df1)
for i in range(0, len(df1)):
    for j in range(0, len(df1.columns)):
        s1 = s1 + str(df1.iloc[i, j]) + "!"
        # if j == 21 or j == 1 or j == 2 or j == 10 or j == 20:
        #     s1 = s1 + str(df1.iloc[i, j]) + "!"
    print(str(i)+"-"+s1)
#     s1=""
# # df = df.sort_values(["Service Unique Identifier","Service Group Cost Center"])
# s1=""
# for i in range(0, len(df)):
#     for j in range(0, len(df.columns)):
#         if j==21 or j==1 or j==2 or j==10 or j==20:
#             s1 = s1 + str(df.iloc[i, j]) + "!"
#     print(str(i)+"-"+s1)
#     s1=""
