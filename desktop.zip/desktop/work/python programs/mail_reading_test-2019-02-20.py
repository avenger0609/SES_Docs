import win32com.client

outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

inbox = outlook.GetDefaultFolder(6) # "6" refers to the index of a folder - in this case,
                                    # the inbox. You can change that number to reference
                                    # any other folder
messages = inbox.Items
message = messages.GetLast()
print(message)
for message in messages:
    subject_content=message.subject
    if subject_content=="SMART Transport | Roster TAT, Cancellation TAT & Adhoc TAT":
        body_content = message.body
        print(body_content)   
    
    