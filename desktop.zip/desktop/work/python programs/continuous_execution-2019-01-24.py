import time
from datetime import datetime
import datetime
x=10
def execute():
    # print(str((datetime.datetime.now())))
    try:
        print(str(10/x))
    except:
        print("error")

while True:
    execute()
    x=x-1
    time.sleep(10)
