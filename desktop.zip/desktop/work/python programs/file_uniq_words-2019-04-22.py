import os 
os.chdir('C:\\users\\asrilekh\\desktop\\training examples')
file_names=list()
for entry in os.scandir('C:\\users\\asrilekh\\desktop\\training examples'):
    if entry.is_file() and str(entry.name).split('.')[1]=="txt":
        print(entry.name)
        file_names.append(entry.name)


x=list()## files from file
y=list()## unique words from file
for fn in file_names:
    file1 = open(fn,"r")
    for line in file1:
        x.append(line.rstrip(line[-1:]))
    file1.close()
for line in x:
    # print(line)
    xs=line.strip(' ').split(' ')
    for xsw in xs:
        y.append(xsw)
y = list(dict.fromkeys(y))
print(y)