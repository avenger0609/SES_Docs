import datetime
from datetime import datetime
date_str=datetime(2016,3,22)
print(date_str.strftime('%Y-%b-%d'))
exit