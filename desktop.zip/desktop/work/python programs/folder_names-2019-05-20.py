import os

MYDIR="C:\\Users\\asrilekh\\Desktop\\training examples\\WF2_Duration\\finalized"
folder_names = []
for entry_name in os.listdir(MYDIR):
    entry_path = os.path.join(MYDIR, entry_name)
    if os.path.isdir(entry_path):
        folder_names.append(entry_name)

print(str(folder_names))