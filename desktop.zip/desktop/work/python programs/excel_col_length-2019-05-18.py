import pandas as pd
import xlsxwriter
import os
from datetime import datetime

files_list=list()
for entry in os.scandir('C:\\Users\\asrilekh\\Desktop\\May-Test'):
    if entry.is_file():
        if "_test.xlsx" in str(entry.name).lower():
            files_list.append(entry.name)

for fname in files_list:
    print(fname)
    try:
        cdf = pd.read_excel('C:\\Users\\asrilekh\\Desktop\\May-Test\\'+fname,sheet_name="test",encoding = 'unicode_escape')
        # print(cdf.columns)
        converterS = {col: str for col in cdf.columns}
        # print(str(converterS))
        cdf = pd.read_excel('C:\\Users\\asrilekh\\Desktop\\May-Test\\'+fname,sheet_name="test",converters=converterS,encoding = 'unicode_escape')
        for i in range(0,len(cdf)):
            for j in range(0,len(cdf.columns)):
                if str(cdf.iloc[i,j]).lower()=='nan':
                    continue
                if (int(cdf.iloc[i,j]))>249:
                    print("row="+str(i+1)+",column="+str(j+1)+",data="+str(cdf.iloc[i,j]))
    except Exception as e:
        print(str(e))