import win32com.client
import win32com
import os
import sys

outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
folder = outlook.Folders("ITCB - IT Consumption and Billing")
inbox = folder.Folders("04. Ask")
msg = inbox.Items
msgs = msg.GetLast()
print(msgs)

for msg1 in msg:
    if msg1.UnRead==True:
        print(msg1.Subject)

# outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
# accounts= win32com.client.Dispatch("Outlook.Application").Session.Accounts

# def emailleri_al(folder):
#     messages = folder.Items
#     message = messages.GetLast()
#     print(message)    



# for account in accounts:
#     global inbox
#     inbox = outlook.Folders(account.DeliveryStore.DisplayName)
#     print("****Account Name**********************************")
#     print(account.DisplayName)
#     print(account.DisplayName)
#     print("***************************************************")
#     folders = inbox.Folders

#     for folder in folders:
#         print("****Folder Name**********************************")
#         print(folder)
#         print("*************************************************")
#         emailleri_al(folder)
#         a = len(folder.folders)

#         if a>0 :
#             global z
#             z = outlook.Folders(account.DeliveryStore.DisplayName).Folders(folder.name)
#             x = z.Folders
#             for y in x:
#                 emailleri_al(y)
#                 print("****Folder Name**********************************")
#                 print("..."+y.name,file=f)
#                 print("*************************************************")



# print("Finished Succesfully")