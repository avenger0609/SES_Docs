import pyhs2    
conn = pyhs2.connect(host='dbslp0503', port=10021, authMechanism='KERBEROS', user='mpawante', password ='Pulsar@143', database='nps')
# conn = pyhs2.connect(host='dbslp0307', port=10290, user='kmohan22', password ='Pulsar@143', database='pdi')
with conn.cursor() as cur:
    cur.execute("show tables")
    for i in cur.fetch():
        print(i)
#############################################
# from pyhive import hive
# # conn = hive.Connection(host="10.111.22.11", port=10000, username="user1" ,database="default")
# # conn = hive.Connection(host='dbslp0307', port=10290, username='kmohan22', password ='Pulsar@143', database='pdi')
# conn = hive.Connection(host='dbslp0503', port=10021, username='mpawante', database='nps')
# with conn.cursor() as cur:
#     cur.execute("show tables")
#     for i in cur.fetchall():
#         print(i)
# def __init__(self, host=None, port=None, username=None, database='default', auth=None,
#          configuration=None, kerberos_service_name=None, password=None,
#          thrift_transport=None):
#############################################

# from impala.dbapi import connect
# # conn = connect(host='my_host_name', port=10000, auth_mechanism='PLAIN')
# conn = connect(host="dbslp0503", port=10021, auth_mechanism='SASL')
# cursor = conn.cursor()
# cursor.execute('SHOW TABLES')
# print (cursor.description)  # prints the result set's schema
# for table in cursor.fetchall():
#     print (table)
# results = cursor.fetchall()
#######################################################