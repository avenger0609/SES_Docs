import datetime
from datetime import datetime
import calendar

def get_first_day(s1):

    # str1="2018-12"
    str1=s1
    date_str=datetime(str1.split('-')[0],str1.split('-')[1],1)
    return date_str.strftime('%Y-%m-%d')
