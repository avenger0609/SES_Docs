from flask import Flask
from flask import render_template,jsonify,request
import requests
from models import *
from knowledge_rev import *
import random 



app = Flask(__name__)
app.secret_key = '12345'

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/chat',methods=['POST'])
def chat():
    try:
        user_message = request.form["text"]
        user_message=str(user_message).replace('?','').strip(' ').lower()
        response = requests.get("http://localhost:5000/parse",params={"q":user_message})
        response = response.json()
        # print(response)
        entities = response.get("entities")
        intent = response.get("intent")
        text=response.get("text")
        print(str(response))
        print(str(response.get("text")))        
        print("Intent {}, Entities {}".format(intent['name'],entities))
        if intent['name'].upper().strip(' ')=='TIME':            
            response_text = claim_get_time(entities,text) 
        elif intent['name'].upper().strip(' ')=='STATUS':            
            response_text = claim_get_status(entities,text)
        elif intent['name'].lower().strip(' ')=='denial_reason':            
            response_text = claim_get_den_reason(entities,text)
        elif intent['name'].lower().strip(' ')=='resubmit':            
            response_text = claim_get_resubmit(entities,text)
        elif intent['name'].lower().strip(' ')=='adjusted_reason':            
            response_text = claim_get_adj_reason(entities,text)
        elif intent['name'].lower().strip(' ')=='adjusted_amount':            
            response_text = claim_get_adj_amount(entities,text)    # details of amount for claim which is adjusted not adjusted amount     
        elif intent['name'].upper() == "AFFIRM":
            response_text = affirm()
        elif intent['name'].upper() == "GREET":
            response_text = greeting()
        elif intent['name'].upper() == "GOODBYE":
            response_text = goodbye()
        elif intent['name'].lower().strip(' ')=='received_claim_cnt':            
            response_text = get_rcvd_cnt(entities,text) 
        elif intent['name'].lower().strip(' ')=='rcvd_bill_amt':            
            response_text = get_rcvd_bill_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='rcvd_paid_cnt':            
            response_text = get_rcvd_paid_cnt(entities,text)    
        elif intent['name'].lower().strip(' ')=='rcvd_paid_amt':            
            response_text = get_rcvd_paid_amt(entities,text)    
        elif intent['name'].lower().strip(' ')=='rcvd_submsn_mode':            
            response_text = get_rcvd_submsn_mode(entities,text)   
        elif intent['name'].lower().strip(' ')=='denied_claim_cnt':            
            response_text = get_denied_claim_cnt(entities,text)
        elif intent['name'].lower().strip(' ')=='dend_bill_amt':            
            response_text = get_dend_bill_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='dend_submsn_mode':            
            response_text = get_dend_submsn_mode(entities,text)
        elif intent['name'].lower().strip(' ')=='prtl_dend_cnt':            
            response_text = get_prtl_dend_cnt(entities,text)
        elif intent['name'].lower().strip(' ')=='prtl_dend_billed_amt':            
            response_text = get_prtl_dend_billed_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='prtl_dend_paid_amt':            
            response_text = get_prtl_dend_paid_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='prtl_dend_submsn_mode':            
            response_text = get_prtl_dend_submsn_mode(entities,text)
        elif intent['name'].lower().strip(' ')=='adj_claims_cnt':            
            response_text = get_adj_claims_cnt(entities,text)   
        elif intent['name'].lower().strip(' ')=='adj_claims_paid_amt':            
            response_text = get_adj_claims_paid_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='adj_claims_submsn_mode':            
            response_text = get_adj_claims_submsn_mode(entities,text)
        elif intent['name'].lower().strip(' ')=='adj_claims_billed_amt':            
            response_text = get_adj_claims_billed_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='hgh_dlr_recvd_bil_amt':            
            response_text = get_hgh_dlr_recvd_bil_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='hgh_dlr_recvd_paid_amt':            
            response_text = get_hgh_dlr_recvd_paid_amt(entities,text)
        elif intent['name'].lower().strip(' ')=='hgh_dlr_submsn_mode_recvd':            
            response_text = get_hgh_dlr_submsn_mode_recvd(entities,text)
        elif intent['name'].lower().strip(' ')=='hgh_dlr_recvd_paid_cnt':            
            response_text = get_hgh_dlr_recvd_paid_cnt(entities,text)
        elif intent['name'].lower().strip(' ')=='hgh_dlr_recvd_cnt':            
            response_text = get_hgh_dlr_recvd_cnt(entities,text)
        else:
            response_text = "Sorry, can not help at this time"
        return jsonify({"status":"success","response":response_text})
        #return 'OK'
    except Exception as e:
        print(e)
        return jsonify({"status":"success","response":"Sorry I am not trained to do that yet..."})

app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(port=8080)
