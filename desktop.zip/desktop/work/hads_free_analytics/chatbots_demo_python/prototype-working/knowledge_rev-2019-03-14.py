##dict of response for each type of intent
import random
from sqlite_python import *
from duckling_wrapper import *

GREETING_RESPONSES = ["sup bro", "hey", "Hi", "how can i help?","hello"]
GOODBYE_RESPONSES = ["bye", "cya", "take care", "good", "bye bye","Bye..Tc"]
AFFIRM_RESPONSES = ["indeed", "OK", "that's right", "great", "cool"]

##########
claim_numbers_req=list()
dt_req=list()
##########

def greeting():
    """If any of the words in the user's input was a greeting, return a greeting response"""
    return random.choice(GREETING_RESPONSES)

def goodbye():
    """If any of the words in the user's input was a goodbye, return a goddbye response"""
    return random.choice(GOODBYE_RESPONSES)

def affirm():
    """If any of the words in the user's input was a goodbye, return a goddbye response"""
    return random.choice(AFFIRM_RESPONSES)

def claim_get_time(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_processing_time(str(claim_num)))            
    print(res)            
    return res

def claim_get_status(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_status(str(claim_num)))
    print(res)            
    return res

def claim_get_den_reason(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_denial_reason(str(claim_num)))
    print(res)            
    return res

def claim_get_resubmit(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_resubmit_proc())
    print(res)            
    return res

def claim_get_adj_reason(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_adjustment_reason(str(claim_num)))
    print(res)            
    return res

def claim_get_adj_amount(entities,text):    # details of amount for claim which is adjusted not adjusted amount    
    claim_num=0
    claim_paid_amt_ind=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
        if e['entity'].upper()=='action_on_claim'.upper():        
            claim_paid_amt_ind=1
            
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    if claim_paid_amt_ind==1:
        res=str(get_adj_amt_paid(str(claim_num)))
        print(res)            
        return res
    else:
        res=str(get_adjusted_amt(str(claim_num)))
        print(res)            
        return res

def get_rcvd_cnt(entities,text):    
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_rcvd_cnt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_received_claims(dt)        
    else:
        dt_req.append(dt)
        res=get_received_claims(dt)        
    print(res)
    return res.replace('}','')

def get_rcvd_bill_amt(entities,text):    
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_rcvd_bill_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_bill_amt_recvd(dt)
    else:
        dt_req.append(dt)
        res=get_bill_amt_recvd(dt)
    print(res)
    return res.replace('}','')


def get_rcvd_paid_cnt(entities,text):    
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_rcvd_paid_cnt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_paid_claims_recvd(dt)
    else:
        dt_req.append(dt)
        res=get_paid_claims_recvd(dt)
    print(res)
    return res.replace('}','')

def get_rcvd_paid_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_rcvd_paid_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_paid_amt_recvd(dt)
    else:
        dt_req.append(dt)
        res=get_paid_amt_recvd(dt)
    print(res)
    return res.replace('}','')


def get_rcvd_submsn_mode(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    # dt=test1(crctd_ip)
    print("get_rcvd_submsn_mode")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_mode_submission_recvd(dt)
    else:
        dt_req.append(dt)
        res=get_mode_submission_recvd(dt)
        
    print(res)
    return res.replace('}','')

def get_denied_claim_cnt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_denied_claim_cnt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_denied_claims(dt)
    else:
        dt_req.append(dt)
        res=get_denied_claims(dt)
    print(res)
    return res.replace('}','')

def get_dend_bill_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_dend_bill_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_bill_amt_dend(dt)
    else:
        dt_req.append(dt)
        res=get_bill_amt_dend(dt)
    print(res)
    return res

def get_dend_submsn_mode(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_dend_submsn_mode")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_mode_submission_dend(dt)
    else:
        dt_req.append(dt)
        res=get_mode_submission_dend(dt)
    print(res)
    return res.replace('}','')

def get_prtl_dend_cnt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_prtl_dend_cnt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_partial_dend_claims(dt)
    else:
        dt_req.append(dt)
        res=get_partial_dend_claims(dt)
    print(res)
    return res.replace('}','')

def get_prtl_dend_billed_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_prtl_dend_billed_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_bill_amt_partial_dend(dt)
    else:
        dt_req.append(dt)
        res=get_bill_amt_partial_dend(dt)
    print(res)
    return res.replace('}','')

def get_prtl_dend_paid_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_prtl_dend_paid_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_paid_amt_partial_dend(dt)
    else:
        dt_req.append(dt)
        res=get_paid_amt_partial_dend(dt) # needs to be implemented
    print(res) 
    return res.replace('}','')

def get_prtl_dend_submsn_mode(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_prtl_dend_submsn_mode")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_mode_submission_prtl_dend(dt)
    else:
        dt_req.append(dt)
        res=get_mode_submission_prtl_dend(dt)
    print(res)
    return res.replace('}','')

def get_adj_claims_cnt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_adj_claims_cnt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_adjstd_claims(dt)
    else:
        dt_req.append(dt)
        res=get_adjstd_claims(dt)
    print(res)
    return res.replace('}','')

def get_adj_claims_paid_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_adj_claims_paid_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_paid_amt_adjstd(dt)
    else:
        dt_req.append(dt)
        res=get_paid_amt_adjstd(dt)
    print(res)
    return res.replace('}','')

def get_adj_claims_submsn_mode(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_adj_claims_submsn_mode")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_mode_submission_adjstd(dt)
    else:
        dt_req.append(dt)
        res=get_mode_submission_adjstd(dt)
    print(res)
    return res.replace('}','')

def get_adj_claims_billed_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_adj_claims_billed_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_bill_amt_adjstd(dt)
    else:
        dt_req.append(dt)
        res=get_bill_amt_adjstd(dt)
    print(res)
    return res.replace('}','')


def get_hgh_dlr_recvd_bil_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_hgh_dlr_recvd_bil_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_bill_amt_hgh_dlr(dt)
    else:
        dt_req.append(dt)
        res=get_bill_amt_hgh_dlr(dt)
    print(res)
    return res.replace('}','')

def get_hgh_dlr_recvd_paid_amt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_hgh_dlr_recvd_paid_amt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_paid_amt_hgh_dlr(dt)
    else:
        dt_req.append(dt)
        res=get_paid_amt_hgh_dlr(dt)
    print(res)
    return res.replace('}','')

def get_hgh_dlr_submsn_mode_recvd(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_hgh_dlr_submsn_mode_recvd")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_mode_submsn_hgh_dlr(dt)
    else:
        dt_req.append(dt)
        res=get_mode_submsn_hgh_dlr(dt)
    print(res)
    return res.replace('}','')

def get_hgh_dlr_recvd_paid_cnt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_hgh_dlr_recvd_paid_cnt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_paid_claims_hgh_dlr(dt)
    else:
        dt_req.append(dt)
        res=get_paid_claims_hgh_dlr(dt)
    print(res)
    return res.replace('}','')

def get_hgh_dlr_recvd_cnt(entities,text):
    crctd_ip=(text)
    dt=time_extract(crctd_ip)
    print("get_hgh_dlr_recvd_cnt")
    if len(dt)==0:
        if len(dt_req)==0:
            res="Please make sure you entered correct range of time period"
        else:
            dt=dt_req[len(dt_req)-1]
            res=get_high_dollar_claims(dt)
    else:
        dt_req.append(dt)
        res=get_high_dollar_claims(dt)
    print(res)
    return res.replace('}','')

