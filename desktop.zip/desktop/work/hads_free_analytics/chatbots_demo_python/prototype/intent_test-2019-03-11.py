import time
from dateutil import parser
import redis
import re
import xlrd
import openpyxl
from openpyxl.styles import Alignment
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl.styles import colors
from openpyxl.cell import Cell
import xlsxwriter
from datetime import datetime
import os
import csv
import openpyxl
import pandas as pd
import numpy as np
import datetime
import time
from dateutil import parser
import redis
import re
import xlrd
import xlwt
import xlsxwriter
from datetime import datetime
import os
import csv
import openpyxl
import pandas as pd
import numpy as np
from flask import Flask
from flask import render_template,jsonify,request
import requests
from models import *
from knowledge import *
import random

def int_test():
    TCS_filename="c:\\users\\asrilekh\\downloads\\sample_Data_claims_1.xlsx"
    cdf = pd.read_excel(TCS_filename)
    op_lst=list()
    for i in range(0, len(cdf)):
        print(str(i))
        user_message = cdf.iloc[i,0]        
        user_message=str(user_message).replace('?','').strip(' ').lower()
        response = requests.get("http://localhost:5000/parse",params={"q":user_message})
        response = response.json()
        intent = response.get("intent")
        entities = response.get("entities")
        s=""
        for j in range(0,len(entities)):
            s=s+entities[j]['entity']+","
        op_lst.append(user_message+"!"+cdf.iloc[i,1]+"!"+intent['name']+"!"+s)
    ############################
    merged_x="c:\\users\\asrilekh\\downloads\\ouput_intent_entity.xlsx"
    merged_x_wb = xlsxwriter.Workbook(merged_x)
    merged_sheet = merged_x_wb.add_worksheet("det_recds")
    for deli in range(0, len(op_lst)):
        del_str = op_lst[deli].split('!')
        for delsi in range(0, len(del_str)):
            value_w="N/A" if str(del_str[delsi].strip(' '))=='' else str(del_str[delsi].strip(' '))
            merged_sheet.write(deli, delsi, value_w)  ##format changed
    merged_x_wb.close()
    ############################
    print("completed")
if __name__ == "__main__":
    int_test()