import sqlite3
from sqlite3 import Error
from datetime import datetime

def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by the db_file
    :param db_file: database file
    :return: Connection object or None
    """
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)

    return None


def get_status(value1):

    try:
        
        print("get_status")
        database = "claims.db"
        claim_num_rec="'"+str(value1)+"'"
        print(claim_num_rec)
        conn = create_connection(database)
        cur = conn.cursor()
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec)
        all_rows=cur.fetchall()
        n_records=str(all_rows[0][0])
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec+" and claim_denial_ind='1'")
        all_rows=cur.fetchall()
        n_denial_recds=str(all_rows[0][0])
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec+" and claim_adj_ind='1'")
        all_rows=cur.fetchall()
        n_adj_recds=str(all_rows[0][0])

        if int(n_records)==int(n_denial_recds) and int(n_records)!=0:
            print("1")
            cur.execute("select sum(amt_billed) from claims_sample where root_claim_num="+claim_num_rec+"")
            denial_amt=str(round(float(str((cur.fetchall())[0][0])),2))
            print(denial_amt)
            cur.execute("select max(received_date) from claims_sample where root_claim_num="+claim_num_rec+" ")
            t=str(cur.fetchall()[0][0])        
            date_str=datetime(int(t.split('-')[0]),int(t.split('-')[1]),int((t.split('-')[2]).split(' ')[0]))
            t=(date_str.strftime('%Y-%b-%d'))
            status="Your claim has been completely denied for the amount "+denial_amt+" on "+t.split('-')[2]+"th of "+t.split('-')[1] +", "+t.split('-')[0]+"!Why was my Claim Denied!How can I resubmit my Claim!What's the time taken to process my claim"
            print(status)
            return(status)
        elif int(n_denial_recds)==0 and int(n_adj_recds)==0 and int(n_records)!=0:
            print("2")
            cur.execute("select sum(amt_paid) from claims_sample where root_claim_num="+claim_num_rec+"")
            paid_amt=str(round(float(str((cur.fetchall())[0][0])),2))
            print(paid_amt)
            cur.execute("select max(received_date) from claims_sample where root_claim_num="+claim_num_rec+" ")
            t=str(cur.fetchall()[0][0])        
            date_str=datetime(int(t.split('-')[0]),int(t.split('-')[1]),int((t.split('-')[2]).split(' ')[0]))
            t=(date_str.strftime('%Y-%b-%d'))
            status="Your claim has been completely paid for the amount "+paid_amt+" on "+t.split('-')[2]+"th of "+t.split('-')[1] +", "+t.split('-')[0]+"!What's the time taken to process my claim"
            print(status)
            return(status)
        elif int(n_denial_recds)==0 and int(n_adj_recds) > 0 and int(n_records)!=0:
            print("3")
            cur.execute("select sum(amt_paid) from claims_sample where root_claim_num="+claim_num_rec+"")
            paid_amt=str(round(float(str((cur.fetchall())[0][0])),2))
            print(paid_amt)
            cur.execute("select max(received_date) from claims_sample where root_claim_num="+claim_num_rec+" ")
            t=str(cur.fetchall()[0][0])        
            date_str=datetime(int(t.split('-')[0]),int(t.split('-')[1]),int((t.split('-')[2]).split(' ')[0]))
            t=(date_str.strftime('%Y-%b-%d'))##max received date
            status="Your claim has been paid for the amount "+paid_amt+" on "+t.split('-')[2]+"th of "+t.split('-')[1] +", "+t.split('-')[0]+" with adjustments!Why was my Claim Adjusted!What is Adjusted amount!What is the amount paid towards Claim!What's the time taken to process my claim"
            print(status)
            return(status)
        elif int(n_denial_recds)>0 and int(n_records)!=0:
            print("4")
            cur.execute("select sum(amt_paid) from claims_sample where root_claim_num="+claim_num_rec+"")
            paid_amt=(round(float(str((cur.fetchall())[0][0])),2))
            print(paid_amt)
            cur.execute("select sum(amt_billed) from claims_sample where root_claim_num="+claim_num_rec+"")
            billed_amt=(round(float(str((cur.fetchall())[0][0])),2))
            print(billed_amt)
            denied_amt=str(billed_amt-paid_amt)
            cur.execute("select max(received_date) from claims_sample where root_claim_num="+claim_num_rec+" ")
            t=str(cur.fetchall()[0][0])        
            date_str=datetime(int(t.split('-')[0]),int(t.split('-')[1]),int((t.split('-')[2]).split(' ')[0]))
            t=(date_str.strftime('%Y-%b-%d'))##max received date
            status="Your claim has been partially denied with "+str(denied_amt) +" being denied out of "+str(billed_amt)+" on "+t.split('-')[2]+"th of "+t.split('-')[1] +", "+t.split('-')[0]+"!Why is my claim partially denied!How can I resubmit my claim!What's the time taken to process my claim"
            print(status)
            return(status)
        elif int(n_records)==0:
            print("5")
            status="Could not find claim with Claim Number "+claim_num_rec+", Please make sure you entered correct details "
            print(status)
            return(status)
        else:
            print(str(n_records))
            print(str(n_adj_recds))
            print(str(n_denial_recds))

        conn.commit()
        conn.close()
    except:
        return "Sorry! Could not fetch you results at this time"


def get_processing_time(value1):

    try:
        print("get_processing_time")
        database = "claims.db"
        claim_num_rec="'"+str(value1)+"'"
        print(claim_num_rec)
        conn = create_connection(database)
        cur = conn.cursor()
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec)
        all_rows=cur.fetchall()
        n_records=str(all_rows[0][0])
        if int(n_records)==0:
            proc_time="Could not find claim with Claim Number "+claim_num_rec+", Please make sure you entered correct details "
            print(proc_time)
            return(proc_time)
        elif int(n_records)>0:
            cur.execute("select max(fromdatetopaiddate) from claims_sample where root_claim_num="+claim_num_rec)
            all_rows=cur.fetchall()
            n_p_days=str(all_rows[0][0])
            proc_time="End to End processing time for your claim is "+n_p_days+" days"##+"!Give me processing time for this period"
            cur.execute("select max(fromdatetoreceiveddate) from claims_sample where root_claim_num="+claim_num_rec)
            all_rows=cur.fetchall()
            n_p_days=str(all_rows[0][0])
            proc_time=proc_time+"\n Provider claim submission time for your claim is "+n_p_days+" days"
            cur.execute("select max(receiveddatetopaiddate) from claims_sample where root_claim_num="+claim_num_rec)
            all_rows=cur.fetchall()
            n_p_days=str(all_rows[0][0])
            proc_time=proc_time+"\n UHC Processing time for your claim is "+n_p_days+" days"
            print(proc_time)
            return(proc_time)
        
        conn.commit()
        conn.close()
    except:
        return "Sorry! Could not fetch you results at this time"

def get_denial_reason(value1):

    try:
        print("get_denial_reason")
        database = "claims.db"
        claim_num_rec="'"+str(value1)+"'"
        print(claim_num_rec)
        conn = create_connection(database)
        cur = conn.cursor()
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec)
        all_rows=cur.fetchall()
        n_records=str(all_rows[0][0])
        if int(n_records)==0:
            denial_reason="Could not find claim with Claim Number "+claim_num_rec+", Please make sure you entered correct details "
            print(denial_reason)
            return(denial_reason)
        elif int(n_records) > 0:
            cur.execute("select distinct denial_full_reasons,denial_description from claims_sample where root_claim_num="+claim_num_rec+" and claim_denial_ind='1'")
            all_rows=cur.fetchall()
            n_d_records=len(all_rows)
            if n_d_records > 0:
                denial_reason="Your claim is denied due to following reasons<br><ul>"
                s1=""
                for row in all_rows:                
                    s1=s1+"<li>"+"Denial Code "+row[0]+" with description as "+row[1]+"</li>"
                denial_reason=denial_reason+s1+"</ul>" 
                denial_reason=denial_reason+"!How can I resubmit my Claim!What's the processing time of my Claim" 
                print(denial_reason)
                return(denial_reason)
            else:
                denial_reason="Your Claim is not denied"
                print(denial_reason)
                return(denial_reason)
        conn.commit()
        conn.close()
    except:
        return "Sorry! Could not fetch you results at this time"

def get_resubmit_proc():

    try:
        print("get_resubmit_proc")
        database = "claims.db"
        conn = create_connection(database)
        cur = conn.cursor()    
        cur.execute("select distinct abbreviated_final_category from claims_sample where abbreviated_final_category<>'?'")
        all_rows=cur.fetchall()    
        if len(all_rows) > 0:
            resubmit_proc="Please keep following things in check while resubmitting your Claim<br><ul>"
            s1=""
            for row in all_rows:
                s1=s1+"<li>"+row[0]+"</li>"
            resubmit_proc=resubmit_proc+s1+"</ul>"
            print(resubmit_proc)
            return(resubmit_proc)
        conn.commit()
        conn.close()
    except:
        return "Sorry! Could not fetch you results at this time"

def get_adjustment_reason(value1):

    try:
        print("get_adjustment_reason")
        database = "claims.db"
        claim_num_rec="'"+str(value1)+"'"
        print(claim_num_rec)
        conn = create_connection(database)
        cur = conn.cursor()
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec)
        all_rows=cur.fetchall()
        n_records=str(all_rows[0][0])
        if int(n_records)==0:
            adj_reason="Could not find claim with Claim Number "+claim_num_rec+", Please make sure you entered correct details "
            print(adj_reason)
            return(adj_reason)
        elif int(n_records) > 0:
            cur.execute("select distinct adjustment_reasons,adjustment_description from claims_sample where root_claim_num="+claim_num_rec+" and claim_adj_ind='1'")
            all_rows=cur.fetchall()
            n_d_records=len(all_rows)
            if n_d_records > 0:
                adj_reason="Your claim is adjusted due to following reasons<br><ul>"
                s1=""
                for row in all_rows:                
                    s1=s1+"<li>"+"Adjustment Code "+row[0]+" with description as "+row[1]+"</li>"
                adj_reason=adj_reason+s1+"</ul>" 
                adj_reason=adj_reason+"!What's the processing time of my Claim!What's the Adjsuted Amount!What's the amount paid towards claim" 
                print(adj_reason)
                return(adj_reason)
            else:
                adj_reason="Your Claim is not Adjusted"
                print(adj_reason)
                return(adj_reason)
        conn.commit()
        conn.close()
    except:
        return "Sorry! Could not fetch you results at this time"

def get_adjusted_amt(value1):
    try:
        print("get_adjusted_amt")
        database = "claims.db"
        claim_num_rec="'"+str(value1)+"'"
        print(claim_num_rec)
        conn = create_connection(database)
        cur = conn.cursor()
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec)
        all_rows=cur.fetchall()
        n_records=str(all_rows[0][0])
        if int(n_records)==0:
            adj_amt_paid="Could not find claim with Claim Number "+claim_num_rec+", Please make sure you entered correct details "
            print(adj_amt_paid)
            return(adj_amt_paid)
        else:
            cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec+" and claim_adj_ind='1'")
            all_rows=cur.fetchall()
            n_d_records=len(all_rows)
            if n_d_records > 0:
                cur.execute("select sum(amt_paid) from claims_sample where root_claim_num="+claim_num_rec+" and claim_adj_ind='1'")
                paid_amt=(round(float(str((cur.fetchall())[0][0])),2))            
                cur.execute("select sum(amt_billed) from claims_sample where root_claim_num="+claim_num_rec+" and claim_adj_ind='1'")
                billed_amt=(round(float(str((cur.fetchall())[0][0])),2))
                adj_paid_amt=str(billed_amt-paid_amt)
                
                adj_amt_paid="An adjustment of "+str(adj_paid_amt)+" was made toward your claim!Why was my Claim Adjusted!How much amount was paid after adjustments!What's the processing time of my claim"
                print(adj_amt_paid)
                return(adj_amt_paid)
            else:
                adj_amt_paid="Your Claim is not Adjusted"
                print(adj_amt_paid)
                return(adj_amt_paid)
        conn.commit()
        conn.close()
    except:
        return "Sorry! Could not fetch you results at this time"

def get_adj_amt_paid(value1):
    try:
        print("get_adj_amt_paid")
        database = "claims.db"
        claim_num_rec="'"+str(value1)+"'"
        print(claim_num_rec)
        conn = create_connection(database)
        cur = conn.cursor()
        cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec)
        all_rows=cur.fetchall()
        n_records=str(all_rows[0][0])
        if int(n_records)==0:
            adj_amt_paid="Could not find claim with Claim Number "+claim_num_rec+", Please make sure you entered correct details "
            print(adj_amt_paid)
            return(adj_amt_paid)
        else:
            cur.execute("select count(*) from claims_sample where root_claim_num="+claim_num_rec+" and claim_adj_ind='1'")
            all_rows=cur.fetchall()
            n_d_records=len(all_rows)
            if n_d_records > 0:
                cur.execute("select sum(amt_paid) from claims_sample where root_claim_num="+claim_num_rec+" and claim_adj_ind='1'")
                paid_amt=(round(float(str((cur.fetchall())[0][0])),2))
                adj_amt_paid=str(paid_amt)+" was paid for the claim after adjustments!Why was my Claim Adjusted!How much amount was adjusted!What's the processing time of my claim"
                print(adj_amt_paid)
                return(adj_amt_paid)
            else:
                adj_amt_paid="Your Claim is not Adjusted"
                print(adj_amt_paid)
                return(adj_amt_paid)
        conn.commit()
        conn.close()
    except:
        return "Sorry! Could not fetch you results at this time"

def main():
    get_status(123)
    get_adjusted_amt(123)
    get_adjustment_reason(123)
    get_denial_reason(1123)
    get_processing_time(1223)
    get_resubmit_proc()
    get_adj_amt_paid(7454335711)
    



if __name__ == '__main__':
    main()





