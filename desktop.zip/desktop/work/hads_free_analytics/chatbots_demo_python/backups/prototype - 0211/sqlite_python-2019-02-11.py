import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by the db_file
    :param db_file: database file
    :return: Connection object or None
    """
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)

    return None


def select_all_tasks(conn):
    """
    Query all rows in the tasks table
    :param conn: the Connection object
    :return:
    """
    # database = "C:\\users\\asrilekh\\downloads\\claims.db"
    database = "claims.db"
    # create a database connection
    conn = create_connection(database)
    cur = conn.cursor()
    cur.execute("SELECT * FROM claims")

    rows = cur.fetchall()

    for row in rows:
        print(row)


def slect_status_by_claim_number(claim_number):
    """
    Query tasks by priority
    :param conn: the Connection object
    :param priority:
    :return:
    """
    # database = "C:\\users\\asrilekh\\downloads\\claims.db"
    database = "claims.db"

    # create a database connection
    conn = create_connection(database)
    cur = conn.cursor()
    cur.execute("SELECT claims.status FROM claims WHERE CLAIM_NUMBER=?", (claim_number,))

    rows = list(cur.fetchall())
    for row in rows:
        if row[0]==None:
            return "NE"
        else:
            return (str(row[0]))

    # for row in rows:
    #     print(str(row[0]))


def main():
    # database = "C:\\users\\asrilekh\\downloads\\claims.db"
    database = "claims.db"

    # create a database connection
    conn = create_connection(database)
    with conn:
        print("1. Query task by priority:")
        select_task_by_priority(conn,1101)

        print("2. Query all tasks")
        select_all_tasks(conn)


if __name__ == '__main__':
    main()
