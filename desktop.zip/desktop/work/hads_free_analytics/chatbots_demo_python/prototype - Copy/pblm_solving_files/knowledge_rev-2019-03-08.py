##dict of response for each type of intent
import random
from pblm_solving_files.sqlite_python import *




GREETING_RESPONSES = ["sup bro", "hey", "Hi", "how can i help?","hello"]
GOODBYE_RESPONSES = ["bye", "cya", "take care", "good", "bye bye","Bye..Tc"]
AFFIRM_RESPONSES = ["indeed", "OK", "that's right", "great", "cool"]

##########
claim_numbers_req=list()
##########

def greeting():
    """If any of the words in the user's input was a greeting, return a greeting response"""
    return random.choice(GREETING_RESPONSES)

def goodbye():
    """If any of the words in the user's input was a goodbye, return a goddbye response"""
    return random.choice(GOODBYE_RESPONSES)

def affirm():
    """If any of the words in the user's input was a goodbye, return a goddbye response"""
    return random.choice(AFFIRM_RESPONSES)

def claim_get_time(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_processing_time(str(claim_num)))            
    print(res)            
    return res

def claim_get_status(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_status(str(claim_num)))
    print(res)            
    return res

def claim_get_den_reason(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_denial_reason(str(claim_num)))
    print(res)            
    return res

def claim_get_resubmit(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_resubmit_proc())
    print(res)            
    return res

def claim_get_adj_reason(entities,text):
    claim_num=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    res=str(get_adjustment_reason(str(claim_num)))
    print(res)            
    return res

def claim_get_adj_amount(entities,text):    # details of amount for claim which is adjusted not adjusted amount    
    claim_num=0
    claim_paid_amt_ind=0
    for e in entities:
        if e['entity'].upper()=='Claim_Number'.upper():        
            claim_num=e['value']
        if e['entity'].upper()=='action_on_claim'.upper():        
            claim_paid_amt_ind=1
            
    if claim_num==0:
        claim_num=claim_numbers_req[len(claim_numbers_req)-1]
    else:
        claim_numbers_req.append(str(claim_num) )
        print(str(claim_numbers_req))
    if claim_paid_amt_ind==1:
        res=str(get_adj_amt_paid(str(claim_num)))
        print(res)            
        return res
    else:
        res=str(get_adjusted_amt(str(claim_num)))
        print(res)            
        return res



        


