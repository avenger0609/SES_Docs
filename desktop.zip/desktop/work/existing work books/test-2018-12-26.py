from openpyxl import load_workbook
wb2 = load_workbook('template.xlsx')
wb2.create_sheet('sid1')
wb2.save('template.xlsx')