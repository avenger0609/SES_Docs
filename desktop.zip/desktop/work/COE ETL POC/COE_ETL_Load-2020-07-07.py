
import pandas as pd
from pymongo import MongoClient
import pymongo
import time
import datetime
import sqlite3
import datetime


def MongoLoad(df):

    time1 = datetime.datetime.now()    
    myclient = pymongo.MongoClient(u"mongodb://apsrp03693.uhc.com:27017")
    # print(myclient.list_database_names())
    mydb = myclient["COE_ETL_POC"]
    # print(mydb.list_collection_names())
    mycol = mydb["COE_WOM_US_COVID_OUTPUT_TEST"]
    if "COE_WOM_US_COVID_OUTPUT_TEST" in mydb.list_collection_names():
        mycol.drop()
    mycol = mydb["COE_WOM_US_COVID_OUTPUT_TEST"]
    s=mycol.insert_many(df.to_dict('records'))
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to load "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
    # print("loaded to mongo db collection")

def Flat_file_load(df):
    time1 = datetime.datetime.now()    
    df.to_excel(r'C:\users\asrilekh\documents\COE_OP_test.xlsx',index=False)
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to load "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
    # print("loaded to Excel file")

def SQL_load(df):
    time1 = datetime.datetime.now()  
    db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
    con = sqlite3.connect(db_file)
    df.to_sql("covid_output_0707", con, if_exists='replace')
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to load "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
    # print("loaded to SQLite")

def SQL_Inc_load(df):
    time1 = datetime.datetime.now()  
    db_file = "C:\\Users\\asrilekh\\Documents\\ITBM_Montly_Refresh\\Refresh.db"
    con = sqlite3.connect(db_file)
    df.to_sql("covid_output_0707", con, if_exists='append')
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to load "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
    # print("loaded to SQLite")

