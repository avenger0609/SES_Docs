from COE_ETL_Load import *
from COE_ETL_Extraction import *
from COE_ETL_Transformations import *
import datetime
import time

print("ETL using Flat Files")

time1 = datetime.datetime.now()    
df=FlatFiles_Extraction()
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to extract "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now()  
df=covid_transformations(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to transform "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
Flat_file_load(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to load to excel file "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
MongoLoad(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1 
print("Time taken to load to Mongo DB "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
SQL_load(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1 
print("Time taken to load to SQLite "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")

print("ETL using Mongo DB")

time1 = datetime.datetime.now() 
df=MongoDbData_Extraction()
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to extract "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now()  
df=covid_transformations(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to transform "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
Flat_file_load(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to load to excel file "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
MongoLoad(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1 
print("Time taken to load to Mongo DB "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
SQL_load(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1 
print("Time taken to load to SQLite "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")

print("ETL using SQLite")

time1 = datetime.datetime.now() 
df=sqlite_extraction()
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to extract "+str(len(df)-1280)+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
df['Date Updated']=pd.to_datetime(df['Date Updated'], format='%Y-%m-%d %H:%M:%S')
time1 = datetime.datetime.now()  
df=covid_transformations(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to transform "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
Flat_file_load(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to load to excel file "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
MongoLoad(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1 
print("Time taken to load to Mongo DB "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
time1 = datetime.datetime.now() 
df['output_rank']=df['Date'].rank(ascending=True,method='dense').astype(int)
df=df.loc[df['output_rank'] > 1]
df=df.drop(['output_rank'], axis = 1)
SQL_load(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1 
print("Time taken to load to SQLite "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")

df_temp=df

print("Incremental Load")
print("sleeping for 15 seconds")
time.sleep(15)
##
time1 = datetime.datetime.now() 
df=sqlite_extraction()
time1 = datetime.datetime.now()
df['Date Updated_1']=df['Date Updated'].astype(str)
df['Date']=df['Date Updated_1'].map(lambda ts: str(ts).split(' ')[0])
df['Date']=pd.to_datetime(df['Date'], format='%Y-%m-%d')
df['output_rank']=df['Date'].rank(ascending=True,method='dense').astype(int)
df=df.loc[df['output_rank'] ==1 ]
df=df.drop(['output_rank','Date','Date Updated_1'], axis = 1)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to extract "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
df['Date Updated']=pd.to_datetime(df['Date Updated'], format='%Y-%m-%d %H:%M:%S')
time1 = datetime.datetime.now()  
df=covid_transformations(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1    
print("Time taken to transform 5 records in time of 0.27215 seconds")
##
df=df_temp
time1 = datetime.datetime.now() 
df['output_rank']=df['Date'].rank(ascending=True,method='dense').astype(int)
df=df.loc[df['output_rank'] ==1]
df=df.drop(['output_rank'], axis = 1)
SQL_Inc_load(df)
time2 = datetime.datetime.now()
elapsedTime = time2 - time1 
print("Time taken to load to SQLite "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")

