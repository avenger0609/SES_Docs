import pandas as pd
from pymongo import MongoClient
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
from urllib.parse import quote_plus
import csv
import sqlite3
import datetime
from dateutil.relativedelta import relativedelta

def Remove_Dup(df):
    
    dup_before=len(df)
    time1 = datetime.datetime.now()        
    df=df.drop_duplicates()
    dup_after=len(df)
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to remove duplicates of "+str(dup_after-dup_before)+" records in time of "+str(elapsedTime.total_seconds())+" seconds")
    return df


def covid_transformations(df):

    ## Value Mapper

    time1 = datetime.datetime.now()
    df['USA State']=df['USA State'].map(lambda ts: 'Noise' if str(ts)=='USA Total' or str(ts)=='Total:' else ts )
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken for value mapper of "+str(len(df))+" records in time of "+str(elapsedTime.total_seconds())+" seconds")

    ## filter

    time1 = datetime.datetime.now()
    dup_before=len(df)
    df=df.loc[df['USA State']!='Noise']
    dup_after=len(df)
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to filter "+str(dup_after-dup_before)+" records from "+str(dup_before)+" in time of "+str(elapsedTime.total_seconds())+" seconds")

    df_state_abb=pd.read_excel(r'c:\users\asrilekh\downloads\State Abbreviations.xlsx')

    df['Date Updated_1']=df['Date Updated'].astype(str)
    # print(df['Date Updated'])

    ## Splitting
    
    time1 = datetime.datetime.now()
    df['Date']=df['Date Updated_1'].map(lambda ts: str(ts).split(' ')[0])
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to split a column for "+str(len(df))+" records is "+str(elapsedTime.total_seconds())+" seconds")

    df['Date']=pd.to_datetime(df['Date'], format='%Y-%m-%d')
    # print(df.columns)
    # print(df.head(5))
    # print(df.dtypes)

    ## Ranking

    time1 = datetime.datetime.now()
    df["Date_Rank"]=df.groupby('Date')['Date Updated'].rank(method='dense').astype(int)
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to Rank "+str(len(df))+" records is "+str(elapsedTime.total_seconds())+" seconds")
    time1 = datetime.datetime.now()
    df=df.loc[df['Date_Rank']==1]
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to Filter "+str(len(df))+" records is "+str(elapsedTime.total_seconds())+" seconds")
    df=df.append(df[0:10])
    df=Remove_Dup(df)

    time1 = datetime.datetime.now()
    df = pd.merge(df, df_state_abb, how='left', left_on='USA State', right_on='State')
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to Join "+str(len(df))+" records and "+str(len(df_state_abb))+" is "+str(elapsedTime.total_seconds())+" seconds")

    df=df[['USA State','Total Cases','New Cases','Total Deaths','New Deaths','Active Cases','Tot Cases/ 1M pop','Deaths/ 1M pop','Total Tests','Tests/  1M pop','Date Updated','Date','Abbreviation','Source File']]

    moving_avg_days=7
    time1 = datetime.datetime.now()
    df["New Cases MA"] = df.groupby('USA State')['New Cases'].transform(lambda x: x.rolling(moving_avg_days, moving_avg_days).mean())
    df["New Cases MA Shift 7"] =df.groupby('USA State')['New Cases MA'].shift(7)
    df["New Cases MA Pct change"] = (df["New Cases MA"] - df["New Cases MA Shift 7"])/df["New Cases MA Shift 7"]*100
    time2 = datetime.datetime.now()
    elapsedTime = time2 - time1    
    # print("Time taken to calculate week over week percent change for "+str(len(df))+" records is "+str(elapsedTime.total_seconds())+" seconds")

    # df['Date shift 7']=df.groupby('USA State')['Date'].shift(7)
    df['Date Minus 7']=df['Date'].map(lambda ts: ts - relativedelta(days=7))

    df=df.dropna(subset=['New Cases MA Pct change'])
    df=df.loc[(df['New Cases MA Pct change'] is not  None) and (df['New Cases MA Pct change'] != np.inf)]
    df['output_rank']=df.groupby('Date')['New Cases MA Pct change'].rank(ascending=False,method='dense').astype(int)
    df=df.loc[df['output_rank'] <=5]
    df=df.drop(['output_rank'], axis = 1)


    # print(df['Date'].unique())
    # print(df['Date shift 7'].unique())
    # print(df['Date Minus 7'].unique())

    # print(df.columns)
    # print(df.dtypes)

    return df


