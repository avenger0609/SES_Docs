## worked ###
from selenium.webdriver.common.keys import Keys 
from selenium import webdriver
import time
import pandas as pd
import xlsxwriter
from selenium.common.exceptions import NoSuchElementException
import calendar
from datetime import datetime
from dateutil.relativedelta import relativedelta

data=[]

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
# chromeOptions.add_experimental_option('useAutomationExtension', False)
download_dir='c:\\users\\asrilekh\\documents'
preferences = {"download.default_directory": download_dir ,
                      "directory_upgrade": True,
                      "safebrowsing.enabled": True,
                      "useAutomationExtension":True }
chromeOptions.add_experimental_option("prefs", preferences)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
driver.get("https://uhg.apptio.com/#TBMStudio:dev:uhg.com:Cost+Transparency")
## to check if page is loaded
c=0
while True:
    try:
        elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
        # elem.click()
        break
    except NoSuchElementException:  
        c=c+1
        if c==10:
            print("checked for 10 times")
            break
        time.sleep(90)
## to check if page is loaded
# driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div/div[3]/div[4]/div[2]').click()
# time.sleep(5)
# tbl_id=driver.find_element_by_xpath('/html/body/div[7]/div/div/div/div[1]/div/div/div[1]/div[2]/div')
# rows=tbl_id.find_elements_by_tag_name('div')
last_month = datetime.now() - relativedelta(months=1)
text = format(last_month, '%m %B %Y')
previous_month = str(text).split(' ')[0]
fmon = datetime.now() - relativedelta(months=2)
fmon_f = format(fmon, '%B %Y')
fmon_name = str(fmon_f).split(' ')[0]+"_"+str(fmon_f).split(' ')[1]
# if previous_month==12:
#     for i in range(0,len(rows)-1):
#         rows[i].click()
#         time.sleep(10)
# else:
#     for i in range(0,len(rows)):
#         rows[i].click()
#         time.sleep(10)


# # driver.find_element_by_xpath('/html/body/div[7]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[1]').click()
# # driver.find_element_by_xpath('/html/body/div[12]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[2]').click() ## need to change yearly
# # /html/body/div[12]/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[2]
# time.sleep(15)
# if previous_month==1:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[1]/div/div/div[2]').click()
# elif previous_month==2:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[2]/div/div/div[2]').click()
# elif previous_month==3:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[3]/div/div/div[2]').click()
# elif previous_month==4:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[5]/div/div/div[2]').click()
# elif previous_month==5:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[6]/div/div/div[2]').click()
# elif previous_month==6:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[7]/div/div/div[2]').click()
# elif previous_month==7:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[9]/div/div/div[2]').click()
# elif previous_month==8:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[10]/div/div/div[2]').click()
# elif previous_month==9:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[11]/div/div/div[2]').click()
# elif previous_month==10:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[13]/div/div/div[2]').click()
# elif previous_month==11:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[14]/div/div/div[2]').click()
# elif previous_month==12:
#     driver.find_element_by_xpath('//*[@id="grid"]/div/div[2]/div[15]/div/div/div[2]').click()

def no_of_line_items(tbl_name): 

    time.sleep(10)
    try:
        
        c=0
        while True:
            try:
                elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
                elem.clear()
                elem.send_keys(tbl_name)
                time.sleep(20)
                elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
                elem.click()
                time.sleep(10)
                break
            except  NoSuchElementException:  
                c=c+1
                if c==10:
                    print("checked for 10 times"+tbl_name+" tab load")
                    break
                time.sleep(90)
        
        time.sleep(10)        
        rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
        rows_len=len(rows)
        if rows[rows_len-1].get_attribute('title')==tbl_name:

            rows[rows_len-1].click()
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]   
            c=0
            while len(elements)==0:
                time.sleep(90)
                c=c+1
                if c==10:
                    print("checked for 10 times for"+tbl_name+" data")
                    break
                try:
                    elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
                except:
                    elements=[]
            if len(elements) > 0:
                ele=driver.find_element_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[2]/span[7]')
                s=str(ele.get_attribute('innerHTML'))
                s1=s.split('of')
                s1=s1[-1].strip(' ')
                print(s1)
                data.append(str(s1))
                
        driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()

        
    except Exception as e:
        print("Exception took place in"+ tbl_name +str(e) )
        data.append("error")
        driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()

def parameter_count_r_sum(tbl_name,cnt_r_sum_element_xpath):
    
    time.sleep(10)
    try:
    
        c=0
        while True:
            try:
                elem = driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[2]/div/div[3]/div/div[2]/input')
                elem.clear()
                elem.send_keys(tbl_name)
                time.sleep(20)
                elem= driver.find_element_by_xpath('//*[@id="studio-workspace-contents"]/div[3]/div/div[2]/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[1]/div[2]/div[2]')
                elem.click()
                time.sleep(10)
                break
            except  NoSuchElementException:  
                c=c+1
                if c==10:
                    print("checked for 10 times"+tbl_name+" tab load")
                    break
                time.sleep(90)
        time.sleep(10)        
        rows=driver.find_elements_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div[1]/div/div/div[1]')
        rows_len=len(rows)
        if rows[rows_len-1].get_attribute('title')==tbl_name:

            rows[rows_len-1].click()
            try:
                elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
            except:
                elements=[]   
            c=0
            while len(elements)==0:
                time.sleep(90)
                c=c+1
                if c==10:
                    print("checked for 10 times"+tbl_name+" data")
                    break
                try:
                    elements=driver.find_elements_by_xpath('//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[1]/div[1]/div[3]/div')
                except:
                    elements=[]
            if len(elements) > 0:
                ele=driver.find_element_by_xpath(cnt_r_sum_element_xpath)
                s=str(ele.get_attribute('innerHTML'))
                print(s)
                data.append(str(s))
                
        driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
    except Exception as e:
        print(" Exception in "+tbl_name+str(e))
        data.append("error")
        driver.find_element_by_xpath('/html/body/div[3]/div/div[3]/div/div[5]/div/div[6]/div/div[2]/div/div/div/div/div[2]').click()
time.sleep(120)     
df = pd.read_excel('C:\\Users\\asrilekh\\Desktop\\work\\Audit Report\\Audit_Report_'+fmon_name+'_trunk.xlsx')   
mon_name=str(str(text).split(' ')[1])+"_"+str(str(text).split(' ')[2])
try:

    df = pd.read_excel('C:\\Users\\asrilekh\\Desktop\\work\\Audit Report\\Audit_Report_'+fmon_name+'_trunk.xlsx')   
    print(len(df)) 
    for i in range(0,len(df)):
        
        prev_len=len(data)
        if str(df.iloc[i,3]).strip(' ')=="No of line items" or str(df.iloc[i,2]) in ["SRC ACT ASK Application List","SRC ACT Midrange Configured MIPS","SRC ACT Personal Computers","SRC ACT Middleware Instances","SRC ACT Mainframe Middleware","SRC ACT Database","SRC ACT Fixed Assets","SRC SMPL ACT Labor Headcount Data","SRC ACT Headcount Plan Taleo","SRC ACT Headcount Plan Fieldglass","SRC SMPL AP Details","SRC eGRC Vendor Details","SRC ACT Server Master","SRC ACT Service Desk Tickets","SRC ACT Bus Seg Headcount","SRC ACT Server App","SRC ACT MPWR Service Volumes"]:
            no_of_line_items(str(df.iloc[i,2]).strip(' '))
        elif str(df.iloc[i,2])=="SRC ACT User Counts":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
        elif str(df.iloc[i,2])=="SRC ACT Desk Phones":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[2]/div')
        elif str(df.iloc[i,2])=="SRC ACT Mainframe Configured MIPS":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[2]/div')
        elif str(df.iloc[i,2])=="SRC ACT Email":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[5]/div')
        elif str(df.iloc[i,2])=="SRC ACT Project Capex":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
        elif str(df.iloc[i,2])=="SRC ACT Time Tracking Suspend":
            data.append("no data")
        elif str(df.iloc[i,2])=="SRC ACT Time Tracking 01540":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
        elif str(df.iloc[i,2])=="SRC ACT Time Tracking 01530":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
        elif str(df.iloc[i,2])=="SRC ACT Time Tracking 01510":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
        elif str(df.iloc[i,2])=="SRC ACT Time Tracking 01508 PE":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
        elif str(df.iloc[i,2])=="SRC ACT Time Tracking 01508 DS":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
        elif str(df.iloc[i,2])=="SRC ACT Mainframe Storage On-Off":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[3]/div')
        elif str(df.iloc[i,2])=="SRC ACT Forecast Project CapEx":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
        elif str(df.iloc[i,2])=="SRC ACT NAS":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[5]/div')
        elif str(df.iloc[i,2])=="SRC ACT Storage":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[7]/div')
        elif str(df.iloc[i,2])=="SRC ACT Mainframe Database":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div[1]/div/div/div[5]/table/tbody/tr[2]/td[6]/div')
        elif str(df.iloc[i,2])=="SRC ACT Data Center":
            parameter_count_r_sum(str(df.iloc[i,2]).strip(' '),'//*[@id="studioDoc"]/div[3]/div/div[2]/div/div[3]/div/div[2]/div[2]/div/div[3]/div/div/div/div/div/div[5]/table/tbody/tr[2]/td[4]/div')
        else:
            print(' if condition not matched')
        after_len=len(data)
        if prev_len==after_len:
            data.append("no data")
    mon_name=str(str(text).split(' ')[1])+"_"+str(str(text).split(' ')[2])
    print(len(data))
    print(len(df))
    df[mon_name] = data
    df.to_excel('C:\\Users\\asrilekh\\Desktop\\work\\Audit Report\\Audit_Report_'+str(mon_name)+'_trunk.xlsx',index=False)
    
except Exception as e:
    print(str(e))
    df.to_excel('C:\\Users\\asrilekh\\Desktop\\work\\Audit Report\\Audit_Report_'+str(mon_name)+'_trunk.xlsx',index=False)

    