import win32com.client
import win32com
import os
import sys
from turbodbc import connect
from pandas import DataFrame
import xlsxwriter
from datetime import datetime
import win32com.client as win32
from dateutil.relativedelta import relativedelta
import pandas as pd

def send_email(fname):
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)

    ## actual mail ids ##
    # mail.To = 'ITCB-1_DL@ds.uhc.com'
    # mail.CC= 'itcb@uhc.com;suman_mondal@optum.com;steve_w_johnson@optum.com'
    # mail.BCC= 'srilekha.anumula@optum.com'
    ## actual mail ids ##

    ## test email ids ##        
    mail.To='srilekha.anumula@optum.com'
    ## test email ids ##
    
    mail.Subject = 'ASK Decomission Application ID Status'      
   
    mail.HTMLBody='<p>Hi Everyone,</p><p>Please find attached status of application ids requesting decom'+"<p>Thanks.</p>"

    # To attach a file to the email (optional):
    attachment  = fname
    mail.Attachments.Add(attachment)
    mail.Send()

def app_id_decom_check(app_id_1):
  
    connection = connect(dsn='TRMDB')
    cursor = connection.cursor()
    ### write code to check accounting year here##
    text=""
    try:
        last_month = datetime.now() - relativedelta(months=0)
        text = format(last_month, '%y%m')
        print("current month and year is "+text)
    except Exception as e:
        print("error: while retrieving current month and year "+str(e))
    cur_mon_yr=text
    try:
        last_month = datetime.now() - relativedelta(months=1)
        text = format(last_month, '%y%m')
        print("previous month and year is "+text)
    except Exception as e:
        print("error: while retrieving previous month and year "+str(e))
    prev_mon_yr=text
    acctng_yr=""
    if int(str(datetime.now().day)) > 25:
        acctng_yr=str(cur_mon_yr)
    else:
        acctng_yr=str(prev_mon_yr)
    ### write code to check accounting year here##
    stmt="SELECT * FROM dbo.uv_cb_vetting WHERE globalapplicationid in (\'"+app_id_1.strip(' ')+"\')  and accountingyearmonth=\'"+acctng_yr+"\'"
    cursor.executemany(stmt)
    cur_df=DataFrame(cursor.fetchall()) 
    if len(cur_df) > 0:   
        cur_df.columns=['RowID','AccountingYearMonth','VolumeYearMonth','DateOfChargeback','DivisionID','ServiceGroup','ServiceGroupCostCenter','ServiceCodeName','ServiceCode','BillCodeName','BillingCode','BillCodeStatus','ServiceUniqueIdentifier','SUIdescription','ServicePhysical','ServiceVirtual','InternalComment','AppName','TMDB_SearchCode','Published','ProjectNumber','Project_Name','Project_Manager','ServiceRequestNumber','ServiceDeliveryDate','CustomerAcceptance','BusinessSegmentName','GL_BU','GL_OU','GL_LOC','GL_ACCT','GL_DEPT','ConsumingServiceGroup','GL_PROD','GL_CUST','GL_PID','UnadjustedUnits','AdjustedUnits','UnadjustedStorage','AdjustedStorage','AdjSanOrAdjStorage','San_Cost','BaseService_Cost','ProdNonProd','EnvironmentCode','DataCenterCode','DRMates','DRCode','NetworkZone','ChangeReason','Requestor','Description','RequestorEmail','CreateDate','RequestType','ParentRequestID','ParentRequestor','ParentRequestorEmail','ParentDescription','ParentCreateDate','ParentRequestType','ProjectName','ProjectRequestor','ProjectManager','Prompt_ID','BusinessApplicationName','GL_CodeOwner','LongApplicationName','Global Application Id','ComputeUnitPctCPU','ComputeUnitPctRAM','CPUAllocated','CPUAverageUtilPct','CPUPeakUtilPct','RAMAllocated','RAMAverageUtilPct','RAMPeakUtilPct','PctUptime','FileName','FileKey','RecordID','TransactionCycleKey','FileOutput','OutputYesNo','RateTypeID','UnitRate','UnitCost','AdjUnitCost','AdjUnitCost_presplit','StorageRate','StorageCost','AdjStorageCost','AdjStorageCost_presplit','Rate Type','GL Source','App Source','Project Source','Cap','Floor','Multiplier','RecordID_presplit','GL_PRAC','CBUniqueKey']
        print(type(cur_df))
        dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')    
        cur_df.to_excel("AppIdDecomm_"+app_id_1+"_"+dt+".xlsx",sheet_name=app_id,index=False)
        return len(cur_df)
    return len(cur_df)    
    
def merge_outputs(req_fname_lst_1):
    print(os.getcwd())
    excel = win32.gencache.EnsureDispatch('Excel.Application')
    # excel = win32.Dispatch('Excel.Application')
    wb = excel.Workbooks.Add()
    
    filenames=list()
    filenames=req_fname_lst_1
    print(len(filenames))
    j=1
    for f in filenames:
        
        xl = pd.ExcelFile(f)
        res = len(xl.sheet_names)
        print(str(res))
        w = excel.Workbooks.Open(os.getcwd()+"\\"+f)

        for i in range(0,(res)):
            w.Sheets(i+1).Copy(wb.Sheets(j+i))
        j=j+i+1
    dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
    output_rept_name=os.getcwd()+"\\ASK_Decom_report_"+dt+".xlsx"
    wb.SaveAs(output_rept_name)    
    excel.Application.Quit()
    send_email(output_rept_name)

outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
folder = outlook.Folders("ITCB - IT Consumption and Billing")
inbox = folder.Folders("04. Ask")
msg = inbox.Items
dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
foldername="ASKDECOM_"+str(dt)
try:
    os.makedirs('C:\\Users\\asrilekh\\Desktop\\work\\ASK Automation\\'+foldername)
except:
    junk=1
os.chdir('C:\\Users\\asrilekh\\Desktop\\work\\ASK Automation\\'+foldername)
# msgs = msg.GetLast()
# print(msgs)
############
try:
    last_month = datetime.now() - relativedelta(months=0)
    text = format(last_month, '%y%m')
    print("current month and year is "+text)
except Exception as e:
    print("error: while retrieving current month and year "+str(e))
cur_mon_yr_1=text
try:
    last_month = datetime.now() - relativedelta(months=1)
    text = format(last_month, '%y%m')
    print("previous month and year is "+text)
except Exception as e:
    print("error: while retrieving previous month and year "+str(e))
prev_mon_yr_1=text
acctng_yr_1=""
if int(str(datetime.now().day)) > 25:
    acctng_yr_1=str(cur_mon_yr_1)
else:
    acctng_yr_1=str(prev_mon_yr_1)
############
app_id_lst=[]
app_id_lst_res=[]
app_id_req_date=[]
app_id_is_infra_lst=[]
for msg1 in msg:
    if msg1.UnRead==True:
        if "Action Required - Application Decommission Request" in msg1.Subject:
            print(msg1.Subject)
            date1 = msg1.SentOn.strftime("%d-%m-%y")
            app_id_req_date.append(str(date1))
            body_content = msg1.body
            # print(body_content)
            bc1=(str(body_content).index("A request has been submitted to decommission"))+len("A request has been submitted to decommission")
            bc2=str(body_content).index("in ASK.",bc1)
            bc_ss=""
            for i in range(bc1,bc2):
                bc_ss=bc_ss+str(body_content)[i]
            bc_ss=bc_ss.strip(' ')
            app_id=bc_ss.split(' ')[len(bc_ss.split(' '))-1]
            app_id_lst.append(app_id.strip(' '))
            print(app_id)
            check_cnt=app_id_decom_check(app_id.strip(' '))
            if check_cnt > 0:
                app_id_lst_res.append("Declined")
                app_id_is_infra_lst.append("Yes")
            elif check_cnt==0:
                app_id_lst_res.append("Approved")
                app_id_is_infra_lst.append("No")
print(str(app_id_lst)+" app id list")
print(str(app_id_lst_res)+" app id list res")
app_id_res_cons=[]
sno=0
s1=str("sno")+"!"+"Request Date"+"!"+"ASK Id"+"!"+"Charge Back Month"+"!"+"Is Infra Attached ?"+"!"+"Suggestion"
app_id_res_cons.append(s1)
for app_i in range(0,len(app_id_lst)):
    s1=str(sno+1)+"!"+app_id_req_date[app_i]+"!"+app_id_lst[app_i]+"!"+acctng_yr_1+"!"+app_id_is_infra_lst[app_i]+"!"+app_id_lst_res[app_i]
    # app_id_res_cons.append(app_id_lst[app_i]+"!"+app_id_lst_res[app_i])
    sno=sno+1
    app_id_res_cons.append(s1)


dt=str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.','')
merged_x = "AppIdDecomm_"+"Final"+"_"+dt+".xlsx"
merged_x_wb = xlsxwriter.Workbook(merged_x)
merged_sheet = merged_x_wb.add_worksheet("Result")
x=app_id_res_cons
for deli in range(0, len(x)):
    del_str = x[deli].split('!')
    for delsi in range(0, len(del_str)):
        merged_sheet.write(deli, delsi, del_str[delsi])
merged_x_wb.close()


req_fname_lst=[]

for entry in os.scandir(os.getcwd()):
    if entry.is_file():
        if str(entry.name).startswith('AppIdDecomm'):
            en=str(entry.name)
            en_arr=en.split('_')
            print(str(en_arr))
            dt_now=(str(datetime.now()).replace(' ','').replace(':','').replace('-','').replace('.',''))[0:8]
            print(str(dt_now))            
            dt_gen=str(en_arr[2])[0:8]
            print(str(dt_gen))
            if en_arr[0]=='AppIdDecomm' and (en_arr[1] in app_id_lst or en_arr[1]=="Final")and dt_now==dt_gen:
                req_fname_lst.append(en)

merge_outputs(req_fname_lst) 




    