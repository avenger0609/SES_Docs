import pandas as pd
from datetime import datetime as dt
from collections import Counter
DateString = dt.now().strftime("%Y%m%d-%I%M%S%p")
Parent_Path='C:\\Users\\asrilekh\\Desktop\\'
###### Step 1 Local Data Preparation. Pick the columns "Search Term" and "Search Frequency Rank" from Amazon Search Report and find most common keyword ######
df_input = pd.read_csv(Parent_Path+r'AmazonSearchTerm\AmazonSearchTermMay21.csv", encoding ='ISO-8859-1')
print("Starting to Read Amazon Search Term file")
df_input_step1 = df_input[['Search Term','Search Frequency Rank']]
df_input_step0 = df_input_step1[['Search Term']]
df_input_step0.rename(columns = {'Search Term':'Search_Term'}, inplace = True)
print("Count of Rows in Amazon Search Term file: ", len(df_input_step1))
df_input_step0['Search_Term']=df_input_step0['Search_Term'].astype(str)
print(df_input_step1.dtypes)
print(df_input_step0.dtypes)
words = ''
for i in df_input_step0.Search_Term.values:
    words += '{} '.format(i.lower())

# Create a pandas dataframe with the word and its frequency
df_input_step0 = pd.DataFrame(Counter(words.split()).most_common(200), columns=['SearchTerm', 'Frequency'])
df_input_step0.to_csv(Parent_Path+r'AmazonSearchTerm\Step0_SearchTermKeywordsCloud"+DateString+".csv", index=False)

###### Step 2 Remove Bad Search Terms ######
df_exclusion_list = pd.read_csv(Parent_Path+r'AmazonSearchTerm\Exclusing_List.csv")
print("Starting to Read Exclusing list file")
print("Exclusing list word count: ", len(df_exclusion_list))
df_input_step2 = df_input_step1[df_input_step1['Search Term'].str.contains('|'.join(df_exclusion_list['Exclusion_List']),case=False)==False]
print("Count of Exlusing words: ",len(df_input_step2))
df_input_step2.to_csv(Parent_Path+r'AmazonSearchTerm\Step2_RemoveBadTerms"+DateString+".csv", index=False)

###### Step 3 Remove Last Batch Search Terms which has HIGH Competition ######
try:
    df_HighCompetition = pd.read_csv(Parent_Path+r'AmazonSearchTerm\Python_SearchTerm_Output20210604093119.csv")
    print("Starting to Read High Competition list file")
    df_HighCompetition=df_HighCompetition[(df_HighCompetition["Number Of Products"] != "Number Of Products")]
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("results for","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("result for","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("1-48 of ","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("1-16 of ","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("over","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("Number Of Products","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace(",","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("1-24 of ","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace(" ","")
    print("High Competion file read successful and also replaced unwanted words")

    df_HighCompetition["Number Of Products"] = pd.to_numeric(df_HighCompetition["Number Of Products"], errors='coerce')
    print("After coerce")
    print(df_HighCompetition.dtypes)
    df_LowCompetition = df_HighCompetition
    df_HighCompetition = df_HighCompetition[df_HighCompetition['Number Of Products'] > 500]
    print(df_HighCompetition.dtypes)
    print("After > 500")
    df_LowCompetition = df_LowCompetition[df_LowCompetition['Number Of Products'] < 500]
    print("After < 500")
    print("Sarting: Writing the High/ Low Competition files")
    df_HighCompetition.to_csv(Parent_Path+r'AmazonSearchTerm\Output_HighCompetition_"+DateString+".csv", index=False)
    #df_LowCompetition.to_csv(Parent_Path+r'AmazonSearchTerm\Output_LowCompetition_"+DateString+".csv", index=False)
    df_input_step2 = df_input_step2.reset_index(drop=True)
    print("After resetting index from Step2")

    df_input_step3 = df_input_step2[df_input_step2['Search Term'].str.contains('|'.join(df_HighCompetition['Keywords']),case=False)==False]
    print("After doing join")
    df_input_step3.to_csv(Parent_Path+r'AmazonSearchTerm\Step3_RemoveHighCompetition"+DateString+".csv", index=False)
    print("Successful: Writing the High/ Low Competition files")
except Exception as E :
    print(str(E))
    print("Stet 3: Except Block. High Competition file is not available")
    df_input_step3 = df_input_step2
    df_input_step3.to_csv(Parent_Path+r'AmazonSearchTerm\Step3_RemoveHighCompetition"+DateString+".csv", index=False)

###### Step 4 Lookup for Category keywords ######
try:
    print("Starting to read file")
    df_CategoryKeywords = pd.read_csv(Parent_Path+r'AmazonSearchTerm\Category_Keywords.csv")
    print("Reading file successful")
    print("Started reading Category Keyword file, count of rows in Category Keyword are: ",len(df_CategoryKeywords))
    df_input_step4 = df_input_step3[df_input_step3['Search Term'].str.contains('|'.join(df_CategoryKeywords['Category_Keywords']),case=False)==True]
    print("Number of Rows after doing vlookup with Category Keywords are: ",len(df_input_step4))
    df_input_step4.to_csv(Parent_Path+r'AmazonSearchTerm\Step4_Input_forPythonScript"+DateString+".csv", index=False)
except:
    print("Step 4: Except Block. Category Keyword doesnt exist")
    df_input_step4 = df_input_step3
    df_input_step4.to_csv(Parent_Path+r'AmazonSearchTerm\Step4_Input_forPythonScript"+DateString+".csv", index=False)
# ###### Step 5 Remove 1 letter Search Terms ######
# print("Starting to count number of letters")
# #number_of_words = df_input_step3["Search Term"].map(lambda x: len(x))
# number_of_words = df_input_step3["Search Term"].str.count(' ').add(1).value_counts(sort=False)
# df_input_step3["number_of_words"] = number_of_words
# df_input_step4 = df_input_step3
# print(df_input_step4.head())
# df_input_step3.to_csv(Parent_Path+r'AmazonSearchTerm\Input_forPythonScript"+DateString+".csv", index=False)
