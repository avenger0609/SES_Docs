from flask import Flask
from flask import render_template,jsonify,request
import requests
from models import *
from pblm_solving_files.knowledge_rev import *
import random
import urllib3



app = Flask(__name__)
app.secret_key = '12345'

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route("/parse", methods=['GET', 'POST', 'OPTIONS'])
def parse():
        # print((request.url))
        parsed=(urllib3.util.url.parse_url(request.url))
        # print(parsed.query)
        s1=str(str(parsed.query).split('=')[1].replace('+',' ').replace('%2C',' ').replace('%3F',' '))        
        while True:
            a=s1.find("%")
            if a > -1:
                ss=s1[a]+s1[a+1]+s1[a+2]
                s1=s1.replace(ss," ")
            else:
                break
        s1=s1.replace('  ',' ').replace('  ',' ').strip(' ').lower()
        print(s1)
        return jsonify({"intent":s1})
        # s1=urllib3.util.url.parse_url.parse_qs(parsed.query)
        # print("result="+str((s1)))
        


app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(port=8080)
