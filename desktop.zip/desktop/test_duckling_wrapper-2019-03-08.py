import pytest
from datetime import time, date, timedelta, datetime
from dateutil import parser
from dateutil.tz import tzlocal
from duckling import DucklingWrapper, Dim
from autocorrect import spell
import calendar

def corrected_ip_string(s1):
    s1=s1.replace('  ',' ').replace('  ',' ')
    s2=s1.split(' ')
    s3=""
    for i in range(0,len(s2)):
        
        if spell(s2[i]).upper() in ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER','MONTH','YEAR','QUARTER','FIRST','SECOND','THIRD','FOURTH','FIFTH','SIXTH','SEVENTH','EIGHTH','NINTH','TENTH','ELEVENTH','ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','TEN','ELEVEN','MONTHS','YEARS','QUARTERS']:
            s3=s3+" "+spell(s2[i]).lower()+" "
        elif spell(s2[i]).upper() in ['TWELFTH','TWELEVE']:
            s3=s3+" twelfth "
        else:
            s3=s3+" "+s2[i].lower()+" "
    s4=s3.replace('since','last').replace('  ',' ').strip(' ')
    s2=s4.split(' ')
    rev_s=""
    # print(s2)
    for i in range(0,len(s2)):
        # s3=i.split()
        n=""
        for j in range(0,len(s2[i])):
                # print(j)
                try:
                    n1=int(s2[i][j])
                    n=n+str(n1)
                except:
                    w=1
        if len(str(n)) > 0 and int(str(n)) > 0 and int(str(n)) < 12:
            if s2[i+1].lower()=='month':
                mn=calendar.month_name[int(str(n))]
                rev_s=rev_s+" "+mn+" "
            else:
                rev_s=rev_s+" "+s2[i].lower()+" "
        else:
            # print(s2[i])
            if s2[i].lower()=='first' and s2[i+1].lower()=='month':
                # print("entered first")
                rev_s=rev_s+" "+calendar.month_name[1]+" "
            elif s2[i].lower()=='second' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[2]+" "
            elif s2[i].lower()=='third' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[3]+" "
            elif s2[i].lower()=='fourth' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[4]+" "
            elif s2[i].lower()=='fifth' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[5]+" "
            elif s2[i].lower()=='sixth' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[6]+" "
            elif s2[i].lower()=='seventh' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[7]+" "
            elif s2[i].lower()=='eighth' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[8]+" "
            elif s2[i].lower()=='ninth' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[9]+" "
            elif s2[i].lower()=='tenth' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[10]+" "
            elif s2[i].lower()=='eleventh' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[11]+" "
            elif s2[i].lower()=='twelfth' and s2[i+1].lower()=='month':
                rev_s=rev_s+" "+calendar.month_name[12]+" "
            else:
                rev_s=rev_s+" "+s2[i].lower()+" "
    return str(rev_s.replace('  ',' ').strip(' '))


def time_extract(ip_str):
    
    op_str=corrected_ip_string(ip_str)    
    result = DucklingWrapper().parse_time(u''+op_str)
    if len(result)==1:
        print(str(result[0]['value']['value']))        
        if str(type(result[0]['value']['value']))=="<class 'dict'>":
            from_dt=str(result[0]['value']['value']['from']).split('T')[0]
            to_dt=str(result[0]['value']['value']['to']).split('T')[0]
            rng_lst=list()
            rng_lst.append(from_dt)
            rng_lst.append(to_dt)
            return rng_lst
        else:
            day_lst=list()
            mon_lst=list()
            yr_lst=list()
            if str(result[0]['value']['grain']).lower()=='day':
                dt=str(result[0]['value']['value']).split('T')[0]
                if int(dt.split('-')[0]) > int(str(datetime.now().year)):                    
                    dt=dt.replace(str(int(dt.split('-')[0])),str(int(str(datetime.now().year))))
                print(dt)
                day_lst.append(dt.split('-')[2])
                mon_lst.append(dt.split('-')[1])
                yr_lst.append(dt.split('-')[0])
            elif str(result[0]['value']['grain']).lower()=='month':
                dt=str(result[0]['value']['value']).split('T')[0]
                if int(dt.split('-')[0]) > int(str(datetime.now().year)):                    
                    dt=dt.replace(str(int(dt.split('-')[0])),str(int(str(datetime.now().year))))
                print(dt)
                mon_lst.append(dt.split('-')[1])
                yr_lst.append(dt.split('-')[0])
            elif str(result[0]['value']['grain']).lower()=='year':
                dt=str(result[0]['value']['value']).split('T')[0]
                if int(dt.split('-')[0]) > int(str(datetime.now().year)):                    
                    dt=dt.replace(str(int(dt.split('-')[0])),str(int(str(datetime.now().year))))
                print(dt)                
                yr_lst.append(dt.split('-')[0])
            comb_list=list()
            comb_list.append(day_lst)
            comb_list.append(mon_lst)
            comb_list.append(yr_lst)
            return comb_list
    else:

        day_lst=list()
        mon_lst=list()
        yr_lst=list()

        for r_i in range(0,len(result)):
            
            if str(result[r_i]['value']['grain']).lower()=='day':
                dt=str(result[r_i]['value']['value']).split('T')[0]
                if int(dt.split('-')[0]) > int(str(datetime.now().year)):
                    
                    dt=dt.replace(str(int(dt.split('-')[0])),str(int(str(datetime.now().year))))
                print(dt)
                day_lst.append(dt.split('-')[2])
                    # mon_lst.append(dt.split('-')[1])
                    # yr_lst.append(dt.split('-')[0])
            elif str(result[r_i]['value']['grain']).lower()=='month':
                dt=str(result[r_i]['value']['value']).split('T')[0]
                if int(dt.split('-')[0]) > int(str(datetime.now().year)):
                    
                    dt=dt.replace(str(int(dt.split('-')[0])),str(int(str(datetime.now().year))))
                print(dt)
                mon_lst.append(dt.split('-')[1])
                    # yr_lst.append(dt.split('-')[0])
            elif str(result[r_i]['value']['grain']).lower()=='year':
                dt=str(result[r_i]['value']['value']).split('T')[0]
                if int(dt.split('-')[0]) > int(str(datetime.now().year)):
                    
                    dt=dt.replace(str(int(dt.split('-')[0])),str(int(str(datetime.now().year))))
                print(dt)                
                yr_lst.append(dt.split('-')[0])
            comb_list=list()
            comb_list.append(day_lst)
            comb_list.append(mon_lst)
            comb_list.append(yr_lst)
            return comb_list          
            
            

def test():
    result = DucklingWrapper().parse_time(u'received claims')
    print(result)
    # print(str(type(result[0]['value']['value'])))
    result = DucklingWrapper().parse_time(u'received claims on Jan,28')
    print(str(type(result[0]['value']['value'])))

    
test() 
# print(str(time_extract("received claims in yesterday")))

# result = DucklingWrapper().parse_time(u'received claims on Jan,28')
# print(str(result))

# result = DucklingWrapper().parse_time(u'received claims on Jan 28')
# print(str(result))

# result = DucklingWrapper().parse_time(u'received claims on January 28')
# print(str(result))

# result = DucklingWrapper().parse_time(u'received claims on January 28')
# print(str(result))