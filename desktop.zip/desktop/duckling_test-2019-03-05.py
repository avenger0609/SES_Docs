import duckling

s1=duckling.Duckling.parse("give me date after 2 days","give me date after 2 days")
print(str(s1))
